# 概述
    统计每天每种设备损坏量

# 执行时间
    每天凌晨一点

# 依赖
  - 开发组
    每天凌晨00:35使用Spark程序com.gnow.transplant.DeviceBreakdownTransplant从MySQL(10.0.35.6:3306)库oa_storage的表repair_out_order拉取数据到hdfs
  - 数据
    - input
        hdfs目录：/rdb/oa/repair_out_order
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表DEVICE_BREAKDOWN

# 数据格式
    建表语句
    CREATE TABLE `repair_out_order` (
      `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '流水号',
      `dtype_id` int(11) NOT NULL DEFAULT '0' COMMENT '设备类型id',
      `dtype_name` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '设备名称',
      `from_storage_id` int(11) NOT NULL DEFAULT '0' COMMENT '出仓id',
      `to_storage_id` int(11) NOT NULL DEFAULT '0' COMMENT '入仓id',
      `device_num` int(11) NOT NULL DEFAULT '0' COMMENT '设备数量',
      `device_codes` text COLLATE utf8_bin COMMENT '设备编号',
      `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0返厂维修 1返库维修 ',
      `repair_order_id` int(11) NOT NULL DEFAULT '0' COMMENT '维修单id',
      `express_company` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '快递公司',
      `express_code` varchar(200) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '快递号',
      `operator_id` int(11) NOT NULL DEFAULT '0' COMMENT '操作者id',
      `operator_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '操作者名字',
      `remark` varchar(200) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '备注',
      `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=4195 DEFAULT CHARSET=utf8 COLLATE=utf8_bin


# 计算逻辑
    用dtype_id做group，对device_num进行sum

# 调试

# FAQ

## 现存问题

## 注意事项

## 常见问题









