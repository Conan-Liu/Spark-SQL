# 概述
    微信用户留存情况统计：
    UserRetention4WechatDaily  统计微信用户的日留存率
    UserRetention4WechatMonthly  统计微信用户的周留存率
    UserRetention4WechatWeekly  统计微信用户的月留存率

# 执行时间
    UserRetention4WechatDaily  每天凌晨两点
    UserRetention4WechatMonthly  每周日凌晨三点
    UserRetention4WechatWeekly 每月一号凌晨四点

# 依赖
  - 开发组
    从ES拉取日志到hdfs
  - 数据
    - input
        hdfs目录：/repository/kafka/basic_wechat_trace
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表USER_RETENTION

# 数据格式
    日志格式
    {
        "phase": -2, //阶段 0：首次使用 1：Login -1：Logout -2：取关 2：除以上外所有
        "msg": "取关",
        "business": "basic",
        "device_id": 0,  //设备ID
        "create_time": 1495850690,  //创建时间 类型:Unix timestamp
        "level": "info",
        "open_id": "oWT18jmg_3_xckyChddR39y1XNIo", //微信用户唯一标识，代表一个微信用户
        "module": "WECHAT",
        "latitude": "",
        "pid": 4743,
        "device_type": 2,  //设备类型 0：未知 1：IOS 2：ANDROID
        "type": "javalog",
        "path": "/var/log/application/basic-20170527.log",
        "@timestamp": "2017-05-27T02:04:50.389Z",
        "datatype": 1,  //部署环境 0：生产 1：测试
        "data_type": 1,
        "@version": "1",
        "host": "cend_wx_service14.mwee.prd",
        "action": "TRACE",
        "verSion": 1,
        "longitude": ""
      }

# 计算逻辑
    日：计算前天新用户数(phase=0)，计算前天的新用户在昨天还有活跃并且没有取关(phase!=0 and phase!=-2)的用户数,计算留存率
    周：计算上上周新用户数(phase=0)，计算上上周的新用户在上周还有活跃并且没有取关(phase!=0 and phase!=-2)的用户数,计算留存率
    月：计算上上月新用户数(phase=0)，计算上上月的新用户在上月还有活跃并且没有取关(phase!=0 and phase!=-2)的用户数,计算留存率

# 调试

#  FAQ

## 现存问题

## 注意事项
    - 表USER_RETENTION中device_type与日志中device_type没有关系，表USER_RETENTION中device_type为12代表ANDROID，
    device_type为11代表IOS,device_type为1代表微信。使用c_type中0，1，2代表日，周，月。
    - 对于月留存率计算，要考虑跨年问题

## 常见问题









