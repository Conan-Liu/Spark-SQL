# 概述
    统计每天提供各项服务的店铺数

# 执行时间
    每天凌晨两点

# 依赖
  - 开发组
    每天从ES拉取日志到hdfs
  - 数据
    - input
        hdfs目录：/repository/kafka/basic_shop_service
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表SHOP_AND_SERVICE

# 数据格式
    日志格式
    {
        "date": "2017-05-27 17:21:39",
        "createtime": " 2017:05:27 17:21:39 ",
        "business": "basic",
        "create_time": 1495876899,
        "level": "info ",
        "module": "SHOP",
        "pid": " 22874 ",
        "type": "seaslog",
        "shop_name": "金时代顺风大酒店(西藏中路六合店)",
        "version": 1,
        "path": "/var/log/seaslog/BASIC/20170527.log",
        "shop_id": "62079",
        "@timestamp": "2017-05-27T09:21:39.747Z",
        "datatype": 1,
        "service": "6",   //1 排队,2 菜单,3 点餐,4 侍者,5 外卖,6 预定,7 埋藏,8 支付,9 扫描打印,10 预点打单,11 菜单查看,12 卡券服务,13 POS收款,14 弹幕 ,15 预约服务,16 快餐
        "@version": "1",
        "host": "biz_www56.mwee.prd",
        "action": "SERVICE",
        "timestamp": " 1495876899.542 ",
        "status": 1                            //服务状态 0:禁用 1:启用
      }


# 计算逻辑
    先对shopid和service进行去重，取最新的；然后使用service和status进行group，对shopid做count

# 调试

# FAQ

## 现存问题

## 注意事项

## 常见问题









