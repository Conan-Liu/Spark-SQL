# 概述
    计算每个店铺每天秒付小猫的保活次数

# 执行时间
    每天凌晨两点

# 依赖
  - 开发组
    从ES拉取日志到hdfs
  - 数据
    - input
        hdfs目录：/repository/kafka/ordering_mobile-api_dcb-online
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表SPAY_ONLINE_SHOP_DAILY

# 数据格式
    日志格式，参考http://wiki.mwbyd.cn/pages/viewpage.action?pageId=6334859
    {
        "datatype": 1,
        "action": "dcb-online",
        "business": "ordering",
        "module": "mobile-api",
        "currentTime": "2017-05-16 14:16:37",
        "shopId": 123192, //商家店铺id
        "type": 0, //0全部(指服务端+客户端)，1点菜宝代理服务端，2点菜宝代理客户端(即小猫)
        "currentState": 2, //1正常，2不在线(指小猫与餐饮系统本地通讯异常)
        "syncTime": "2017-05-16 14:16:38" //小猫上报的保活时间
    }

# 计算逻辑
    根据shopid按照type in(0,2) and currentState='1'的条件做count

# 调试

# FAQ

## 现存问题
    type为0时的日志还是不太清楚具体为什么能代表1和2的全部

## 注意事项

## 常见问题









