# 概述
    APP用户留存情况统计
    UserRetention4AppAndroidDaily  统计安卓用户日留存率
    UserRetention4AppAndroidWeekly  统计安卓用户周留存率
    UserRetention4AppAndroidMonthly  统计安卓用户月留存率
    UserRetention4AppIOSDaily  统计苹果用户日留存率
    UserRetention4AppIOSWeekly  统计苹果用户周留存率
    UserRetention4AppIOSMonthly  统计苹果用户月留存率
    UserRetention4AppDaily  统计APP(包括安卓和苹果)用户日留存率
    UserRetention4AppWeekly  统计APP(包括安卓和苹)用户周留存率
    UserRetention4AppMonthly  统计APP(包括安卓和苹)用户月留存率


# 执行时间
    UserRetention4AppAndroidDaily  每天凌晨两点
    UserRetention4AppAndroidWeekly  每周日凌晨三点
    UserRetention4AppAndroidMonthly  每月一号凌晨四点
    UserRetention4AppIOSDaily  每天凌晨两点
    UserRetention4AppIOSWeekly  每周日凌晨三点
    UserRetention4AppIOSMonthly  每月一号凌晨四点
    UserRetention4AppDaily  每天凌晨两点
    UserRetention4AppWeekly  每周日凌晨三点
    UserRetention4AppMonthly  每月一号凌晨四点

# 依赖
  - 开发组
    从ES拉取日志到hdfs
  - 数据
    - input
        hdfs目录：/repository/kafka/basic_app_trace
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表USER_RETENTION

# 数据格式
    日志格式
    {
        "date": "2017-05-27 10:15:58",
        "phase": 2, //阶段 0：首次使用 1：Login -1：Logout 2：除以上外所有
        "createtime": " 2017:05:27 10:15:58 ",
        "business": "basic",
        "create_time": 1495851358,
        "device_id": "7AA67F934BCF1BC6347841E57F8095F4", //设备ID
        "level": "info ",
        "module": "APP",
        "latitude": "31.31311",
        "mobile": "18662240803", //手机号码
        "pid": " 25011 ",
        "device_type": 2, //设备类型 0：未知 1：IOS 2：ANDROID
        "type": "seaslog",
        "version": 1,
        "path": "/var/log/seaslog/BASIC/20170527.log",
        "@timestamp": "2017-05-27T02:15:59.289Z",
        "datatype": 1, //部署环境 0：生产 1：测试
        "@version": "1",
        "host": "c_api94.mwee.prd",
        "action": "TRACE",
        "timestamp": " 1495851358.770 ",
        "longitude": "120.620626"
      }

# 计算逻辑
    日：计算前天新用户数(phase=0)，计算前天的新用户在昨天还有活跃(phase!=0)的用户数,计算留存率
    周：计算上上周新用户数(phase=0)，计算上上周的新用户在上周还有活跃(phase!=0)的用户数,计算留存率
    月：计算上上月新用户数(phase=0)，计算上上月的新用户在上月还有活跃(phase!=0)的用户数,计算留存率

# 调试

# FAQ

## 现存问题

## 注意事项
    - 表USER_RETENTION中device_type与日志中device_type没有关系，表USER_RETENTION中device_type为12代表ANDROID，
    device_type为11代表IOS,device_type为1代表微信。使用c_type中0，1，2代表日，周，月。
    - 对于月留存率计算，要考虑跨年问题

## 常见问题









