# 概述
    统计排队等待时间相关指标

# 执行时间
    每天凌晨两点

# 依赖
  - 开发组
    每天从ES拉取日志到hdfs
  - 数据
    - input
        hdfs目录：
        QUEUEING_TABLE
        ORACLE_QUEUEING_GOOD_SHOP
        SHOP_CONFIG_TABLE
    - output
        MySQL数据库

# 数据格式
    QUEUEING_WAITING_TIME日志格式
      {
        "date": "2017-06-07 19:20:19",
        "business": "queueing",
        "create_time": 1496834419859,
        "module": "WAITING",
        "type": "javalog",
        "version": 1,
        "timing_type": 1,   //预估时机 0 入队  1 刷新
        "shop_id": 62971,
        "path": "/var/log/application/pd_estimate_time.log",
        "environment": 0,
        "@timestamp": "2017-06-07T11:20:19.868Z",
        "datatype": 1,
        "serial_id": 0,     //号单id
        "@version": "1",
        "host": "pdv3_estimate62.mwee.prd",
        "action": "TIME",
        "queue_id": 370260,    //队列id
        "waiting_number": 1,   //等待人数
        "estimated_time": 1594   //-1 未预估出来;其他是预估出来的时间;目前估计时间超过7200也不会显示
      }
    QueueingTable建表语句：
      CREATE TABLE `QueuingTable` (
        `SerialID` bigint(12) NOT NULL COMMENT '流水号',
        `SerialCode` varchar(64) DEFAULT NULL COMMENT '排号单序号',
        `QType` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0、统一，1、午市，2、晚上',
        `QueueID` int(11) DEFAULT '0' COMMENT '云端队列ID',
        `ShopQueueID` varchar(40) DEFAULT NULL COMMENT '商家队列ID',
        `ShopID` int(11) NOT NULL DEFAULT '0' COMMENT '商家ID',
        `Type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '排队类别：0，所有 1，平板1，2，手机，3，委托',  //oracle中表c_qeue_type,可以区分线上线下,我们一般认为2,5,6,7,8都是线上
        `devType` tinyint(4) NOT NULL DEFAULT '0' COMMENT '设备类型：0、未知；1、ios设备；2、安卓设备',
        `ResetTime` varchar(32) NOT NULL DEFAULT '' COMMENT '排队重置时间',
        `DeviceID` int(11) DEFAULT '0' COMMENT '设备ID',
        `UserID` int(11) DEFAULT '0' COMMENT '用户ID',
        `openid` varchar(256) DEFAULT NULL COMMENT 'openid',
        `Mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号码',
        `People` int(11) NOT NULL DEFAULT '1' COMMENT '排队人数',
        `Number` int(11) NOT NULL DEFAULT '0' COMMENT '队列号码',
        `QueuingTime` datetime DEFAULT NULL COMMENT '创建时间',
        `CreateDate` datetime DEFAULT NULL COMMENT '取号时间',               //使用到
        `EntrustDate` datetime DEFAULT NULL COMMENT '委托时间',
        `State` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：0，初始化；1，拿号中；2，取到号；3，就绪；4，叫号；5，就坐；,6，过号；7，取号失败；8，委托失败；9，取消中；,10，取消；11，取消失败',
        `Del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除，默认0，未删除，1，删除',
        `Remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注（用户标示一些错误原因）',
        `Reset` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0，未复位，1，队列复位',
        `Acked` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'XMPP：应答确认，默认未应答[bit0，为1手机取号已应答，bit1，为1手机取消已应答]',
        `LastTime` datetime DEFAULT NULL COMMENT '操作更新时间',             //使用到
        `EventNo` int(11) DEFAULT NULL COMMENT '事件号',
        `ExecTime` datetime DEFAULT NULL COMMENT '记录写入时间',
        `ManageShopID` int(11) DEFAULT NULL COMMENT '总店商家ID',
        `KeepQueuing` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排队保留',
        `AllTotal` smallint(6) NOT NULL DEFAULT '0' COMMENT '总店排队总数目',
        `EstimateTime` mediumint(6) DEFAULT '0' COMMENT '预估时间,单位秒',        //
        `WaitPeople` smallint(6) DEFAULT NULL COMMENT '当前等待人数',
        `AllocTime` datetime DEFAULT NULL COMMENT '资源分配时间',
        `QRScan` tinyint(6) DEFAULT '0' COMMENT '排号单扫描',
        `SMSView` tinyint(6) DEFAULT '0' COMMENT '通过短信查看',
        `WeixinView` tinyint(4) DEFAULT '0' COMMENT '通过微信查看',
        `APPView` tinyint(4) DEFAULT NULL COMMENT 'APP查看排队',
        `CreditUserGot` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户获得的积分',
        `WxNotice` tinyint(4) DEFAULT NULL COMMENT '微信提醒提前桌数',
        `DiscountID` int(11) NOT NULL DEFAULT '0' COMMENT '等位优惠ID',
        `OffNotice` tinyint(4) DEFAULT NULL COMMENT '是否已经离线通知',
        `ThirdUrl` varchar(200) NOT NULL DEFAULT '' COMMENT '第三方接口',
        `LastAccess` tinyint(4) NOT NULL DEFAULT '0' COMMENT '最后访问方式：0，未访问；1，美味不用等公共号；2，第三方',
        `EstQueueID` int(11) DEFAULT NULL COMMENT '预约队列ID',
        `EstEnTime` smallint(6) DEFAULT NULL COMMENT '预估入队时间,精确到分钟',
        `MName` varchar(64) NOT NULL DEFAULT '' COMMENT '会员名称',
        `Times` tinyint(4) NOT NULL DEFAULT '0' COMMENT '消费次数',
        `AuthID` int(11) NOT NULL DEFAULT '0' COMMENT '授权用户',
        `AuthOrderID` varchar(256) DEFAULT NULL,
        PRIMARY KEY (`SerialID`),
        KEY `ShopID_3` (`ShopID`,`EventNo`),
        KEY `CreateDate` (`CreateDate`),
        KEY `openid` (`openid`(255)),
        KEY `Mobile` (`Mobile`,`CreateDate`),
        KEY `EntrustDate` (`Type`,`QType`,`EstQueueID`,`EntrustDate`),
        KEY `QueueID` (`QueueID`,`CreateDate`),
        KEY `UserID` (`UserID`,`CreateDate`),
        KEY `AuthID` (`AuthID`,`CreateDate`),
        KEY `AuthID_2` (`AuthID`,`AuthOrderID`(255),`CreateDate`),
        KEY `shopid` (`ShopID`),
        KEY `ShopID_CreateDate` (`ShopID`,`CreateDate`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8


# 计算逻辑

# 调试

# FAQ

## 现存问题
    计算时间有点长，可以使用user_tag类似的优化方式优化一下磁盘IO。
    
    Shuffle的数据量有点多，应该要优化一下SQL语句。

## 注意事项
    QUEUEING_WAITING_TIME日志中部分create_time和serial_id格式为double型的，例如：1.497110856726e+12
    而且有非常多serial_id为0的日志
    
    睢说：QueueingTable中字段QRScan和WeixinView有任意一个为1，代表线下扫码
    平会说：wxView = 1 是 微信扫码
    线下号单字段QRScan和WeixinView都为零的时候，还会预估时间。原因是等位桌数变动主动推送的，c端都推，如果发现号单是b端的就不推了，在发现的过程中会预估打出几条日志出来。
    
    队列预估 会产生很多serial_id为0的日志 预估 这个队列 目前还有登多少桌 ，放在app首页的
    
    ORACLE_QUEUEING_GOOD_SHOP,每月刷新一个月份
    
## 常见问题

## 修改历史

## 参考
    Oracle表c_qeue_type 排队类型
    0	所有
    1	平板1
    2	手机app
    3	委托
    4	平板2
    5	第三方
    6	微信
    7	M站
    8	号单预留
    9	未知
    10	未知
    11	未知
    12	未知
    13	未知
    14	未知
    15	未知
    16	未知
    17	未知
    18	未知
    19	未知
    20	未知











