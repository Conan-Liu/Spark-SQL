# 概述
    对每天每个店铺的预定数，定金总额进行统计

# 执行时间
    每天凌晨一点

# 依赖
  - 开发组
    每天凌晨00:35使用Spark程序com.gnow.transplant.BookingDepositTransplant从MySQL(10.0.146.89:3307)库restaurant的表orderbooksdeposit拉取数据到hdfs
  - 数据
    - input
        hdfs目录：/rdb/booking/booking_deposit
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表BOOKING_DEPOSIT

# 数据格式
    建表语句
    CREATE TABLE `orderbooksdeposit` (
      `id` int(20) NOT NULL AUTO_INCREMENT,
      `tradeNo` varchar(20) DEFAULT NULL COMMENT '内部交易流水号',
      `orderId` varchar(10) NOT NULL COMMENT '订单ID(主键)',
      `shopId` int(10) DEFAULT NULL,
      `zongdianId` int(10) DEFAULT NULL,
      `deposit` double(8,2) NOT NULL COMMENT '定金  会存实际收取的金额(会在钱超通知回调的时候修改成实际收取的金额)，如果没有支付宝优惠，这里的值一般跟redis配置一样   退款时需要拿这里的实际的金额',
      `status` tinyint(2) NOT NULL COMMENT '定金状态(1：未支付(默认状态)、2超时支付失败；3：订金已支付、4.定金已扣款   6.定金已申请退款)',
      `outTradeNode` varchar(20) DEFAULT NULL COMMENT '第三方交易流水号  对应钱超那边的pay_id',
      `payType` tinyint(2) DEFAULT NULL COMMENT '支付方式（1：微信；2：支付宝；3: 银联支付; 4: 百度钱包）',
      `payBackResult` varchar(4000) DEFAULT '' COMMENT '第三方返回的退款结果字符窜',
      `payResult` varchar(4000) DEFAULT NULL COMMENT '第三方返回的支付结果字符窜',
      `insertTime` bigint(13) NOT NULL,
      `updateTime` bigint(13) DEFAULT NULL,
      `type` tinyint(2) DEFAULT '2' COMMENT '表示是线上订单的定金，还是线下订单的定金。2：线下定金；3：c端线上定金  ,默认2',
      `refundTime` bigint(14) DEFAULT '0' COMMENT '退款时间 ，当状态为已申请退款时修改此字段',
      `refundMoney` double(8,2) DEFAULT '0.00' COMMENT '退款金额',
      `refundTradeNo` varchar(20) DEFAULT '' COMMENT '退款单号（退款时，退款方返回的唯一退款id     钱超那边的payback_id）',
      `deductTime` bigint(14) DEFAULT '0' COMMENT '扣款时间，当状态为已扣款时修改此字段',
      `deductMoney` double(14,2) DEFAULT '0.00' COMMENT '扣款金额  单位元',
      `phones` varchar(13) DEFAULT '' COMMENT '预订的客户号码',
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=49646 DEFAULT CHARSET=utf8

# 计算逻辑
    用type_和shopid进行group，id进行count，对deposit进行sum

# 调试

# FAQ

## 现存问题

## 注意事项

## 常见问题









