# 概述
    APP用户活跃情况统计
    UserActive4AppWeekly  统计每周APP活跃
    UserActive4AppMonthly  统计每月APP活跃

# 执行时间
    UserActive4AppWeekly  每周日凌晨三点
    UserActive4AppMonthly  每月一号凌晨四点


# 依赖
  - 开发组
    从ES拉取日志到hdfs
  - 数据
    - input
        hdfs目录：/repository/kafka/basic_app_trace
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表USER_ACTIVE_RATE

# 数据格式
    日志格式
    {
        "date": "2017-05-27 10:15:58",
        "phase": 2, //阶段 0：首次使用 1：Login -1：Logout 2：除以上外所有
        "createtime": " 2017:05:27 10:15:58 ",
        "business": "basic",
        "create_time": 1495851358,
        "device_id": "7AA67F934BCF1BC6347841E57F8095F4", //设备ID
        "level": "info ",
        "module": "APP",
        "latitude": "31.31311",
        "mobile": "18662240803", //手机号码
        "pid": " 25011 ",
        "device_type": 2, //设备类型 0：未知 1：IOS 2：ANDROID
        "type": "seaslog",
        "version": 1,
        "path": "/var/log/seaslog/BASIC/20170527.log",
        "@timestamp": "2017-05-27T02:15:59.289Z",
        "datatype": 1, //部署环境 0：生产 1：测试
        "@version": "1",
        "host": "c_api94.mwee.prd",
        "action": "TRACE",
        "timestamp": " 1495851358.770 ",
        "longitude": "120.620626"
      }

# 计算逻辑
    UserActive4AppWeekly  使用distinct device_id和本周create_time来统计APP各个阶段用户数
    UserActive4AppMonthly  使用distinct device_id和本月create_time来统计APP各个阶段用户数

# 调试

# FAQ

## 现存问题

## 注意事项
    表USER_ACTIVE_RATE中device_type与日志中device_type没有关系，表USER_ACTIVE_RATE中device_type为0代表APP，
    device_type为1代表微信。使用time_interval中0，1，2代表日，周，月。

## 常见问题









