# 概述
    计算每个用户的一些tag，比如当前所在城市，是否关注美味不用等公众号，使用排队，预定和点菜功能的最后时间和次数，手机号是多少，使用什么操作系统，设备ID是多少等等。其中所在城市和是否关注公众号两点是比较重要的，运营要使用这些来做公告，因为每一个城市的广告是不一样的。

# 执行时间
    每天凌晨一点

# 依赖
 - 开发组
    从ES拉取每天的basic_user_tag日志

 - 数据
   - input
   
        hdfs目录：/repository/kafka/basic_user_tag
   - output
   
        MySQL数据库：10.1.32.185:3306，库associator，表user_tag，使用到临时表user_tag_tmp

# 数据格式
    日志格式 label为美味不用等：
    {
        "business": "basic",
        "create_time": 0,
        "openId": "oWT18jlGg6dnCN445Vp2zKXB1Gxk", //2017-03-13日(含)之前字段名叫open_id
        "module": "USER",
        "ip": "10.1.32.201",
        "device_type": 0,
        "label": "美味不用等",
        "type": "javalog",
        "reqData": {
          "devType": 0,
          "cityName": "上海",
          "lng": "121.5285",
          "openId": "oWT18jlGg6dnCN445Vp2zKXB1Gxk",
          "userAgent": "wechat",
          "cityId": "258",
          "tag": "10001",
          "time": 0,
          "userId": 33236360,
          "lat": "31.17898"
        },
        "path": "/var/log/application/usersystem_jms_bigdata.log",
        "environment": 1,
        "@timestamp": "2017-06-07T02:54:40.596Z",
        "datatype": 1,
        "mwbyd_status": 1,
        "user_id": 33236360,
        "@version": "1",
        "host": "usersys_java201.mwee.prd",
        "action": "TAG",
        "time": 0
      }
      
      日志格式 label为城市：
      {
          "business": "basic",
          "create_time": 0,
          "openId": "oWT18jlGg6dnCN445Vp2zKXB1Gxk",
          "module": "USER",
          "ip": "10.1.32.201",
          "device_type": 0,
          "label": "城市",
          "type": "javalog",
          "reqData": {
            "devType": 0,
            "cityName": "上海",
            "lng": "121.5285",
            "openId": "oWT18jlGg6dnCN445Vp2zKXB1Gxk",
            "userAgent": "wechat",
            "cityId": "258",
            "tag": "10001",
            "time": 0,
            "userId": 33236360,
            "lat": "31.17898"
          },
          "path": "/var/log/application/usersystem_jms_bigdata.log",
          "environment": 1,
          "@timestamp": "2017-06-07T02:54:40.595Z",
          "datatype": 1,
          "mwbyd_status": 1,
          "user_id": 33236360,
          "@version": "1",
          "host": "usersys_java201.mwee.prd",
          "action": "TAG",
          "attributes": {
            "city_name": "上海",
            "latitude": "31.17898",
            "city_id": "258",
            "longitude": "121.5285"
          }
          
          排队预定2016-12-16日日志都有  
          
# 计算逻辑

# 调试

#  FAQ


## 现存问题
    优化方案一：
        1.手动指定json的schema，Spark自动识别json的schema需要扫描一遍所有数据
        2.预处理数据为parquet格式：json中很多字段不使用就过滤掉，json的结构字符如"{}:"这种本身就占空间，读的时候容易受到磁盘IO的限制，保存临时文件为parquet格式
        3.使用多次的Dataframe缓存一下，比如处理结果。其他的还得评估一下，太占内存
    进一步的优化：
        1.是否可以按年，或半年把数据预处理，这样可以进一步减少磁盘IO
        2.SQL优化，这个要求比较高

## 注意事项
    业务从中午到下午五六点会使用user_tag数据进行推送，特别是周三。from 睢文蓉
    
    微信推送业务周一到周五都有可能。业务方自己定日期用。每个城市在哪天推，看他们跟甲方签的合同和排期，有时周末也推。数据质量层面我们看邮件，推送过程我们看关键指标，就靠这个业务监控了。from 唐超
    
    11:30跑ES。

## 常见问题
