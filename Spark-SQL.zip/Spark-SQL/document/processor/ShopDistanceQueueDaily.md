# 概述
    统计排队用户与商店距离
    
# 执行时间
    ShopDistanceQueueDaily 每天凌晨两点

# 依赖
  - 开发组
    - 每天从ES拉取日志到hdfs
    - 从MYSQL_32_RESTAURANT拉取数据到hdfs
  - 数据
    - input
        - hdfs目录：/repository/kafka/queueing_main_queue
        - hdfs目录：/rdb/basic/shop_table
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表SHOP_DISTANCE

# 数据格式
    queueing_main_queue日志格式：
    {
        "date": "2017-05-31 09:59:06",
        "open_id": "",
        "latitude": "36.26963",
        "pid": " 8657 ",
        "device_type": 1,      //0 未知 1 IOS 2 ANDROID
        "type": "seaslog",
        "people_count": 4,
        "path": "/var/log/seaslog/QUEUEING/20170531.log",
        "user_type": 2,        //1 平板 2 手机APP 3 委托 4 平板2 5 第三方 6 微信 7 M站 
        "datatype": 1,
        "serial_id": 563498840,
        "@version": "1",
        "host": "c_api94.mwee.prd",
        "action": "QUEUE",
        "waiting_count": 0,
        "queue_id": 0,          //队列号
        "timestamp": " 1496195946.684 ",
        "longitude": "120.347684",
        "createtime": " 2017:05:31 09:59:06 ",
        "business": "queueing",
        "create_time": 1496195946,
        "queue_type": 0,        //0 统一 1 午市 2 晚市
        "level": "info ",
        "module": "MAIN",
        "mobile": "15054298558",
        "shop_name": "海底捞(凯德MALL新都心店)",
        "version": 1,
        "shop_id": 127213,
        "@timestamp": "2017-05-31T01:59:07.430Z",
        "user_id": 38578232,
        "status": 1 //0 初始化 1 拿号中 2 取到号 3 就绪 4 叫号 5 就座 6 过号 7 取号失败 8 委托失败 9 取消中 10 取消 11 取消失败
      }
    shop_table建表语句：
    CREATE TABLE `ShopTable` (
      `ShopID` int(11) NOT NULL AUTO_INCREMENT,
      `StyleCooking` varchar(20) NOT NULL DEFAULT '' COMMENT '菜系',
      `EncryptedShopID` varchar(48) NOT NULL DEFAULT '' COMMENT 'SHA1加密后的商家ID',
      `countryId` smallint(6) NOT NULL DEFAULT '1' COMMENT '1，中国；',
      `AreaID` int(11) NOT NULL DEFAULT '0' COMMENT '大区域id',
      `City` int(11) NOT NULL DEFAULT '0' COMMENT '城市ID',
      `Cooperation` tinyint(1) NOT NULL DEFAULT '1' COMMENT '合作商家:1',
      `NamePinyin` varchar(200) NOT NULL DEFAULT '' COMMENT '商家名称拼音',
      `CheckWay` tinyint(4) NOT NULL DEFAULT '1' COMMENT '结账方式：1先结账；2后结账',
      `ShopName` varchar(255) DEFAULT '',
      `Type` tinyint(4) NOT NULL DEFAULT '2' COMMENT '商店类别：1为商场，2为餐饮，3为零售，15为其他，16为商圈',
      `Industry` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1、美食；2、',
      `ShopType` int(4) DEFAULT '0' COMMENT '商家菜系',
      `EntityStore` tinyint(4) DEFAULT '1',
      `Tel` varchar(32) DEFAULT NULL,
      `BookPhone` varchar(256) NOT NULL DEFAULT '' COMMENT '预定电话',
      `Address` varchar(200) DEFAULT NULL,
      `Logo` varchar(256) DEFAULT NULL,
      `TLogo` varchar(256) DEFAULT NULL,
      `MLogo` varchar(256) DEFAULT NULL,
      `BgImage` varchar(256) DEFAULT NULL,
      `TBgImage` varchar(256) DEFAULT NULL,
      `MBgImage` varchar(256) DEFAULT NULL,
      `Integrals` int(11) DEFAULT '0' COMMENT '商家可发放积分',
      `Sent` bigint(20) NOT NULL DEFAULT '0' COMMENT '发放总积分',
      `app_pay` smallint(6) DEFAULT '0' COMMENT '是否开启app买单功能',
      `EnterInRate` int(11) NOT NULL DEFAULT '1' COMMENT '进店给积分频度，按天为单位。',
      `VoucherValue` int(11) DEFAULT '0' COMMENT '商家需要供用户兑换的券的积分价值',
      `IntegralRatio` float DEFAULT '1' COMMENT '用户消费积分返回基数',
      `ConsumptionRatio` int(11) DEFAULT '1',
      `Email` varchar(100) DEFAULT NULL,
      `Description` varchar(400) DEFAULT NULL,
      `Services` varchar(100) DEFAULT NULL COMMENT '商店服务：1为排队，2为点菜。。。',
      `c_services` varchar(256) NOT NULL DEFAULT '' COMMENT 'C端展示的服务',
      `State` tinyint(4) DEFAULT '0' COMMENT '商店状态：1为注册，2为激活，3为运行，4为删除',
      `Longitude` double DEFAULT NULL,
      `Latitude` double DEFAULT NULL,
      `LngGPS` double DEFAULT NULL COMMENT '标准GPS 经度',
      `LatGPS` double DEFAULT NULL COMMENT '标准GPS 纬度',
      `ManageShopID` int(11) DEFAULT NULL COMMENT '总店ID',
      `ShoppingmallShopID` int(11) DEFAULT NULL,
      `Traffic` varchar(200) DEFAULT NULL,
      `ShopHours` varchar(100) DEFAULT '10:00–22:00',
      `RegNum` varchar(100) DEFAULT NULL,
      `RegName` varchar(100) DEFAULT NULL,
      `LegalPerson` varchar(100) DEFAULT NULL,
      `RegImage` varchar(40) DEFAULT NULL,
      `CreateDate` datetime DEFAULT NULL,
      `VoucherLimitation` int(11) NOT NULL DEFAULT '5000000' COMMENT '债券上限',
      `OrderPrintNum` int(11) NOT NULL DEFAULT '4' COMMENT '下单打印数目',
      `PayPrintNum` int(11) NOT NULL DEFAULT '2' COMMENT '支付打印数目',
      `EnPrint` tinyint(4) NOT NULL DEFAULT '0',
      `TableCount` int(11) NOT NULL DEFAULT '0' COMMENT '餐桌数目',
      `GoodUpdateTime` datetime DEFAULT NULL COMMENT '菜单更新时间',
      `WaitList` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0:默认不支持，1：支持',
      `OrderDistanceLimit` int(11) NOT NULL DEFAULT '3000' COMMENT '提交订单默认距离',
      `QueueVersion` datetime DEFAULT NULL COMMENT '排队：队列配置版本',
      `Index` int(11) NOT NULL DEFAULT '0' COMMENT '索引',
      `DefineShopID` varchar(128) DEFAULT NULL COMMENT '商家自定义名称',
      `CityAreaID` varchar(256) NOT NULL DEFAULT '' COMMENT '城市区域ID',
      `BCID` varchar(256) NOT NULL DEFAULT '' COMMENT '商业区ID,支持多个,逗号分隔',
      `QueuingTotal` int(11) NOT NULL DEFAULT '0' COMMENT '排队总数/周',
      `ProvinceID` int(11) DEFAULT '0' COMMENT '省份ID',
      `mmShopID` int(11) DEFAULT NULL COMMENT '某某id',
      `KuaiCanMode` tinyint(4) NOT NULL DEFAULT '0' COMMENT '快餐模式',
      `DisFlag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '优惠表示',
      `TiyanDian` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否是体验店',
      `DianpingID` int(11) NOT NULL DEFAULT '0' COMMENT '点评网商家ID',
      `OnLine` tinyint(4) NOT NULL DEFAULT '1' COMMENT '默认上线：1线上；0下线；',
      `forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '永远不离线',
      `MemFunc` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员功能：默认关闭；0，关闭、，1开启',
      `linQu` tinyint(4) DEFAULT NULL COMMENT '邻趣活动',
      `attenActive` tinyint(4) DEFAULT NULL COMMENT '关注活动',
      `Img_Do` tinyint(1) NOT NULL DEFAULT '0',
      `offInvalid` tinyint(4) NOT NULL DEFAULT '1' COMMENT '过号是否作废：默认过号不作废1',
      `clientManager` varchar(256) DEFAULT NULL COMMENT '客户经理',
      `BookVersion` datetime DEFAULT NULL COMMENT '预定配置更新时间',
      `shareFlag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '分享优惠标示',
      `maxWaitLimit` smallint(6) NOT NULL DEFAULT '10800' COMMENT '最大等位时间门限',
      `LastTime` datetime DEFAULT NULL COMMENT '最后更新时间',
      `location` varchar(128) NOT NULL DEFAULT '' COMMENT '坐标系-谷歌',
      PRIMARY KEY (`ShopID`),
      KEY `State` (`State`,`Longitude`,`Latitude`),
      KEY `City_2` (`City`,`ShopName`,`State`),
      KEY `ManageShopID` (`ManageShopID`),
      KEY `ShoppingmallShopID` (`ShoppingmallShopID`),
      KEY `EncryptedShopID` (`EncryptedShopID`),
      KEY `City` (`City`,`Type`,`State`,`CityAreaID`(255),`BCID`(255),`EntityStore`,`ShopType`,`DisFlag`),
      KEY `DisFlag` (`DisFlag`),
      KEY `ShopName_2` (`ShopName`,`Type`,`State`,`ManageShopID`,`DianpingID`),
      KEY `DianpingID` (`DianpingID`)
    ) ENGINE=InnoDB AUTO_INCREMENT=170955 DEFAULT CHARSET=utf8

# 计算逻辑
  - 根据经纬度计算距离
  - user_type不为1(平板)和4(平板2)

# 调试

# FAQ

## 现存问题

## 注意事项

## 常见问题









