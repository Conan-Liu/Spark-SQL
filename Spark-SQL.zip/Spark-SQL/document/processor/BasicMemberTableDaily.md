# 概述

# 执行时间
    每天凌晨两点

# 依赖
  - 开发组
    每天从ES拉取日志到hdfs
  - 数据
    - input
        hdfs目录：/repository/kafka/basic_member_table
    - output
        MySQL数据库10.0.146.37:3306：库restaurant，表basic_member_table

# 数据格式
    日志格式
    {
        "date": "2017-05-27 15:56:00",
        "createtime": " 2017:05:27 15:56:00 ",
        "business": "basic",
        "create_time": 1495871760,
        "level": "info ",
        "module": "MEMBER",
        "pid": " 27956 ",
        "type": "seaslog",
        "b_version": "372",
        "version": "",
        "path": "/var/log/seaslog/BASIC/20170527.log",
        "shop_id": 166712,
        "environment": "0",
        "@timestamp": "2017-05-27T07:56:00.199Z",
        "datatype": 1,
        "@version": "1",
        "host": "biz_pd106.mwee.prd",
        "action": "TABLE",
        "function_id": 3002,                          //功能ID
        "online": 147778308,                          //该页面点击次数
        "create_date": "2017-05-27",
        "website_id": 301,                            //页面ID
        "timestamp": " 1495871760.145 "
      }


# 计算逻辑
    转存一下数据

# 调试

# FAQ

## 现存问题
    往MySQL插入数据所花时间过长，20+万数据要花差不多两个小时。应该是MySQL性能问题，basic_member_table已经有2000+数据。

## 注意事项

## 常见问题









