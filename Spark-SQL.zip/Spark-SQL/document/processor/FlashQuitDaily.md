# 概述
    统计每天出现设备出现故障的餐厅
# 执行时间
    每天凌晨一点

# 依赖
  - 开发组
    每天凌晨00:35使用Spark程序com.gnow.transplant.DeviceBreakdownTransplant从MySQL(10.0.146.36:3306)库nowwarning的表warnwarnings拉取数据到hdfs
  - 数据
    - input
        hdfs目录：/rdb/paying/warn_warnings
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表FLASH_QUIT_SHOP

# 数据格式
    建表语句
    CREATE TABLE `warnwarnings` (
      `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
      `warningTypeId` int(11) NOT NULL COMMENT '警报类型ID',
      `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '警报状态（1、未解决；2已解决；3、未查看）',
      `level` tinyint(2) DEFAULT NULL COMMENT '警报级别（1、一级警报；2、二级警报；3、三级警报；级别越大，错误越严重）',
      `context` text COMMENT '警报详情',
      `createTime` bigint(20) NOT NULL COMMENT '创建时间',
      `updateTime` bigint(20) DEFAULT NULL COMMENT '修改时间 ',
      `shopId` int(11) DEFAULT '0',
      `verNm` varchar(20) DEFAULT NULL COMMENT 'B端版本号',
      PRIMARY KEY (`id`),
      KEY `warnings_createTime_typeId` (`createTime`,`warningTypeId`),
      KEY `idx_createTime_typeId` (`warningTypeId`,`createTime`),
      CONSTRAINT `FK_warnwarnings` FOREIGN KEY (`warningTypeId`) REFERENCES `warnwarningdictionary` (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=18220025 DEFAULT CHARSET=utf8 COMMENT='警报记录表'

# 计算逻辑
    统计warning_type_id in (231, 283, 232, 428, 433, 432, 431, 430, 429)的shopid
# 调试

# FAQ

## 现存问题

## 注意事项

## 常见问题









