# 概述
    统计每天设备销售量，销售额

# 执行时间
    每天凌晨一点

# 依赖
  - 开发组
    每天凌晨00:35使用Spark程序com.gnow.transplant.DeviceBreakdownTransplant从MySQL(10.0.35.6:3306)库oa_storage的表device_order拉取数据到hdfs
  - 数据
    - input
        hdfs目录：/rdb/oa/device_order
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表DEVICE_SELLING

# 数据格式
    建表语句
    CREATE TABLE `device_order` (
      `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
      `shop_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商户id',
      `shop_name` varchar(50) NOT NULL DEFAULT '' COMMENT '商户名称',
      `brand_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '品牌id',
      `brand_name` varchar(50) NOT NULL DEFAULT '' COMMENT '品牌名称',
      `order_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '订单类型 0 未指定 1 排队 2 预定 3 点菜 4 支付 5 微信服务 6 排队软件服务费',
      `sale_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '销售人',
      `sale_name` varchar(30) NOT NULL DEFAULT '' COMMENT '销售人姓名',
      `sale_city` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '销售人所在城市id',
      `sale_city_name` varchar(20) NOT NULL DEFAULT '' COMMENT '销售人所在城市',
      `mark` varchar(200) NOT NULL DEFAULT '' COMMENT '备注',
      `scheme_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '套餐总价',
      `other_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '其他设备总价',
      `change_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '调整总额 （如优惠，涨价等）',
      `order_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '订单状态 1 未完成 2 已完成 3 已取消',
      `pay_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '支付状态 1 待支付 2已支付 3已退款 4支付失败',
      `pay_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
      `pay_method` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '支付方式 2支付宝 1微信 3银行卡  6网银支付',
      `pay_id` varchar(50) NOT NULL DEFAULT '' COMMENT '普景支付流水号',
      `pay_number` varchar(50) NOT NULL DEFAULT '' COMMENT '第三方支付流水号',
      `device_status` tinyint(1) unsigned NOT NULL DEFAULT '2' COMMENT '设备状态 1 已安装 2 未安装',
      `invoice_status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '发票状态 1未申请 2已申请 3已邮寄 4审核通过 5审核未通过',
      `date` date NOT NULL DEFAULT '0000-00-00' COMMENT '创建日期',
      `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
      `category` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '默认销售订单0，设备押金1',
      `pay_mark` varchar(1000) NOT NULL DEFAULT '' COMMENT '支付说明',
      `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      `refound_time` int(11) NOT NULL DEFAULT '0' COMMENT '退款时间',
      `refound_mark` varchar(1000) NOT NULL DEFAULT '' COMMENT '退款说明',
      `refound_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '退款方式（1：微信；2：支付宝；3：转账；4：百付宝；5：银联；6：淘宝店）',
      `device_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '安装时间',
      `sale_device_code` text COMMENT '设备售卖回写备注',
      `purchase_order` varchar(200) NOT NULL DEFAULT '' COMMENT '申购单号',
      `device_order_type` int(2) NOT NULL DEFAULT '0' COMMENT '新旧设备(1:新设备 2:旧设备)',
      `pay_time_confirm` int(10) NOT NULL DEFAULT '0' COMMENT '确认收款时间',
      PRIMARY KEY (`id`),
      KEY `idx_date` (`date`),
      KEY `shop_id` (`shop_id`,`category`) USING BTREE,
      KEY `pay_number` (`pay_number`)
    ) ENGINE=InnoDB AUTO_INCREMENT=16919 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='设备销售订单基本信息表'


# 计算逻辑
    对order_type和shopid进行group，对id求count，对scheme_amount等求sum

# 调试

# FAQ

## 现存问题

## 注意事项

## 常见问题









