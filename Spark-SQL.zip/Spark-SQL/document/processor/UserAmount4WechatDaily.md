# 概述
    统计每天新增微信用户数

# 执行时间
    每天凌晨两点

# 依赖
  - 开发组
    从ES拉取日志到hdfs
  - 数据
    - input
        hdfs目录：/repository/kafka/basic_wechat_trace
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表USER_AMOUNT

# 数据格式
    日志格式
    {
        "phase": -2, //阶段 0：首次使用 1：Login -1：Logout -2：取关 2：除以上外所有
        "msg": "取关",
        "business": "basic",
        "device_id": 0,  //设备ID
        "create_time": 1495850690,  //创建时间 类型:Unix timestamp
        "level": "info",
        "open_id": "oWT18jmg_3_xckyChddR39y1XNIo", //微信用户唯一标识，代表一个微信用户
        "module": "WECHAT",
        "latitude": "",
        "pid": 4743,
        "device_type": 2,  //设备类型 0：未知 1：IOS 2：ANDROID
        "type": "javalog",
        "path": "/var/log/application/basic-20170527.log",
        "@timestamp": "2017-05-27T02:04:50.389Z",
        "datatype": 1,  //部署环境 0：生产 1：测试
        "data_type": 1,
        "@version": "1",
        "host": "cend_wx_service14.mwee.prd",
        "action": "TRACE",
        "verSion": 1,
        "longitude": ""
      }

# 计算逻辑
    使用distinct open_id，phase=0和当天create_time来统计微信用户数

# 调试

#  FAQ

## 现存问题

## 注意事项
    USER_AMOUNT表中的device_type与日志中的device_type没有关系。USER_AMOUNT表中divice_type恒为0，用c_type区分微信和APP，c_type为0代表APP，为1代表微信。

## 常见问题









