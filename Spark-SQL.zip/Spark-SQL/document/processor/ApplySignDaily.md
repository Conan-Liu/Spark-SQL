# 概述
    计算每个店铺每天申请某些服务的次数和缴纳金额总额

# 执行时间
    每天凌晨一点

# 依赖
  - 开发组
    每天凌晨00:35使用Spark程序com.gnow.transplant.BookingApplySignTransplant从MySQL(10.0.146.89:3307)库restaurant的表applySign拉取数据到hdfs
  - 数据
    - input
        hdfs目录：/rdb/booking/booking_apply_sign
    - output
        Oracle数据库10.0.24.10:1521：实例BQSWD，表APPLY_SIGN

# 数据格式
    建表语句
    CREATE TABLE `applySign` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `inserttime` bigint(20) NOT NULL,
      `shopId` int(11) NOT NULL,
      `zongdianId` int(11) NOT NULL,
      `money` double(11,2) NOT NULL COMMENT '申请金额',
      `state` int(11) NOT NULL COMMENT '0 等待支付 1 支付成功 2 支付失败 3 支付成功且审核通过 4 支付成功且审核不通过 5 退款 6 退款失败 7 退款成功',
      `payaccount` varchar(255) DEFAULT NULL COMMENT '支付账户',
      `orderId` varchar(32) NOT NULL COMMENT '订单id 时间戳+随机数+shopid',
      `tranNum` varchar(300) DEFAULT NULL COMMENT '交易流水号',
      `outTradeNo` varchar(30) DEFAULT NULL COMMENT '对账pay_order',
      `payrecord` varchar(4000) DEFAULT NULL COMMENT '支付返回明文',
      `updatetime` bigint(20) NOT NULL,
      `payChannel` int(11) DEFAULT NULL COMMENT '充费账号（支付宝账号、银行卡） 1微信2支付宝',
      `isNext` tinyint(1) DEFAULT NULL COMMENT '1 续费 0 否',
      `errno` int(11) DEFAULT NULL COMMENT '状态码，为 0 表示业务正常，其他非政治',
      `errmsg` varchar(4000) DEFAULT NULL COMMENT '业务信息',
      `orderName` varchar(500) DEFAULT NULL COMMENT '订单商品名称',
      `payOrder1` varchar(200) DEFAULT NULL COMMENT '第三方订单号',
      `deadTime` bigint(200) DEFAULT NULL COMMENT '截止日期',
      `valTime` bigint(200) DEFAULT NULL COMMENT '生效日期',
      `invoiceState` tinyint(1) DEFAULT '0' COMMENT '订单号对应发票状态：0 未开发票 1 待审核 2 已开发票',
      `refundStartTime` bigint(20) DEFAULT NULL,
      `refundEndTime` bigint(20) DEFAULT NULL,
      `auditTime` bigint(20) DEFAULT NULL,
      `packId` varchar(80) DEFAULT '' COMMENT '退款交易号（支付方返回）',
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8


# 计算逻辑
    对shopid进行group，做shopid的count和money的sum

# 调试

# FAQ

## 现存问题

## 注意事项

## 常见问题









