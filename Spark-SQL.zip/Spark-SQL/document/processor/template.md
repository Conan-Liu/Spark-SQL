# 概述

  ~~此job主要用于＊＊＊~~

# 执行时间

  ~~每天凌晨一点~~

# 依赖
 - 开发组

  ~~基础业务~~

 - 数据

   - input

      ~~/hadoop/**~~

   - output

   ~~mysql dsn string~~

# 数据格式

   ~~主要描述日志格式~~

```json
{
    "business":"basic", //string 业务名称
    "datatype":0,       //int   数据类型
    "module":"USER",    // string
    "action":"TAG"
    "data":{
        "logitude":121.11 //double 经纬度
        "shopid":3223     //int 店铺id
    }  
}

```
# 计算逻辑

  ~~主要将计算中需要注册哪些临时表，如何抽取数据以及关键sql~~

# 调试

   ~~此处主要描述开发环境以及线上问题如何调试~~

#  FAQ

   ~~主要说明有些 现存问题，注意事项,常见问题~~

## 现存问题

- 执行时间过长 ？

  ~~答：预处理数据，全量计算改成增量计算，增加cache。~~

## 注意事项

## 常见问题
