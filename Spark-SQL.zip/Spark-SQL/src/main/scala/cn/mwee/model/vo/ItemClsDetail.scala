package cn.mwee.model.vo

/**
  *
  * @param shopId
  * @param shopName
  * @param clsName
  * @param custSum
  * @param itemCount
  */
case class ItemClsDetail(shopId: String, shopName: String, goodTypeName: String, custSum: String, clsName: String, itemCount: String)
