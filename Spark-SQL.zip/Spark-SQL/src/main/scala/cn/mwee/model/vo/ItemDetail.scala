package cn.mwee.model.vo

/**
  *
  * @param shopId
  * @param shopName
  * @param goodTypeName
  * @param itemId
  * @param itemName
  * @param clsName
  * @param itemCount
  */
case class ItemDetail(shopId: String, shopName: String, goodTypeName: String, itemId: String, itemName: String,clsName: String, itemCount: String)
