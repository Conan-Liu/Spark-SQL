package cn.mwee.model

import cn.mwee.util.GisUtils
import com.github.davidmoten.geo.GeoHash
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBReader
import com.gnow.{DB, Processor}

/**
  * Created by tal on 10/08/2017.
  */
class DpBaSeparator extends Processor{
  val DIANPING_CITY = "dianping_city"
  val DIANPING_MALL_LOCATION = "dianping_mall_location"
  val DIANPING_SHOP_LOCATION = "dianping_shop_location"
  val DIANPING_BUSINESS_AREA = "dianping_business_area"

  def reset(targetDate: String): Unit = {
    val sql = "delete from dianping_business_area"
    println(sql)
    DBEraser.remove(DB.ORACLE_7_BWSWD, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    //获取城市商圈数据
    val dpCity = RDBReader.read(DB.ORACLE_7_BWSWD, DIANPING_CITY)
    dpCity.printSchema()
    dpCity.show()
    //获取商场数据
    val dpMallLocation = RDBReader.read(DB.ORACLE_7_BWSWD, DIANPING_MALL_LOCATION)
    dpCity.printSchema()
    dpCity.show()
    //获取点评店铺位置数据
    val dpShopLocation = RDBReader.read(DB.ORACLE_7_BWSWD, DIANPING_SHOP_LOCATION)
    dpShopLocation.printSchema()
    dpShopLocation.cache()
    dpShopLocation.show()

    //需要计算的商圈ID
//    val baIds = List("67275", "70265", "70531", "865", "872", "873", "860", "861", "859", "862", "835", "836", "812", "811", "842", "839", "843", "854", "815", "9177", "12026", "5941", "", "", "", "8848")

    //获取商圈ID
//    val dpCityBa = dpCity.where("CITY_ID=\'1\'").select("CITY_ID", "BUSINESS_AREA_ID").rdd.collect().map(row => (row.get(0).toString, row.get(1).toString)).filter(row => baIds.contains(row._2))
    val dpCityBa = dpCity.where("CITY_ID in ('8','10','17','33','29','35','299','208','18','27','94','344','224','3','5','6','15','258','24','14','46','93','2','13','22','160','162','4','7','11','21','23','19','70','101','267','9','1','25','16','79','110','134','219')").dropDuplicates(Seq("CITY_ID", "BUSINESS_AREA_ID")).select("CITY_ID", "BUSINESS_AREA_ID").rdd.collect().map(row => (row.get(0).toString, row.get(1).toString))

    //所有点heatmap
    var allHeatMapPoints: Array[String] = Array()

    //对每个商圈进行计算 一级商圈
    dpCityBa.foreach(cityBa => {
      println("计算一级商圈")
//      //获取所有点，用来画热力图
//      val pointsAll = dpShopLocation.where("BUSINESS_AREA_ID=" + cityBa._2)
//                                    .select("STREET_LOCATION")
//                                    .rdd
//                                    .map(row => row.get(0)).collect()

      //对6位精度的geohash进行过滤
      val pointsRaw = dpShopLocation.where("BUSINESS_AREA_ID=" + cityBa._2)
                                 .select("GEOHASH6")
                                 .rdd
                                 .map(row => (row.get(0).toString, 1))
                                 .reduceByKey(_+_)
                                 .filter(geo => geo._2 > 10)

      pointsRaw.cache()

      val points = pointsRaw.collect()

      //计算商圈内店铺个数
      val shopCount = pointsRaw.map(row => row._2).sum()

      pointsRaw.unpersist()

      //求经纬度
      var latLons = points.map(geo => {
        val geohash = geo._1
        val latLon = GeoHash.decodeHash(geohash)
        latLon.getLat + "," +latLon.getLon
      })

      //求商圈中心
      val center = GisUtils.getCenter(latLons)
      if(!"NaN,NaN".equals(center)){
        println(cityBa._1 + "," + cityBa._2 + "," + center.split(",")(1) + "," + center.split(",")(0))
      }

      //求商圈大致的大小
      var radius = Math.pow(latLons.size, 0.5) * 0.610 * 2
      println("商圈大致的大小: " + radius)

      //过滤掉离商圈太远的点
      latLons = latLons.filter(geo => {
        val distance = GisUtils.calcDistance(center, geo)
        distance < radius * 1.5
      })

      //求geohash
      val geoHashes = latLons.map(latLon => {
        val geohash = GeoHash.encodeHash(latLon.split(",")(0).toDouble, latLon.split(",")(1).toDouble)
        geohash.substring(0, 6)
      })
      var geoHash6 = ""
      if(geoHashes.size > 0){
        geoHash6 = geoHashes.reduce((a, b) => a + "," + b)
      }

      //重新计算商圈的大小
      radius = Math.pow(geoHashes.size, 0.5) * 0.610 * 2

      //求商圈的面积
      val baArea = geoHashes.size * 0.610 * 2 * 0.610 * 2

      //求商圈的密度
      var baDensity = 0.0
      if(baArea > 0){
        baDensity = shopCount / baArea
      }

      //所有点的热力图
//      val latLons_heatmap_all = pointsAll.map(geo => {
//        val lat = geo.toString.split(",")(1)
//        val lon = geo.toString.split(",")(0)
//        "{\"lng\":" + lon + "," + "\"lat\":" + lat + "," + "\"count\":5}"
//      })

      //求热力图 画好的
//      val latLons_heatmap = latLons.map(geo => {
//        val lat = geo.split(",")(0)
//        val lon = geo.split(",")(1)
//        "{\"lng\":" + lon + "," + "\"lat\":" + lat + "," + "\"count\":100}"
//      })

      //城市热力图
//      allHeatMapPoints =  allHeatMapPoints.union(latLons_heatmap)

      //热力图 所有点
//      if(!"NaN,NaN".equals(center)){
//        println(StringUtils.concat("var heatmapData = [", latLons_heatmap_all, ",", "]"))
//        println()
//      }

      //热力图 画好的
//      if(!"NaN,NaN".equals(center)){
//        println(StringUtils.concat("var heatmapData = [", latLons_heatmap, ",", "]"))
//        println()
//      }

      //将结果插入数据库
      //保存数据库
      val sql = """insert into DIANPING_BUSINESS_AREA values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')""".format(
        cityBa._1
        ,cityBa._2
        ,""
        ,""
        ,"1"
        ,center
        ,radius
        ,baArea
        ,baDensity
        ,""
        ,geoHash6
        ,""
        ,System.currentTimeMillis()
      )
      DBEraser.insert(DB.ORACLE_7_BWSWD, sql)
    })

//    val heatMap = StringUtils.concat("var heatmapData = [", allHeatMapPoints, ",", "]")
//    println(heatMap)

  }
}
