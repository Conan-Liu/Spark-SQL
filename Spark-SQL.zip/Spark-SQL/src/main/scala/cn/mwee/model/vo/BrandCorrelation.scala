package cn.mwee.model.vo

/**
  * Created by tal on 01/12/2017.
  */
/**
  *
  * @param brand1
  * @param brand2
  * @param correlation
  */
case class BrandCorrelation(brand1: String, brand2: String, correlation: String, brand1cnt: String, brand2cnt: String, brand12cnt: String)
