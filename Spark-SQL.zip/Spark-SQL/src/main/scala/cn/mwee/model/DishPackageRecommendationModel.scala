package cn.mwee.model

import cn.mwee.model.vo.{ItemClsDetail, ItemClsIdDetail, ItemDetail}
import cn.mwee.util.DateUtils
import com.gnow.eraser.DBEraser
import com.gnow.schema.rdb
import com.gnow.{DB, Processor}

/**
  * Created by tal on 01/08/2017.
  */
class DishPackageRecommendationModel extends Processor{
  def reset(targetDate: String): Unit = {
    val monthId = targetDate.substring(0,7)
    val sql = "delete from mw_dish_recommend where month_id='%s'".format(monthId)
    println(sql)
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    //计算起始日期
    val startDay = DateUtils.getPreMonthDay(targetDate)
    val endDay = targetDate

    //Oracle
    rdb.basic.dfBeginAndEnd(rdb.basic.TB_SELL, startDay, endDay).printSchema()
    rdb.basic.dfBeginAndEnd(rdb.basic.TB_SELL_ORDER_ITEM, startDay, endDay).printSchema()
    rdb.basic.df(rdb.basic.ODS_SHOPTABLE).printSchema()
    rdb.basic.df(rdb.basic.C_SHOP_GOODTYPE).printSchema()

    //MySQL
    rdb.basic.df(rdb.basic.TB_SHOP).printSchema()
    rdb.basic.df(rdb.basic.TB_MENU_ITEM).printSchema()
    rdb.basic.df(rdb.basic.TB_MENU_CLS).printSchema()

    //计算每个门店每个就餐人次的样本量，太少的过滤掉,推荐时使用
    val filteredShopDF = sqlContext.sql(
      """
        |select t2.fs_shop_guid,
        |       t2.fi_cust_sum,
        |       t2.cnt
        |from (select t1.fs_shop_guid,
        |             t1.fi_cust_sum,
        |             count(1) cnt
        |      from tb_sell t1
        |      group by t1.fs_shop_guid,
        |               t1.fi_cust_sum) t2
        |where t2.cnt > 150
      """.stripMargin)
    filteredShopDF.registerTempTable("filteredShop")
    filteredShopDF.cache()
    filteredShopDF.show(20, false)

    //计算每个门店最新的菜单 快餐
    val menuClsKDF = sqlContext.sql(
      """
        |SELECT
        | mi.fs_shop_guid,
        |	mi.fi_item_cd,
        |	mi.fs_item_id,
        |	mi.fs_item_name,
        |	mi.fs_menu_cls_id,
        |	mc.fs_menu_cls_name
        |FROM
        |	tbmenuitem mi
        |LEFT JOIN tbmenucls mc ON mi.fs_shop_guid = mc.fs_shop_guid
        |                             AND
        |                             mc.fi_data_kind = 2
        |                             AND
        |                             mi.fs_menu_cls_id = mc.fs_menu_cls_id
        |join tbshop ts on ts.fs_shop_guid = mi.fs_shop_guid
        |                          and
        |                          ts.fs_food_trade_id in (1)
        |WHERE 1 = 1
        |      AND mi.fi_item_kind = 1
        |      AND mi.fi_status <> 13
        |      AND mi.fi_is_out =0
        |GROUP BY
        |     mi.fs_shop_guid,
        |	    mi.fi_item_cd,
        |	    mi.fs_item_id,
        |	    mi.fs_item_name,
        |	    mi.fs_menu_cls_id,
        |	    mc.fs_menu_cls_name
        |ORDER BY
        |	     mi.fi_item_cd
      """.stripMargin)
    menuClsKDF.registerTempTable("menuClsK")
    menuClsKDF.show(20, false)

    //计算每个门店最新的菜单 正餐
    val menuClsZDF = sqlContext.sql(
      """
        |SELECT
        | mi.fs_shop_guid,
        |	mi.fi_item_cd,
        |	mi.fs_item_id,
        |	mi.fs_item_name,
        |	mi.fs_menu_cls_id,
        |	mc.fs_menu_cls_name
        |FROM
        |	tbmenuitem mi
        |LEFT JOIN tbmenucls mc ON mi.fs_shop_guid = mc.fs_shop_guid
        |                             AND
        |                             mc.fi_data_kind = 2
        |                             AND
        |                             mi.fs_menu_cls_id = mc.fs_menu_cls_id
        |join tbshop ts on ts.fs_shop_guid = mi.fs_shop_guid
        |                          and
        |                          ts.fs_food_trade_id in (2,3)
        |WHERE 1 = 1
        |      AND mi.fi_item_kind = 1
        |      AND mi.fi_status <> 13
        |GROUP BY
        |     mi.fs_shop_guid,
        |	    mi.fi_item_cd,
        |	    mi.fs_item_id,
        |	    mi.fs_item_name,
        |	    mi.fs_menu_cls_id,
        |	    mc.fs_menu_cls_name
        |ORDER BY
        |	     mi.fi_item_cd
      """.stripMargin)
    menuClsZDF.registerTempTable("menuClsZ")
    menuClsZDF.show(20, false)

    //合并菜单信息
    val menuCls = menuClsKDF.unionAll(menuClsZDF).dropDuplicates(Seq("fs_shop_guid", "fs_item_id"))
    menuCls.registerTempTable("menuCls")

    //根据分类名与菜名进行过滤
    val orderDetailFilted = sqlContext.sql(
      """
        |select s1.shop_id,
        |       s1.shopname,
        |       s1.goodtype_name,
        |       s1.fs_sell_no,
        |       s1.fi_cust_sum,
        |       s1.item_id,
        |       s1.item_name,
        |       s1.fs_menu_cls_id,
        |       s1.fs_menu_cls_name
        |from (select u1.shop_id,
        |             mos.shopname,
        |             msg.goodtype_name,
        |             u1.fs_sell_no,
        |             u1.fi_cust_sum,
        |             u1.item_id,
        |             u1.item_name,
        |             mm.fs_menu_cls_id,
        |             mm.fs_menu_cls_name
        |        from (select t2.fs_shop_guid shop_id,
        |                     t1.fs_sell_no,
        |                     t2.fi_cust_sum,
        |                     t1.fi_item_cd item_id,
        |                     t1.fs_item_name item_name
        |                from tb_sell_order_item t1, tb_sell t2
        |               where t1.fi_item_make_ste >= 0
        |                     and
        |                     t2.fi_bill_status >= 0
        |                     and
        |                     t1.fs_sell_no = t2.fs_sell_no
        |                     and
        |                     t1.fs_shop_guid = t2.fs_shop_guid
        |                     and
        |                     t2.fi_bill_status > 2
        |                     and
        |                     t2.fs_sell_date >= '{startDay}'
        |                     and
        |                     t2.fs_sell_date <= '{endDay}'
        |                 ) u1
        |        join ods_shoptable mos on mos.shopid = u1.shop_id
        |                                  and
        |                                  mos.shopid != mos.manageshopid
        |                                  and
        |                                  mos.shopname is not null
        |                                  and
        |                                  mos.shopname not like '%测试%'
        |                                  and
        |                                  mos.shopname not like '%体验%'
        |        join tbshop ts on ts.fs_shop_guid = u1.shop_id
        |                          and
        |                          ts.fs_food_trade_id in (1,2,3)
        |        left join c_shop_goodtype msg on msg.goodtype_id = mos.shoptype
        |        join menuCls mm
        |                on mm.fs_shop_guid = u1.shop_id
        |                and
        |                mm.fi_item_cd = u1.item_id
        |        order by u1.fs_sell_no) s1
        |where
        |      s1.fs_menu_cls_name not in('饮料','软饮料','啤酒','黄酒','葡萄酒','白酒','米酒','茶水','龙虾配料','配料','调料类','其它','其他','其它类','其他类','其他商品','Drinks','Juice','特饮','加工费','服务费','全家幸福餐','花露','补折扣','年夜饭','店长推荐','楼面','店长推荐','十大必点菜','测试','ceshi','AAA','抽奖赠品','常用类','特价菜','顾客需求','酱料需求','器具需求','餐具','用餐','吧台用料','茶位','生啤','威士忌','酒水饮品','醉侠','甜品类','饮品类','畅饮时刻','鲜榨鲜饮','酒 水','酒水类','饮 料','啤酒类','茶','绿茶','酒烟类','烟','香烟','香烟系列','洋酒系列','白酒系列','啤酒系列','7月新番','当季新番','水果茶','主食','杂项','伴手礼','人气推荐')
        |      and
        |      s1.fs_menu_cls_name not like '%团餐'
        |      and
        |      s1.fs_menu_cls_name not like '%酒'
        |      and
        |      s1.fs_menu_cls_name not like '%水'
        |      and
        |      s1.fs_menu_cls_name not like '%酒水%'
        |      and
        |      s1.fs_menu_cls_name not like '%饮料%'
        |      and
        |      s1.fs_menu_cls_name not like '%外卖%'
        |      and
        |      s1.fs_menu_cls_name not like '%团购%'
        |      and
        |      s1.fs_menu_cls_name not like '%赠送%'
        |      and
        |      s1.fs_menu_cls_name not like '%套餐%'
        |      and
        |      s1.fs_menu_cls_name not like '%餐包费%'
        |      and
        |      s1.fs_menu_cls_name not like '%果汁'
        |      and
        |      s1.fs_menu_cls_name not like '%热饮'
        |      and
        |      s1.fs_menu_cls_name not like '%冷饮'
        |      and
        |      s1.fs_menu_cls_name not like '%软饮'
        |      and
        |      s1.fs_menu_cls_name not like '%饮品%'
        |      and
        |      s1.fs_menu_cls_name not like '%特饮%'
        |      and
        |      s1.fs_menu_cls_name not like '%甜品%'
        |      and
        |      s1.fs_menu_cls_name not like '%奶昔%'
        |      and
        |      s1.fs_menu_cls_name not like '%果昔%'
        |      and
        |      s1.fs_menu_cls_name not like '%鲜榨%'
        |      and
        |      s1.fs_menu_cls_name not like '%调料'
        |      and
        |      s1.fs_menu_cls_name not like '%手写单%'
        |      and
        |      s1.fs_menu_cls_name not like '%特价%'
        |      and
        |      s1.fs_menu_cls_name not like '其他%'
        |      and
        |      s1.fs_menu_cls_name not like '其它%'
        |      and
        |      s1.item_name not in('酸梅汤','餐包费','服务费','餐位费','茶位费','茶水费','自助费','台位费','闪惠买单','纸巾','餐包','餐巾纸','餐巾纸1','纸巾','盒纸巾','湿纸巾','香巾','湿 巾','湿巾','湿毛巾','一次性纸巾','茶位毛巾','茶位纸巾','纸巾盒','餐具','餐具包','餐盒','筷子','一次性筷子套包','一次性餐包','茶位','茶水(位)','位人','加杯','早餐','美团外卖','炭火','打包方盒','米饭','二米饭','茶位调料','自助小料','餐盒（小）')
        |      and
        |      s1.item_name not like '%酒'
        |      and
        |      s1.item_name not like '%米饭%'
        |      and
        |      s1.item_name not like '%汁'
        |      and
        |      s1.item_name not like '%酸梅汤'
        |      and
        |      s1.item_name not like '%调料包%'
        |      and
        |      s1.item_name not like '%奶昔'
        |      and
        |      s1.item_name not like '%赠%'
        |      and
        |      s1.item_name not like '%打包盒%'
        |      and
        |      s1.item_name not like '%餐具%'
        |      and
        |      s1.item_name not like '%餐盒%'
        |      and
        |      s1.item_name not like '%餐包%'
        |      and
        |      s1.item_name not like '%套包%'
        |      and
        |      s1.item_name not like '%马甲袋%'
        |      and
        |      s1.item_name not like '%会员免费%'
        |      and
        |      s1.item_name not like '%饮料袋%'
        |      and
        |      s1.item_name not like '%豆宝夹%'
        |      and
        |      s1.item_name not like '%早餐券%'
        |      and
        |      s1.item_name not like '%正餐券%'
        |      and
        |      s1.item_name not like '%纸巾%'
        |      and
        |      s1.item_name not like '%毛巾%'
        |      and
        |      s1.item_name not like '%单人餐%'
      """.stripMargin.replace("{startDay}", startDay).replace("{endDay}", endDay))

    orderDetailFilted.registerTempTable("orderDetailFilted")
    orderDetailFilted.cache()
    orderDetailFilted.show()

    //计算给定就餐人数时点菜个数的众数 用做给定就餐人数时推荐菜的总数，推荐时使用
    val  dishNumDS = sqlContext.sql(
      """
        |select t4.shop_id,
        |      t4.shopname,
        |      t4.goodtype_name,
        |      t4.fi_cust_sum,
        |      min(t4.item_count) item_count
        |from  (select tl.shop_id,
        |                tl.shopname,
        |                tl.goodtype_name,
        |                tl.fi_cust_sum,
        |                tr.item_count
        |        from  (select  t3.shop_id,
        |                      t3.shopname,
        |                      t3.goodtype_name,
        |                      t3.fi_cust_sum,
        |                      max(t3.pop_count) max_pop_count
        |              from  (select  t2.shop_id,
        |                            t2.shopname,
        |                            t2.goodtype_name,
        |                            t2.fi_cust_sum,
        |                            t2.item_count,
        |                            count(1) pop_count
        |                    from (select  t1.shop_id,
        |                                  t1.shopname,
        |                                  t1.goodtype_name,
        |                                  t1.fi_cust_sum,
        |                                  t1.fs_sell_no,
        |                                  count(1) item_count
        |                          from orderDetailFilted t1
        |                          group by t1.shop_id,
        |                                   t1.shopname,
        |                                   t1.goodtype_name,
        |                                   t1.fi_cust_sum,
        |                                   t1.fs_sell_no
        |                                    ) t2
        |                    group by  t2.shop_id,
        |                              t2.shopname,
        |                              t2.goodtype_name,
        |                              t2.fi_cust_sum,
        |                              t2.item_count) t3
        |              group by t3.shop_id,
        |                       t3.shopname,
        |                       t3.goodtype_name,
        |                       t3.fi_cust_sum) tl
        |        left join
        |              (select  t2.shop_id,
        |                        t2.shopname,
        |                        t2.goodtype_name,
        |                        t2.fi_cust_sum,
        |                        t2.item_count,
        |                        count(1) pop_count
        |                from (select  t1.shop_id,
        |                              t1.shopname,
        |                              t1.goodtype_name,
        |                              t1.fi_cust_sum,
        |                              t1.fs_sell_no,
        |                              count(1) item_count
        |                      from orderDetailFilted t1
        |                      group by t1.shop_id,
        |                               t1.shopname,
        |                               t1.goodtype_name,
        |                               t1.fi_cust_sum,
        |                               t1.fs_sell_no
        |                                ) t2
        |                group by  t2.shop_id,
        |                          t2.shopname,
        |                          t2.goodtype_name,
        |                          t2.fi_cust_sum,
        |                          t2.item_count) tr
        |        on tl.shop_id = tr.shop_id
        |           and
        |           tl.fi_cust_sum = tr.fi_cust_sum
        |           and
        |           tl.max_pop_count = tr.pop_count) t4
        |group by t4.shop_id,
        |        t4.shopname,
        |        t4.goodtype_name,
        |        t4.fi_cust_sum
        |order by t4.shop_id
      """.stripMargin)
    dishNumDS.show()
    dishNumDS.cache()
    dishNumDS.registerTempTable("dishNum")
    println("dishNumDS count: " + dishNumDS.select("shop_id").distinct().count())

    //计算每个类别的销量情况，推荐时使用
    val dishClsIdNumDS = sqlContext.sql(
      """
        |select t1.shop_id,
        |       t1.fi_cust_sum,
        |       t1.fs_menu_cls_name,
        |       count(distinct fs_sell_no) cnt
        |from orderDetailFilted t1
        |group by t1.shop_id,
        |         t1.fi_cust_sum,
        |         t1.fs_menu_cls_name
      """.stripMargin)
    dishClsIdNumDS.registerTempTable("dishClsIdNum")
    dishClsIdNumDS.cache()
    println("每个类别的销量情况:")
    dishClsIdNumDS.show()

    //计算每个类别应该推荐几个菜，推荐时使用
    val dishClsNumDS = sqlContext.sql(
      """
        |select t4.shop_id,
        |        t4.shopname,
        |        t4.goodtype_name,
        |        t4.fi_cust_sum,
        |        t4.fs_menu_cls_name,
        |        min(t4.item_count) item_count
        |from   (select tl.shop_id,
        |                tl.shopname,
        |                tl.goodtype_name,
        |                tl.fi_cust_sum,
        |                tl.fs_menu_cls_name,
        |                tr.item_count
        |        from  (select  t3.shop_id,
        |                      t3.shopname,
        |                      t3.goodtype_name,
        |                      t3.fi_cust_sum,
        |                      t3.fs_menu_cls_name,
        |                      max(t3.pop_count) max_pop_count
        |              from  (select  t2.shop_id,
        |                            t2.shopname,
        |                            t2.goodtype_name,
        |                            t2.fi_cust_sum,
        |                            t2.fs_menu_cls_name,
        |                            t2.item_count,
        |                            count(1) pop_count
        |                    from (select  t1.shop_id,
        |                                  t1.shopname,
        |                                  t1.goodtype_name,
        |                                  t1.fi_cust_sum,
        |                                  t1.fs_sell_no,
        |                                  t1.fs_menu_cls_name,
        |                                  count(1) item_count
        |                          from orderDetailFilted t1
        |                          group by t1.shop_id,
        |                                   t1.shopname,
        |                                   t1.goodtype_name,
        |                                   t1.fi_cust_sum,
        |                                   t1.fs_sell_no,
        |                                   t1.fs_menu_cls_name
        |                                    ) t2
        |                    group by  t2.shop_id,
        |                              t2.shopname,
        |                              t2.goodtype_name,
        |                              t2.fi_cust_sum,
        |                              t2.item_count,
        |                              t2.fs_menu_cls_name) t3
        |              group by t3.shop_id,
        |                       t3.shopname,
        |                       t3.goodtype_name,
        |                       t3.fi_cust_sum,
        |                       t3.fs_menu_cls_name) tl
        |        left join
        |              (select  t2.shop_id,
        |                        t2.shopname,
        |                        t2.goodtype_name,
        |                        t2.fi_cust_sum,
        |                        t2.item_count,
        |                        t2.fs_menu_cls_name,
        |                        count(1) pop_count
        |                from (select  t1.shop_id,
        |                              t1.shopname,
        |                              t1.goodtype_name,
        |                              t1.fi_cust_sum,
        |                              t1.fs_sell_no,
        |                              t1.fs_menu_cls_name,
        |                              count(1) item_count
        |                      from orderDetailFilted t1
        |                      group by t1.shop_id,
        |                               t1.shopname,
        |                               t1.goodtype_name,
        |                               t1.fi_cust_sum,
        |                               t1.fs_sell_no,
        |                               t1.fs_menu_cls_name
        |                                ) t2
        |                group by  t2.shop_id,
        |                          t2.shopname,
        |                          t2.goodtype_name,
        |                          t2.fi_cust_sum,
        |                          t2.item_count,
        |                          t2.fs_menu_cls_name) tr
        |        on tl.shop_id = tr.shop_id
        |           and
        |           tl.fi_cust_sum = tr.fi_cust_sum
        |           and
        |           tl.max_pop_count = tr.pop_count) t4
        |group by t4.shop_id,
        |        t4.shopname,
        |        t4.goodtype_name,
        |        t4.fi_cust_sum,
        |        t4.fs_menu_cls_name
        |order by t4.shop_id
      """.stripMargin)
    dishClsNumDS.show()
    dishClsNumDS.cache()
    dishClsNumDS.registerTempTable("dishClsNum")

    //计算热销菜品 推荐时使用
    val hotDishDS = sqlContext.sql(
      """
        |select t1.shop_id,
        |       t1.shopname,
        |       t1.goodtype_name,
        |       t1.item_id,
        |       t1.item_name,
        |       t1.fs_menu_cls_name,
        |       count(t1.fs_sell_no) item_count
        |from orderDetailFilted t1
        |group by t1.shop_id,
        |         t1.shopname,
        |         t1.goodtype_name,
        |         t1.item_id,
        |         t1.item_name,
        |         t1.fs_menu_cls_name
        |order by t1.item_id
      """.stripMargin)
    hotDishDS.show(20, false)
    hotDishDS.cache()
    hotDishDS.registerTempTable("hotDish")

    //开始推荐
    //推荐菜品倍数
    val ratio = 3
    //排名限制
    val rankLimit = 20

    //推荐计算
    // 166352 老胡同日月光店
//    dishNumDS.where("shop_id=\'103783\'").rdd.collect().foreach(row => { //test
    dishNumDS.rdd.collect().foreach(row => {
      //获取每个门店就餐人数推荐菜品数
      val shopId = row.get(0)
      val shopName = row.get(1)
      val goodTypeName = row.get(2)
      val custSum = row.get(3)
      val itemCount = row.get(4)
      println(shopName)
      println("就餐人数：" + custSum)

      //判断这个店铺这个就餐人数是否推荐
      val filteredShop = filteredShopDF.where("fs_shop_guid=\'" + shopId + "\' and fi_cust_sum=\'" + custSum + "\'").rdd.collect()
      if(filteredShop.size > 0){
        println("-------------------------START-----------------------------")

        //样本数
        val sampleCnt = filteredShop(0).get(2)

        //推荐菜个数
        val recNum = Integer.parseInt(itemCount.toString)

        //获取每个分类推荐菜数
        val dishClsNumList = dishClsNumDS.where("shop_id=\'" + shopId + "\' and fi_cust_sum=\'" + custSum + "\'")
          .rdd
          .map(row => ItemClsDetail(row.get(0).toString, row.get(1).toString, row.get(2).toString, row.get(3).toString, row.get(4).toString, row.get(5).toString))
          .collect()

        //获取每个分类的热销程度
        val dishClsIdNumList = dishClsIdNumDS.where("shop_id=\'" + shopId + "\' and fi_cust_sum=\'" + custSum + "\'")
          .rdd
          .map(row => ItemClsIdDetail(row.get(0).toString, row.get(1).toString, row.get(2).toString, row.get(3).toString))
          .collect()
          .sortBy(item => - Integer.parseInt(item.cnt))

        //计算最终用来推荐的分类
        var sum_flag = 0
        val dishClsList = dishClsIdNumList.filter(itemClsIdDetail => {
          val num = dishClsNumList.filter(item => item.clsName.equals(itemClsIdDetail.clsName))
          if(sum_flag < recNum){
            sum_flag = sum_flag + num(0).itemCount.toInt
            true
          } else {
            false
          }
        }).map(item => item.clsName)

        //获取热销菜品
        val hotDishList = hotDishDS.where("shop_id=\'" + shopId + "\'")
          .rdd
          .map(row => ItemDetail(row.get(0).toString, row.get(1).toString, row.get(2).toString, row.get(3).toString, row.get(4).toString, row.get(5).toString, row.get(6).toString))
          .sortBy(item => - Integer.parseInt(item.itemCount))
          .collect().sortBy(item => - Integer.parseInt(item.itemCount))

        //排名20以内的热销菜品
        val hotDishListLimit = hotDishList.take(rankLimit)

        //计算每个分类的推荐菜
        dishClsNumList.foreach(itemClsDetail =>{
          if(dishClsList.contains(itemClsDetail.clsName)){
            //确定推荐这个分类推荐几个菜
            val clsRecNum = Integer.parseInt(itemClsDetail.itemCount) //至少
            val clsRecNumTriple = ratio * Integer.parseInt(itemClsDetail.itemCount) //最多

            var rec = ""
            //从排名20以内的热销菜中找
            var recDish = hotDishListLimit.filter((item) => item.clsName.equals(itemClsDetail.clsName)).take(clsRecNumTriple)
            //如果找到的菜个数小于应该推荐的个数,在所有菜品中找到指定数量的菜数
            if(recDish.size < clsRecNum){
              recDish = hotDishList.filter((item) => item.clsName.equals(itemClsDetail.clsName)).take(clsRecNum)
            }
            recDish.foreach(item => rec += item.itemName + "||")
            rec = rec.substring(0, rec.length - 2)
            println("clsRecNum: " + rec)

            //保存数据库
            val sql = """insert into mw_dish_recommend values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')""".format(
              shopId
              ,shopName
              ,goodTypeName
              ,custSum
              ,recNum
              ,itemClsDetail.clsName
              ,clsRecNum
              ,recDish.size
              ,rec
              ,sampleCnt
              ,targetDate.substring(0,7)
              ,System.currentTimeMillis()
            )
            DBEraser.insert(DB.ORACLE_37_BWSWD, sql)
          }
        })
        println("--------------------------END----------------------------")
      }
    })
  }
}
