package cn.mwee.model

import cn.mwee.model.vo.{BrandCorrelation, Correlation, RelatedBrands}
import cn.mwee.util.DateUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.{RDBReader, RDBWriter}
import com.gnow.schema.{crawler, rdb}
import com.gnow.{DB, Processor}
import org.apache.spark.mllib.linalg.Vectors

import scala.collection.mutable.ListBuffer

/**
  * Created by tal on 29/11/2017.
  */
class AddrLocationgBaRecommendModel extends Processor{
  val bakTable = "dm_mwboss_bc_recommend_bk"
  val destTable = "dm_mwboss_bc_recommend"
  val db = DB.ORACLE_37_BWSWD

  def reset(targetDate: String): Unit = {
    //备份老数据
    val sqlBak = "insert into %s select * from %s".format(bakTable, destTable)
    DBEraser.remove(db, sqlBak)

    val sql = "delete from %s".format(destTable)
    println("删除db数据: " + db.toString)
    println("run: " + sql)
    println()
    DBEraser.remove(db, sql)

  }

  def execute(targetDate: String, input: String, output: String) = {

    process(targetDate, input: String, output: String)

    println("Happy Ending!")
  }

  def process(targetDate: String, input: String, output: String) = {
    import sqlContext.implicits._

    //起始日期
    val startDate = DateUtils.getMonthLastDay(targetDate , -3)
    val endDate = targetDate

    /**
      * 读取Oracle数据
      */
    println("读取Oracle数据")
    //日期C表
    val cDateDailyDS = rdb.oracle.c.ds(rdb.oracle.c.C_DATE_DAILY)
    println("schema of cDateDailyDS:")
    cDateDailyDS.printSchema()
    //品牌C表
    val cShopBrandDS = rdb.oracle.c.ds(rdb.oracle.c.C_SHOP_BRAND)
    println("schema of cShopBrandDS:")
    cShopBrandDS.printSchema()
    //店铺C表
    val cShopInfomationDS = rdb.oracle.c.ds(rdb.oracle.c.C_SHOP_INFORMATION)
    println("schema of cShopInfomationDS:")
    cShopInfomationDS.printSchema()
    //店铺商圈C表
    val cRelaShopbcDS = rdb.oracle.c.ds(rdb.oracle.c.C_RELA_SHOPBC)
    println("schema of cRelaShopbcDS:")
    cRelaShopbcDS.printSchema()
    //预订C表
    val cBookShopDS = rdb.oracle.c.ds(rdb.oracle.c.C_BOOK_SHOP)
    println("schema of cBookShopDS:")
    cBookShopDS.printSchema()
    //支付数据
    val dmCashDailyDS = rdb.oracle.dm.dsBeginAndEnd(rdb.oracle.dm.DM_CASH_DAILY, startDate, endDate)
    println("schema of dmCashDailyDS:")
    dmCashDailyDS.printSchema()
    //点菜数据
    val dmOrderShopMbossDDS = rdb.oracle.dm.dsBeginAndEnd(rdb.oracle.dm.DM_ORDER_SHOP_MBOSS_D, startDate, endDate)
    println("schema of dmOrderShopMbossDDS:")
    dmOrderShopMbossDDS.printSchema()
    //预订数据
    val dwBookDailyDS = rdb.oracle.dw.dsBeginAndEnd(rdb.oracle.dw.DW_BOOK_DAILY, startDate, endDate)
    println("schema of dwBookDailyDS:")
    dwBookDailyDS.printSchema()
    //排队数据
    val dwQueueDailyDS = rdb.oracle.dw.dsBeginAndEnd(rdb.oracle.dw.DW_QUEUE_DAILY, startDate, endDate)
    println("schema of dwQueueDailyDS:")
    dwQueueDailyDS.printSchema()
    //会员数据 手机号中有11111111111和10000000000的是测试数据，或者服务员为了占位用的
    val dwMemberHistoryDS = rdb.oracle.dw.dsBeginAndEnd(rdb.oracle.dw.DW_MEMBER_HISTORY, "2018-01-01", endDate)
    println("schema of dwMemberHistoryDS:")
    dwMemberHistoryDS.printSchema()
    //ods shop表
    val odsShoptableDS = rdb.oracle.ods.ds(rdb.oracle.ods.ODS_SHOPTABLE)
    println("schema of odsShoptableDS:")
    odsShoptableDS.printSchema()

    /**
      * 读取爬虫数据
      */
    println("读取爬虫数据")
    //点评城市数据
    val dpCityDS = sqlContext.read.parquet("/crawler/parquet/dianping/" + crawler.parquet.dianping.DIANPING_CITY)
    dpCityDS.createOrReplaceTempView("dianping_city")
    println("schema of dpCityDS:")
    dpCityDS.printSchema()
    //点评分类数据
    val dpCategoryDS = sqlContext.read.parquet("/crawler/parquet/dianping/" + crawler.parquet.dianping.DIANPING_CATEGORY)
    dpCategoryDS.createOrReplaceTempView("dianping_category")
    println("schema of dpCategoryDS:")
    dpCategoryDS.printSchema()
    //点评商圈数据
    val dpBaDS = sqlContext.read.parquet("/crawler/parquet/dianping/" + crawler.parquet.dianping.DIANPING_BUSINESS_AREA)
    dpBaDS.createOrReplaceTempView("dianping_business_area")
    println("schema of dpBaDS:")
    dpBaDS.printSchema()
    //点评美食数据
    val dpDishDS = sqlContext.read.parquet("/crawler/parquet/dianping/" + crawler.parquet.dianping.DIANPING_SHOP_DISH + "/2017-12")
    dpDishDS.createOrReplaceTempView("dianping_shop_dish")
    dpDishDS.cache()
    println("schema of dpDishDS:")
    dpDishDS.printSchema()
    //点评非餐饮数据
    val dpShopDS = sqlContext.read.parquet("/crawler/parquet/dianping/" + crawler.parquet.dianping.DIANPING_SHOP + "/2017-11")
    dpShopDS.createOrReplaceTempView("dianping_shop")
    println("schema of dpShopDS:")
    dpShopDS.printSchema()
    //点评营业时间数据
    val dpShopServiceTimeDS = sqlContext.read.parquet("/crawler/parquet/dianping/" + crawler.parquet.dianping.DIANPING_SHOP_SERVICE_TIME + "/2017-11")
    dpShopServiceTimeDS.createOrReplaceTempView("dianping_shop_service_time")
    println("schema of dpShopServiceTimeDS:")
    dpShopServiceTimeDS.printSchema()

    /**
      * step1: 计算优质参考门店
      */
    //所有门店
    val shopDS = sqlContext.sql(
      """
        |select manageshopid,
        |       brand_name,
        |       brand_shop_qty,
        |       dianpingid,
        |       shopid,
        |       shopname,
        |       top_queue_shop,
        |       top_review_shop,
        |       top_book_shop,
        |       top_order_shop,
        |       top_pay_shop
        |  from (select distinct ss.manageshopid,
        |                        ss.brand_name,
        |                        ss.brand_shop_qty,
        |                        ss.dianpingid,
        |                        ss.shopid,
        |                        ss.shopname,
        |                        brand_queue_shop_qty,
        |                        (case
        |                          when (brand_queue_shop_qty > 0 and
        |                               rr_mean_queue_qty_normalize > 0.5) then
        |                           ss.shopid
        |                        end) top_queue_shop, ----有排队就用排队
        |                        (case
        |                          when (brand_queue_shop_qty = 0 and
        |                               brand_review_shop_qty != 0 and
        |                               rr_review_count_normalize > 0.8) then
        |                           ss.shopid
        |                        end) top_review_shop, ----无排队有评论门店就用评论门店
        |                        (case
        |                          when (brand_queue_shop_qty = 0 and
        |                               brand_review_shop_qty = 0 and
        |                               rr_mean_BOOK_QTY_normalize > 0.8) then
        |                           ss.shopid
        |                        end) top_book_shop, ---无排队、无评论门店就用预订top20%、点菜top20%、支付top20% 或的关系（TODO：需结合点评评论数，商户未必全部使用我们的预订、点菜、支付）
        |                        (case
        |                          when (brand_queue_shop_qty = 0 and
        |                               brand_review_shop_qty = 0 and
        |                               rr_mean_order_amount_normalize > 0.8) then
        |                           ss.shopid
        |                        end) top_order_shop,
        |                        (case
        |                          when (brand_queue_shop_qty = 0 and
        |                               brand_review_shop_qty = 0 and
        |                               rr_mean_all_paid_normalize > 0.8) then
        |                           ss.shopid
        |                        end) top_pay_shop
        |          from (select mos.manageshopid,
        |                       m_big_brand.brand_name,
        |                       m_big_brand.brand_shop_qty,
        |                       mos.dianpingid,
        |                       mos.shopid,
        |                       mos.shopname,
        |                       nvl(max(dp.brand_review_shop_qty)
        |                           over(partition by mos.manageshopid),
        |                           0) brand_review_shop_qty, ---品牌有评论数（评论数不为0）的门店数
        |                       dp.rr_review_count_normalize, ---评论数排名
        |                       nvl(max(m_queue.brand_queue_shop_qty)
        |                           over(partition by mos.manageshopid),
        |                           0) brand_queue_shop_qty, ---品牌有排队出单量的门店数
        |                       m_queue.rr_mean_queue_qty_normalize, ---日均排队出单量排名（归一化）
        |                       m_book.rr_mean_BOOK_QTY_normalize, ---日均预订出单量排名（归一化）
        |                       m_order.rr_mean_order_amount_normalize, ---日均营业额排名（归一化）
        |                       m_pay.rr_mean_all_paid_normalize ---日均总支付金额排名（归一化）
        |                  from ods_shoptable mos
        |                  left join (select *
        |                              from (select manageshopid,
        |                                           mc.brand_name,
        |                                           count(shopid) brand_shop_qty
        |                                      from ods_shoptable mot
        |                                      left join c_shop_brand mc on mc.brand_id =
        |                                                                   mot.manageshopid
        |                                     where mot.shopname not like '%测试%'
        |                                       and mot.tiyandian = 0
        |                                       and mot.type_ = 2
        |                                       and mot.shopid != mot.manageshopid
        |                                       and mot.manageshopid != 43
        |                                       and nvl(mot.dianpingid, 0) != 0 ---51923
        |                                     group by manageshopid, mc.brand_name ---46006
        |                                    )
        |                             where brand_shop_qty >= 1 ---3291
        |                            ) m_big_brand on m_big_brand.manageshopid =
        |                                             mos.manageshopid
        |
        |                  left join ( --------------------------------点评----评论数-------------------------
        |                            select t2.dianpingid,
        |                                    t2.manageshopid,
        |                                    t2.shopid,
        |                                    t2.shopname,
        |                                    t2.review_count, ---评论数
        |                                    rr_review_count, ---评论数排名
        |                                    count(case
        |                                            when review_count != 0 then
        |                                             shopid
        |                                          end) over(partition by manageshopid) brand_review_shop_qty, ---品牌有评论数（评论数不为0）的门店数
        |                                    (count(shopid)
        |                                     over(partition by manageshopid) -
        |                                     rr_review_count + 1) / count(shopid) over(partition by manageshopid) rr_review_count_normalize ---评论数排名（归一化）
        |                              from (select t1.dianpingid,
        |                                            t1.manageshopid,
        |                                            t1.shopid,
        |                                            t1.shopname,
        |                                            t1.review_count,
        |                                            row_number() over(partition by manageshopid order by review_count desc) rr_review_count
        |                                       from (select mos.dianpingid,
        |                                                    mos.manageshopid,
        |                                                    mos.shopid,
        |                                                    mos.shopname,
        |                                                    nvl(dp.review_count, 0) review_count
        |                                               from dianping_shop_dish dp
        |                                              inner join ods_shoptable mos on mos.dianpingid =
        |                                                                                       dp.shop_id
        |                                              where mos.shopid !=
        |                                                    mos.manageshopid
        |                                                and mos.dianpingid != 0) t1) t2) dp on dp.dianpingid =
        |                                                                                       mos.dianpingid
        |                  left join
        |
        |                 ( ---------------------------------排队------------18843----------------------------
        |                 select t2.dianpingid,
        |                         t2.manageshopid,
        |                         t2.shopid,
        |                         t2.shopname,
        |                         t2.mean_queue_qty, ---日均排队出单量
        |                         rr_mean_queue_qty, ---日均排队出单量排名
        |                         count(shopid) over(partition by manageshopid) brand_queue_shop_qty, ---品牌有排队出单量的门店数
        |                         (count(shopid)
        |                          over(partition by manageshopid) - rr_mean_queue_qty + 1) /
        |                         count(shopid) over(partition by manageshopid) rr_mean_queue_qty_normalize ---日均排队出单量排名（归一化）
        |                   from (select t1.dianpingid,
        |                                 t1.manageshopid,
        |                                 t1.shopid,
        |                                 t1.shopname,
        |                                 t1.mean_queue_qty,
        |                                 row_number() over(partition by manageshopid order by mean_queue_qty desc) rr_mean_queue_qty
        |                            from (select mos.dianpingid,
        |                                         mos.manageshopid,
        |                                         mos.shopid,
        |                                         mos.shopname,
        |                                         sum(mq.queue_qty) / 61 mean_queue_qty
        |                                    from DW_QUEUE_DAILY mq
        |                                   inner join c_date_daily mc on mc.daily_key =
        |                                                                          mq.daily_key
        |                                   inner join c_shop_information mi on mi.shop_key =
        |                                                                                mq.shop_key
        |                                   inner join ods_shoptable mos on mos.shopid =
        |                                                                            mi.shop_id
        |                                   where mq.qeuestate_key = 5
        |                                     and mc.day_id >=
        |                                         to_date('2017-09-01 00:00:00')
        |                                     and mc.day_id <=
        |                                         to_date('2017-10-31 00:00:00')
        |                                        /*                               and mos.manageshopid = 35124
        |                                                                                                                                                        */
        |                                     and mos.shopid != mos.manageshopid
        |                                        /*                               and mos.shopname like '%云海肴%'
        |                                                                                                                                                        */
        |                                     and mos.dianpingid != 0
        |                                   group by mos.dianpingid,
        |                                            mos.manageshopid,
        |                                            mos.shopid,
        |                                            mos.shopname) t1) t2) m_queue on m_queue.shopid =
        |                                                                             mos.shopid
        |                  left join
        |
        |                 ( --------------------------------预订-------------------------16729------------------
        |                 select t2.dianpingid,
        |                         t2.manageshopid,
        |                         t2.shopid,
        |                         t2.shopname,
        |                         t2.mean_BOOK_QTY, ---日均预订出单量
        |                         rr_mean_BOOK_QTY, ---日均预订出单量排名
        |                         (count(shopid)
        |                          over(partition by manageshopid) - rr_mean_BOOK_QTY + 1) /
        |                         count(shopid) over(partition by manageshopid) rr_mean_BOOK_QTY_normalize ---日均预订出单量排名（归一化）
        |                   from (
        |
        |                          select t1.dianpingid,
        |                                  t1.manageshopid,
        |                                  t1.shopid,
        |                                  t1.shopname,
        |                                  t1.mean_BOOK_QTY,
        |                                  row_number() over(partition by manageshopid order by mean_BOOK_QTY desc) rr_mean_BOOK_QTY
        |                            from (select mos.dianpingid,
        |                                          mos.manageshopid,
        |                                          mos.shopid,
        |                                          mos.shopname,
        |                                          sum(mbook.BOOK_QTY) / 61 mean_BOOK_QTY
        |                                     from dw_book_daily mbook
        |                                    inner join c_date_daily mc on mc.daily_key =
        |                                                                           mbook.daily_key
        |                                    inner join c_book_shop ms on ms.shop_key =
        |                                                                          mbook.shop_key
        |                                    inner join ods_shoptable mos on mos.shopid =
        |                                                                             ms.shop_id
        |                                    where mc.day_id >=
        |                                          to_date('2017-09-01 00:00:00')
        |                                      and mc.day_id <=
        |                                          to_date('2017-10-31 00:00:00')
        |                                         /*and mos.manageshopid = 35124*/
        |                                      and mos.shopid != mos.manageshopid
        |                                         /*and mos.shopname like '%云海肴%'*/
        |                                      and mos.dianpingid != 0
        |                                    group by mos.dianpingid,
        |                                             mos.manageshopid,
        |                                             mos.shopid,
        |                                             mos.shopname) t1) t2) m_book on m_book.shopid =
        |                                                                             mos.shopid
        |
        |                  left join (
        |                            ---------------------------------点菜------------11545----------------------------
        |                            select t2.dianpingid,
        |                                    t2.manageshopid,
        |                                    t2.shopid,
        |                                    t2.shopname,
        |                                    t2.mean_order_amount, ---日均营业额
        |                                    rr_mean_order_amount, ---日均营业额排名
        |                                    (count(shopid)
        |                                     over(partition by manageshopid) -
        |                                     rr_mean_order_amount + 1) / count(shopid) over(partition by manageshopid) rr_mean_order_amount_normalize ---日均排营业额排名（归一化）
        |                              from (select t1.dianpingid,
        |                                            t1.manageshopid,
        |                                            t1.shopid,
        |                                            t1.shopname,
        |                                            t1.mean_order_amount,
        |                                            row_number() over(partition by manageshopid order by mean_order_amount desc) rr_mean_order_amount
        |                                       from (select mos.dianpingid,
        |                                                    mos.manageshopid,
        |                                                    mos.shopid,
        |                                                    mos.shopname,
        |                                                    sum(morder.order_amount) / 61 mean_order_amount
        |                                               from DM_ORDER_SHOP_MBOSS_D morder
        |                                              inner join c_date_daily mc on mc.day_id =
        |                                                                                     morder.day_id
        |                                              inner join ods_shoptable mos on mos.shopid =
        |                                                                                       morder.shopid
        |                                              where mc.day_id >=
        |                                                    to_date('2017-08-01')
        |                                                and mc.day_id <=
        |                                                    to_date('2017-09-30')
        |                                                   /*                               and mos.manageshopid = 35124
        |                                                                                                                                                                                                    */
        |                                                and mos.shopid !=
        |                                                    mos.manageshopid
        |                                                   /*                               and mos.shopname like '%云海肴%'
        |                                                                                                                                                                                                    */
        |                                                and mos.dianpingid != 0
        |                                              group by mos.dianpingid,
        |                                                       mos.manageshopid,
        |                                                       mos.shopid,
        |                                                       mos.shopname) t1) t2) m_order on m_order.shopid =
        |                                                                                        mos.shopid
        |                  left join
        |
        |                 (
        |                 ---------------------------------支付------------11271----------------------------
        |                 select t2.dianpingid,
        |                         t2.manageshopid,
        |                         t2.shopid,
        |                         t2.shopname,
        |                         t2.mean_all_paid, ---日均总支付金额
        |                         rr_mean_all_paid, ---日均总支付金额排名
        |                         (count(shopid)
        |                          over(partition by manageshopid) - rr_mean_all_paid + 1) /
        |                         count(shopid) over(partition by manageshopid) rr_mean_all_paid_normalize ---日均总支付金额排名（归一化）
        |                   from (select t1.dianpingid,
        |                                 t1.manageshopid,
        |                                 t1.shopid,
        |                                 t1.shopname,
        |                                 t1.mean_all_paid,
        |                                 row_number() over(partition by manageshopid order by mean_all_paid desc) rr_mean_all_paid
        |                            from (select mos.dianpingid,
        |                                         mos.manageshopid,
        |                                         mos.shopid,
        |                                         mos.shopname,
        |                                         sum(nvl(m_pay.cash_totalpay, 0) +
        |                                             nvl(cash_fastpay, 0) +
        |                                             nvl(cash_scangun_pay, 0) +
        |                                             nvl(cash_scan_pay, 0)) / 61 mean_all_paid --总支付金额
        |                                    from dm_cash_daily m_pay
        |                                   inner join ods_shoptable mos on mos.shopid =
        |                                                                            m_pay.shop_id
        |                                   where m_pay.day_id >=
        |                                         to_date('2017-09-01 00:00:00')
        |                                     and m_pay.day_id <=
        |                                         to_date('2017-10-31 00:00:00')
        |                                        /*                               and mos.manageshopid = 35124
        |                                                                                                                                                        */
        |                                     and mos.shopid != mos.manageshopid
        |                                        /*                               and mos.shopname like '%云海肴%'
        |                                                                                                                                                        */
        |                                     and mos.dianpingid != 0
        |                                   group by mos.dianpingid,
        |                                            mos.manageshopid,
        |                                            mos.shopid,
        |                                            mos.shopname) t1
        |                           where t1.mean_all_paid > 0) t2) m_pay on m_pay.shopid =
        |                                                                    mos.shopid
        |                 where mos.shopname not like '%测试%'
        |                   and mos.tiyandian = 0
        |                   and mos.type_ = 2
        |                   and mos.manageshopid != 43
        |                   and mos.shopid != mos.manageshopid
        |                   and nvl(mos.dianpingid, 0) != 0 ----先看点评ID不等于0的门店（看所有品牌的话，品牌内部分分店有点评ID的品牌占90%左右）
        |                ) ss) ---92786
        | where (top_queue_shop is not null or top_review_shop is not null or
        |       top_book_shop is not null or top_order_shop is not null or
        |       top_pay_shop is not null)
        |   and brand_shop_qty >= 1
      """.stripMargin)
    //所有门店
    shopDS.createOrReplaceTempView("shop")
    shopDS.cache()
    //计算所有门店所在商圈
    val shopBaDSTmp = sqlContext.sql(
      """
        |select          mcr.manageshopid,
        |                mcr.brand_name,
        |                mc.city_id,
        |                mc.city_name,
        |                mc.business_area_id,
        |                mc.business_area_name,
        |                mct.sec_cat,
        |                mct.sec_cat_name
        |  from shop mcr --8094
        | inner join dianping_shop_dish dp on dp.shop_id = mcr.dianpingid ---品牌维度，2481个信息完整的品牌
        |
        | inner join DIANPING_CITY mc on mc.city_id = dp.city_id
        |                            and mc.business_area_id = dp.business_area_id
        |                            and mc.BUSINESS_AREA_NAME not like '%其他%' ---品牌维度，2425条有商圈的品牌
        | inner join DIANPING_CATEGORY mct on mct.sec_cat = dp.sec_cat
        |                                 and mct.pri_cat = dp.pri_cat
        |                                 and mct.city_id = dp.city_id ---3373    ---品牌维度，1503条有商圈、有菜系的品牌
        | where nvl(dp.avg_price, 0) is not null
      """.stripMargin)
    shopBaDSTmp.createOrReplaceTempView("shop_business_area_tmp")
    //对品牌菜系进行修正 修正逻辑：所有品牌门店中菜系门店最多的视作该品牌的菜系
    val shopBaDS = sqlContext.sql(
      """
        |select
        |	t0.manageshopid,
        |	t0.brand_name,
        |	t0.city_id,
        |	t0.city_name,
        |	t0.business_area_id,
        |	t0.business_area_name,
        |	t4.sec_cat,
        |	t4.sec_cat_name
        |from
        |	(select distinct manageshopid,brand_name,city_id,city_name,business_area_id,business_area_name from shop_business_area_tmp) t0
        |inner join
        |	(select
        |		t3.manageshopid,
        |		t3.sec_cat,
        |		t3.sec_cat_name
        |	from
        |		(select
        |			t2.manageshopid,
        |			t2.sec_cat,
        |			t2.sec_cat_name,
        |			row_number() over(partition by t2.manageshopid order by cnt desc) rn
        |		from
        |			(select
        |				t1.manageshopid,
        |			    t1.sec_cat,
        |			    t1.sec_cat_name,
        |			    count(1) cnt
        |			from
        |				shop_business_area_tmp t1
        |			group by
        |				t1.manageshopid,
        |			    t1.sec_cat,
        |			    t1.sec_cat_name) t2) t3
        |	where
        |		t3.rn = 1) t4
        |on
        |	t0.manageshopid = t4.manageshopid
        |
      """.stripMargin)
    shopBaDS.createOrReplaceTempView("shop_business_area")
    shopBaDS.cache()
    shopBaDS.show()
    //优质门店
    val goodShopDS = sqlContext.sql(
      """
        |select manageshopid,
        |       brand_name,
        |       brand_shop_qty,
        |       dianpingid,
        |       shopid,
        |       shopname,
        |       top_queue_shop,
        |       top_review_shop,
        |       top_book_shop,
        |       top_order_shop,
        |       top_pay_shop
        |  from (select distinct ss.manageshopid,
        |                        ss.brand_name,
        |                        ss.brand_shop_qty,
        |                        ss.dianpingid,
        |                        ss.shopid,
        |                        ss.shopname,
        |                        brand_queue_shop_qty,
        |                        (case
        |                          when (brand_queue_shop_qty > 0 and
        |                               rr_mean_queue_qty_normalize > 0.5) then
        |                           ss.shopid
        |                        end) top_queue_shop, ----有排队就用排队
        |                        (case
        |                          when (brand_queue_shop_qty = 0 and
        |                               brand_review_shop_qty != 0 and
        |                               rr_review_count_normalize > 0.8) then
        |                           ss.shopid
        |                        end) top_review_shop, ----无排队有评论门店就用评论门店
        |                        (case
        |                          when (brand_queue_shop_qty = 0 and
        |                               brand_review_shop_qty = 0 and
        |                               rr_mean_BOOK_QTY_normalize > 0.8) then
        |                           ss.shopid
        |                        end) top_book_shop, ---无排队、无评论门店就用预订top20%、点菜top20%、支付top20% 或的关系（TODO：需结合点评评论数，商户未必全部使用我们的预订、点菜、支付）
        |                        (case
        |                          when (brand_queue_shop_qty = 0 and
        |                               brand_review_shop_qty = 0 and
        |                               rr_mean_order_amount_normalize > 0.8) then
        |                           ss.shopid
        |                        end) top_order_shop,
        |                        (case
        |                          when (brand_queue_shop_qty = 0 and
        |                               brand_review_shop_qty = 0 and
        |                               rr_mean_all_paid_normalize > 0.8) then
        |                           ss.shopid
        |                        end) top_pay_shop
        |          from (select mos.manageshopid,
        |                       m_big_brand.brand_name,
        |                       m_big_brand.brand_shop_qty,
        |                       mos.dianpingid,
        |                       mos.shopid,
        |                       mos.shopname,
        |                       nvl(max(dp.brand_review_shop_qty)
        |                           over(partition by mos.manageshopid),
        |                           0) brand_review_shop_qty, ---品牌有评论数（评论数不为0）的门店数
        |                       dp.rr_review_count_normalize, ---评论数排名
        |                       nvl(max(m_queue.brand_queue_shop_qty)
        |                           over(partition by mos.manageshopid),
        |                           0) brand_queue_shop_qty, ---品牌有排队出单量的门店数
        |                       m_queue.rr_mean_queue_qty_normalize, ---日均排队出单量排名（归一化）
        |                       m_book.rr_mean_BOOK_QTY_normalize, ---日均预订出单量排名（归一化）
        |                       m_order.rr_mean_order_amount_normalize, ---日均营业额排名（归一化）
        |                       m_pay.rr_mean_all_paid_normalize ---日均总支付金额排名（归一化）
        |                  from ods_shoptable mos
        |                  left join (select *
        |                              from (select manageshopid,
        |                                           mc.brand_name,
        |                                           count(shopid) brand_shop_qty
        |                                      from ods_shoptable mot
        |                                      left join c_shop_brand mc on mc.brand_id =
        |                                                                   mot.manageshopid
        |                                     where mot.shopname not like '%测试%'
        |                                       and mot.tiyandian = 0
        |                                       and mot.type_ = 2
        |                                       and mot.shopid != mot.manageshopid
        |                                       and mot.manageshopid != 43
        |                                       and nvl(mot.dianpingid, 0) != 0 ---51923
        |                                     group by manageshopid, mc.brand_name ---46006
        |                                    )
        |                             where brand_shop_qty >= 5 ---3291
        |                            ) m_big_brand on m_big_brand.manageshopid =
        |                                             mos.manageshopid
        |
        |                  left join ( --------------------------------点评----评论数-------------------------
        |                            select t2.dianpingid,
        |                                    t2.manageshopid,
        |                                    t2.shopid,
        |                                    t2.shopname,
        |                                    t2.review_count, ---评论数
        |                                    rr_review_count, ---评论数排名
        |                                    count(case
        |                                            when review_count != 0 then
        |                                             shopid
        |                                          end) over(partition by manageshopid) brand_review_shop_qty, ---品牌有评论数（评论数不为0）的门店数
        |                                    (count(shopid)
        |                                     over(partition by manageshopid) -
        |                                     rr_review_count + 1) / count(shopid) over(partition by manageshopid) rr_review_count_normalize ---评论数排名（归一化）
        |                              from (select t1.dianpingid,
        |                                            t1.manageshopid,
        |                                            t1.shopid,
        |                                            t1.shopname,
        |                                            t1.review_count,
        |                                            row_number() over(partition by manageshopid order by review_count desc) rr_review_count
        |                                       from (select mos.dianpingid,
        |                                                    mos.manageshopid,
        |                                                    mos.shopid,
        |                                                    mos.shopname,
        |                                                    nvl(dp.review_count, 0) review_count
        |                                               from dianping_shop_dish dp
        |                                              inner join ods_shoptable mos on mos.dianpingid =
        |                                                                                       dp.shop_id
        |                                              where mos.shopid !=
        |                                                    mos.manageshopid
        |                                                and mos.dianpingid != 0) t1) t2) dp on dp.dianpingid =
        |                                                                                       mos.dianpingid
        |                  left join
        |
        |                 ( ---------------------------------排队------------18843----------------------------
        |                 select t2.dianpingid,
        |                         t2.manageshopid,
        |                         t2.shopid,
        |                         t2.shopname,
        |                         t2.mean_queue_qty, ---日均排队出单量
        |                         rr_mean_queue_qty, ---日均排队出单量排名
        |                         count(shopid) over(partition by manageshopid) brand_queue_shop_qty, ---品牌有排队出单量的门店数
        |                         (count(shopid)
        |                          over(partition by manageshopid) - rr_mean_queue_qty + 1) /
        |                         count(shopid) over(partition by manageshopid) rr_mean_queue_qty_normalize ---日均排队出单量排名（归一化）
        |                   from (select t1.dianpingid,
        |                                 t1.manageshopid,
        |                                 t1.shopid,
        |                                 t1.shopname,
        |                                 t1.mean_queue_qty,
        |                                 row_number() over(partition by manageshopid order by mean_queue_qty desc) rr_mean_queue_qty
        |                            from (select mos.dianpingid,
        |                                         mos.manageshopid,
        |                                         mos.shopid,
        |                                         mos.shopname,
        |                                         sum(mq.queue_qty) / 61 mean_queue_qty
        |                                    from DW_QUEUE_DAILY mq
        |                                   inner join c_date_daily mc on mc.daily_key =
        |                                                                          mq.daily_key
        |                                   inner join c_shop_information mi on mi.shop_key =
        |                                                                                mq.shop_key
        |                                   inner join ods_shoptable mos on mos.shopid =
        |                                                                            mi.shop_id
        |                                   where mq.qeuestate_key = 5
        |                                     and mc.day_id >=
        |                                         to_date('2017-09-01 00:00:00')
        |                                     and mc.day_id <=
        |                                         to_date('2017-10-31 00:00:00')
        |                                        /*                               and mos.manageshopid = 35124
        |                                                                                                                                                        */
        |                                     and mos.shopid != mos.manageshopid
        |                                        /*                               and mos.shopname like '%云海肴%'
        |                                                                                                                                                        */
        |                                     and mos.dianpingid != 0
        |                                   group by mos.dianpingid,
        |                                            mos.manageshopid,
        |                                            mos.shopid,
        |                                            mos.shopname) t1) t2) m_queue on m_queue.shopid =
        |                                                                             mos.shopid
        |                  left join
        |
        |                 ( --------------------------------预订-------------------------16729------------------
        |                 select t2.dianpingid,
        |                         t2.manageshopid,
        |                         t2.shopid,
        |                         t2.shopname,
        |                         t2.mean_BOOK_QTY, ---日均预订出单量
        |                         rr_mean_BOOK_QTY, ---日均预订出单量排名
        |                         (count(shopid)
        |                          over(partition by manageshopid) - rr_mean_BOOK_QTY + 1) /
        |                         count(shopid) over(partition by manageshopid) rr_mean_BOOK_QTY_normalize ---日均预订出单量排名（归一化）
        |                   from (
        |
        |                          select t1.dianpingid,
        |                                  t1.manageshopid,
        |                                  t1.shopid,
        |                                  t1.shopname,
        |                                  t1.mean_BOOK_QTY,
        |                                  row_number() over(partition by manageshopid order by mean_BOOK_QTY desc) rr_mean_BOOK_QTY
        |                            from (select mos.dianpingid,
        |                                          mos.manageshopid,
        |                                          mos.shopid,
        |                                          mos.shopname,
        |                                          sum(mbook.BOOK_QTY) / 61 mean_BOOK_QTY
        |                                     from dw_book_daily mbook
        |                                    inner join c_date_daily mc on mc.daily_key =
        |                                                                           mbook.daily_key
        |                                    inner join c_book_shop ms on ms.shop_key =
        |                                                                          mbook.shop_key
        |                                    inner join ods_shoptable mos on mos.shopid =
        |                                                                             ms.shop_id
        |                                    where mc.day_id >=
        |                                          to_date('2017-09-01 00:00:00')
        |                                      and mc.day_id <=
        |                                          to_date('2017-10-31 00:00:00')
        |                                         /*and mos.manageshopid = 35124*/
        |                                      and mos.shopid != mos.manageshopid
        |                                         /*and mos.shopname like '%云海肴%'*/
        |                                      and mos.dianpingid != 0
        |                                    group by mos.dianpingid,
        |                                             mos.manageshopid,
        |                                             mos.shopid,
        |                                             mos.shopname) t1) t2) m_book on m_book.shopid =
        |                                                                             mos.shopid
        |
        |                  left join (
        |                            ---------------------------------点菜------------11545----------------------------
        |                            select t2.dianpingid,
        |                                    t2.manageshopid,
        |                                    t2.shopid,
        |                                    t2.shopname,
        |                                    t2.mean_order_amount, ---日均营业额
        |                                    rr_mean_order_amount, ---日均营业额排名
        |                                    (count(shopid)
        |                                     over(partition by manageshopid) -
        |                                     rr_mean_order_amount + 1) / count(shopid) over(partition by manageshopid) rr_mean_order_amount_normalize ---日均排营业额排名（归一化）
        |                              from (select t1.dianpingid,
        |                                            t1.manageshopid,
        |                                            t1.shopid,
        |                                            t1.shopname,
        |                                            t1.mean_order_amount,
        |                                            row_number() over(partition by manageshopid order by mean_order_amount desc) rr_mean_order_amount
        |                                       from (select mos.dianpingid,
        |                                                    mos.manageshopid,
        |                                                    mos.shopid,
        |                                                    mos.shopname,
        |                                                    sum(morder.order_amount) / 61 mean_order_amount
        |                                               from DM_ORDER_SHOP_MBOSS_D morder
        |                                              inner join c_date_daily mc on mc.day_id =
        |                                                                                     morder.day_id
        |                                              inner join ods_shoptable mos on mos.shopid =
        |                                                                                       morder.shopid
        |                                              where mc.day_id >=
        |                                                    to_date('2017-08-01')
        |                                                and mc.day_id <=
        |                                                    to_date('2017-09-30')
        |                                                   /*                               and mos.manageshopid = 35124
        |                                                                                                                                                                                                    */
        |                                                and mos.shopid !=
        |                                                    mos.manageshopid
        |                                                   /*                               and mos.shopname like '%云海肴%'
        |                                                                                                                                                                                                    */
        |                                                and mos.dianpingid != 0
        |                                              group by mos.dianpingid,
        |                                                       mos.manageshopid,
        |                                                       mos.shopid,
        |                                                       mos.shopname) t1) t2) m_order on m_order.shopid =
        |                                                                                        mos.shopid
        |                  left join
        |
        |                 (
        |                 ---------------------------------支付------------11271----------------------------
        |                 select t2.dianpingid,
        |                         t2.manageshopid,
        |                         t2.shopid,
        |                         t2.shopname,
        |                         t2.mean_all_paid, ---日均总支付金额
        |                         rr_mean_all_paid, ---日均总支付金额排名
        |                         (count(shopid)
        |                          over(partition by manageshopid) - rr_mean_all_paid + 1) /
        |                         count(shopid) over(partition by manageshopid) rr_mean_all_paid_normalize ---日均总支付金额排名（归一化）
        |                   from (select t1.dianpingid,
        |                                 t1.manageshopid,
        |                                 t1.shopid,
        |                                 t1.shopname,
        |                                 t1.mean_all_paid,
        |                                 row_number() over(partition by manageshopid order by mean_all_paid desc) rr_mean_all_paid
        |                            from (select mos.dianpingid,
        |                                         mos.manageshopid,
        |                                         mos.shopid,
        |                                         mos.shopname,
        |                                         sum(nvl(m_pay.cash_totalpay, 0) +
        |                                             nvl(cash_fastpay, 0) +
        |                                             nvl(cash_scangun_pay, 0) +
        |                                             nvl(cash_scan_pay, 0)) / 61 mean_all_paid --总支付金额
        |                                    from dm_cash_daily m_pay
        |                                   inner join ods_shoptable mos on mos.shopid =
        |                                                                            m_pay.shop_id
        |                                   where m_pay.day_id >=
        |                                         to_date('2017-09-01 00:00:00')
        |                                     and m_pay.day_id <=
        |                                         to_date('2017-10-31 00:00:00')
        |                                        /*                               and mos.manageshopid = 35124
        |                                                                                                                                                        */
        |                                     and mos.shopid != mos.manageshopid
        |                                        /*                               and mos.shopname like '%云海肴%'
        |                                                                                                                                                        */
        |                                     and mos.dianpingid != 0
        |                                   group by mos.dianpingid,
        |                                            mos.manageshopid,
        |                                            mos.shopid,
        |                                            mos.shopname) t1
        |                           where t1.mean_all_paid > 0) t2) m_pay on m_pay.shopid =
        |                                                                    mos.shopid
        |                 where mos.shopname not like '%测试%'
        |                   and mos.tiyandian = 0
        |                   and mos.type_ = 2
        |                   and mos.manageshopid != 43
        |                   and mos.shopid != mos.manageshopid
        |                   and nvl(mos.dianpingid, 0) != 0 ----先看点评ID不等于0的门店（看所有品牌的话，品牌内部分分店有点评ID的品牌占90%左右）
        |                ) ss) ---92786
        | where (top_queue_shop is not null or top_review_shop is not null or
        |       top_book_shop is not null or top_order_shop is not null or
        |       top_pay_shop is not null)
        |   and brand_shop_qty >= 5
      """.stripMargin)
    goodShopDS.createOrReplaceTempView("good_shop")
    goodShopDS.cache()
    goodShopDS.show()
    //将优质门店保存到hdfs
    val goodShopPath = "/model/addr_location/good_shop"
    goodShopDS.write.mode("overwrite").parquet(goodShopPath)
    val goodShopHdfsDS = sqlContext.read.parquet(goodShopPath)
    goodShopHdfsDS.createOrReplaceTempView("good_shop")
    //计算优质门店所在商圈
    val goodShopBaDSTmp = sqlContext.sql(
      """
        |select distinct mcr.manageshopid,
        |                mcr.brand_name,
        |                mc.city_id,
        |                mc.city_name,
        |                mc.business_area_id,
        |                mc.business_area_name,
        |                mct.sec_cat,
        |                mct.sec_cat_name
        |  from good_shop mcr --8094
        | inner join dianping_shop_dish dp on dp.shop_id = mcr.dianpingid ---品牌维度，2481个信息完整的品牌
        |
        | inner join DIANPING_CITY mc on mc.city_id = dp.city_id
        |                            and mc.business_area_id = dp.business_area_id
        |                            and mc.BUSINESS_AREA_NAME not like '%其他%' ---品牌维度，2425条有商圈的品牌
        | inner join DIANPING_CATEGORY mct on mct.sec_cat = dp.sec_cat
        |                                 and mct.pri_cat = dp.pri_cat
        |                                 and mct.city_id = dp.city_id ---3373    ---品牌维度，1503条有商圈、有菜系的品牌
        | where nvl(dp.avg_price, 0) is not null
      """.stripMargin)
    goodShopBaDSTmp.createOrReplaceTempView("good_shop_business_area_tmp")
    //对品牌菜系进行修正 修正逻辑：所有品牌门店中菜系门店最多的视作该品牌的菜系
    val goodShopBaDS = sqlContext.sql(
      """
        |select
        |	t0.manageshopid,
        |	t0.brand_name,
        |	t0.city_id,
        |	t0.city_name,
        |	t0.business_area_id,
        |	t0.business_area_name,
        |	t4.sec_cat,
        |	t4.sec_cat_name
        |from
        |	(select distinct manageshopid,brand_name,city_id,city_name,business_area_id,business_area_name from good_shop_business_area_tmp) t0
        |inner join
        |	(select
        |		t3.manageshopid,
        |		t3.sec_cat,
        |		t3.sec_cat_name
        |	from
        |		(select
        |			t2.manageshopid,
        |			t2.sec_cat,
        |			t2.sec_cat_name,
        |			row_number() over(partition by t2.manageshopid order by cnt desc) rn
        |		from
        |			(select
        |				t1.manageshopid,
        |			    t1.sec_cat,
        |			    t1.sec_cat_name,
        |			    count(1) cnt
        |			from
        |				good_shop_business_area_tmp t1
        |			group by
        |				t1.manageshopid,
        |			    t1.sec_cat,
        |			    t1.sec_cat_name) t2) t3
        |	where
        |		t3.rn = 1) t4
        |on
        |	t0.manageshopid = t4.manageshopid
      """.stripMargin)
    goodShopBaDS.createOrReplaceTempView("good_shop_business_area")
    goodShopBaDS.cache()
    goodShopBaDS.show()
    //将优质门店所在商圈保存到hdfs
    val goodShopBaPath = "/model/addr_location/good_shop_business_area"
    goodShopBaDS.write.mode("overwrite").parquet(goodShopBaPath)
    val goodShopBaHdfsDS = sqlContext.read.parquet(goodShopBaPath)
    goodShopBaHdfsDS.createOrReplaceTempView("good_shop_business_area")
    goodShopBaHdfsDS.where("manageshopid = '35124'").show(100, false)
    //计算优质门店所在的美味商圈
    val bcIdsDS = sqlContext.sql(
      """
        |select distinct
        |	t1.bc_id
        |from
        |	(select
        |	    gs.shopid,
        |	    crs.bc_id
        |	from
        |	    good_shop gs
        |	left join
        |	    c_rela_shopbc crs
        |	on
        |	    gs.shopid = crs.shopid) t1
      """.stripMargin)
    bcIdsDS.createOrReplaceTempView("bc_ids")
    //计算每个品牌的人均和总店铺数
    val shopAvgPriceAndCntDS = sqlContext.sql(
      """
        |select
        |    t2.manageshopid brand_id,
        |    cast(round(sum(t2.avg_price)/count(case when t2.avg_price = 0 then 0 else 1 end), 0) as int) avg_price,
        |    count(t2.shopid) shop_qty
        |from
        |    (select t1.dianpingid,
        |        t1.manageshopid,
        |        t1.shopid,
        |        t1.shopname,
        |        t1.avg_price
        |    from (select mos.dianpingid,
        |                mos.manageshopid,
        |                mos.shopid,
        |                mos.shopname,
        |                nvl(dp.avg_price, 0) avg_price
        |           from dianping_shop_dish dp
        |          inner join ods_shoptable mos on mos.dianpingid =
        |                                                   dp.shop_id
        |          where mos.shopid !=
        |                mos.manageshopid
        |            and mos.dianpingid != 0) t1) t2
        |group by
        |    t2.manageshopid
      """.stripMargin)
    shopAvgPriceAndCntDS.createOrReplaceTempView("shop_avg_price_cnt")
    //计算每个品牌的品牌数排名占比
    val shopCntPercentDS = sqlContext.sql(
      """
        |select
        |    sapc.brand_id,
        |    sapc.shop_qty,
        |    round((1 - row_number() over(order by sapc.shop_qty desc) / bcnt.b_cnt), 4) percent
        |from
        |    shop_avg_price_cnt sapc
        |cross join
        |    (select count(distinct brand_id) b_cnt from shop_avg_price_cnt) bcnt
        |on
        |    1 = 1
      """.stripMargin)
    shopCntPercentDS.createOrReplaceTempView("shop_cnt_percent")
    //计算所有需要计算推荐商圈的品牌ID
    val brandIdsDs = sqlContext.sql(
      """
        |select
        |   distinct t1.manageshopid
        |from
        |   good_shop_business_area t1
      """.stripMargin)
    brandIdsDs.createOrReplaceTempView("brand_ids")
    brandIdsDs.cache()
    brandIdsDs.show()

    //debug start TODO
    println("brand_ids:")
    brandIdsDs.where("manageshopid='3521'").show()
    //debug end

    /**
      * step 2: 计算点评门店数大于50的所有商圈的特征
      */
    val baFeatureDS = sqlContext.sql(
      """
        |select s1.business_area_id,
        |       s1.business_area_name,
        |       s1.ba_area / (max(s1.ba_area) over(partition by 1)) ba_area_normal, ---点评商圈面积（归一化）
        |       s1.low_price_rate, ---商圈店均(0-50]的门店数占比
        |       s1.middle_price_rate, ---商圈店均(50-100]的门店数占比
        |       s1.high_price_rate, ---商圈店均(100-150]的门店数占比
        |       s1.higher_price_rate, ---商圈店均(150-200]的门店数占比
        |       s1.highest_price_rate, ---商圈店均200+ 的门店数占比
        |       s1.bc_avg_price_mean /
        |       (max(s1.bc_avg_price_mean) over(partition by 1)) bc_avg_price_mean_noraml, ---商圈店均均值（归一化）
        |       s1.bc_shop_qty / (max(s1.bc_shop_qty) over(partition by 1)) shop_qty_normal, ---商圈门店数（归一化）
        |       s1.bc_shop_qty_s / (max(s1.bc_shop_qty_s) over(partition by 1)) shop_qty_s_normal, ---商圈单位面积门店数（归一化）
        |       s1.bc_taste_mean / (max(s1.bc_taste_mean) over(partition by 1)) bc_taste_mean_normal, ---商圈口味均值（归一化）
        |       s1.bc_environment_mean /
        |       (max(s1.bc_environment_mean) over(partition by 1)) bc_environment_all_normal, ---商圈环境均值（归一化）
        |       s1.bc_serve_mean / (max(s1.bc_serve_mean) over(partition by 1)) bc_serve_all_normal, ---商圈服务均值（归一化）
        |       s1.bc_star_mean / (max(bc_star_mean) over(partition by 1)) bc_star_all_normal, ---商圈点评星级均值（归一化）
        |       s1.bc_review_mean / (max(s1.bc_review_mean) over(partition by 1)) bc_review_all_normal, ---商圈点评数量均值（归一化）
        |       s1.bc_UNIQLO_qty_s / (max(s1.bc_UNIQLO_qty_s) over(partition by 1)) UNIQLO_qty_s_normal, ---商圈内单位面积优衣库门店数量（归一化）
        |       s1.bc_ZARA_qty_s / (max(s1.bc_ZARA_qty_s) over(partition by 1)) ZARA_qty_s_normal, ---商圈内单位面积ZARA门店数量（归一化）
        |       s1.bc_HM_qty_s / (max(s1.bc_HM_qty_s) over(partition by 1)) HM_qty_s_normal, ---商圈内单位面积HM门店数量（归一化）
        |       s1.bc_JACKJONES_qty_s /
        |       (max(s1.bc_JACKJONES_qty_s) over(partition by 1)) JACKJONES_qty_s_normal, ---商圈内单位面积杰克琼斯门店数量（归一化）
        |       s1.bc_TOM_qty_s / (max(s1.bc_TOM_qty_s) over(partition by 1)) TOM_qty_s_normal, ---商圈内单位面积TOM门店数量（归一化）
        |       s1.bc_Watsons_qty_s /
        |       (max(s1.bc_Watsons_qty_s) over(partition by 1)) Watsons_qty_s_normal, ----商圈内单位面积屈臣氏门店数量（归一化）
        |       s1.bc_KTV_qty_s / (max(s1.bc_KTV_qty_s) over(partition by 1)) KTV_qty_s_normal, ---商圈内单位面积人均100以上KTV门店数量（归一化）
        |       s1.bc_bar_qty_s / (max(s1.bc_bar_qty_s) over(partition by 1)) bar_qty_s_normal, ---商圈内单位面积人均100以上酒吧门店数量（归一化）
        |       s1.bc_Starbucks_qty_s /
        |       (max(s1.bc_Starbucks_qty_s) over(partition by 1)) bc_Starbucks_qty_s_normal, ---商圈内单位面积星巴克门店数量（归一化）
        |       s1.bc_sports_qty_s / (max(s1.bc_sports_qty_s) over(partition by 1)) sports_qty_s_normal ----商圈内单位面积人均100以上运动健身门店数量（归一化）
        |  from (select u1.business_area_id,
        |               u1.business_area_name,
        |               u1.ba_area, ---点评商圈面积
        |               u1.bc_shop_qty, ---商圈门店数
        |               u1.bc_shop_qty / ba_area bc_shop_qty_s, ---商圈单位面积门店数
        |               u1.low_price_shop_qty / u1.bc_shop_qty low_price_rate,
        |               u1.middle_price_shop_qty / u1.bc_shop_qty middle_price_rate,
        |               u1.high_price_shop_qty / u1.bc_shop_qty high_price_rate,
        |               u1.higher_price_shop_qty / u1.bc_shop_qty higher_price_rate,
        |               u1.highest_price_shop_qty / u1.bc_shop_qty highest_price_rate,
        |               u1.bc_avg_price_all / u1.bc_shop_qty bc_avg_price_mean,
        |               u1.bc_taste_all / u1.bc_shop_qty bc_taste_mean,
        |               u1.bc_environment_all / u1.bc_shop_qty bc_environment_mean,
        |               u1.bc_serve_all / u1.bc_shop_qty bc_serve_mean,
        |               u1.bc_star_all / u1.bc_shop_qty bc_star_mean,
        |               u1.bc_review_all / u1.bc_shop_qty bc_review_mean,
        |               nvl(a1.bc_UNIQLO_qty, 0) / ba_area bc_UNIQLO_qty_s,
        |               nvl(a2.bc_ZARA_qty, 0) / ba_area bc_ZARA_qty_s,
        |               nvl(a3.bc_HM_qty, 0) / ba_area bc_HM_qty_s,
        |               nvl(a4.bc_JACKJONES_qty, 0) / ba_area bc_JACKJONES_qty_s,
        |               nvl(a10.bc_TOM_qty, 0) / ba_area bc_TOM_qty_s,
        |               nvl(a5.bc_Watsons_qty, 0) / ba_area bc_Watsons_qty_s,
        |               nvl(a6.bc_KTV_qty, 0) / ba_area bc_KTV_qty_s,
        |               nvl(a7.bc_bar_qty, 0) / ba_area bc_bar_qty_s,
        |               nvl(a8.bc_Starbucks_qty, 0) / ba_area bc_Starbucks_qty_s,
        |               nvl(a9.bc_sports_qty, 0) / ba_area bc_sports_qty_s
        |          from (select u.business_area_id,
        |                       u.business_area_name,
        |                       u.ba_area, ---点评商圈面积
        |                       count(u.shop_id) bc_shop_qty, ---商圈门店数
        |                       count(case
        |                               when u.avg_price > 0 and u.avg_price <= 50 then
        |                                u.shop_id
        |                             end) low_price_shop_qty,
        |                       count(case
        |                               when u.avg_price > 50 and u.avg_price <= 100 then
        |                                u.shop_id
        |                             end) middle_price_shop_qty,
        |                       count(case
        |                               when u.avg_price > 100 and u.avg_price <= 150 then
        |                                u.shop_id
        |                             end) high_price_shop_qty,
        |                       count(case
        |                               when u.avg_price > 150 and u.avg_price <= 200 then
        |                                u.shop_id
        |                             end) higher_price_shop_qty,
        |                       count(case
        |                               when u.avg_price > 200 then
        |                                u.shop_id
        |                             end) highest_price_shop_qty,
        |                       sum(u.avg_price) bc_avg_price_all, ---商圈店均总和
        |                       sum(u.taste) bc_taste_all, ---商圈口味评分总和
        |                       sum(u.environment) bc_environment_all, ---商圈环境评分总和
        |                       sum(u.serve) bc_serve_all, ---商圈服务评分总和
        |                       sum(u.star) bc_star_all, ---商圈门店星级总和
        |                       sum(u.review_count) bc_review_all ---商圈评论数总和
        |                  from (select distinct mc.business_area_id,
        |                                        mc.business_area_name,
        |                                        dpbc.ba_area, ---点评商圈面积
        |                                        dp.shop_id,
        |                                        dp.shop_name,
        |                                        dp.avg_price,
        |                                        mct.sec_cat,
        |                                        mct.sec_cat_name,
        |                                        (case
        |                                          when dp.star = '准一星商户' then
        |                                           '0.5'
        |                                          when dp.star = '一星商户' then
        |                                           '1.0'
        |                                          when dp.star = '准二星商户' then
        |                                           '1.5'
        |                                          when dp.star = '二星商户' then
        |                                           '2.0'
        |                                          when dp.star = '准三星商户' then
        |                                           '2.5'
        |                                          when dp.star = '三星商户' then
        |                                           '3.0'
        |                                          when dp.star = '准四星商户' then
        |                                           '3.5'
        |                                          when dp.star = '四星商户' then
        |                                           '4.0'
        |                                          when dp.star = '准五星商户' then
        |                                           '4.5'
        |                                          when dp.star = '五星商户' then
        |                                           '5.0'
        |                                          else
        |                                           null
        |                                        end) star,
        |                                        dp.review_count,
        |                                        substr(dp.comment_score, 4, 3) taste, ---口味
        |                                        substr(dp.comment_score, 11, 3) environment, ---环境
        |                                        substr(dp.comment_score, 18, 3) serve
        |                          from dianping_shop_dish dp
        |                         inner join DIANPING_CITY mc on mc.city_id =
        |                                                        dp.city_id
        |                                                    and mc.business_area_id =
        |                                                        dp.business_area_id
        |                                                    and mc.BUSINESS_AREA_NAME not like
        |                                                        '%其他%'
        |                          left join DIANPING_CATEGORY mct on mct.city_id =
        |                                                             dp.city_id
        |                                                         and mct.sec_cat =
        |                                                             dp.sec_cat
        |                                                         and mct.pri_cat =
        |                                                             dp.pri_cat
        |                         inner join DIANPING_BUSINESS_AREA dpbc on dpbc.business_area_id =
        |                                                                   dp.business_area_id
        |                         where dp.pri_cat = '10'
        |                           and nvl(dp.avg_price, 0) != 0 ---153910---8782
        |                           and nvl(dpbc.ba_area, 0) != 0) u
        |                 group by u.business_area_id, u.business_area_name, u.ba_area) u1
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_UNIQLO_qty ---商圈内优衣库门店数量
        |                      from dianping_shop ss
        |                     where (ss.shop_name like '%优衣库%' or
        |                           ss.shop_name like '%UNIQLO%') ---649
        |                       and sec_cat in (120, 121, 33911, 130)
        |                     group by ss.business_area_id) a1 on a1.business_area_id =
        |                                                         u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_ZARA_qty ---商圈内ZARA门店数量
        |                      from dianping_shop ss
        |                     where (ss.shop_name like '%ZARA%' or
        |                           ss.shop_name like '%zara%') ---320
        |                       and sec_cat in (120, 121, 33911, 130)
        |                     group by ss.business_area_id) a2 on a2.business_area_id =
        |                                                         u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_HM_qty ---商圈内HM门店数量
        |                      from dianping_shop ss
        |                     where (ss.shop_name like 'HM(%' or
        |                           ss.shop_name like concat('H', "&", 'M%')) ---485
        |                       and sec_cat in (120, 121, 33911, 130)
        |                     group by ss.business_area_id) a3 on a3.business_area_id =
        |                                                         u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_JACKJONES_qty ---商圈内杰克琼斯门店数量
        |                      from dianping_shop ss
        |                     where (ss.shop_name like '%杰克琼斯%' or
        |                           ss.shop_name like
        |                           concat('JACK', "&", 'JONES%')) ---1293
        |                       and sec_cat in (120, 121, 33911, 130)
        |                     group by ss.business_area_id) a4 on a4.business_area_id =
        |                                                         u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_TOM_qty ---商圈内TOM门店数量
        |                      from dianping_shop ss
        |                     where (ss.shop_name like '%Tommy%' or
        |                           ss.shop_name like '%TOMMY%' or
        |                           ss.shop_name like '%tommy%') ---277
        |                       and sec_cat in (120, 121, 33911, 130)
        |                     group by ss.business_area_id) a10 on a10.business_area_id =
        |                                                          u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_Watsons_qty ---商圈内屈臣氏门店数量
        |                      from dianping_shop ss
        |                     where ss.shop_name like '屈臣氏(%' ---1109
        |                       and pri_cat = 20 ---包含化妆品的各个部分
        |                     group by ss.business_area_id) a5 on a5.business_area_id =
        |                                                         u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_KTV_qty ---商圈内人均100以上KTV门店数量
        |                      from dianping_shop ss
        |                     where ss.sec_cat = 135 ---KTV  ---66046
        |                       and nvl(ss.avg_price, 0) > 100
        |                     group by ss.business_area_id) a6 on a6.business_area_id =
        |                                                         u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_bar_qty ---商圈内人均100以上酒吧门店数量
        |                      from dianping_shop ss
        |                     where ss.sec_cat = 133 ---酒吧
        |                       and nvl(ss.avg_price, 0) > 100 --1706
        |                     group by ss.business_area_id) a7 on a7.business_area_id =
        |                                                         u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_Starbucks_qty ---商圈内星巴克门店数量
        |                      from dianping_shop ss
        |                     where ss.sec_cat = 132 ---咖啡厅
        |                       and (ss.shop_name like '%星巴克%' or
        |                           ss.shop_name like '%Starbucks%') ---2777
        |                     group by ss.business_area_id) a8 on a8.business_area_id =
        |                                                         u1.business_area_id
        |          left join (select ss.business_area_id,
        |                           count(ss.shop_name) bc_sports_qty ---商圈内人均100以上运动健身门店数量
        |                      from dianping_shop ss
        |                     where ss.pri_cat = 45
        |                       and nvl(ss.avg_price, 0) > 100 --3457
        |                     group by ss.business_area_id) a9 on a9.business_area_id =
        |                                                         u1.business_area_id
        |         where u1.business_area_id is not null
        |           and u1.bc_shop_qty > 50) s1
        |
        | inner join (
        |             --------------------------------------------------全国商圈营业时间----------1282-----------11083-------------shop_qty > 50----4392------------
        |             select u1.business_area_id,
        |                   u1.business_area_name,
        |                   u1.shop_qty,
        |                   u1.workday_start_time /
        |                   (max(u1.workday_start_time) over(partition by 1)) workday_start_time_noraml,
        |                   u1.workday_end_time /
        |                   (max(u1.workday_end_time) over(partition by 1)) workday_end_time_noraml
        |             from (select u.business_area_id,
        |                           u.business_area_name,
        |                           u.shop_qty,
        |                           u.workday_start_time_h +
        |                           u.workday_start_time_m / 60 workday_start_time, ---工作日营业起始时间（归一化）
        |                           u.workday_end_time_h +
        |                           u.workday_end_time_m / 60 workday_end_time ---工作日营业结束时间（归一化）
        |                      from (
        |                            select mc.business_area_id,
        |                                    mc.business_area_name,
        |                                    count(t.shop_id) shop_qty,
        |                                    hour(from_unixtime(substr(cast(round(sum(t.workday_start_time) / count(t.shop_id)) as long),0,9))) workday_start_time_h,
        |                                    minute(from_unixtime(substr(cast(round(sum(t.workday_start_time) / count(t.shop_id)) as long),0,9))) workday_start_time_m,
        |                                    hour(from_unixtime(substr(cast(round(sum(t.workday_end_time) / count(t.shop_id)) as long),0,9))) workday_end_time_h,
        |                                    minute(from_unixtime(substr(cast(round(sum(t.workday_end_time) / count(t.shop_id)) as long),0,9))) workday_end_time_m
        |                              from dianping_shop_service_time t
        |                             inner join dianping_shop_dish dp on dp.shop_id =
        |                                                                 t.shop_id
        |                             inner join dianping_city mc on mc.business_area_id =
        |                                                            dp.business_area_id
        |                                                        and mc.BUSINESS_AREA_NAME not like
        |                                                            '%其他%'
        |                             where t.service_time is not null
        |                               and dp.pri_cat = '10' ---76450
        |                               and t.workday_start_time is not null
        |                               and t.workday_end_time is not null
        |                               and t.weekend_start_time is not null
        |                               and t.weekend_end_time is not null ---71865
        |                             group by mc.business_area_id,
        |                                       mc.business_area_name) u) u1
        |            where u1.shop_qty > 50) s2 on s1.business_area_id =
        |                                            s2.business_area_id
      """.stripMargin).dropDuplicates(Seq("business_area_id"))
    baFeatureDS.createOrReplaceTempView("ba_feature")
    baFeatureDS.printSchema()
    baFeatureDS.cache()
    baFeatureDS.show()
    //将商圈特征保存到hdfs
    val baFeaturePath = "/model/addr_location/ba_feature"
    baFeatureDS.write.mode("overwrite").parquet(baFeaturePath)
    //从hdfs读取商圈特征数据
    val baFeatureHdfsDS = sqlContext.read.parquet(baFeaturePath)
    baFeatureHdfsDS.createOrReplaceTempView("ba_feature")

    /**
      * step 3: 计算源商圈的top100相似商圈
      */
    //计算商圈相似度
    println("计算商圈相似度")
    val baFeatureRdd = baFeatureHdfsDS.drop("business_area_name").rdd.map(row => {
      val listBuf: ListBuffer[Double] = new ListBuffer[Double]
      for(i <- 1 to row.size - 1){
        listBuf.append(row.get(i).toString.toDouble)
      }
      (row.get(0), Vectors.dense(listBuf.toArray))
    })
    val baCorrelationRDD = baFeatureRdd.cartesian(baFeatureRdd).map(all => {
      val baId1 = all._1._1.toString()
      val baFeatureArray1 = all._1._2.toArray
      val baId2 = all._2._1.toString()
      val baFeatureArray2 = all._2._2.toArray

      val member = baFeatureArray1.zip(baFeatureArray2).map(dd => dd._1 * dd._2).reduce(_ + _)
      val tmp1 = math.sqrt(baFeatureArray1.map(num => {math.pow(num, 2)}).reduce(_ + _))
      val tmp2 = math.sqrt(baFeatureArray2.map(num => {math.pow(num, 2)}).reduce(_ + _))

      //求相似度
      val similarity = member / (tmp1 * tmp2)
      Correlation(baId1, baId2, similarity.toString)
    }).distinct()
    val baCorrelationDS = baCorrelationRDD.toDS()
    baCorrelationDS.createOrReplaceTempView("ba_correlation")
    baCorrelationDS.printSchema()
    baCorrelationDS.cache()
    baCorrelationDS.show()
    //将商圈相似度保存到hdfs
    val baCorrelationPath = "/model/addr_location/ba_correlation"
    baCorrelationDS.write.mode("overwrite").parquet(baCorrelationPath)
    //从hdfs读取商圈相似度
    val baCorrelationHdfsDS = sqlContext.read.parquet(baCorrelationPath)
    println("schema of baCorrelationHdfsDS")
    baCorrelationHdfsDS.printSchema()
    baCorrelationHdfsDS.createOrReplaceTempView("ba_correlation")
    //计算top100相似商圈
    val baCorrelationTopDS = sqlContext.sql(
      """
        |select
        |    t1.manageshopid,
        |    t1.business_area_id,
        |    t1.ba_id2,
        |    t1.correlation,
        |    t1.rank
        |from
        |    (select distinct
        |        gsba.manageshopid,
        |        gsba.business_area_id,
        |        bc.ba_id2,
        |        bc.correlation,
        |        row_number() over(partition by gsba.manageshopid order by cast(bc.correlation as double) desc) rank
        |    from
        |        good_shop_business_area gsba
        |    left join
        |        (select * from ba_correlation where ba_id1 != ba_id2) bc
        |    on
        |        business_area_id = bc.ba_id1) t1
        |where
        |    cast(t1.correlation as double) > 0.9 or t1.rank <= 100
      """.stripMargin)
    baCorrelationTopDS.createOrReplaceTempView("ba_correlation_top")
//    //将top100相似商圈保存到hdfs
    val baCorrelationTopPath = "/model/addr_location/ba_correlation_top"
    baCorrelationTopDS.write.mode("overwrite").parquet(baCorrelationTopPath)
    val baCorrelationTopHdfsDS = sqlContext.read.parquet(baCorrelationTopPath)
    baCorrelationTopHdfsDS.createOrReplaceTempView("ba_correlation_top")

    /**
      * step 4: 会员对品牌的喜好关联度
      */
    //计算会员品牌的消费情况
    val memberBrandDS = sqlContext.sql(
      """
        |select
        |  tt.mobile,
        |  tt.MANAGESHOPID,
        |  tt.cnt
        |from
        |    (select mm.mobile,
        |           mm.MANAGESHOPID,
        |           count(mm.MANAGESHOPID) cnt
        |      from DW_MEMBER_HISTORY mm
        |     inner join (select *
        |                   from ods_shoptable t
        |                  where t.type_ = 2
        |                    and t.tiyandian = 0
        |                    and t.manageshopid != 43
        |                    and t.shopname not like '%测试%'
        |                    and t.shopid != t.manageshopid) mos on mos.shopid = mm.SHOP_ID
        |     inner join c_rela_shopbc mrc on mrc.shopid = mos.shopid
        |     where create_time > to_date('2017-01-01') ---49466701
        |       and ((mm.source_id = 1 and mm.SOURCE_STATUE = 5) or
        |           (mm.source_id = 2 and mm.SOURCE_STATUE in (3, 8)) or
        |           (mm.source_id = 3 and mm.SOURCE_STATUE = 3) or
        |           (mm.source_id = 4 and mm.SOURCE_STATUE = 1))
        |       and mm.MOBILE not in
        |           (select mobile
        |              from (select substr(create_time,0,10),
        |                           mm.mobile,
        |                           mm.MANAGESHOPID,
        |                           count(*) MANAGESHOP_cnt
        |                      from DW_MEMBER_HISTORY mm
        |                     where create_time > to_date('2015-07-01') ---49466701
        |                       and ((mm.source_id = 1 and mm.SOURCE_STATUE = 5) or
        |                           (mm.source_id = 2 and mm.SOURCE_STATUE in (3, 8)) or
        |                           (mm.source_id = 3 and mm.SOURCE_STATUE = 3) or
        |                           (mm.source_id = 4 and mm.SOURCE_STATUE = 1))
        |                     group by substr(create_time,0,10),
        |                              mm.mobile,
        |                              mm.MANAGESHOPID)
        |             where MANAGESHOP_cnt > 3)
        |       and mm.MANAGESHOPID != 43
        |       and mrc.bc_id in
        |           (select bc_id from bc_ids)  ---TODO：加上品牌ID
        |     group by mm.mobile, mm.MANAGESHOPID
        |     order by mm.mobile) tt
        |where
        |  tt.MANAGESHOPID in(select manageshopid from brand_ids)
      """.stripMargin)
    memberBrandDS.createOrReplaceTempView("member_brand")
    memberBrandDS.coalesce(50).cache()
    println("memberBrandDS count: " + memberBrandDS.count())//12684417
    memberBrandDS.show()
    val memberBrandPath = "/model/addr_location/member_brand"
    memberBrandDS.write.mode("overwrite").parquet(memberBrandPath)

    //品牌相似度计算:1.根据品牌groupBy；2.计算相似度，使用相同手机号的个数(a)每个品牌的手机号个数(b1,b2),a/(b1*b1+b2*b2)
    val memberBrandRdd = sqlContext
                        .read
                        .parquet(memberBrandPath)
                        .where("mobile not like '11%' and mobile not like '10%'")
                        .rdd.map(row => (row.get(1).toString, row.get(0).toString))
                        .groupByKey(10)
    //debug start
    memberBrandRdd.cache()
    println("cnt of memberBrandRdd:" + memberBrandRdd.count())
    println("num of partitions:" + memberBrandRdd.getNumPartitions)
    sqlContext
      .read
      .parquet(memberBrandPath)
      .rdd.map(row => (row.get(1).toString, row.get(0).toString)).map(all => (all._1, 1)).reduceByKey(_+_).sortBy(all => - all._2).take(100).foreach(println)
    //debug end

    val brandCorrelationDS = memberBrandRdd.cartesian(memberBrandRdd).map(all => {
      val brand1 = all._1._1
      val brand1Members = all._1._2.toArray
      val membersCnt1 = brand1Members.size
      val brand2 = all._2._1
      val brand2Members = all._2._2.toArray
      val membersCnt2 = brand2Members.size

      //计算相同手机号的个数
      var a = 0
      if(membersCnt1 > membersCnt2){
        a = brand1Members.intersect(brand2Members).size

      }else{
        a = brand2Members.intersect(brand1Members).size
      }
      //计算相似度
      val correlation = a / (math.pow(membersCnt1, 0.5) * math.pow(membersCnt2, 0.5))

      BrandCorrelation(brand1, brand2, correlation.toString, membersCnt1.toString, membersCnt2.toString, a.toString)
    }).toDS()
    brandCorrelationDS.createOrReplaceTempView("brand_correlation")
    println("schema of brandCorrelationDS:")
    brandCorrelationDS.printSchema()
    brandCorrelationDS.cache()
    brandCorrelationDS.where("brand1 = '17796' and correlation != '0'").orderBy("correlation").show(100, false)
    //将品牌相似度保存到hdfs
    val brandCorrelationPath = "/model/addr_location/brand_correlation"
    brandCorrelationDS.write.mode("overwrite").parquet(brandCorrelationPath)
    //计算每个品牌相似度最大的五个品牌
    //debug start TODO
    val brandCorrelationHdfsDS = sqlContext.read.parquet(brandCorrelationPath)
    brandCorrelationHdfsDS.createOrReplaceTempView("brand_correlation")
    sqlContext.sql(
      """
        |select * from brand_correlation where brand1 != brand2 order by correlation desc
        |
      """.stripMargin).show(100, false)
    //debug end
    val brandCorrelationTop5DS = sqlContext.sql(
      """
        |select
        |    t3.brand1,
        |    t5.brand_name brand_name1,
        |    t3.brand2,
        |    t6.brand_name brand_name2,
        |    round(t3.brand12cnt/t4.brand12cnt_all, 4) percent
        |from
        |    (select
        |        t2.brand1,
        |        t2.brand2,
        |        t2.brand12cnt,
        |        t2.rank
        |    from
        |            (select
        |               t1.brand1,
        |               t1.brand2,
        |               t1.brand12cnt,
        |               row_number() over(partition by t1.brand1 order by cast(t1.brand12cnt as int) desc) rank
        |            from
        |               brand_correlation t1
        |            where
        |               t1.brand1 != t1.brand2
        |               --and t1.brand1 = '35124'
        |               ) t2
        |    where
        |        t2.rank <= 5) t3
        |left join
        |    (select
        |        t2.brand1,
        |        sum(t2.brand12cnt) brand12cnt_all
        |    from
        |        (select
        |            t2.brand1,
        |            t2.brand2,
        |            t2.brand12cnt,
        |            t2.rank
        |        from
        |                (select
        |                   t1.brand1,
        |                   t1.brand2,
        |                   t1.brand12cnt,
        |                   row_number() over(partition by t1.brand1 order by cast(t1.brand12cnt as int) desc) rank
        |                from
        |                   brand_correlation t1
        |                where
        |                   t1.brand1 != t1.brand2
        |                   --and t1.brand1 = '35124'
        |                   ) t2
        |        where
        |            t2.rank <= 5) t2
        |    group by
        |        t2.brand1) t4
        |on t3.brand1 = t4.brand1
        |left join
        |    c_shop_brand t5
        |on
        |    t3.brand1 = t5.brand_id
        |left join
        |    c_shop_brand t6
        |on
        |    t3.brand2 = t6.brand_id
      """.stripMargin)
    brandCorrelationTop5DS.createOrReplaceTempView("brand_correlation_top")
    brandCorrelationTop5DS.printSchema()
    brandCorrelationTop5DS.cache()
    brandCorrelationTop5DS.show(100, false)
    //将每个品牌相似度最大的五个品牌的结果保存到hdfs
    val brandCorrelationTop5Path = "/model/addr_location/brand_correlation_top"
    brandCorrelationTop5DS.write.mode("overwrite").parquet(brandCorrelationTop5Path)
    //计算每个品牌的关联品牌
    val relatedBrandsDS = brandCorrelationTop5DS.where("percent is not null").select("brand1", "brand_name2", "percent")
                          .rdd
                          .map(row => (row.get(0).toString, (row.get(1).toString, row.get(2).toString.toDouble)))
                          .groupByKey()
                          .map(all => {
                              val brandId = all._1
                              val related = all._2.toArray.sortBy(all => - all._2).map(all => all._1)
                            RelatedBrands(brandId, related.mkString("||"))
                            }).toDF()
    relatedBrandsDS.show()
    relatedBrandsDS.createOrReplaceTempView("related_brands")

    /**
      * step 5: 将上述top100相似商圈去重后得到目标商圈，计算点评门店在目标商圈中的关联品牌数
      */
    //给每个点评商圈标注有哪些品牌
    println("给每个点评商圈标注有哪些品牌")
//    val baBrandDS = sqlContext.sql(
//      """
//        |select distinct
//        |	dsd.business_area_id,
//        |	dsd.shop_name,
//        |	(case when instr(dsd.shop_name, gsba.brand_name) > 0 then gsba.manageshopid else '' end) brand_id,
//        |	(case when instr(dsd.shop_name, gsba.brand_name) > 0 then gsba.brand_name else '' end) brand_name
//        |from
//        |	(select
//        |		t0.business_area_id,
//        |		t0.shop_name
//        |	from
//        |		dianping_shop_dish t0
//        |	where
//        |		t0.business_area_id in (select distinct ba_id2 from ba_correlation_top)
//        |		or
//        |		t0.business_area_id not in (select distinct business_area_id from ba_correlation_top)
//        |		) dsd
//        |cross join
//        |	good_shop_business_area gsba
//        |on
//        |	1 = 1
//      """.stripMargin).where("brand_id != ''")
    val baBrandDS = sqlContext.sql(
      """
        |select distinct
        |	dsd.business_area_id,
        |	dsd.shop_name,
        |	(case when instr(dsd.shop_name, gsba.brand_name) > 0 then gsba.manageshopid else '' end) brand_id,
        |	(case when instr(dsd.shop_name, gsba.brand_name) > 0 then gsba.brand_name else '' end) brand_name
        |from
        |	dianping_shop_dish dsd
        |cross join
        |	good_shop_business_area gsba
        |on
        |	1 = 1
      """.stripMargin).where("brand_id != ''")
    baBrandDS.createOrReplaceTempView("ba_brand")
    //将计算好的每个商圈有哪些品牌的数据保存到hdfs
    val baBrandPath = "/model/addr_location/ba_brand"
    baBrandDS.write.mode("overwrite").parquet(baBrandPath)
    val baBrandHdfsDS = sqlContext.read.parquet(baBrandPath)
    baBrandHdfsDS.createOrReplaceTempView("ba_brand")
    //计算每个品牌有哪些可推荐的商圈
    println("计算每个品牌有哪些可推荐的商圈")
    val baBrandPercentDS = sqlContext.sql(
      """
        |select distinct
        |	bct.manageshopid,
        | bctt.brand_name1,
        |	bct.ba_id2,
        |	bb.brand_id,
        |	bb.brand_name,
        |	bctt.percent
        |from
        |	ba_correlation_top bct
        |left join
        |	ba_brand bb
        |on
        |	bct.ba_id2 = bb.business_area_id
        |inner join
        |	brand_correlation_top bctt
        |on
        |	bct.manageshopid = bctt.brand1
        |	and
        |	bb.brand_id = bctt.brand2
        |
      """.stripMargin)
    println("ba_brand_percent")
    baBrandPercentDS.createOrReplaceTempView("ba_brand_percent")
    val monthId = targetDate.substring(0,7)
    val updateTime = System.currentTimeMillis()
    val baRecommendTmpDS = sqlContext.sql(
      """
        |select
        |  '%s' month_id,
        |  bbp.manageshopid brand_id,
        |  bbp.brand_name1,
        |  sapc.shop_qty,
        |  sapc.avg_price,
        |  dc.city_id,
        |  dc.city_name,
        |  bbp.ba_id2 business_area_id,
        |  dc.business_area_name,
        |  round(sum(bbp.percent), 4) correlation,
        |  max('1') rec_type,
        |  max('%s') update_time
        |from
        |  ba_brand_percent bbp
        |left join
        |  (select distinct t0.city_id, t0.city_name, t0.business_area_id, t0.business_area_name from dianping_city t0) dc
        |on
        |  bbp.ba_id2 = dc.business_area_id
        |left join
        |  shop_avg_price_cnt sapc
        |on
        |  bbp.manageshopid = sapc.brand_id
        |group by
        |  '%s',
        |  bbp.manageshopid,
        |  bbp.brand_name1,
        |  sapc.shop_qty,
        |  sapc.avg_price,
        |  dc.city_id,
        |  dc.city_name,
        |  bbp.ba_id2,
        |  dc.business_area_name
        |order by correlation desc
      """.stripMargin.format(monthId, updateTime, monthId))
    baRecommendTmpDS.where("manageshopid = '35124'").show()
    baRecommendTmpDS.createOrReplaceTempView("brand_ba_recommend_tmp")
    val baRecommendDS = sqlContext.sql(
      """
        |select
        |  bbrt.month_id MONTH_ID,
        |  bbrt.brand_id BRAND_ID,
        |  bbrt.brand_name1 BRAND_NAME,
        |  bbrt.shop_qty BRAND_SHOP_QTY,
        |  bbrt.avg_price BRAND_AVG_PRICE,
        |  gsba.sec_cat GOODTYPE_ID,
        |  dcc.sec_cat_name GOODTYPE_NAME,
        |  bbrt.city_id CITY_ID,
        |  bbrt.city_name CITY_NAME,
        |  bbrt.business_area_id BUSINESS_AREA_ID,
        |  bbrt.business_area_name BUSINESS_AREA_NAME,
        |  bbrt.correlation CORRELATION,
        |  rb.related_brand RELATED_BRAND,
        |  bbrt.rec_type REC_TYPE,
        |  bbrt.update_time UPDATE_TIME
        |from
        |  brand_ba_recommend_tmp bbrt
        |inner join
        |  (select distinct t0.manageshopid, t0.sec_cat from good_shop_business_area t0 where t0.sec_cat != '118') gsba
        |on
        |  bbrt.brand_id = gsba.manageshopid
        |left join
        |  dianping_category dcc
        |on
        |  bbrt.city_id = dcc.city_id
        |  and
        |  gsba.sec_cat = dcc.sec_cat
        |left join
        |  related_brands rb
        |on
        |  bbrt.brand_id = rb.brand_id
      """.stripMargin).where("RELATED_BRAND is not null")
    baRecommendDS.cache()
    baRecommendDS.where("manageshopid = '35124'").show()
    //保存结果到数据库
//    println("保存结果到数据库")
//    RDBWriter.overwrite(baRecommendDS.where("GOODTYPE_NAME!='null'").repartition(10), db, destTable)
    baRecommendDS.show()
    baRecommendDS.createOrReplaceTempView("brand_ba_recommend")

    //计算门店数小于5的品牌的推荐
    println("计算门店数小于5的品牌的推荐")
    //对标中型品牌推荐
    println("对标中型品牌推荐")
    val baRecommend2TmpDS = sqlContext.sql(
      """
        |select distinct
        |    t2.MONTH_ID,
        |    sapc.brand_id BRAND_ID,
        |    sba.brand_name BRAND_NAME,
        |    sapc.shop_qty BRAND_SHOP_QTY,
        |    sapc.avg_price BRAND_AVG_PRICE,
        |    sba.sec_cat GOODTYPE_ID,
        |    t2.GOODTYPE_NAME,
        |    t2.CITY_ID,
        |    t2.CITY_NAME,
        |    t2.BUSINESS_AREA_ID,
        |    t2.BUSINESS_AREA_NAME,
        |    t2.CORRELATION,
        |    t2.RELATED_BRAND,
        |    t2.REC_TYPE,
        |    t2.UPDATE_TIME
        |from
        |    (select * from shop_avg_price_cnt where brand_id not in (select distinct BRAND_ID from brand_ba_recommend)) sapc
        |left join
        |    (select distinct manageshopid,brand_name,sec_cat from shop_business_area) sba
        |on
        |    sapc.brand_id = sba.manageshopid
        |left join
        |    (select
        |        bbr.MONTH_ID,
        |        bbr.BRAND_ID,
        |        bbr.GOODTYPE_ID,
        |        bbr.GOODTYPE_NAME,
        |        bbr.BRAND_AVG_PRICE,
        |        scp.percent,
        |        bbr.CITY_ID,
        |        bbr.CITY_NAME,
        |        bbr.BUSINESS_AREA_ID,
        |        bbr.BUSINESS_AREA_NAME,
        |        bbr.CORRELATION,
        |        bbr.RELATED_BRAND,
        |        '2' REC_TYPE,
        |        bbr.UPDATE_TIME
        |    from
        |        brand_ba_recommend bbr
        |    inner join
        |        (select * from shop_cnt_percent where (1- percent) >= 0.2 and (1 - percent) <= 0.5) scp
        |    on
        |        bbr.BRAND_ID = scp.brand_id) t2
        |on
        |    abs(1 - sapc.avg_price / t2.BRAND_AVG_PRICE) <= 0.2
        |    and
        |    sba.sec_cat = t2.GOODTYPE_ID
      """.stripMargin).where("GOODTYPE_NAME is not null and UPDATE_TIME is not null and RELATED_BRAND is not null")
    baRecommend2TmpDS.createOrReplaceTempView("brand_ba_recommend2_tmp")
    baRecommend2TmpDS.cache()
    baRecommend2TmpDS.show(50, false)
    //保存到hdfs
    val baRecommend2TmpPath = "/model/addr_location/brand_ba_recommend2_tmp"
    baRecommend2TmpDS.repartition(10).write.mode("overwrite").parquet(baRecommend2TmpPath)
    //读取
    val baRecommend2TmpHdfsDS = sqlContext.read.parquet(baRecommend2TmpPath)
    baRecommend2TmpHdfsDS.createOrReplaceTempView("brand_ba_recommend2_tmp")
    //TODO 去重
    val baRecommend2DS = sqlContext.sql(
      """
        |select
        |    t1.MONTH_ID,
        |    t1.BRAND_ID,
        |    t1.BRAND_NAME,
        |    t1.BRAND_SHOP_QTY,
        |    t1.BRAND_AVG_PRICE,
        |    t1.GOODTYPE_ID,
        |    t1.GOODTYPE_NAME,
        |    t1.CITY_ID,
        |    t1.CITY_NAME,
        |    t1.BUSINESS_AREA_ID,
        |    t1.BUSINESS_AREA_NAME,
        |    t1.CORRELATION,
        |    t1.RELATED_BRAND,
        |    t1.REC_TYPE,
        |    t1.UPDATE_TIME
        |from
        |    (select
        |        t0.MONTH_ID,
        |        t0.BRAND_ID,
        |        t0.BRAND_NAME,
        |        t0.BRAND_SHOP_QTY,
        |        t0.BRAND_AVG_PRICE,
        |        t0.GOODTYPE_ID,
        |        t0.GOODTYPE_NAME,
        |        t0.CITY_ID,
        |        t0.CITY_NAME,
        |        t0.BUSINESS_AREA_ID,
        |        t0.BUSINESS_AREA_NAME,
        |        t0.CORRELATION,
        |        t0.RELATED_BRAND,
        |        t0.REC_TYPE,
        |        t0.UPDATE_TIME,
        |        row_number() over(partition by t0.BRAND_ID,t0.GOODTYPE_ID,t0.BUSINESS_AREA_ID order by t0.CORRELATION desc) RANK
        |    from
        |        brand_ba_recommend2_tmp t0) t1
        |where t1.RANK = 1
      """.stripMargin)
    val baRecommend2Path = "/model/addr_location/brand_ba_recommend2"
    baRecommend2DS.repartition(10).write.mode("overwrite").parquet(baRecommend2Path)
//    println("保存结果到数据库")
//    RDBWriter.overwrite(baRecommend2DS.repartition(10), db, destTable)

    //对标大型品牌推荐
//    println("对标大型品牌推荐")
//    val baRecommend3TmpDS = sqlContext.sql(
//      """
//        |select distinct
//        |    t2.MONTH_ID,
//        |    sapc.brand_id BRAND_ID,
//        |    sba.brand_name BRAND_NAME,
//        |    sapc.shop_qty BRAND_SHOP_QTY,
//        |    sapc.avg_price BRAND_AVG_PRICE,
//        |    sba.sec_cat GOODTYPE_ID,
//        |    t2.GOODTYPE_NAME,
//        |    t2.CITY_ID,
//        |    t2.CITY_NAME,
//        |    t2.BUSINESS_AREA_ID,
//        |    t2.BUSINESS_AREA_NAME,
//        |    t2.CORRELATION,
//        |    t2.RELATED_BRAND,
//        |    t2.REC_TYPE,
//        |    t2.UPDATE_TIME
//        |from
//        |    (select * from shop_avg_price_cnt where brand_id not in (select distinct BRAND_ID from brand_ba_recommend)) sapc
//        |left join
//        |    (select distinct manageshopid,brand_name,sec_cat from shop_business_area) sba
//        |on
//        |    sapc.brand_id = sba.manageshopid
//        |left join
//        |    (select
//        |        bbr.MONTH_ID,
//        |        bbr.BRAND_ID,
//        |        bbr.GOODTYPE_ID,
//        |        bbr.GOODTYPE_NAME,
//        |        bbr.BRAND_AVG_PRICE,
//        |        scp.percent,
//        |        bbr.CITY_ID,
//        |        bbr.CITY_NAME,
//        |        bbr.BUSINESS_AREA_ID,
//        |        bbr.BUSINESS_AREA_NAME,
//        |        bbr.CORRELATION,
//        |        bbr.RELATED_BRAND,
//        |        '3' REC_TYPE,
//        |        bbr.UPDATE_TIME
//        |    from
//        |        brand_ba_recommend bbr
//        |    inner join
//        |        (select * from shop_cnt_percent where (1- percent) <= 0.2) scp
//        |    on
//        |        bbr.BRAND_ID = scp.brand_id) t2
//        |on
//        |    abs(1 - sapc.avg_price / t2.BRAND_AVG_PRICE) <= 0.2
//        |    and
//        |    sba.sec_cat = t2.GOODTYPE_ID
//      """.stripMargin).where("GOODTYPE_NAME is not null and UPDATE_TIME is not null")
//    baRecommend3TmpDS.cache()
//    baRecommend3TmpDS.show(50, false)
//    val baRecommend3Path = "/model/addr_location/brand_ba_recommend3"
//    baRecommend3TmpDS.write.mode("overwrite").parquet(baRecommend3Path)
//    println("保存结果到数据库")
//    RDBWriter.overwrite(baRecommend3TmpDS.repartition(10), db, destTable)

    //读取菜系mapping维度表
    val mappingDS = RDBReader.read(DB.ORACLE_37_BWSWD, "c_dm_sec_cat_mapping")
    mappingDS.createOrReplaceTempView("c_dm_sec_cat_mapping")

    //对菜系进行合并
    println("对菜系进行合并")
    val baRecAll = baRecommendDS.union(baRecommend2DS)
    baRecAll.createOrReplaceTempView("brand_ba_recommend_all")
    val res = sqlContext.sql(
      """
        |select distinct
        |    t1.MONTH_ID,
        |    t1.BRAND_ID,
        |    t1.BRAND_NAME,
        |    t1.BRAND_SHOP_QTY,
        |    t1.BRAND_AVG_PRICE,
        |    t2.sec_cat GOODTYPE_ID,
        |    t2.sec_cat_name GOODTYPE_NAME,
        |    t1.CITY_ID,
        |    t1.CITY_NAME,
        |    t1.BUSINESS_AREA_ID,
        |    t1.BUSINESS_AREA_NAME,
        |    t1.CORRELATION,
        |    t1.RELATED_BRAND,
        |    t1.REC_TYPE,
        |    t1.UPDATE_TIME
        |from
        |	brand_ba_recommend_all t1
        |left join
        |	c_dm_sec_cat_mapping t2
        |on
        |	t1.goodtype_id = t2.sec_cat_old
        |
      """.stripMargin)
      .where("CORRELATION > 0")
    res.cache()
    println("保存结果到数据库")
    reset(targetDate)
    RDBWriter.overwrite(res.repartition(10), db, destTable)
    res.createOrReplaceTempView("res")

    //提取维度表数据
    println("提取维度表数据")
    val cityCat = sqlContext.sql(
      """
        |select distinct CITY_ID,GOODTYPE_ID,GOODTYPE_NAME from res
      """.stripMargin)
    DBEraser.remove(db, "delete from dm_mwboss_bc_category_rec")
    RDBWriter.overwrite(cityCat.repartition(1), db, "dm_mwboss_bc_category_rec")

    val brandDim = sqlContext.sql(
      """
        |select distinct BRAND_ID,BRAND_NAME,BRAND_AVG_PRICE,GOODTYPE_ID,GOODTYPE_NAME,CITY_ID,CITY_NAME from res
      """.stripMargin)
    DBEraser.remove(db, "delete from dm_mwboss_bc_recommend_dim")
    RDBWriter.overwrite(brandDim.repartition(1), db, "dm_mwboss_bc_recommend_dim")

    println("Happy Ending!")

  }
}






