package cn.mwee.model.vo

/**
  * Created by tal on 01/12/2017.
  */
/**
  *
  * @param brand_id
  * @param related_brand
  */
case class RelatedBrands(brand_id: String, related_brand: String)
