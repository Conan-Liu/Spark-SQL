package cn.mwee.model.vo

/**
  * Created by tal on 01/12/2017.
  */
/**
  *
  * @param ba_id1
  * @param ba_id2
  * @param correlation
  */
case class Correlation(ba_id1: String, ba_id2: String, correlation: String)
