package cn.mwee.model.vo

/**
  *
  * @param shopId
  * @param custSum
  * @param clsName
  * @param cnt
  */
case class ItemClsIdDetail(shopId: String, custSum: String, clsName: String, cnt: String)
