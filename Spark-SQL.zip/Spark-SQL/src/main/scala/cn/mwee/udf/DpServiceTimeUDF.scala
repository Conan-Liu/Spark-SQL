package cn.mwee.udf

import cn.mwee.util.{DateUtils, RegUtils}

/**
  * Created by tal on 10/08/2017.
  */
object DpServiceTimeUDF {
  /**
    *
    * @param args
    */
  def main(args: Array[String]): Unit = {
    /**
      * 可能会有的情况:
      * (null)
      * 周一至周日 11:00-22:00
      * 周一至周日 18:00-01:00
      * 周一至周日 11:30-13:00 17:30-21:30
      * 周一至周日 午市 11:00-14:00 晚市 17:00-02:00
      * 11:00-14:00,17:00-22:00
      * 10:00-22:30
      * 10:00-3:00
      * 10:00:21:00
      * 10:00~23:00
      * 10：00~22：00
      * 10:00--21:30
      * 10：00_20:00
      * 10：30--21:00
      * 10-20
      * 午餐晚餐 11:00-22:00 周一至周日
      *
      * 每天
      * 周一至周日 全天;
      * 全天 周一至周日
      * 24小时
      * 24小时营业
      * 周一,周二,周四,周五,周六,周日
      *
      * 周一至周四 06:00-22:00 周五,周六 06:00-12:00
      * 周六,周日 09:00-22:00 周一至周五 10:00-22:30
      * 周五 08:30-14:30 周一至周四 08:30-20:30
      * 周日 00:00-01:00 周一至周四 10:00-12:00 周六 10:00-01:00 周五 10:00-24:00
      *
      * 每天 9: 00 -- 24: 00
      * 每天 6: 30 -- 24: 30
      * 10:00-2:00 周一至周日
      * 周一至周日 06:00-17:00 非营业时段 2017-01-27至2017-01-31
      *
      * 8点到23点
      * 至22:00
      *
      * 店内营业时间是：10:00-凌晨2点。由福州美食圈配送时间是11:00-22:00
      * 8:30 - 凌晨2:00
      *
      * 中午和晚上，早晨不营业
      *
      */


  }


  /**
    *
    * @param serviceTime
    * @return
    */
  def parseServiceTime(serviceTime: String, dest: String): String ={
    val startReg = "([0-9]+[:：][0-9]+)[-~]+"
    val endReg = "[-~]+([0-9]+[:：][0-9]+)"
    val defaultStart = "00:00"
    val defaultEnd = "24:00"
    var workdayStart = ""
    var workdayEnd = ""
    var weekendStart = ""
    var weekendEnd = ""
    var lunchStart = ""
    var lunchEnd = ""
    var dinnerStart = ""
    var dinnerEnd = ""
    var nightStart = ""
    var nightEnd = ""

    var ret = ""

    //如果为空，跳过
    if(serviceTime == null || serviceTime.equals("null")){
      return ""
    }

    //开始
    val startList = RegUtils.getListByReg(serviceTime, startReg)
    //如果返回一个结果
    if(startList.size() == 1){
      workdayStart = startList.get(0)
      weekendStart = workdayStart
    }else if(startList.size() == 2){
      val first = startList.get(0)
      val second = startList.get(1)
      //判断有两个时间段是午餐晚餐，还是工作日周末
      if(!serviceTime.contains("周六") && !serviceTime.contains("周一至周六")){
        workdayStart = first
        weekendStart =first
        lunchStart = first
        dinnerStart = second
      }else{
        val satIndex = serviceTime.indexOf("周六")
        val monIndex = serviceTime.indexOf("周一")
        if(monIndex < satIndex){
          workdayStart = first
          weekendStart =second
        }else{
          workdayStart = second
          weekendStart = second
        }
      }
    }

    //结束
    val endList = RegUtils.getListByReg(serviceTime, endReg)
    //如果返回一个结果
    if(endList.size() == 1){
      workdayEnd = endList.get(0)
      weekendEnd = workdayEnd
    }else if(endList.size() == 2){
      val first = endList.get(0)
      val second = endList.get(1)
      //判断有两个时间段是午餐晚餐，还是工作日周末
      if(!serviceTime.contains("周六")){
        lunchEnd = first
        dinnerEnd = second
        workdayEnd = second
        weekendEnd = second
      }else{
        val satIndex = serviceTime.indexOf("周六")
        val monIndex = serviceTime.indexOf("周一")
        if(monIndex < satIndex){
          workdayEnd = first
          weekendEnd = second
        }else{
          workdayEnd = second
          weekendEnd =first
        }
      }
    }

    //处理几种特殊情况
    if("每天".equals(serviceTime) || serviceTime.contains("24小时") || serviceTime.contains("全天")){
      workdayStart = defaultStart
      weekendStart = defaultStart
      workdayEnd = defaultEnd
      weekendEnd = defaultEnd
    }

    if(dest.equals("workday_start")){
      ret = convertTime(workdayStart, dest)
    }else if(dest.equals("workday_end")){
      ret = convertTime(workdayEnd, dest)
    }else if(dest.equals("weekend_start")){
      ret = convertTime(weekendStart, dest)
    }else if(dest.equals("weekend_end")){
      ret = convertTime(weekendEnd, dest)
    }else if(dest.equals("lunch_start")){
      ret = convertTime(lunchStart, dest)
    }else if(dest.equals("lunch_end")){
      ret = convertTime(lunchEnd, dest)
    }else if(dest.equals("dinner_start")){
      ret = convertTime(dinnerStart, dest)
    }else if(dest.equals("dinner_end")){
      ret = convertTime(dinnerEnd, dest)
    }else if(dest.equals("night_start")){
      ret = convertTime(nightStart, dest)
    }else if(dest.equals("night_end")){
      ret = convertTime(nightEnd, dest)
    }

    ret
  }


  /**
    *
    * @param time
    * @return
    */
  def convertTime(time: String, dest: String): String ={
    val firstDay = "1990-01-01 "
    val secondDay = "1990-01-02 "
    if(dest.contains("_end")){
      if(time.startsWith("0")){
        DateUtils.getTime(secondDay + time + ":00")
      } else {
        DateUtils.getTime(firstDay + time + ":00")
      }
    } else {
      DateUtils.getTime(firstDay + time + ":00")
    }
  }









}
