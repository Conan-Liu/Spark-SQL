package cn.mwee.udf

/**
  * Created by tal on 17/08/2017.
  */
object CommonUDF {
//  /**
//    *
//    * @param args
//    */
//  def main(args: Array[scala.Predef.String]): Unit = {
//    println(getMD5("1"))
//    println(getMD5("2"))
//
//  }

  /**
    *
    * @param text
    * @return
    */
  def getMD5(text: java.lang.String): java.lang.String={
    import java.security.MessageDigest
    val digest = MessageDigest.getInstance("MD5")
    if(text != null){
      digest.digest(text.getBytes).map("%02x".format(_)).mkString
    } else{
      ""
    }
  }
}
