package cn.mwee.udf

/**
  * Created by tal on 10/05/2018.
  */
object StringUDF {

  /**
    *
    * @param args
    */
  def main(args: Array[scala.Predef.String]): Unit = {
    println(isNumber("12423498"))
    println(isNumber("1242349a8"))

  }

  /**
    *
    * @param str
    * @return
    */
  def isNumber(str: String): String ={
    try{
      val num = Integer.parseInt(str)
      str
    }catch {
      case e: Exception => ""
    }
  }



}

