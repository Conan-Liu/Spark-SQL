package cn.mwee.processor

import com.gnow.{DB, Processor}
import com.gnow.eraser.DBEraser
import org.apache.spark.sql.types.{StringType, StructField, StructType}

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
  * Created by tal on 18/10/2017.
  */
class SpecialPageFunnelProcessor extends Processor {
  val db = DB.ORACLE_37_BWSWD
  val appoint1 = "DM_MONITOR_FUNNEL_APPOINT1"
  val appoint2 = "DM_MONITOR_FUNNEL_APPOINT2"
  val appoint3 = "DM_MONITOR_FUNNEL_APPOINT3"

  def reset(targetDate: String): Unit = {
    val sql1 = "delete from %s where day_id = '%s'".format(appoint1, targetDate)
    println(sql1)
    DBEraser.remove(db, sql1)

    val sql2 = "delete from %s where day_id = '%s'".format(appoint2, targetDate)
    println(sql2)
    DBEraser.remove(db, sql2)

    val sql3 = "delete from %s where day_id = '%s'".format(appoint3, targetDate)
    println(sql3)
    DBEraser.remove(db, sql3)

  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
    println("Happy Ending!")

  }

  def process(targetDate: String, input: String, output: String) = {
    val schema = StructType(
      List(
        StructField("business", StringType, true),
        StructField("module", StringType, true),
        StructField("action", StringType, true),
        StructField("open_id", StringType, true),
        StructField("app_version", StringType, true),
        StructField("device_type", StringType, true),
        StructField("device_info", StringType, true),
        StructField("city_id", StringType, true),
        StructField("mobile", StringType, true),
        StructField("location", StringType, true),
        StructField("event", StringType, true),
        StructField("update_time", StringType, true)
      )
    )
    val appOperationLogDF = sqlContext.read.schema(schema).json("/repository/kafka/user_action_app_operation/{date}".replace("{date}", targetDate))
    appOperationLogDF.printSchema()
    appOperationLogDF.registerTempTable("app_operation_log")

    val wechatOperationLogDF = sqlContext.read.schema(schema).json("/repository/kafka/user_action_wechat_operation/{date}".replace("{date}", targetDate))
    wechatOperationLogDF.printSchema()
    wechatOperationLogDF.registerTempTable("wechat_operation_log")

    var operationLogDF = appOperationLogDF.unionAll(wechatOperationLogDF).distinct()
    if(!operationLogDF.columns.toList.contains("open_id")){
      operationLogDF = operationLogDF.withColumn("open_id", operationLogDF("mobile"))
    }
    operationLogDF.registerTempTable("operation_log")

    val logDF = sqlContext.sql(
      """
        |select
        | business
        | ,t1.module
        | ,t1.action
        | ,t1.app_version
        | ,t1.device_type
        | ,t1.device_info
        | ,t1.city_id
        | ,t1.mobile
        | ,t1.open_id
        | ,t1.location
        | ,get_json_object(t1.event, '$.page') page
        | ,get_json_object(t1.event, '$.area') area
        | ,get_json_object(t1.event, '$.url') url
        | ,get_json_object(t1.event, '$.keyword') keyword
        | ,get_json_object(t1.event, '$.content_id') content_id
        | ,get_json_object(t1.event, '$.etype') etype
        | ,get_json_object(t1.event, '$.event') event
        | ,get_json_object(t1.event, '$.order_type') order_type
        | ,get_json_object(t1.event, '$.order_no') order_no
        | ,get_json_object(t1.event, '$.waiting_table') waiting_table
        | ,get_json_object(t1.event, '$.estimated_waiting_time') estimated_waiting_time
        | ,substr(cast(cast(t1.update_time as long) as string), 0, 10) time
        | ,from_unixtime(substr(cast(cast(t1.update_time as long) as string), 0, 10))
        |from
        | operation_log t1
        |order by
        | t1.device_info
        | ,time
      """.stripMargin)
    //debug
    //    logDF.where("keyword is null")
    //      .select("device_info", "page", "area", "etype", "event", "time", "url").show(100, false)
    import sqlContext.implicits._
    //    //测试数据
    //    val tdDF = sqlContext.sparkContext.parallelize(Seq(
    //      Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","https://m.mwee.cn/c_operation/specialv2?id=37","h5_special_V2","","","","1510024871")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","list_shops_branch","","","","1510025424")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","detail_shop","","","","1510026643")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","reservation_order","","","","1510027312")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","pay_book","","","","1510027339")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","reservation_order_detail","","","","1510029032")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","https://m.mwee.cn/c_operation/specialv2?id=37","h5_special_V2","","","","1510033281")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","","","10","back","1510037530")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","https://m.mwee.cn/c_operation/specialv2?id=37","h5_special_V2","","","","1510041779")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","list_shops_branch","","","","1510046028")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","detail_shop","","","","1510050277")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","quick_queue_order","","","","1510054526")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","pay_queue_fast","","","","1510058775")
    //      ,Log("FA258D5A1F2A442A86F3B8D5997C1178,1a55e8b412f4ac810e2044aa1bb8560bc9b6236ecdef05529b94e41e7cdeb223","","quick_queue_order_detail","","","","1510063024")
    //    )).toDF()

    //漏斗计算最好能做成可配置的
    //访问节点标注
    val markedLogDF =
    logDF
      .where("keyword is null")
      .select("device_info", "url", "page", "area", "etype", "event", "time").rdd
      .map(row =>{
        var userId = ""
        if(row.get(0) != null){
          userId = row.get(0).toString
        }
        var url = ""
        if(row.get(1) != null){
          url = row.get(1).toString
          //https://m.mwee.cn/c_operation/specialv2?id=50 TODO
          if(url.contains("specialv2")){
            url = url.split("&")(0)
          }
          if(url.contains("specialv1")){
            url = url.split("&")(0)
          }
        }
        var page = ""
        if(row.get(2) != null){
          page = row.get(2).toString
        }
        var area = ""
        if(row.get(3) != null){
          area = row.get(3).toString
        }
        var etype = ""
        if(row.get(4) != null){
          etype = row.get(4).toString
        }
        var event = ""
        if(row.get(5) != null){
          event = row.get(5).toString
        }
        val time = row.get(6).toString
        if(userId.equals("")){
          userId = time
        }
        //进行访问节点标注 将路径分析转换为字符串匹配
        if((page.equals("h5_special_V2") || page.equals("h5_special_V1")) && !url.contains("-") && !url.contains("%")){
          Node(userId, "special", url, 0, time.toLong)
        } else if(page.equals("list_shops_branch")){
          Node(userId, "list", "", 0, time.toLong)
        } else if(page.equals("detail_shop")){
          Node(userId, "shop", "", 0, time.toLong)
        } else if(page.equals("reservation_order")){ //预订支付页
          Node(userId, "order", "", 1, time.toLong)
        } else if(page.equals("reservation_order_detail")){ //预订详情页
          Node(userId, "orderDetail", "", 1, time.toLong)
        } else if(page.equals("quick_queue_order")){ //预约支付页
          Node(userId, "order", "", 2, time.toLong)
        } else if(page.equals("quick_queue_order_detail")){ //预约详情页
          Node(userId, "orderDetail", "", 2, time.toLong)
        } else if(etype.equals("10")){
          Node(userId, "back", "", 0, time.toLong) //返回
        } else{
          Node(userId, "", "", 0, time.toLong)
        }
      })

    //debug
    println("markedLogDF:")
    markedLogDF.toDF().where("page!=''").select("userId", "page").show(1000, false)
    println("end")

    val groupedLog = markedLogDF
      //过滤掉节点为空的数据
      .filter(node => !node.page.equals(""))
      .map(node => (node.userId, node))
      //根据用户groupBy
      .groupByKey()
    //缓存
    groupedLog.cache()
    //debug
    println("groupedLog:")
    //    groupedLog.collect().foreach(println)
    println("end")

    //配置的漏斗
    //情况一
    val funnelReserv1 = List(
      Node("", "special", "", 0, 0),
      Node("", "list", "", 0, 0),
      Node("", "shop", "", 0, 0),
      Node("", "order", "", 0, 0),
      Node("", "orderDetail", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val appoint1Res = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[Node]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnelReserv1.size
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[Node]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnelReserv1(j)
                if(j == 0 && cNode.page.equals(fNode.page)){
                  path.append(cNode)
                }else if(j == 1 && cNode.page.equals("back")){
                  break()
                }else if(j == 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnelReserv1(j)
                if(j == 0 && cNode.page.equals(fNode.page)){
                  path.append(cNode)
                }else if(j == 1 && cNode.page.equals("back")){
                  break()
                }else if(j == 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val url = list(0).url
        val len = list.size
        val lastNodeOrderType = list(len - 1).orderType
        if(lastNodeOrderType > 0){
          list.map(node => Node(node.userId, node.page, url, lastNodeOrderType, node.time))
        } else{
          val a1 = list.map(node => Node(node.userId, node.page, url, 1, node.time))
          val a2 = list.map(node => Node(node.userId, node.page, url, 2, node.time))
          a1.union(a2)
        }
      })
      .map(node => ((node.url, node.page, node.orderType), 1))
      .reduceByKey(_+_)
      .map(all => {
        val (url, page, orderType) = all._1
        val cnt = all._2
        ((url, orderType), (page, cnt))
      })
      .groupByKey()
      .collect()
      .map(all => {
        println(all)
        val (url, orderType) = all._1
        val pages = all._2.toArray
        val map = new mutable.HashMap[String, Int]()

        pages.foreach(pageDetail => {
          val (page, cnt) = pageDetail
          map.put(page, cnt)
        })
        println(map)

        val sql = "insert into %s values('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')".format(
          appoint1
          ,targetDate
          ,url
          ,map.get(funnelReserv1(0).page).getOrElse(0)
          ,map.get(funnelReserv1(1).page).getOrElse(0)
          ,map.get(funnelReserv1(2).page).getOrElse(0)
          ,map.get(funnelReserv1(3).page).getOrElse(0)
          ,map.get(funnelReserv1(4).page).getOrElse(0)
          ,orderType
          ,System.currentTimeMillis()
        )
        println(sql)
        sql
      })
    appoint1Res.filter(sql => !sql.isEmpty).foreach(sql => DBEraser.insert(db, sql))

    //分割线
    println()
    println("--" * 50)
    println()

    //情况二
    val funnelReserv2 = List(
      Node("", "special", "", 0, 0),
      Node("", "shop", "", 0, 0),
      Node("", "order", "", 0, 0),
      Node("", "orderDetail", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val appoint2Res = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[Node]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnelReserv2.size
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[Node]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnelReserv2(j)
                if(j == 0 && cNode.page.equals(fNode.page)){
                  path.append(cNode)
                }else if(j == 1 && cNode.page.equals("back")){
                  break()
                }else if(j == 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnelReserv2(j)
                if(j == 0 && cNode.page.equals(fNode.page)){
                  path.append(cNode)
                }else if(j == 1 && cNode.page.equals("back")){
                  break()
                }else if(j == 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val url = list(0).url
        val len = list.size
        val lastNodeOrderType = list(len - 1).orderType
        if(lastNodeOrderType > 0){
          list.map(node => Node(node.userId, node.page, url, lastNodeOrderType, node.time))
        } else{
          val a1 = list.map(node => Node(node.userId, node.page, url, 1, node.time))
          val a2 = list.map(node => Node(node.userId, node.page, url, 2, node.time))
          a1.union(a2)
        }
      })
      .map(node => ((node.url, node.page, node.orderType), 1))
      .reduceByKey(_+_)
      .map(all => {
        val (url, page, orderType) = all._1
        val cnt = all._2
        ((url, orderType), (page, cnt))
      })
      .groupByKey()
      .collect()
      .map(all => {
        println(all)
        val (url, orderType) = all._1
        val pages = all._2
        val map = new mutable.HashMap[String, Int]()

        pages.foreach(pageDetail => {
          val (page, cnt) = pageDetail
          map.put(page, cnt)
        })
        println(map)

        val sql = "insert into %s values('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')".format(
          appoint2
          ,targetDate
          ,url
          ,map.get(funnelReserv2(0).page).getOrElse(0)
          ,map.get(funnelReserv2(1).page).getOrElse(0)
          ,map.get(funnelReserv2(2).page).getOrElse(0)
          ,map.get(funnelReserv2(3).page).getOrElse(0)
          ,orderType
          ,System.currentTimeMillis()
        )
        println(sql)
        sql
      })
    appoint2Res.foreach(sql => DBEraser.insert(db, sql))

    //分割线
    println()
    println("--" * 50)
    println()

    val funnelReserv3 = List(
      Node("", "special", "", 0, 0),
      Node("", "order", "", 0, 0),
      Node("", "orderDetail", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val appoint3Res = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[Node]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnelReserv3.size
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[Node]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnelReserv3(j)
                if(j == 0 && cNode.page.equals(fNode.page)){
                  path.append(cNode)
                }else if(j == 1 && cNode.page.equals("back")){
                  break()
                }else if(j == 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnelReserv3(j)
                if(j == 0 && cNode.page.equals(fNode.page)){
                  path.append(cNode)
                }else if(j == 1 && cNode.page.equals("back")){
                  break()
                }else if(j == 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.page.equals(fNode.page) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val url = list(0).url
        val len = list.size
        val lastNodeOrderType = list(len - 1).orderType
        if(lastNodeOrderType > 0){
          list.map(node => Node(node.userId, node.page, url, lastNodeOrderType, node.time))
        } else{
          val a1 = list.map(node => Node(node.userId, node.page, url, 1, node.time))
          val a2 = list.map(node => Node(node.userId, node.page, url, 2, node.time))
          a1.union(a2)
        }
      })
      .map(node => ((node.url, node.page, node.orderType), 1))
      .reduceByKey(_+_)
      .map(all => {
        val (url, page, orderType) = all._1
        val cnt = all._2
        ((url, orderType), (page, cnt))
      })
      .groupByKey()
      .collect()
      .map(all => {
        println(all)
        val (url, orderType) = all._1
        val pages = all._2
        val map = new mutable.HashMap[String, Int]()

        pages.foreach(pageDetail => {
          val (page, cnt) = pageDetail
          map.put(page, cnt)
        })
        println(map)

        val sql = "insert into %s values('%s', '%s', '%s', '%s', '%s', '%s', '%s')".format(
          appoint3
          ,targetDate
          ,url
          ,map.get(funnelReserv3(0).page).getOrElse(0)
          ,map.get(funnelReserv3(1).page).getOrElse(0)
          ,map.get(funnelReserv3(2).page).getOrElse(0)
          ,orderType
          ,System.currentTimeMillis()
        )
        println(sql)
        sql
      })
    appoint3Res.foreach(sql => DBEraser.insert(db, sql))
    //END
  }
}



/**
  * 用来标识每个访问节点
  *
  * @param userId
  * @param page
  * @param url
  * @param orderType
  * @param time
  */
case class Node(userId: String, page: String, url: String, orderType: Int, time: Long)

/**
  *
  * @param device_info
  * @param url
  * @param page
  * @param area
  * @param etype
  * @param event
  * @param time
  */
case class Log(device_info: String, url: String, page: String, area: String, etype: String, event: String, time: String)


