package cn.mwee.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}

/**
  * Created by tal on 25/10/2017.
  */
class QueueingEstimwaitValidationProcessor extends Processor {
  val db = DB.ORACLE_12_BWSWD
  val destTable = "QUEUEING_ESTIMWAIT_VALIDATION"
  var res: DataFrame = _

  def reset(targetDate: String): Unit = {
    val sql1 = "delete from %s where day_id = '%s'".format(destTable, targetDate)
    println(sql1)
    DBEraser.remove(db, sql1)

  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    RDBWriter.save(res.repartition(10), db, destTable)
    println("Happy Ending!")

  }

  def process(targetDate: String, input: String, output: String) = {
    val qevLogDF = sqlContext.read.json("/repository/kafka/estimatewaittime_estimwait_validation/{date}".replace("{date}", targetDate))
    qevLogDF.printSchema()
    qevLogDF.createOrReplaceTempView("qev")

    val tmpRes = sqlContext.sql(
      """
        |select
        |	'%s' day_id,
        |	t1.shopid shop_id,
        |	t1.queueid queue_id,
        |	t1.serialId serial_id,
        |	t1.type type,
        |	t1.modeversion model_version,
        |	unix_timestamp(t1.currtime) current_time,
        |	t1.estimatetime estimate_time,
        |	t1.estimatetime_old estimate_time_old
        |from
        |	qev t1
        |where
        | t1.serialId != ''
      """.stripMargin.format(targetDate))
    tmpRes.createOrReplaceTempView("tmp_res")
    tmpRes.show()

    val tmpRes2 = sqlContext.sql(
      """
        |select distinct
        |  t1.day_id,
        |  t1.shop_id,
        |  t1.queue_id,
        |  t1.serial_id,
        |  t1.type,
        |  t1.model_version,
        |  t1.current_time,
        |  t1.estimate_time,
        |  t1.estimate_time_old
        |from
        |  tmp_res t1
        |inner join
        |  (select
        |    t1.day_id,
        |    t1.shop_id,
        |    t1.queue_id,
        |    t1.serial_id,
        |    t1.type,
        |    t1.model_version,
        |    min(t1.current_time) min_time
        |  from
        |    tmp_res t1
        |  group by
        |    t1.day_id,
        |    t1.shop_id,
        |    t1.queue_id,
        |    t1.serial_id,
        |    t1.type,
        |    t1.model_version) t2
        |on
        |  t1.day_id = t2.day_id
        |  and
        |  t1.shop_id = t2.shop_id
        |  and
        |  t1.queue_id = t2.queue_id
        |  and
        |  t1.serial_id = t2.serial_id
        |  and
        |  t1.type = t2.type
        |  and
        |  t1.model_version = t2.model_version
        |  and t1.current_time = t2.min_time
        |
      """.stripMargin)
    tmpRes2.createOrReplaceTempView("tmp_res2")
    tmpRes2.show()

    res = sqlContext.sql(
      """
        |select
        |    t2.day_id,
        |    t2.shop_id,
        |    t2.queue_id,
        |    t2.serial_id,
        |    t2.model_version,
        |    t2.current_time create_time,
        |    t3.current_time last_time,
        |    t2.estimate_time,
        |    t2.estimate_time_old
        |from
        |  (select
        |    t1.day_id,
        |    t1.shop_id,
        |    t1.queue_id,
        |    t1.serial_id,
        |    t1.type,
        |    t1.model_version,
        |    t1.current_time,
        |    t1.estimate_time,
        |    t1.estimate_time_old
        |  from
        |    tmp_res2 t1
        |  where
        |    t1.type = 'alloc') t2
        |inner join
        |  (select
        |    t1.day_id,
        |    t1.shop_id,
        |    t1.queue_id,
        |    t1.serial_id,
        |    t1.type,
        |    t1.model_version,
        |    t1.current_time,
        |    t1.estimate_time,
        |    t1.estimate_time_old
        |  from
        |    tmp_res2 t1
        |  where
        |    t1.type = 'call') t3
        |on
        |  t2.day_id = t3.day_id
        |  and
        |  t2.shop_id = t3.shop_id
        |  and
        |  t2.queue_id = t3.queue_id
        |  and
        |  t2.serial_id = t3.serial_id
      """.stripMargin)
    res.show()







  }
}





