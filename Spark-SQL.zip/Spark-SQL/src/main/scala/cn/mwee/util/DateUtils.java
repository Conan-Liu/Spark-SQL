package cn.mwee.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtils {
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat sdf_month = new SimpleDateFormat("yyyy-MM");
	private static SimpleDateFormat sdf_all = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/**
	 * 计算三个月前的一天，比如根据2017-08-01计算出2017-05-01
	 * @param today
	 * @return
	 */
	public static String getPreMonthDay(String today){
		Date date = null;
		try{
			date = sdf_all.parse(today + " 00:00:00");//取时间
		} catch (Exception e) {
			e.printStackTrace();
		}
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(calendar.MONTH,-3);//把日期往后增加一天.整数往后推,负数往前移动
		date=calendar.getTime(); //这个时间就是日期往后推一天的结果
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = formatter.format(date);
		return dateString;
	}

	public static String getDay(String srcDate, int days){
		Date date = null;
		try{
			date = sdf_all.parse(srcDate + " 00:00:00");//取时间
		} catch (Exception e) {
			e.printStackTrace();
		}
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(calendar.DATE,days);//把日期往后增加一天.整数往后推,负数往前移动
		date=calendar.getTime(); //这个时间就是日期往后推一天的结果
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = formatter.format(date);
		return dateString;
	}

	public static String getNextDay(int days){
		Date date=new Date();//取时间
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(calendar.DATE,days);//把日期往后增加一天.整数往后推,负数往前移动
		date=calendar.getTime(); //这个时间就是日期往后推一天的结果
		SimpleDateFormat formatter = new SimpleDateFormat("yyMMdd");
		String dateString = formatter.format(date);
		return dateString;
	}

	public static String getNextDay2(int days){
		Date date=new Date();//取时间
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(calendar.DATE,days);//把日期往后增加一天.整数往后推,负数往前移动
		date=calendar.getTime(); //这个时间就是日期往后推一天的结果
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = formatter.format(date);
		return dateString;
	}

	public static String getDateFormatted(String srcDate, String format){
		Date date = null;
		try{
			date = sdf_all.parse(srcDate + " 00:00:00");//取时间
		} catch (Exception e) {
			e.printStackTrace();
		}
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(calendar.DATE,0);//把日期往后增加一天.整数往后推,负数往前移动
		date=calendar.getTime(); //这个时间就是日期往后推一天的结果
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		String dateString = formatter.format(date);
		return dateString;
	}

	public static String getCurrentTime(){
		return sdf_all.format(new Date());

	}

	public static String getToday(){
		return sdf.format(new Date());

	}

	public static String getTime(String time){
		if(time == null || time.equals("null")){
			return "";
		}

		Date date = null;
		try{
			date = sdf_all.parse(time);
		} catch (Exception e){
			e.printStackTrace();
			return "";
		}

		return date.getTime() + "";

	}

	public static String getYear(){
		Date date=new Date();//取时间
		String day = sdf.format(date);
		return day.split("-")[0];
	}

	public static Integer getWeekOfYear(String srcDate){
		Date date = null;
		try{
			date = sdf_all.parse(srcDate + " 00:00:00");//取时间
		} catch (Exception e) {
			e.printStackTrace();
		}
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		return calendar.get(Calendar.WEEK_OF_YEAR);
	}

	public static String getMonth(){
		Date date = new Date();
		String day = sdf_month.format(date);
		return day;
	}

	public static String getLastMonth(){
		Date date = new Date();
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(calendar.MONTH,-1);//把日期往后增加一天.整数往后推,负数往前移动
		date=calendar.getTime(); //这个时间就是日期往后推一天的结果
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM");
		String dateString = formatter.format(date);
		return dateString;
	}

	public static String getMonth(String time){
		Date date = new Date(Long.parseLong(time));
		String day = sdf_month.format(date);
		return day;

	}

	public static String getMonthLastDay(String srcDate, int index){
		Date date = null;
		try{
			date = sdf_all.parse(srcDate + " 00:00:00");//取时间
		} catch (Exception e) {
			e.printStackTrace();
		}
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(calendar.MONTH, index);//把日期往后增加一天.整数往后推,负数往前移动
		date=calendar.getTime(); //这个时间就是日期往后推一天的结果
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = formatter.format(date);
		return dateString;

	}

	public static String getMonthId(String srcDate){
		Date date = null;
		try{
			date = sdf_all.parse(srcDate + " 00:00:00");//取时间
		} catch (Exception e) {
			e.printStackTrace();
		}
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(calendar.MONTH,-1);//把日期往后增加一天.整数往后推,负数往前移动
		date=calendar.getTime(); //这个时间就是日期往后推一天的结果
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM");
		String dateString = formatter.format(date);
		return dateString;
	}

	public static void main(String[] args) {

		System.out.println(getLastMonth());
	}
}
