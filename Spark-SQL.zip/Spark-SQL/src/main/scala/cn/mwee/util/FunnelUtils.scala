package cn.mwee.util

import com.gnow.processor.vo.AppNode
import org.apache.spark.rdd.RDD

import scala.collection.mutable.ListBuffer

/**
  * Created by tal on 19/04/2018.
  */
object FunnelUtils {
  /**
    * 根据漏斗次数来计算
    */
  def getAppFunnelByTimes(groupedLog: RDD[(String, Iterable[AppNode])], funnel1: List[AppNode]): RDD[AppNode] ={
    //将访问路径切割 并进行漏斗匹配
    val res1Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[AppNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel1.size
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[AppNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel1(j)
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel1(j)
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[AppNode]()
        //对list中数据进行补0处理
        if(list.size > 1){
          val first = list(0)
          val userId = first.userId
          val cityId = first.cityId
          val contentId = first.contentId
          for(i <- 0 to funnel1.size - 1){
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel1(i)
              listBuf.append(AppNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time, node.cityId, node.area))
            } else {
              val funnelNode = funnel1(i)
              listBuf.append(AppNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0, cityId, funnelNode.area))
            }
          }
        }
        if(listBuf.size == 0){
          for(i <- 0 to funnel1.size - 1){
            val funnelNode = funnel1(i)
            listBuf.append(AppNode("", funnelNode.nodeId, funnelNode.pageId, funnelNode.page, "", funnelNode.event, 1, 0, funnelNode.cityId, funnelNode.area))
          }
        }
        listBuf
      })
    res1Rdd
  }

  /**
    * 根据漏斗人数来计算
    */
  def getAppFunnelByUsers(groupedLog: RDD[(String, Iterable[AppNode])], funnel1: List[AppNode]): RDD[AppNode] ={
    //将访问路径切割 并进行漏斗匹配
    val res1Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[AppNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel1.size
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[AppNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel1(j)
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel1(j)
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        //从list取最长的那个
        if(list.size > 0){
          val listTmp = list.filter(li2 => li2.size == list.map(li => li.size).max)(0)
          ListBuffer(listTmp)
        }else{
          new ListBuffer[List[AppNode]]()
        }
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[AppNode]()
        //对list中数据进行补0处理
        if(list.size > 1){
          val first = list(0)
          val userId = first.userId
          val cityId = first.cityId
          val contentId = first.contentId
          for(i <- 0 to funnel1.size - 1){
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel1(i)
              listBuf.append(AppNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time, node.cityId, node.area))
            } else {
              val funnelNode = funnel1(i)
              listBuf.append(AppNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0, cityId, funnelNode.area))
            }
          }
        }
        if(listBuf.size == 0){
          for(i <- 0 to funnel1.size - 1){
            val funnelNode = funnel1(i)
            listBuf.append(AppNode("", funnelNode.nodeId, funnelNode.pageId, funnelNode.page, "", funnelNode.event, 1, 0, funnelNode.cityId, funnelNode.area))
          }
        }
        listBuf
      })
    res1Rdd
  }
}





