package cn.mwee.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by tal on 20/07/2017.
 */
public class RegUtils {
    public static void main(String[] args) {
//        String res = getByReg("丫丫网 丫 丫 4.3 SNS/社交网络上海100-499人","(.*?) [0-9].[0-9] ");
//        System.out.println(res);

//        System.out.println(remove("上海(山)海关路（130号）(新昌路和成都北路)", "(", ")"));

//        System.out.println("上海延安东路7号仟宸大厦 7楼".replace(" ", ""));

        getListByReg("a1234ba12345b", "a([0-9]+)b");
    }

    /**
     *
     * @param str
     * @param reg
     * @return
     */
    public static String getByReg(String str, String reg){
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(str);
        if(matcher.find()){
            String mat = matcher.group(1);
            if("null".equals(mat) || mat == null){
                mat = "";
            }
            return mat;
        }
        return "";
    }

    /**
     *
     * @param str
     * @param reg
     * @return
     */
    public static List<String> getListByReg(String str, String reg){
        List<String> list = new ArrayList<String>();
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(str);
        while (matcher.find()){
            list.add(matcher.group(1));
        }
        return list;
    }

    /**
     * 根据始末
     *
     * @param src
     * @param start
     * @param end
     * @return
     */
    public static String remove(String src, String start, String end){
        String replace = getByReg(src, "[" + start + "](.*?)[" + end + "]");
        src = src.replace(start + replace + end, "");

        return src;
    }
}
