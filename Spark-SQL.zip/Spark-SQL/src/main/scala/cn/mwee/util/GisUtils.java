package cn.mwee.util;

import com.spatial4j.core.context.SpatialContext;
import com.spatial4j.core.distance.DistanceUtils;

/**
 * Created by tal on 10/08/2017.
 */
public class GisUtils {
    /**
     * 根据多个经纬度点计算它的几何中心
     *
     * @param latLons
     * @return
     *
     */
    public static String getCenter(String[] latLons){
        int total = latLons.length;
        double lat = 0;
        double lon = 0;
        for(String latLon: latLons){
            lat += Double.parseDouble(latLon.split(",")[0]) * Math.PI / 180;
            lon += Double.parseDouble(latLon.split(",")[1]) * Math.PI / 180;
        }
        lat = lat / total;
        lon = lon / total;
        return lat * 180 / Math.PI + "," + lon * 180 / Math.PI;
    }


    /**
     *
     * @param latLon1
     * @param latLon2
     * @return
     */
    public static double calcDistance(String latLon1, String latLon2){
        // 移动设备经纬度
        double lon1 = Double.parseDouble(latLon1.split(",")[1]), lat1 = Double.parseDouble(latLon1.split(",")[0]);
        // 商户经纬度
        double lon2 = Double.parseDouble(latLon2.split(",")[1]), lat2 = Double.parseDouble(latLon2.split(",")[0]);

        SpatialContext geo = SpatialContext.GEO;
        double distance = geo.calcDistance(geo.makePoint(lon1, lat1), geo.makePoint(lon2, lat2))
                * DistanceUtils.DEG_TO_KM;
//        System.out.println(distance);// KM

        return distance;
    }




}
