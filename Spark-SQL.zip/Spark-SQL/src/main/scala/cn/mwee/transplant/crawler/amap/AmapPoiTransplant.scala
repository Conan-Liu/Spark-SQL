package cn.mwee.transplant.crawler.amap

import cn.mwee.transplant.crawler.amap.vo.{Ba, Poi}
import cn.mwee.udf.CommonUDF
import cn.mwee.util.{GisUtils, RegUtils}
import com.github.davidmoten.geo.{GeoHash, LatLong}
import com.gnow.eraser.DBEraser
import com.gnow.persistence.{RDBReader, RDBWriter}
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame
import scala.collection.mutable.ListBuffer

/**
  * Created by tal on 24/08/2017.
  */
class AmapPoiTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val destTable = "AMAP_POI_201709"
  val key = "POI_MD5_KEY"
  val DP_BA = "DIANPING_BUSINESS_AREA"
  val AMAP_CITY = "AMAP_CITY"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where crawl_batch=\'%s\'".format(destTable, targetDate)
    println(sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res.repartition(5), db, destTable)
    println("Happy Ending!")
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/amap/poi/%s/*".format(targetDate)
    val destPath = "/crawler/amap/poi/%s".format(targetDate)
    //读取划分好的商圈数据
    val dpBa = RDBReader.read(DB.ORACLE_7_BWSWD, DP_BA).where("GEOHASH6 is not null").rdd.map(row => Ba(row.get(0).toString, row.get(1).toString, row.get(5).toString, row.get(6).toString, row.get(10).toString))
    val dpBaB = dpBa.collect()

    //读取高德城市ID到点评城市ID的mapping数据
    val dpAmapMap = RDBReader.read(DB.ORACLE_7_BWSWD, AMAP_CITY).where("CITY_CODE is not null and CITY_ID_DP is not null").dropDuplicates(Seq("CITY_CODE", "CITY_ID_DP")).rdd.map(row => (row.get(0), row.get(6))).collect()

    //读取爬取得POI数据
    val comments = sqlContext.sparkContext.textFile(path, 10).map(line => {
      val id = RegUtils.getByReg(line, "id:\"(.*?)\"")
      val tag = RegUtils.getByReg(line, "tag:\"(.*?)\",")
      val name = RegUtils.getByReg(line, "name:\"(.*?)\",")
      val typeName = RegUtils.getByReg(line, "type:\"(.*?)\",")
      //特殊 有这样的：150909|150907
      val typecode = RegUtils.getByReg(line, "typecode:\"(.*?)\",")
      val address = RegUtils.getByReg(line, "address:\"(.*?)\",")
      val location = RegUtils.getByReg(line, "location:\"(.*?)\"")
      val website = RegUtils.getByReg(line, "website:\"(.*?)\"")
      var pcode = RegUtils.getByReg(line, "pcode:\"(.*?)\"")
      if(pcode.equals("{}") || pcode.equals("[]")){
        pcode = ""
      }
      if(!pcode.equals("")){
        pcode = pcode.toInt.toString
      }

      val pname = RegUtils.getByReg(line, "pname:\"(.*?)\"")
      val citycode = RegUtils.getByReg(line, "citycode:\"(.*?)\"")
      val cityname = RegUtils.getByReg(line, "cityname:\"(.*?)\"")
      var adcode = RegUtils.getByReg(line, "adcode:\"(.*?)\"")
      if(adcode.equals("{}") || adcode.equals("[]")){
        adcode = ""
      }
      if(!adcode.equals("")){
        adcode = adcode.toInt.toString
      }
      val adname = RegUtils.getByReg(line, "adname:\"(.*?)\"")
      val business_area = RegUtils.getByReg(line, "business_area:\"(.*?)\"")

      //计算点评城市ID
      var city_id_dp = ""
      dpAmapMap.foreach(row => {
        if(row._1.toString.equals(citycode)){
          city_id_dp = row._2.toString
        }
      })

      //计算店铺商圈ID 第一种方法
//      var business_area_id_dp = ""
//      val lat = location.split(",")(1)
//      val lon = location.split(",")(0)
//      val geohash = GeoHash.encodeHash(new LatLong(lat.toDouble, lon.toDouble))
//      //第一种情况 用包含来归类，并考虑poi离哪个商圈中心更近
//      var dpBaCandidate = ListBuffer[Ba]()
//      dpBaB.foreach(ba => {
//        if(ba.geohash.contains(geohash.substring(0,6))){
//          business_area_id_dp = ba.ba
//          dpBaCandidate.append(ba)
//        }
//      })
//      if(!business_area_id_dp.equals("")){
//        var minDistance = 100.0
//        dpBaCandidate.foreach(ba => {
//          if(!ba.center.equals("NaN,NaN")){
//            val distance = GisUtils.calcDistance(lat + "," + lon, ba.center)
//            if(distance < minDistance){
//              minDistance = distance
//              if(distance < ba.radius.toDouble * 1.5){
//                business_area_id_dp = ba.ba
//              }
//            }
//          }
//        })
//      }
//      //第二种情况 用距离来归类
//      if(business_area_id_dp.equals("")){
//        var minDistance = 100.0
//        dpBaB.foreach(ba => {
//          if(!ba.center.equals("NaN,NaN")){
//            val distance = GisUtils.calcDistance(lat + "," + lon, ba.center)
//            if(distance < minDistance){
//              minDistance = distance
//              if(distance < ba.radius.toDouble * 1.5){
//                business_area_id_dp = ba.ba
//              }
//            }
//          }
//        })
//      }
//      var dpBaAll = ListBuffer[String]()
//      dpBaAll.append(business_area_id_dp)


      //计算店铺商圈ID 第二种方法 将poi点划入已经画好的点评商圈，并考虑多商圈的情况
      var business_area_id_dp = ""
      val dpBa = dpBaB
      val locationSplit = location.split(",")
      var lat = "0"
      var lon = "0"
      if(locationSplit.size > 1){
        lat = location.split(",")(1)
        lon = location.split(",")(0)
      }

      val geohash = GeoHash.encodeHash(new LatLong(lat.toDouble, lon.toDouble))
      var dpBaAll = ListBuffer[String]()
      dpBa.foreach(ba => {
        if(ba.geohash.contains(geohash.substring(0,6))){
          business_area_id_dp = ba.ba
          dpBaAll.append(business_area_id_dp)
        }
      })

      //其他信息
      val shopinfo = RegUtils.getByReg(line, "shopinfo:\"(.*?)\"")
      val rating = RegUtils.getByReg(line, "rating:\"(.*?)\"")
      val cost = RegUtils.getByReg(line, "cost:\"(.*?)\"")
      val open_time = RegUtils.getByReg(line, "open_time:\"(.*?)\"")
      val crawlBatch = targetDate
      val crawlTime = RegUtils.getByReg(line, "crawlTime:\"(.*?)\"")

      Poi(id, tag, name, typeName, typecode, address, location, pcode, pname, citycode, cityname, adcode, adname, business_area, city_id_dp, dpBaAll.mkString(","), shopinfo, rating, cost, open_time, crawlBatch, crawlTime)
    })
      .flatMap(poi => {  //考虑多商圈的情况
      val baIds = poi.business_area_id_dp.split(",")
      var res = ListBuffer[Poi]()
      for(ba <- baIds){
        val resPoi = Poi(poi.id, poi.tag, poi.name, poi.typeName, poi.typecode, poi.address, poi.location, poi.pcode, poi.pname, poi.citycode, poi.cityname, poi.adcode, poi.adname, poi.business_area, poi.city_id_dp, ba.toString, poi.shopinfo, poi.rating, poi.cost, poi.open_time, poi.crawlBatch, poi.crawlTime)
        res.append(resPoi)
      }
      res
    })

    import sqlContext.implicits._
    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))
    val srcDF = comments.toDF()
    srcDF.registerTempTable("srcTbl")
//    srcDF.select("business_area_id_dp").show()//Test

    res = sqlContext.sql(
      """
        |select
        |  getMD5(concat_ws(',', id, business_area_id_dp, crawlBatch)) POI_MD5_KEY,
        |  id ID,
        |  tag TAG,
        |  name NAME,
        |  typeName TYPE,
        |  typecode TYPE_CODE,
        |  address ADDRESS,
        |  location LOCATION,
        |  pcode P_CODE,
        |  pname P_NAME,
        |  citycode CITY_CODE,
        |  cityname CITY_NAME,
        |  adcode AD_CODE,
        |  adname AD_NAME,
        |  business_area BUSINESS_AREA,
        |  city_id_dp CITY_ID_DP,
        |  business_area_id_dp BUSINESS_AREA_ID_DP,
        |  shopinfo SHOP_INFO,
        |  rating RATING,
        |  cost COST,
        |  open_time OPEN_TIME,
        |  crawlBatch CRAWL_BATCH,
        |  crawlTime CRAWL_TIME
        |from
        |  srcTbl t1
      """.stripMargin)

    //去重
//    println("去重前条数：" + res.count())  //for Test
    res = res.dropDuplicates(Seq(key))
//    println("去重后条数：" + res.count())  //for Test
    res.cache()
//    res.where("CITY_ID_DP='1'").show(10, false)  //for Test
    res.show(10, false)  //for Test//for Test

    //保存到hdfs
    println("保存到hdfs")
    res.write.mode("overwrite").parquet(destPath)

  }
}
