package cn.mwee.transplant.crawler.dianping.vo

/**
  * Created by tal on 18/08/2017.
  */
case class Comment(shopId: String, dataId: String, userId: String, userName: String, vip: String, contribution: String, avgPrice: String, ratingTaste: String, ratingEnv: String, ratingService: String, ratingStar: String, ratingContent: String, comment: String, heartCount: String, recommentCount: String, commentTime: String, crawlTime: String)
