package cn.mwee.transplant.crawler.amap.vo

/**
  * Created by tal on 24/08/2017.
  */
case class Poi(id: String,tag: String,name: String,typeName: String,typecode: String,address: String,location: String,pcode: String,pname: String,citycode: String,cityname: String,adcode: String,adname: String,business_area: String,city_id_dp: String,business_area_id_dp: String,shopinfo: String,rating: String,cost: String,open_time: String,crawlBatch: String,crawlTime:String)
