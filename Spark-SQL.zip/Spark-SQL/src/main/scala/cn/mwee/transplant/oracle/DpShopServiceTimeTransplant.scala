package cn.mwee.transplant.oracle

import com.gnow.{DB, Processor, Transplant}

class DpShopServiceTimeTransplant extends Processor with Transplant {
  val DATABASE = DB.ORACLE_7_BWSWD
  val BUSINESS: String = "oracle"
  val FROM_TABLE: String = "dianping_shop_service_time"
  val TO_TABLE: String = "/other/dianping_shop_service_time"
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
