package cn.mwee.transplant.crawler.dianping

import cn.mwee.transplant.crawler.dianping.vo.Shop
import cn.mwee.udf.CommonUDF
import cn.mwee.util.RegUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 17/08/2017.
  */
class DpShopTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val destTable = "DIANPING_SHOP"
  val key = "shop_md5_key"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where crawl_batch=\'%s\'".format(destTable, targetDate)
    println(sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res.repartition(10), db, destTable)
    println("Happy Ending!")
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/dianping/shop/%s/*".format(targetDate)
    val destPath = "/crawler/dianping/shop/%s".format(targetDate)
    val shops = sqlContext.sparkContext.textFile(path, 10).map(shop => {
      val cityId = RegUtils.getByReg(shop, "cityId:\"(.*?)\",")
      val businessAreaId = RegUtils.getByReg(shop, "region:\"(.*?)\",")
      val priCat = RegUtils.getByReg(shop, "priCat:\"(.*?)\",")
      val secCat = RegUtils.getByReg(shop, "secCat:\"(.*?)\",")
      var shopId = RegUtils.getByReg(shop, "shopId:\"(.*?)\",")
      if("www.dianping.com".equals(shopId)){
        shopId = ""
      }
      val shopName = RegUtils.getByReg(shop, "shopName:\"(.*?)\",").replace("'", "`")
      val star = RegUtils.getByReg(shop, "star:\"(.*?)\",")
      val reviewCount = RegUtils.getByReg(RegUtils.getByReg(shop, "reviewCount:\"(.*?)\","), "(.*?)条评论")
      val avgPrice = RegUtils.getByReg(RegUtils.getByReg(shop, "avgPrice:\"(.*?)\","), "([0-9]+)")
      val commentScore = RegUtils.getByReg(shop, "commentScore:\"(.*?)\",")
      val addr = RegUtils.getByReg(shop, "addr:\"(.*?)\",").replace("'", "`")
      val tel = RegUtils.getByReg(shop, "tel:\"(.*?)\",").replace("'", "`")
      val serviceTime = RegUtils.getByReg(shop, "serviceTime:\"(.*?)\",").replace("'", "`")
      val commentTag = RegUtils.getByReg(shop, "commentTag:\"(.*?)\",").replace("'", "`")
      val isActive = RegUtils.getByReg(shop, "isActive:\"(.*?)\"")
      val crawlBatch = targetDate
      val crawlTime = RegUtils.getByReg(shop, "crawlTime:\"(.*?)\"")

      Shop(cityId, businessAreaId, priCat, secCat, shopId, shopName, star, reviewCount, avgPrice, commentScore, addr, tel, serviceTime, commentTag, isActive, crawlBatch, crawlTime)
    })

    import sqlContext.implicits._
    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))
    val shopsDF = shops.toDF()
    shopsDF.cache()
    shopsDF.registerTempTable("shops")

    //getMd5 以后要改回来
    res = sqlContext.sql(
      """
        |select
        |  getMD5(concat_ws(',', cityId, businessAreaId, priCat, secCat, shopName, crawlBatch)) shop_md5_key,
        |  cityId city_id,
        |  businessAreaId business_area_id,
        |  priCat pri_cat,
        |  secCat sec_cat,
        |  shopId shop_id,
        |  shopName shop_name,
        |  star star,
        |  reviewCount review_count,
        |  avgPrice avg_price,
        |  commentScore comment_score,
        |  addr addr,
        |  tel tel,
        |  serviceTime service_time,
        |  commentTag comment_tag,
        |  crawlBatch crawl_batch,
        |  crawlTime crawl_time,
        |  isActive is_active
        |from
        |  shops t1
      """.stripMargin)

    //去重
//    println("去重前条数：" + res.count())
    res = res.dropDuplicates(Seq(key))
//    println("去重后条数：" + res.count())
    res.cache()
    res.show(10, false)

    //保存到hdfs
    println("保存到hdfs")
    res.write.mode("overwrite").parquet(destPath)

  }
}