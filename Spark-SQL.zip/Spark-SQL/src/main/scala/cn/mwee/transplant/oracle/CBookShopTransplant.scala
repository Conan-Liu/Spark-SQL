package cn.mwee.transplant.oracle

import com.gnow.{DB, Processor, Transplant}

class CBookShopTransplant extends Processor with Transplant {
  val DATABASE = DB.ORACLE_37_BWSWD
  val BUSINESS: String = "oracle"
  val FROM_TABLE: String = "c_book_shop"
  val TO_TABLE: String = "/c/c_book_shop"
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
