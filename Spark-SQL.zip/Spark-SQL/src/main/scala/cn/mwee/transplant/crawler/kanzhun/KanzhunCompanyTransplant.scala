package cn.mwee.transplant.crawler.kanzhun

import cn.mwee.transplant.crawler.kanzhun.vo.Company
import cn.mwee.udf.CommonUDF
import cn.mwee.util.RegUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 24/08/2017.
  */
class KanzhunCompanyTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val destTable = "KANZHUN_COMPANY"
  val key = "COMPANY_MD5_KEY"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where crawl_batch=\'%s\'".format(destTable, targetDate)
    println(sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res, db, destTable)
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/kanzhun/company/%s/*".format(targetDate)
    val destPath = "/crawler/kanzhun/company/%s".format(targetDate)
    val comments = sqlContext.sparkContext.textFile(path, 10).map(line => {
      val cityCode = RegUtils.getByReg(line, "cityCode:\"(.*?)\"")
      val cityName = RegUtils.getByReg(line, "cityName:\"(.*?)\",")
      val industryCode = RegUtils.getByReg(line, "industryCode:\"(.*?)\",")
      val industryName = RegUtils.getByReg(line, "industryName:\"(.*?)\",")
      val subIndustryCode = RegUtils.getByReg(line, "industryCode:\"(.*?)\",")
      val subIndustryName = RegUtils.getByReg(line, "subIndustryName:\"(.*?)\",")
      val coId = RegUtils.getByReg(line, "coId:\"(.*?)\",")
      val coName = RegUtils.getByReg(line, "coName:\"(.*?)\"")
      val gongz = RegUtils.getByReg(line, "gongz:\"(.*?)\"")
      val star = RegUtils.getByReg(line, "star:\"(.*?)\"")
      val gx = RegUtils.getByReg(line, "gx:\"(.*?)\"")
      val sampleQty = RegUtils.getByReg(line, "sampleQty:\"(.*?)\"")
      val coInfos = RegUtils.getByReg(line, "coInfos:\"(.*?)\"")
      val addr = RegUtils.getByReg(line, "addr:\"(.*?)\"")
      val crawlBatch = targetDate
      val crawlTime = System.currentTimeMillis() + ""

      Company(cityCode, cityName, industryCode, industryName, subIndustryCode, subIndustryName, coId, coName, gongz, star, gx, sampleQty, coInfos, addr, crawlBatch, crawlTime)
    })

    import sqlContext.implicits._
    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))
    val srcDF = comments.toDF()
    srcDF.registerTempTable("srcTbl")

    res = sqlContext.sql(
      """
        |select
        |  getMD5(concat_ws(',', cityCode, coId, crawlBatch)) COMPANY_MD5_KEY,
        |  cityCode CITY_CODE,
        |  cityName CITY_NAME,
        |  industryCode INDUSTRY_CODE,
        |  industryName INDUSTRY_NAME,
        |  subIndustryCode SUBINDUSTRY_CODE,
        |  subIndustryName SUBINDUSTRY_NAME,
        |  coId CO_ID,
        |  coName CO_NAME,
        |  gongz GONGZ,
        |  star STAR,
        |  gx GX,
        |  sampleQty SAMPLE_QTY,
        |  coInfos CO_INFOS,
        |  addr ADDR,
        |  crawlBatch CRAWL_BATCH,
        |  crawlTime CRAWL_TIME
        |from
        |  srcTbl t1
      """.stripMargin)

    //去重
    println("去重前条数：" + res.count())
    res = res.dropDuplicates(Seq(key))
    println("去重后条数：" + res.count())
    res.cache()
    res.show(10, false)

    //保存到hdfs
    println("保存到hdfs")
    res.write.mode("overwrite").parquet(destPath)

  }
}



