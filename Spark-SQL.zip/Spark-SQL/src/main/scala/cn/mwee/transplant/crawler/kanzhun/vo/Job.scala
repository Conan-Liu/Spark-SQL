package cn.mwee.transplant.crawler.kanzhun.vo

/**
  * Created by tal on 24/08/2017.
  */
case class Job(cityCode: String,cityName: String,industryCode: String,industryName: String,subIndustryCode: String,subIndustryName: String,coId: String,coName: String,addr: String,jobTitle: String,monthlySalary: String,workingYear: String,education: String,crawlBatch: String,crawlTime: String)
