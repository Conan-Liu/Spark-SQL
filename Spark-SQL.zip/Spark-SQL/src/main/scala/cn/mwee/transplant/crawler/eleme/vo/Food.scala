package cn.mwee.transplant.crawler.eleme.vo

/**
  * Created by tal on 25/08/2017.
  */
case class Food(shopId: String, shopName: String, categoryId: String, catName: String, foodId: String, foodName: String, packingFee: String, price: String, soldOut: String, monthSale: String, ratingCount: String, satisfyCount: String, satisfyRate: String, foodRating: String, crawlBatch: String, crawlTime: String)
