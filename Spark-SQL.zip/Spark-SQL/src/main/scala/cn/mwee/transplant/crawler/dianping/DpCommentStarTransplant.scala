package cn.mwee.transplant.crawler.dianping

import cn.mwee.transplant.crawler.dianping.vo.CommentStar
import cn.mwee.udf.CommonUDF
import cn.mwee.util.RegUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 17/08/2017.
  */
class DpCommentStarTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val tmpTable = "DIANPING_COMMENT_STAR_TMP"
  val destTable = "DIANPING_COMMENT_STAR"
  val key = "shop_id"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s".format(tmpTable)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    RDBWriter.overwrite(res, db, tmpTable)
    val sqlDelete = "delete from %s where %s in (select %s from %s)".format(destTable, key, key, tmpTable)
    println(sqlDelete)
    DBEraser.remove(db, sqlDelete)
    val sqlInsert = "insert into %s select * from %s".format(destTable, tmpTable)
    println(sqlInsert)
    DBEraser.remove(db, sqlInsert)
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/dianping/comment_star/%s/*".format(targetDate)
    val comments = sqlContext.sparkContext.textFile(path, 10).map(line => {
      val shopId = RegUtils.getByReg(line, "shopId:\"(.*?)\"")
      val allStar = RegUtils.getByReg(line, "allStar:\"(.*?)\",")
      val oneStar = RegUtils.getByReg(line, "oneStar:\"(.*?)\",")
      val twoStar = RegUtils.getByReg(line, "twoStar:\"(.*?)\",")
      val threeStar = RegUtils.getByReg(line, "threeStar:\"(.*?)\",")
      val fourStar = RegUtils.getByReg(line, "fourStar:\"(.*?)\",")
      val fiveStar = RegUtils.getByReg(line, "fiveStar:\"(.*?)\",")
      val crawlTime = RegUtils.getByReg(line, "crawlTime:\"(.*?)\"")

      CommentStar(shopId, allStar, oneStar, twoStar, threeStar, fourStar, fiveStar, crawlTime)
    })

    import sqlContext.implicits._
    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))
    val commentsDF = comments.toDF()
    commentsDF.registerTempTable("comments")

    res = sqlContext.sql(
      """
        |select
        |  shopId shop_id,
        |  allStar all_star,
        |  oneStar one_star,
        |  twoStar two_star,
        |  threeStar three_star,
        |  fourStar four_star,
        |  fiveStar five_star,
        |  crawlTime crawl_time
        |from
        |  comments t1
      """.stripMargin)

    res = res.dropDuplicates(Seq(key))
    res.cache()
    res.show(10, false)


  }
}



