package cn.mwee.transplant.crawler.eleme

import cn.mwee.transplant.crawler.amap.vo.Ba
import cn.mwee.udf.CommonUDF
import cn.mwee.util.{GisUtils, RegUtils}
import com.gnow.eraser.DBEraser
import com.gnow.persistence.{RDBReader, RDBWriter}
import com.gnow.{DB, Processor}
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.sql.types.{StringType, StructField, StructType}

import scala.collection.mutable.ListBuffer

/**
  * Created by tal on 17/08/2017.
  */
class ElemeShopTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val destTable = "ELEME_SHOP"
  val key = "SHOP_MD5_KEY"
  val DP_BA = "DIANPING_BUSINESS_AREA"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where crawl_batch=\'%s\'".format(destTable, targetDate)
    println(sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res.repartition(), db, destTable)
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/eleme/shop/%s/*".format(targetDate)
    val destPath = "/crawler/eleme/shop/%s".format(targetDate)
    //读取划分好的商圈数据
    val dpBa = RDBReader.read(DB.ORACLE_7_BWSWD, DP_BA).where("CITY_ID='1' and GEOHASH6 is not null").rdd.map(row => Ba(row.get(0).toString, row.get(1).toString, row.get(5).toString, row.get(6).toString, row.get(8).toString))
    val dpBaB = dpBa.collect()
    val shops = sqlContext.sparkContext.textFile(path, 10).map(shop => {
      val dpCityId = RegUtils.getByReg(shop, "dpCityId='(.*?)', ")
      val dpBa = RegUtils.getByReg(shop, "dpBa='(.*?)', ")
      val cityId = RegUtils.getByReg(shop, "cityId='(.*?)', ")
      val subCategory = RegUtils.getByReg(shop, "subCategory='(.*?)', ")
      val shopId = RegUtils.getByReg(shop, "shopId='(.*?)', ")
      val shopName = RegUtils.getByReg(shop, "shopName='(.*?)', ")
      val addr = RegUtils.getByReg(shop, "addr='(.*?)', ")
      val brand = RegUtils.getByReg(shop, "brand='(.*?)', ")
      val isNew = RegUtils.getByReg(shop, "isNew='(.*?)', ")
      val openingHours = RegUtils.getByReg(shop, "openingHours='(.*?)', ")
      val orderLeadTime = RegUtils.getByReg(shop, "orderLeadTime='(.*?)', ")
      val rating = RegUtils.getByReg(shop, "rating='(.*?)', ")
      val deliveryFee = RegUtils.getByReg(shop, "deliveryFee='(.*?)', ")
      val minimumOrderAmount = RegUtils.getByReg(shop, "minimumOrderAmount='(.*?)', ")
      val recentOrderNum = RegUtils.getByReg(shop, "recentOrderNum='(.*?)', ")
      val latitude = RegUtils.getByReg(shop, "latitude='(.*?)', ")
      val longitude = RegUtils.getByReg(shop, "longitude='(.*?)', ")
      val geohash = RegUtils.getByReg(shop, "geohash='(.*?)', ")
      //计算商圈
      var business_area_id_dp = ""
      val lat = latitude + 0 //处理为空的情况
      val lon = longitude + 0
      //第一种情况
      var dpBaCandidate = ListBuffer[Ba]()
      dpBaB.foreach(ba => {
        if(geohash.length > 6 && ba.geohash.contains(geohash.substring(0,6))){
          business_area_id_dp = ba.ba
          dpBaCandidate.append(ba)
        }
      })
      if(!business_area_id_dp.equals("")){
        var minDistance = 100.0
        dpBaCandidate.foreach(ba => {
          if(!ba.center.equals("NaN,NaN")){
            val distance = GisUtils.calcDistance(lat + "," + lon, ba.center)
            if(distance < minDistance){
              minDistance = distance
              if(distance < ba.radius.toDouble * 1.5){
                business_area_id_dp = ba.ba
              }
            }
          }
        })
      }

      //第二种情况
      if(business_area_id_dp.equals("")){
        var minDistance = 100.0
        dpBaB.foreach(ba => {
          if(!ba.center.equals("NaN,NaN")){
            val distance = GisUtils.calcDistance(lat + "," + lon, ba.center)
            if(distance < minDistance){
              minDistance = distance
              if(distance < ba.radius.toDouble * 1.5){
                business_area_id_dp = ba.ba
              }
            }
          }
        })
      }

      val compareRating = RegUtils.getByReg(shop, "compareRating='(.*?)', ")
      val foodScore = RegUtils.getByReg(shop, "foodScore='(.*?)', ")
      val positiveRating = RegUtils.getByReg(shop, "positiveRating='(.*?)', ")
      val serviceScore = RegUtils.getByReg(shop, "serviceScore='(.*?)', ")
      val isActive = RegUtils.getByReg(shop, "isActive='(.*?)', ")
      val starLevel = RegUtils.getByReg(shop, "starLevel='(.*?)', ")
      val crawlBatch = targetDate
      val crawlTime = RegUtils.getByReg(shop, "crawlTime='(.*?)'")

      Row(dpCityId, dpBa, cityId, subCategory, shopId, shopName, addr, brand, isNew, openingHours, orderLeadTime, rating, deliveryFee, minimumOrderAmount, recentOrderNum, latitude, longitude, geohash, business_area_id_dp, compareRating, foodScore, positiveRating, serviceScore, isActive, starLevel, crawlBatch, crawlTime)
    })

    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))

    val schema = StructType(
      List(
        StructField("dpCityId", StringType, true),
        StructField("dpBa", StringType, true),
        StructField("cityId", StringType, true),
        StructField("subCategory", StringType, true),
        StructField("shopId", StringType, true),
        StructField("shopName", StringType, true),
        StructField("addr", StringType, true),
        StructField("brand", StringType, true),
        StructField("isNew", StringType, true),
        StructField("openingHours", StringType, true),
        StructField("orderLeadTime", StringType, true),
        StructField("rating", StringType, true),
        StructField("deliveryFee", StringType, true),
        StructField("minimumOrderAmount", StringType, true),
        StructField("recentOrderNum", StringType, true),
        StructField("latitude", StringType, true),
        StructField("longitude", StringType, true),
        StructField("geohash", StringType, true),
        StructField("business_area_id_dp", StringType, true),
        StructField("compareRating", StringType, true),
        StructField("foodScore", StringType, true),
        StructField("positiveRating", StringType, true),
        StructField("serviceScore", StringType, true),
        StructField("isActive", StringType, true),
        StructField("starLevel", StringType, true),
        StructField("crawlBatch", StringType, true),
        StructField("crawlTime", StringType, true)
      )
    )

    val shopsDF = sqlContext.createDataFrame(shops, schema)
    shopsDF.cache()
    shopsDF.registerTempTable("srcTbl")

    res = sqlContext.sql(
      """
        |select
        |  getMD5(concat_ws(',', dpCityId, dpBa, cityId, subCategory, shopId, crawlBatch)) SHOP_MD5_KEY,
        |  dpCityId DP_CITY_ID,
        |  dpBa DP_BA,
        |  cityId CITY_ID,
        |  subCategory SUB_CATEGORY,
        |  shopId SHOP_ID,
        |  shopName SHOP_NAME,
        |  addr ADDR,
        |  brand BRAND,
        |  isNew IS_NEW,
        |  openingHours OPENING_HOURS,
        |  orderLeadTime ORDER_LEAD_TIME,
        |  rating RATING,
        |  deliveryFee DELIVERY_FEE,
        |  minimumOrderAmount MINIMUM_ORDER_AMOUNT,
        |  recentOrderNum RECENT_ORDER_NUM,
        |  latitude LATITUDE,
        |  longitude LONGITUDE,
        |  geohash GEOHASH,
        |  business_area_id_dp BUSINESS_AREA_ID_DP,
        |  compareRating COMPARE_RATING,
        |  foodScore FOOD_SCORE,
        |  positiveRating POSITIVE_RATING,
        |  serviceScore SERVICE_SCORE,
        |  isActive IS_ACTIVE,
        |  starLevel STAR_LEVEL,
        |  crawlBatch CRAWL_BATCH,
        |  crawlTime CRAWL_TIME
        |from
        |  srcTbl t1
      """.stripMargin)

    //去重
    println("去重前条数：" + res.count())
    res = res.dropDuplicates(Seq(key))
    println("去重后条数：" + res.count())
    res.cache()
    res.show(10, false)

    //保存到hdfs
    println("保存到hdfs")
    res.write.mode("overwrite").parquet(destPath)

  }
}