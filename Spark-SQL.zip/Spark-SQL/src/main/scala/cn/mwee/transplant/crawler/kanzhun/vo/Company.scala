package cn.mwee.transplant.crawler.kanzhun.vo

/**
  * Created by tal on 24/08/2017.
  */
case class Company(cityCode: String,cityName: String,industryCode: String, industryName: String,subIndustryCode: String,subIndustryName: String,coId: String,coName: String,gongz: String,star: String,gx: String,sampleQty: String,coInfos: String,addr: String,crawlBatch: String,crawlTime: String)
