package cn.mwee.transplant.oracle

import com.gnow.{DB, Processor, Transplant}

/**
  * 源表每天算两次，因为银联中午结算
  */
class DmCashDailyTransplant extends Processor with Transplant {
  val DATABASE = DB.ORACLE_37_BWSWD
  val BUSINESS: String = "oracle"
  val FROM_TABLE: String = "dm_cash_daily"
  val TO_TABLE: String = "/dm/dm_cash_daily"
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "day_id = to_date('%s', 'yyyy-mm-dd') AND day_id != to_date('%s', 'yyyy-mm-dd')"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}


