package cn.mwee.transplant.oracle

import com.gnow.{DB, Processor, Transplant}

class DwMemberHistoryTransplant extends Processor with Transplant {
  val DATABASE = DB.ORACLE_9_BWSWD
  val BUSINESS: String = "oracle"
  val FROM_TABLE: String = "DW_MEMBER_HISTORY"
  val TO_TABLE: String = "/dw/dw_member_history"
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "create_time >= to_date('%s', 'yyyy-mm-dd') AND create_time < to_date('%s', 'yyyy-mm-dd')"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
