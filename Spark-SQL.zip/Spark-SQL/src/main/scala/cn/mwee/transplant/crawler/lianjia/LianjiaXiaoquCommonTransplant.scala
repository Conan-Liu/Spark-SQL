package cn.mwee.transplant.crawler.lianjia

import cn.mwee.transplant.crawler.amap.vo.{Ba, Poi}
import cn.mwee.udf.CommonUDF
import cn.mwee.util.{GisUtils, RegUtils}
import com.github.davidmoten.geo.{GeoHash, LatLong}
import com.gnow.eraser.DBEraser
import com.gnow.persistence.{RDBReader, RDBWriter}
import com.gnow.{DB, Processor}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.mutable.ListBuffer

/**
  * Created by tal on 27/08/2017.
  */
class LianjiaXiaoquCommonTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val destTable = "LIANJIA_XIAOQU"
  val key = "XIAOQU_MD5_KEY"
  val DP_BA = "DIANPING_BUSINESS_AREA"
  val LIANJIA_CITY = "LIANJIA_CITY"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where crawl_batch=\'%s\' and city_code not in('sh','su')".format(destTable, targetDate)
    println(sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res.repartition(10), db, destTable)
    println("Happy Ending!")
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/lianjia/xiaoqu/common/%s/*".format(targetDate)
    val destPath = "/crawler/lianjia/xiaoqu/common/%s".format(targetDate)
    //读取划分好的商圈数据
    val dpBa = RDBReader.read(DB.ORACLE_7_BWSWD, DP_BA).where("GEOHASH6 is not null").rdd.map(row => Ba(row.get(0).toString, row.get(1).toString, row.get(5).toString, row.get(6).toString, row.get(10).toString))
    val dpBaB = dpBa.collect()
    dpBaB.foreach(println)
    println(dpBaB.length)
    println(dpBaB.length)
    println(dpBaB.length)

    //读取链家城市ID到点评城市ID的映射
    val ljCity = RDBReader.read(DB.ORACLE_7_BWSWD, LIANJIA_CITY).where("CITY_ID_DP is not null").dropDuplicates(Seq("CITY_CODE", "CITY_ID_DP")).rdd.map(row => (row.get(0).toString, row.get(2).toString)).collect()

    val shops = sqlContext.sparkContext.textFile(path, 10).map(shop => {
      val cityCode = RegUtils.getByReg(shop, "city_id\":\"(.*?)\"")
      val districtName = RegUtils.getByReg(shop, "district_name\":\"(.*?)\",")
      val propertyCode = RegUtils.getByReg(shop, "property_code\":\"(.*?)\",")
      val propertyName = RegUtils.getByReg(shop, "property_name\":\"(.*?)\",")
      val propertyNo = RegUtils.getByReg(shop, "property_no\":\"(.*?)\",")
      val propertyAddress = RegUtils.getByReg(shop, "property_addr\":\"(.*?)\",")
      val propertyAge = RegUtils.getByReg(shop, "propertyAge\":\"(.*?)\",")
      var earlyCompleteYear = RegUtils.getByReg(shop, "earlyCompleteYear\":\"(.*?)\",")
      var completeYear = RegUtils.getByReg(shop, "complete_year\":\"(.*?)\",")
      if(completeYear.contains("~")){
        earlyCompleteYear = RegUtils.getByReg(completeYear, "([0-9]+) ~ ")
        completeYear = RegUtils.getByReg(completeYear, " ~ ([0-9]+)")
      }
      if(completeYear.equals("暂无数据")){
        completeYear = ""
      }
      val buildingCount = RegUtils.getByReg(shop, "building_count\":\"(.*?)栋\",")
      val totalRooms = RegUtils.getByReg(shop, "total_rooms\":\"(.*?)户\",")
      val saleTotal = RegUtils.getByReg(shop, "saleTotal\":\"(.*?)\",")
      val soldCount = RegUtils.getByReg(shop, "soldCount\":\"(.*?)\",")
      val dealAvgPrice = RegUtils.getByReg(shop, "dealAvgPrice\":\"(.*?)\",")
      val referAvgPrice = RegUtils.getByReg(shop, "referAvgPrice\":\"(.*?)\",")
      var saleAvgPrice = RegUtils.getByReg(shop, "avg_price\":\"(.*?)元/平\",")
      if(saleAvgPrice.equals("均价未知")){
        saleAvgPrice = ""
      }
      val lowestPrice = RegUtils.getByReg(shop, "lowestPrice\":\"(.*?)\",")
      val houseType = RegUtils.getByReg(shop, "house_type\":\"(.*?)\",")
      val houseType2 = RegUtils.getByReg(shop, "houseType2\":\"(.*?)\",")
      val latitude = RegUtils.getByReg(shop, "latitude\":\"(.*?)\",")
      val longitude = RegUtils.getByReg(shop, "longitude\":\"(.*?)\",")

      //计算点评城市ID
      var city_id_dp = ""
      ljCity.foreach(row => {
        if(row._1.toString.equals(cityCode)){
          city_id_dp = row._2.toString
        }
      })

      //计算点评商圈ID 第一种方法
//      var business_area_id_dp = ""
//      val lat = latitude + "0" //有些经纬度为空
//      val lon = longitude + "0"
//      val geohash = GeoHash.encodeHash(new LatLong(lat.toDouble, lon.toDouble))
//      //第一种情况
//      var dpBaCandidate = ListBuffer[Ba]()
//      dpBaB.foreach(ba => {
//        if(ba.geohash.contains(geohash.substring(0,6))){
//          business_area_id_dp = ba.ba
//          dpBaCandidate.append(ba)
//        }
//      })
//      if(!business_area_id_dp.equals("")){
//        var minDistance = 100.0
//        dpBaCandidate.foreach(ba => {
//          if(!ba.center.equals("NaN,NaN")){
//            val distance = GisUtils.calcDistance(lat + "," + lon, ba.center)
//            if(distance < minDistance){
//              minDistance = distance
//              if(distance < ba.radius.toDouble * 1.5){
//                business_area_id_dp = ba.ba
//              }
//            }
//          }
//        })
//      }
//      //第二种情况
//      if(business_area_id_dp.equals("")){
//        var minDistance = 100.0
//        dpBaB.foreach(ba => {
//          if(!ba.center.equals("NaN,NaN")){
//            val distance = GisUtils.calcDistance(lat + "," + lon, ba.center)
//            if(distance < minDistance){
//              minDistance = distance
//              if(distance < ba.radius.toDouble * 1.5){
//                business_area_id_dp = ba.ba
//              }
//            }
//          }
//        })
//      }
//      var dpBaAll = ListBuffer[String]()
//      dpBaAll.append(business_area_id_dp)

      //计算点评商圈ID 第二种方法
      var business_area_id_dp = ""
      val dpBa = dpBaB
      val lat = latitude + "0" //有些经纬度为空
      val lon = longitude + "0"
      val geohash = GeoHash.encodeHash(new LatLong(lat.toDouble, lon.toDouble))
      var dpBaAll = ListBuffer[String]()
      dpBa.foreach(ba => {
        if(ba.geohash.contains(geohash.substring(0,6))){
          business_area_id_dp = ba.ba
          dpBaAll.append(business_area_id_dp)
        }
      })

      val metroRemark = RegUtils.getByReg(shop, "metroRemark\":\"(.*?)\",")
      val mgtCompany = RegUtils.getByReg(shop, "mgtCompany\":\"(.*?)\",")
      val mgtFee = RegUtils.getByReg(shop, "mgt_fee\":\"(.*?) 元/平米/月\",")
      val plateId = RegUtils.getByReg(shop, "bizcircle_id:\"(.*?)\",")
      val plateName = RegUtils.getByReg(shop, "bizcircle_name\":\"(.*?)\",")
      val crawlBatch = targetDate
      var crawlTime = RegUtils.getByReg(shop, "crawlTime:'(.*?)'")
      if(crawlTime == null){
        crawlTime = System.currentTimeMillis() + ""
      }
      Row(cityCode, districtName, propertyCode, propertyName, propertyNo, propertyAddress, propertyAge, earlyCompleteYear, completeYear, buildingCount, totalRooms, saleTotal, soldCount, dealAvgPrice, referAvgPrice, saleAvgPrice, lowestPrice, houseType, houseType2, latitude, longitude, city_id_dp, dpBaAll.mkString(","), metroRemark, mgtCompany, mgtFee, plateId, plateName, crawlBatch, crawlTime)
    })
      .flatMap(row => {  //考虑多商圈的情况
        val baIds = row.get(22).toString.split(",")
        var res = ListBuffer[Row]()
        for(ba <- baIds){
          val resRow = Row(row.get(0), row.get(1), row.get(2), row.get(3), row.get(4), row.get(5), row.get(6), row.get(7), row.get(8), row.get(9), row.get(10), row.get(11), row.get(12), row.get(13), row.get(14), row.get(15), row.get(16), row.get(17), row.get(18), row.get(19), row.get(20), row.get(21), ba, row.get(23), row.get(24), row.get(25), row.get(26), row.get(27), row.get(28), row.get(29))
          res.append(resRow)
        }
        res
      })

    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))

    val schema = StructType(
      List(
        StructField("cityCode", StringType, true),
        StructField("districtName", StringType, true),
        StructField("propertyCode", StringType, true),
        StructField("propertyName", StringType, true),
        StructField("propertyNo", StringType, true),
        StructField("propertyAddress", StringType, true),
        StructField("propertyAge", StringType, true),
        StructField("earlyCompleteYear", StringType, true),
        StructField("completeYear", StringType, true),
        StructField("buildingCount", StringType, true),
        StructField("totalRooms", StringType, true),
        StructField("saleTotal", StringType, true),
        StructField("soldCount", StringType, true),
        StructField("dealAvgPrice", StringType, true),
        StructField("referAvgPrice", StringType, true),
        StructField("saleAvgPrice", StringType, true),
        StructField("lowestPrice", StringType, true),
        StructField("houseType", StringType, true),
        StructField("houseType2", StringType, true),
        StructField("latitude", StringType, true),
        StructField("longitude", StringType, true),
        StructField("dp_city_id", StringType, true),
        StructField("business_area_id_dp", StringType, true),
        StructField("metroRemark", StringType, true),
        StructField("mgtCompany", StringType, true),
        StructField("mgtFee", StringType, true),
        StructField("plateId", StringType, true),
        StructField("plateName", StringType, true),
        StructField("crawlBatch", StringType, true),
        StructField("crawlTime", StringType, true)
      )
    )

    val shopsDF = sqlContext.createDataFrame(shops, schema)
    shopsDF.cache()
    shopsDF.registerTempTable("srcTbl")

    res = sqlContext.sql(
      """
        |select
        |  getMD5(concat_ws(',', cityCode, propertyCode, crawlBatch)) XIAOQU_MD5_KEY,
        |  cityCode CITY_CODE,
        |  districtName DISTRICT_NAME,
        |  propertyCode PROPERTY_CODE,
        |  propertyName PROPERTY_NAME,
        |  propertyNo PROPERTY_NO,
        |  propertyAddress PROPERTY_ADDRESS,
        |  propertyAge PROPERTY_AGE,
        |  earlyCompleteYear EARLY_COMPLETE_YEAR,
        |  completeYear COMPLETE_YEAR,
        |  buildingCount BUILDING_COUNT,
        |  totalRooms TOTAL_ROOMS,
        |  saleTotal SALE_TOTAL,
        |  soldCount SOLD_COUNT,
        |  dealAvgPrice DEAL_AVG_PRICE,
        |  referAvgPrice REFER_AVG_PRICE,
        |  saleAvgPrice SALE_AVG_PRICE,
        |  lowestPrice LOWEST_PRICE,
        |  houseType HOUSE_TYPE,
        |  houseType2 HOUSE_TYPE2,
        |  latitude LATITUDE,
        |  longitude LONGITUDE,
        |  dp_city_id CITY_ID_DP,
        |  business_area_id_dp BUSINESS_AREA_ID_DP,
        |  metroRemark METRO_REMARK,
        |  mgtCompany MGT_COMPANY,
        |  mgtFee MGT_FEE,
        |  plateId PLATE_ID,
        |  plateName PLATE_NAME,
        |  crawlBatch CRAWL_BATCH,
        |  crawlTime CRAWL_TIME
        |from
        |  srcTbl t1
      """.stripMargin)

    //去重
//    println("去重前条数：" + res.count())
    res = res.dropDuplicates(Seq(key))
//    println("去重后条数：" + res.count())
    res.cache()
    res.show(100, false)

    //保存到hdfs
    println("保存到hdfs")
    res.write.mode("overwrite").parquet(destPath)

  }
}