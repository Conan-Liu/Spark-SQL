package cn.mwee.transplant.oracle

import com.gnow.{DB, Processor, Transplant}


class CRelaShopbcTransplant extends Processor with Transplant {
  val DATABASE = DB.ORACLE_9_BWSWD
  val BUSINESS: String = "oracle"
  val FROM_TABLE: String = "c_rela_shopbc"
  val TO_TABLE: String = "/c/c_rela_shopbc"
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
