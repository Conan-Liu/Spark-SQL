package cn.mwee.transplant.crawler.dianping.vo

/**
  * Created by tal on 18/08/2017.
  */
case class CommentStar(shopId: String, allStar: String, oneStar: String, twoStar: String, threeStar: String, fourStar: String, fiveStar: String, crawlTime: String)
