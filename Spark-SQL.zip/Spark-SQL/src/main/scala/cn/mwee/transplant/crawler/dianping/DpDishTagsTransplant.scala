package cn.mwee.transplant.crawler.dianping

import cn.mwee.transplant.crawler.dianping.vo.{DishTags, Shop}
import cn.mwee.udf.CommonUDF
import cn.mwee.util.RegUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 17/08/2017.
  */
class DpDishTagsTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val destTable = "DIANPING_DISHTAGS"
  val key = "dishtags_md5_key"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where crawl_batch=\'%s\'".format(destTable, targetDate)
    println(sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res, db, destTable)
    println("Happy Ending!")
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/dianping/dishtags/%s/*".format(targetDate)
    val destPath = "/crawler/dianping/dishtags/%s".format(targetDate)
    val shops = sqlContext.sparkContext.textFile(path, 10).map(shop => {
      val cityId = RegUtils.getByReg(shop, "cityId\":(.*?),")
      val businessAreaName = RegUtils.getByReg(shop, "regionName\":\"(.*?)\",")
      val priCat = RegUtils.getByReg(shop, "shopType\":(.*?),")
      val secCat = RegUtils.getByReg(shop, "categoryId\":(.*?),")
      val shopId = RegUtils.getByReg(shop, "id\":(.*?),")
      val shopName = RegUtils.getByReg(shop, "name\":\"(.*?)\",").replace("'", "`")
      val star = RegUtils.getByReg(shop, "shopPower\":(.*?),")
      val avgPrice = RegUtils.getByReg(RegUtils.getByReg(shop, "priceText\":\"(.*?)\","), "([0-9]+)")
      val dishTags = RegUtils.getByReg(shop, "dishtags\":\"(.*?)\",").replace("'", "`")
      val isActive = RegUtils.getByReg(shop, "status\":(.*?)")
      val crawlBatch = targetDate
      val crawlTime = System.currentTimeMillis() + ""

      DishTags(cityId, businessAreaName, priCat, secCat, shopId, shopName, star, avgPrice, dishTags, isActive, crawlBatch, crawlTime)
    })

    import sqlContext.implicits._
    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))
    val shopsDF = shops.toDF()
    shopsDF.cache()
    shopsDF.registerTempTable("shops")

    res = sqlContext.sql(
      """
        |select
        |  getMD5(concat_ws(',', cityId, businessAreaName, priCat, secCat, shopId, crawlBatch)) dishtags_md5_key,
        |  cityId city_id,
        |  businessAreaName business_area_name,
        |  priCat pri_cat,
        |  secCat sec_cat,
        |  shopId shop_id,
        |  shopName shop_name,
        |  star star,
        |  avgPrice avg_price,
        |  dishTags dish_tags,
        |  isActive is_active,
        |  crawlBatch crawl_batch,
        |  crawlTime crawl_time
        |from
        |  shops t1
      """.stripMargin)

    //去重
    println("去重前条数：" + res.count())
    res.show()
    res = res.dropDuplicates(Seq(key))
    println("去重后条数：" + res.count())
    res.cache()
    res.show(10, false)

    //保存到hdfs
    println("保存到hdfs")
    res.write.mode("overwrite").parquet(destPath)

  }
}