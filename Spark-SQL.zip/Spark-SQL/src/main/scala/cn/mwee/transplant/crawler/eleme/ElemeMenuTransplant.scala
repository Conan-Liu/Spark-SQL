package cn.mwee.transplant.crawler.eleme

import cn.mwee.transplant.crawler.eleme.vo.Food
import cn.mwee.udf.CommonUDF
import cn.mwee.util.RegUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 17/08/2017.
  */
class ElemeMenuTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val destTable = "ELEME_MENU"
  val key = "FOOD_MD5_KEY"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where crawl_batch=\'%s\'".format(destTable, targetDate)
    println(sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res, db, destTable)
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/eleme/menu/%s/*".format(targetDate)
    val destPath = "/crawler/eleme/menu/%s".format(targetDate)
    val shops = sqlContext.sparkContext.textFile(path, 10).map(shop => {
      val shopId = RegUtils.getByReg(shop, "shopId='(.*?)', ")
      val shopName = RegUtils.getByReg(shop, "shopName='(.*?)', ")
      val categoryId = RegUtils.getByReg(shop, "categoryId='(.*?)', ")
      val catName = RegUtils.getByReg(shop, "catName='(.*?)', ")
      val foodId = RegUtils.getByReg(shop, "foodId='(.*?)', ")
      val foodName = RegUtils.getByReg(shop, "foodName='(.*?)', ")
      val packingFee = RegUtils.getByReg(shop, "packingFee='(.*?)', ")
      val price = RegUtils.getByReg(shop, "price='(.*?)', ")
      val soldOut = RegUtils.getByReg(shop, "soldOut='(.*?)', ")
      val monthSale = RegUtils.getByReg(shop, "monthSale='(.*?)', ")
      val ratingCount = RegUtils.getByReg(shop, "ratingCount='(.*?)', ")
      val satisfyCount = RegUtils.getByReg(shop, "satisfyCount='(.*?)', ")
      val satisfyRate = RegUtils.getByReg(shop, "satisfyRate='(.*?)', ")
      val foodRating = RegUtils.getByReg(shop, "foodRating='(.*?)', ")
      val crawlBatch = targetDate
      val crawlTime = RegUtils.getByReg(shop, "crawlTime='(.*?)'")

      Food(shopId, shopName, categoryId, catName, foodId, foodName, packingFee, price, soldOut, monthSale, ratingCount, satisfyCount, satisfyRate, foodRating, crawlBatch, crawlTime)
    })

    import sqlContext.implicits._
    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))
    val shopsDF = shops.toDF()
    shopsDF.cache()
    shopsDF.registerTempTable("srcTbl")

    res = sqlContext.sql(
      """
        |select
        |  getMD5(concat_ws(',', shopId, categoryId, foodId, crawlBatch)) FOOD_MD5_KEY,
        |  shopId SHOP_ID,
        |  shopName SHOP_NAME,
        |  categoryId CATEGORY_ID,
        |  catName CAT_NAME,
        |  foodId FOOD_ID,
        |  foodName FOOD_NAME,
        |  packingFee PACKING_FEE,
        |  price PRICE,
        |  soldOut SOLD_OUT,
        |  monthSale MONTH_SALE,
        |  ratingCount RATING_COUNT,
        |  satisfyCount SATISFY_COUNT,
        |  satisfyRate SATISFY_RATE,
        |  foodRating FOOD_RATING,
        |  crawlBatch CRAWL_BATCH,
        |  crawlTime CRAWL_TIME
        |from
        |  srcTbl t1
      """.stripMargin)

    //去重
    println("去重前条数：" + res.count())
    res = res.dropDuplicates(Seq(key))
    println("去重后条数：" + res.count())
    res.cache()
    res.show(10, false)

    //保存到hdfs
    println("保存到hdfs")
    res.write.mode("overwrite").parquet(destPath)

  }
}