package cn.mwee.transplant.crawler.amap.vo

/**
  * Created by tal on 24/08/2017.
  */
case class Ba(cityId: String, ba: String, center: String, radius: String, geohash: String)
