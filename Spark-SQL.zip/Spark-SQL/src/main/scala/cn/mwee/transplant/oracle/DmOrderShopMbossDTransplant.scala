package cn.mwee.transplant.oracle

import com.gnow.{DB, Processor, Transplant}

/**
  * 原表每天重算七天的数据
  */
class DmOrderShopMbossDTransplant extends Processor with Transplant {
  val DATABASE = DB.ORACLE_37_BWSWD
  val BUSINESS: String = "oracle"
  val FROM_TABLE: String = "DM_ORDER_SHOP_MBOSS_D_BK"
  val TO_TABLE: String = "/dm/dm_order_shop_mboss_d"
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "day_id = to_date('%s', 'yyyy-mm-dd') AND day_id != to_date('%s', 'yyyy-mm-dd')"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
