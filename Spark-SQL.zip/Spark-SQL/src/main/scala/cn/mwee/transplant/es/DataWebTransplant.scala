package cn.mwee.transplant.es

import cn.mwee.util.DateUtils
import com.gnow.{Processor, Transplant}

class DataWebTransplant extends Processor with Transplant {

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    val date = DateUtils.getDateFormatted(targetDate, "yyyy.MM.dd")
    val df = sqlContext.read.format("org.elasticsearch.spark.sql")
      .option("pushdown", "true")
      .option("es.nodes", "10.0.26.15,10.0.26.16,10.0.26.17") //10.1.26.76,10.1.26.77,10.1.26.78
      .option("es.port", "9200")
      .option("es.nodes.wan.only", "true")
      .load("data_web-%s/span".format(date))
    df.printSchema()
    df.repartition(1).write.mode("overwrite").json("/repository/kafka/data_web/" + targetDate)
  }

}
