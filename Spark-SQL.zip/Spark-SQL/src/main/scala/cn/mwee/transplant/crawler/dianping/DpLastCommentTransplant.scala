package cn.mwee.transplant.crawler.dianping

import cn.mwee.transplant.crawler.dianping.vo.Comment
import cn.mwee.udf.CommonUDF
import cn.mwee.util.RegUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 17/08/2017.
  */
class DpLastCommentTransplant extends Processor{
  var res: DataFrame = _
  val db = DB.ORACLE_7_BWSWD
  val tmpTable = "DIANPING_LAST_COMMENT_TMP"
  val destTable = "DIANPING_LAST_COMMENT"
  val key = "comment_md5_key"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s".format(tmpTable)
    println(sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    RDBWriter.overwrite(res, db, tmpTable)
    val sqlDelete = "delete from %s where %s in (select %s from %s)".format(destTable, key, key, tmpTable)
    println(sqlDelete)
    DBEraser.remove(db, sqlDelete)
    val sqlInsert = "insert into %s select * from %s".format(destTable, tmpTable)
    println(sqlInsert)
    DBEraser.remove(db, sqlInsert)
  }

  def process(targetDate: String, input: String, output: String) = {
    val path = "/tmp/crawler/dianping/last_comment/%s/*".format(targetDate)
    println(path)
    val comments = sqlContext.sparkContext.textFile(path, 10).map(line => {
      val shopId = RegUtils.getByReg(line, "shopId:\"(.*?)\"")
      val dataId = RegUtils.getByReg(line, "dataId:\"(.*?)\",")
      val userId = RegUtils.getByReg(line, "userId:\"(.*?)\",")
      val userName = RegUtils.getByReg(line, "userName:\"(.*?)\",")
      val vip = RegUtils.getByReg(line, "vip:\"(.*?)\",")
      val contribution = RegUtils.getByReg(line, "contribution:\"(.*?)\",")
      val userInfo = RegUtils.getByReg(line, "userInfo:\"(.*?)\",")
      //从userInfo解析具体字段
      val avgPrice = RegUtils.getByReg(userInfo, "人均 ￥(.*?) |")
      val ratingTaste = RegUtils.getByReg(userInfo, "口味([0-9]+)")
      val ratingEnv = RegUtils.getByReg(userInfo, "环境([0-9]+)")
      val ratingService = RegUtils.getByReg(userInfo, "服务([0-9]+)")
      val ratingStar = RegUtils.getByReg(line, "ratingStar:\"(.*?)\",")
      val ratingContent = RegUtils.getByReg(line, "ratingContent:\"(.*?)\",")
      val comment = RegUtils.getByReg(line, "comment:\"(.*?)\",")
      val heartCount = RegUtils.getByReg(line, "heartCount:\"(.*?)\",")
      val recommentCount = RegUtils.getByReg(line, "recommentCount:\"(.*?)\",")
      val commentTime = RegUtils.getByReg(line, "commentTime:\"(.*?)\",")
      val crawlTime = RegUtils.getByReg(line, "crawlTime:\"(.*?)\"")

      Comment(shopId, dataId, userId, userName, vip, contribution, avgPrice, ratingTaste, ratingEnv, ratingService, ratingStar, ratingContent, comment, heartCount, recommentCount, commentTime, crawlTime)
    })

    import sqlContext.implicits._
    sqlContext.udf.register("getMD5", CommonUDF.getMD5(_: java.lang.String))
    val commentsDF = comments.toDF()
    commentsDF.registerTempTable("comments")

    res = sqlContext.sql(
      """
        |select
        |  getMD5(concat_ws(',', shopId, dataId, userId, commentTime)) comment_md5_key,
        |  shopId shop_id,
        |  dataId data_id,
        |  userId user_id,
        |  userName user_name,
        |  vip vip,
        |  contribution contribution,
        |  avgPrice avg_price,
        |  ratingTaste rating_taste,
        |  ratingEnv rating_environment,
        |  ratingService rating_service,
        |  ratingStar rating_star,
        |  ratingContent rating_content,
        |  comment comment_content,
        |  heartCount heart_count,
        |  recommentCount recomment_count,
        |  commentTime comment_time,
        |  crawlTime crawl_time
        |from
        |  comments t1
      """.stripMargin)

    res = res.dropDuplicates(Seq(key))
    res.cache()
    res.show(10, false)


  }
}

