package cn.mwee.transplant.es

import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by tal on 19/09/2017.
  */
object EsTransplantDemo {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local")
                              .setAppName("demo")
                              .set("pushdown", "true")
                              .set("es.nodes", "10.1.26.76,10.1.26.77,10.1.26.78")
                              .set("es.port", "9200")
                              .set("es.query", "?q=*")
    val sc = new SparkContext(conf)

    val sqlContext = new SQLContext(sc)

    val df = sqlContext.read.format("org.elasticsearch.spark.sql").load("basic-2017.09.25/*module")

    df.printSchema()
    println(df.count())
    df.show()

  }
}
