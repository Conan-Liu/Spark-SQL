package cn.mwee.transplant.crawler.dianping.vo

/**
  * Created by tal on 18/08/2017.
  */
case class DishTags(cityId: String, businessAreaName: String, priCat: String, secCat: String, shopId: String, shopName: String, star: String, avgPrice: String, dishTags: String, isActive: String, crawlBatch: String, crawlTime: String)
