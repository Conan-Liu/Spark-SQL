package cn.mwee.transplant.oracle

import com.gnow.{DB, Processor, Transplant}

/**
  * 源表每天更新
  */
class OdsShoptableTransplant extends Processor with Transplant {
  val DATABASE = DB.ORACLE_37_BWSWD
  val BUSINESS: String = "oracle"
  val FROM_TABLE: String = "ods_shoptable"
  val TO_TABLE: String = "/ods/ods_shoptable"
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
