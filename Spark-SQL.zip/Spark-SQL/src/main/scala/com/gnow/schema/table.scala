package com.gnow.schema

import java.text.SimpleDateFormat

import com.gnow.Utility
import com.gnow.config.{Constants, PathUtil}
import org.apache.spark.SparkContext
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.slf4j.LoggerFactory

object table {
  val logger = LoggerFactory.getLogger("9now")

  def pkg(pkg: String) = {
    object rtn {
      def df4Full(prefix: String, name: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val path = s"${pkg}/${name.toLowerCase()}/*"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def df4Daily(prefix: String, name: String)(date: String): DataFrame = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
        val formattedDate = sdf.format(sdf.parse(date))
        val path = s"${pkg}/${name.toLowerCase()}/$formattedDate/*"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def df4Daily2(prefix: String, name: String)(date: String): DataFrame = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
        val formattedDate = sdf.format(sdf.parse(date))
        val path4TodayAndPrevious = PathUtil.getPath4TodayAndPrevious(date)
        val path = s"${pkg}/${name.toLowerCase()}/$path4TodayAndPrevious"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def df4Weekly2(prefix: String, name: String)(date: String): DataFrame = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
        val formattedDate = sdf.format(sdf.parse(date))
        val path4Weekly = PathUtil.getPath4Weekly14(date)
        val path = s"${pkg}/${name.toLowerCase()}/$path4Weekly"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def df4Weekly(prefix: String, name: String)(date: String): DataFrame = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
        val formattedDate = sdf.format(sdf.parse(date))
        val path4Weekly = PathUtil.getPath4Weekly(date)
        val path = s"${pkg}/${name.toLowerCase()}/$path4Weekly"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def df4Monthly(prefix: String, name: String)(date: String): DataFrame = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
        val formattedDate = sdf.format(sdf.parse(date))
        val path4Monthly = PathUtil.getPath4Monthly(date)
        val path = s"${pkg}/${name.toLowerCase()}/$path4Monthly"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def df4Monthly2(prefix: String, name: String)(date: String): DataFrame = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
        val formattedDate = sdf.format(sdf.parse(date))
        val path4Monthly = PathUtil.getPath4MonthlyTwo(formattedDate)
        val path = s"${pkg}/${name.toLowerCase()}/$path4Monthly"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def tbl(prefix: String, name: String): String = {
        return name;
      }
    }
    rtn
  }
}
