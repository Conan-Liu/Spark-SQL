package com.gnow.schema

import com.gnow.Utility
import com.gnow.config.Constants
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.slf4j.LoggerFactory

object crawler {
  val logger = LoggerFactory.getLogger("mwee")
  val WARN_WARNINGS = "warn_warnings"

  object parquet {
    val PARQUET = "parquet"

    object dianping {
      val DIANPING = "dianping"

      //点评城市数据
      val DIANPING_CITY = "dianping_city"
      //点评分类数据
      val DIANPING_CATEGORY = "dianping_category"
      //点评商圈数据
      val DIANPING_BUSINESS_AREA = "dianping_business_area"
      //点评美食数据
      val DIANPING_SHOP_DISH = "dianping_shop_dish"
      //点评非餐饮数据
      val DIANPING_SHOP = "dianping_shop"
      //点评营业时间数据
      val DIANPING_SHOP_SERVICE_TIME = "dianping_shop_service_time"

      def ds(name: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val path = s"${Constants.CRAWLER_HOME}/$PARQUET/$DIANPING/${name.toLowerCase()}/*"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def ds(name: String, crawlBatch: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val path = s"${Constants.CRAWLER_HOME}/$PARQUET/$DIANPING/${name.toLowerCase()}/{$crawlBatch}/*"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }
    }
  }
}
