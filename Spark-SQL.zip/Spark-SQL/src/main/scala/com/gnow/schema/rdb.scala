package com.gnow.schema

import java.text.SimpleDateFormat

import com.gnow.Utility
import com.gnow.config.{Constants, PathUtil}
import com.gnow.schema.rdb.queueing.QUEUEING
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.slf4j.LoggerFactory

object rdb {
  val logger = LoggerFactory.getLogger("9now")
  val WARN_WARNINGS = "warn_warnings"

  object basic {
    val BASIC = "basic"

    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$BASIC/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$BASIC/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$BASIC/${name.toLowerCase()}/{$date}"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def dfBeginAndEnd(name: String, bDate: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val sdfDate = new SimpleDateFormat("yyyy-MM-dd")
      val endDate = sdfDate.parse(date)
      val beginDate = sdfDate.parse(bDate)
      val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
      val path4Weekly = PathUtil.getPath4Weekly(date, dateCount.toInt)
      val path = s"${Constants.RDB_HOME}/$BASIC/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    val CITY_TABLE = "city_table"
    val CITY_AREA_TABLE = "city_area_table"
    val SHOP_TYPE_TABLE = "shop_type_table"
    val MOBILE_TABLE = "mobile_table"
    val SHOP_TABLE = "shop_table"
    val SHOP_CONFIG_TABLE = "shop_config_table"
    val BUSINESS_TABLE = "business_table"
    val USER_TABLE = "user_table"
    val USER_DEVICE_TABLE = "user_device_table"
    val APNS_TOKEN_TABLE = "apns_token_table"
    val WX_ACCOUNT_TABLE = "wx_account_table"
    val QUEUE_TABLE = "queue_table"
    val SMS_LOG_TABLE = "sms_log_table"
    val SHOP_META_TABLE = "shop_meta_table"

    //菜品套餐推荐
    val TB_MENU_ITEM = "tbmenuitem"
    val TB_MENU_CLS = "tbmenucls"
    val TB_SHOP = "tbshop"
    val TB_SELL = "tb_sell"
    val TB_SELL_ORDER_ITEM = "tb_sell_order_item"
    val ODS_SHOPTABLE = "ods_shoptable"
    val C_SHOP_GOODTYPE = "c_shop_goodtype"

    val TABLES = Set(
      CITY_TABLE,
      MOBILE_TABLE,
      SHOP_TABLE,
      USER_TABLE,
      WX_ACCOUNT_TABLE,
      SHOP_CONFIG_TABLE,
      BUSINESS_TABLE,
      QUEUE_TABLE,
      SHOP_META_TABLE
    )

    def show() = {
      TABLES.foreach(println)
    }
  }

  object booking {
    val BOOKING = "booking"

    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$BOOKING/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$BOOKING/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$BOOKING/${name.toLowerCase()}/{$date}"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    val BOOKING_TABLE = "booking_table"
    val BOOKING_APPLY_SIGN = "booking_apply_sign"
    val BOOKING_DEPOSIT = "booking_deposit"
    val TABLES = Set(
      BOOKING,
      BOOKING_DEPOSIT,
      BOOKING_APPLY_SIGN
    )

    def show() = {
      TABLES.foreach(println)
    }
  }

  object ordering {
    val ORDERING = "ordering"

    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$ORDERING/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$ORDERING/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$ORDERING/${name.toLowerCase()}/{$date}"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    val APP_ORDER = "app_order"
    val APP_PAYMENT_DETAIL = "app_payment_detail"
    val CP_CARD_DATA = "cp_card_data"
    val CP_CARD_MEMBER = "cp_card_member"
    val CP_TRADE_LOG = "cp_trade_log"
    val TABLES = Set(
      APP_ORDER,
      APP_PAYMENT_DETAIL,
      CP_CARD_DATA,
      CP_CARD_MEMBER,
      CP_TRADE_LOG
    )

    def show() = {
      TABLES.foreach(println)
    }
  }
  object oracle {
    val ORACLE = "oracle"

    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$ORACLE/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$ORACLE/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$ORACLE/${name.toLowerCase()}/{$date}"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    val ORACLE_QUEUEING_GOOD_SHOP = "oracle_queueing_good_shop"
    val TABLES = Set(
      ORACLE_QUEUEING_GOOD_SHOP
    )

    def show() = {
      TABLES.foreach(println)
    }

    object c {
      val C = "c"

      //日期C表
      val C_DATE_DAILY = "c_date_daily"
      //品牌C表
      val C_SHOP_BRAND = "c_shop_brand"
      //店铺C表
      val C_SHOP_INFORMATION = "c_shop_information"
      //店铺商圈C表
      val C_RELA_SHOPBC = "c_rela_shopbc"
      //预订C表
      val C_BOOK_SHOP= "c_book_shop"

      def ds(name: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val path = s"${Constants.RDB_HOME}/$ORACLE/$C/${name.toLowerCase()}/*"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }
    }

    object dw {
      val DW = "dw"

      //预订数据
      val DW_BOOK_DAILY = "dw_book_daily"
      //排队数据
      val DW_QUEUE_DAILY = "dw_queue_daily"
      //会员数据
      val DW_MEMBER_HISTORY = "dw_member_history"

      def ds(name: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val path = s"${Constants.RDB_HOME}/$ORACLE/$DW/${name.toLowerCase()}/*"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def dsBeginAndEnd(name: String, sDate: String ,eDate: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val sdfDate = new SimpleDateFormat("yyyy-MM-dd")
        val beginDate = sdfDate.parse(sDate)
        val endDate = sdfDate.parse(eDate)
        val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
        val path4BeginAndEnd = PathUtil.getPath4Weekly(eDate, dateCount.toInt)
        val path = s"${Constants.RDB_HOME}/$ORACLE/$DW/${name.toLowerCase()}/$path4BeginAndEnd"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn

      }
    }

    object dm {
      val DM = "dm"

      //支付数据
      val DM_CASH_DAILY = "dm_cash_daily"
      //点菜数据
      val DM_ORDER_SHOP_MBOSS_D = "dm_order_shop_mboss_d"
      val DM_ORDER_SHOP_MBOSS_D_BK = "dm_order_shop_mboss_d_bk"

      def ds(name: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val path = s"${Constants.RDB_HOME}/$ORACLE/$DM/${name.toLowerCase()}/*"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }

      def dsBeginAndEnd(name: String, sDate: String ,eDate: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val sdfDate = new SimpleDateFormat("yyyy-MM-dd")
        val beginDate = sdfDate.parse(sDate)
        val endDate = sdfDate.parse(eDate)
        val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
        val path4BeginAndEnd = PathUtil.getPath4Weekly(eDate, dateCount.toInt)
        val path = s"${Constants.RDB_HOME}/$ORACLE/$DM/${name.toLowerCase()}/$path4BeginAndEnd"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn

      }

    }

    object ods {
      val ODS = "ods"

      //ods shop表
      val ODS_SHOPTABLE = "ods_shoptable"

      def ds(name: String) = {
        val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
        val path = s"${Constants.RDB_HOME}/$ORACLE/$ODS/${name.toLowerCase()}/*"
        logger.info(s"path:$path")
        val rtn = Utility.registerTableFromPath(sqlContext, path, name)
        rtn
      }
    }
  }

  object queueing {
    val QUEUEING = "queueing"

    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$QUEUEING/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$QUEUEING/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$QUEUEING/${name.toLowerCase()}/{$date}"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }
	
	def df4Weekly(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Weekly = PathUtil.getPath4Weekly(date)
      val path = s"${Constants.RDB_HOME}/$QUEUEING/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df4Monthly(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Monthly = PathUtil.getPath4Monthly(date)
      val path = s"${Constants.RDB_HOME}/$QUEUEING/${name.toLowerCase()}/$path4Monthly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }
	
	def dfBeginAndEnd(name: String, date: String ) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val  sdfDate = new SimpleDateFormat("yyyy-MM-dd")
      val endDate = sdfDate.parse(date)
      val beginDate = sdfDate.parse("2016-01-01")
      val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
      val path4Weekly = PathUtil.getPath4Weekly(date,dateCount.toInt)
      val path = s"${Constants.RDB_HOME}/$QUEUEING/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }
	

    val QUEUEING_TABLE = "queueing_table"
    val SHOP_QUEUE_CONFIG = "shop_queue_config"
    val QUEUE_USER_ORDER = "queue_user_order"
    val QUEUE_USER_PAY_RECORD = "queue_user_pay_record"
    val SHOP_QUEUE_RESERVE_RULE = "shop_queue_reserve_rule"
    val TABLES = Set(
      QUEUEING_TABLE,
      SHOP_QUEUE_CONFIG,
      QUEUE_USER_ORDER,
      QUEUE_USER_PAY_RECORD,
      SHOP_QUEUE_RESERVE_RULE
    )

    def show() = {
      TABLES.foreach(println)
    }
  }

  object paying {
    val PAYING = "paying"

    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$PAYING/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$PAYING/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$PAYING/${name.toLowerCase()}/{$date}"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }
	
	def df4Weekly(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
      val formattedDate = sdf.format(sdf.parse(date))
      val path4Weekly = PathUtil.getPath4Weekly(date)
      val path = s"${Constants.RDB_HOME}/$PAYING/${name.toLowerCase()}/$path4Weekly/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df4Monthly(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
      val formattedDate = sdf.format(sdf.parse(date))
      val path4Monthly = PathUtil.getPath4Monthly(date)
      val path = s"${Constants.RDB_HOME}/$PAYING/${name.toLowerCase()}/$path4Monthly/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    val WARN_WARNINGS = "warn_warnings"
    val COM_PAY = "com_pay"
    val COM_PAY_BACK = "com_pay_back"

    val TABLES = Set(
      WARN_WARNINGS,
      COM_PAY,
      COM_PAY_BACK
    )

    def show() = {
      TABLES.foreach(println)
    }
  }

  object oa {
    val OA = "oa"

    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$OA/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$OA/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.RDB_HOME}/$OA/${name.toLowerCase()}/{$date}"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    val REPAIR_OUT_ORDER = "repair_out_order"
    val DEVICE_ORDER = "device_order"
    val TABLES = Set(
      REPAIR_OUT_ORDER,
      DEVICE_ORDER
    )

    def show() = {
      TABLES.foreach(println)
    }
  }

  def show() = {
    println(s"+---------------------------basic---------------------------+")
    basic.show
    println(s"+-----------------------------------------------------------+")
    println()

    println(s"+---------------------------booking-------------------------+")
    booking.show
    println(s"+-----------------------------------------------------------+")
    println()

    println(s"+---------------------------ordering------------------------+")
    ordering.show
    println(s"+-----------------------------------------------------------+")
    println()

    println(s"+---------------------------queueing------------------------+")
    queueing.show
    println(s"+-----------------------------------------------------------+")
    println()
  }
}
