package com.gnow.schema

import com.gnow.DB
import com.gnow.persistence.RDBReader
import org.slf4j.LoggerFactory

object setting {
  val logger = LoggerFactory.getLogger("9now")

  def df(name: String) = {
    val rtn = RDBReader.read(DB.MYSQL_231_SETTING, name)
    rtn.registerTempTable(name)
    rtn
  }

  val COUNTRY = "country"
  val AREA = "area"
  val PROVINCE = "province"
  val CITY = "city"
  val MAIN_CITY = "main_city"

  val MEMBER_TYPE = "member_type"
  val MODEL_TYPE = "model_type"
  val BOSS_WPNG = "boss_wpng"
  val BIG_CUSTOMER = "big_customer"

  val CONSTELLATION = "constellation"

  val CALENDAR_MISC = "calendar_misc"
  val CALENDAR_MINUTE = "calendar_minute"
  val CALENDAR_MONTH = "calendar_month"

  val INTERVAL_FIVE_MINUTES = "interval_five_minutes"
  val INTERVAL_ONE_HOUR = "interval_one_hour"
  val INTERVAL_ONE_MINUTE = "interval_one_minute"

  val SHOP_DEVICE = "shop_device"
  val SHOP_FAVORITE = "shop_favorite"
  val SHOP_GOOD_TYPE = "shop_good_type"
  val SHOP_SERVICE = "shop_service"

  val CASH_POS_TYPE = "cash_pos_type"
  val CASH_STATUS = "cash_status"
  val CASH_STATUS_NEW = "cash_status_new"
  val CASH_TYPE = "cash_type"
  val CASH_PAY_CLASS = "cash_pay_class"

  val QUEUEING_STATE = "queueing_state"
  val QUEUEING_QUEUE_TYPE = "queueing_queue_type"
  val QUEUEING_CHANNEL = "queueing_channel"
  val QUEUEING_USER_ACTION = "queueing_user_action"
  val QUEUEING_DEVICE_TYPE = "queueing_device_type"

  val BOOKING_IS_SURE = "booking_is_sure"
  val BOOKING_STATUS = "booking_status"
  val BOOKING_TO_PHONE = "booking_to_phone"
  val BOOKING_TO_SMS = "booking_to_sms"
  val BOOKING_SOURCE = "booking_source"
  val BOOKING_SMS_STATUS = "booking_sms_status"
  val BOOKING_SMS_TYPE = "booking_sms_type"

  val ORDERING_DISCOUNT = "ordering_discount"
  val ORDERING_EXTEND_STATUS = "ordering_extend_status"
  val ORDERING_FROM_WAY = "ordering_from_way"
  val ORDERING_PAY_TYPE = "ordering_pay_type"
  val ORDERING_STATUS = "ordering_status"
  val ORDERING_BUSINESS = "ordering_business"
  val ORDERING_PAY_STATUS = "ordering_pay_status"
  val ORDERING_SOURCE = "ordering_source"
  val ORDERING_STATUS_NEW = "ordering_status_new"

  val TABLES = Set(
    COUNTRY,
    AREA,
    PROVINCE,
    CITY,
    MAIN_CITY,

    MEMBER_TYPE,
    MODEL_TYPE,
    BOSS_WPNG,
    BIG_CUSTOMER,

    CONSTELLATION,
    CALENDAR_MISC,
    CALENDAR_MINUTE,
    CALENDAR_MONTH,

    INTERVAL_FIVE_MINUTES,
    INTERVAL_ONE_MINUTE,
    INTERVAL_ONE_HOUR,

    SHOP_DEVICE,
    SHOP_FAVORITE,
    SHOP_GOOD_TYPE,
    SHOP_SERVICE,

    CASH_POS_TYPE,
    CASH_STATUS,
    CASH_STATUS_NEW,
    CASH_TYPE,
    CASH_PAY_CLASS,

    QUEUEING_STATE,
    QUEUEING_QUEUE_TYPE,
    QUEUEING_CHANNEL,
    QUEUEING_USER_ACTION,
    QUEUEING_DEVICE_TYPE,

    BOOKING_IS_SURE,
    BOOKING_STATUS,
    BOOKING_TO_PHONE,
    BOOKING_TO_SMS,
    BOOKING_SOURCE,
    BOOKING_SMS_STATUS,
    BOOKING_SMS_TYPE,

    ORDERING_DISCOUNT,
    ORDERING_EXTEND_STATUS,
    ORDERING_FROM_WAY,
    ORDERING_PAY_TYPE,
    ORDERING_STATUS,
    ORDERING_BUSINESS,
    ORDERING_PAY_STATUS,
    ORDERING_SOURCE,
    ORDERING_STATUS_NEW
  )

  def show() = {
    println(s"+---------------------------basic---------------------------+")
    TABLES.foreach(println)
    println(s"+-----------------------------------------------------------+")
    println()
  }
}
