package com.gnow.schema

import java.text.SimpleDateFormat

import com.gnow.Utility
import com.gnow.config.{Constants, PathUtil}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types.StructType
import org.slf4j.LoggerFactory

object repository {
  val logger = LoggerFactory.getLogger("9now")

  object kafka {
    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
      val formattedDate = sdf.format(sdf.parse(date))
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$formattedDate/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df(name: String, date: String, schema: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
      val formattedDate = sdf.format(sdf.parse(date))
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$formattedDate/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }

    def df(name: String, date: String, schema: StructType) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
      val formattedDate = sdf.format(sdf.parse(date))
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$formattedDate/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, schema)
      rtn
    }

    def df4TodayAndPrevious(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4TodayAndPrevious = PathUtil.getPath4TodayAndPrevious(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4TodayAndPrevious"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df4TodayAndPrevious(name: String, date: String, schema: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4TodayAndPrevious = PathUtil.getPath4TodayAndPrevious(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4TodayAndPrevious"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }

    def df4Weekly14(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Weekly = PathUtil.getPath4Weekly14(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df4Weekly14(name: String, date: String, schema: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Weekly = PathUtil.getPath4Weekly14(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }

    def df4Weekly(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Weekly = PathUtil.getPath4Weekly(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df4Weekly(name: String, date: String, schema: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Weekly = PathUtil.getPath4Weekly(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }

    def df4Monthly(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Monthly = PathUtil.getPath4Monthly(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Monthly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df4Monthly(name: String, date: String, schema: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Monthly = PathUtil.getPath4Monthly(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Monthly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }

    def df4MonthlyTwo(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Monthly = PathUtil.getPath4MonthlyTwo(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Monthly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def df4MonthlyTwo(name: String, date: String, schema: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path4Monthly = PathUtil.getPath4MonthlyTwo(date)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Monthly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }
	
	def dfBeginAndEnd(name: String, date: String ) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val  sdfDate = new SimpleDateFormat("yyyy-MM-dd")
      val endDate = sdfDate.parse(date)
      val beginDate = sdfDate.parse("2016-01-01")
      val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
      val path4Weekly = PathUtil.getPath4Weekly(date,dateCount.toInt)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def dfBeginAndEnd(name: String, date: String, schema: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val  sdfDate = new SimpleDateFormat("yyyy-MM-dd")
      val endDate = sdfDate.parse(date)
      val beginDate = sdfDate.parse("2016-01-01")
      val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
      val path4Weekly = PathUtil.getPath4Weekly(date,dateCount.toInt)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }

    def dfBeginAndEnd1(name: String, date: String ) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val  sdfDate = new SimpleDateFormat("yyyy-MM-dd")
      val endDate = sdfDate.parse(date)
      val beginDate = sdfDate.parse("2016-06-05")
      val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
      val path4Weekly = PathUtil.getPath4Weekly(date,dateCount.toInt)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def dfBeginAndEnd1(name: String, date: String, schema: String ) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val  sdfDate = new SimpleDateFormat("yyyy-MM-dd")
      val endDate = sdfDate.parse(date)
      val beginDate = sdfDate.parse("2016-06-05")
      val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
      val path4Weekly = PathUtil.getPath4Weekly(date,dateCount.toInt)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name , JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }

    def dfBeginAndEnd2(name: String, date: String ) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val  sdfDate = new SimpleDateFormat("yyyy-MM-dd")
      val endDate = sdfDate.parse(date)
      val beginDate = sdfDate.parse("2017-03-14")
      val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
      val path4Weekly = PathUtil.getPath4Weekly(date,dateCount.toInt)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name)
      rtn
    }

    def dfBeginAndEnd2(name: String, date: String, schema: String ) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val  sdfDate = new SimpleDateFormat("yyyy-MM-dd")
      val endDate = sdfDate.parse(date)
      val beginDate = sdfDate.parse("2017-03-14")
      val dateCount = (endDate.getTime - beginDate.getTime)/60/24/60/1000
      val path4Weekly = PathUtil.getPath4Weekly(date,dateCount.toInt)
      val path = s"${Constants.REPOSITORY_KAFKA_HOME}/${name.toLowerCase()}/$path4Weekly"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, JsonSchemaBuilder.getJsonSchema(schema))
      rtn
    }

    val BASIC_APP_TRACE = "basic_app_trace"
    val BASIC_MAIN_QUEUEING = "basic_main_queueing"
    val BASIC_SHOP_SERVICE = "basic_shop_service"
    val BASIC_SHOP_STATUS = "basic_shop_status"
    val BASIC_USER_TAG = "user_biz_user_tag"
    val BASIC_WECHAT_TRACE = "basic_wechat_trace"
    val BOOKING_MAIN_BOOK = "booking_main_book"
    val ORDERING_API_TRACE = "ordering_api_trace"
    val ORDERING_MAIN_ORDER = "ordering_main_order"
    val QUEUEING_APP_FEEDBACK = "queueing_app_feedback"
    val QUEUEING_MAIN_QUEUE = "queueing_main_queue"
    val QUEUEING_WAITING_TIME = "queueing_waiting_time"
    val MARKETING_COMPAIGN_TRACE = "marketing_compaign_trace"
    val QUEUEING_NUMBERING_PHONE = "queueing_numbering_phone"
    val QUEUEING_NUMBERING_OFFVALID = "queueing_numbering_offvalid"
    val PAYING_SECOND_PAY = "paying_second_pay"
    val QUEUEING_QR_SCAN = "queueing_qr_scan"
	  val BASIC_MEMBER_TABLE = "basic_member_table"
    val ORDERING_MOBILE_API_DCB_ONLINE = "ordering_mobile-api_dcb-online"

    val TABLES = Set(
      BASIC_APP_TRACE,
      BASIC_MAIN_QUEUEING,
      BASIC_SHOP_SERVICE,
      BASIC_SHOP_STATUS,
      BASIC_USER_TAG,
      BASIC_WECHAT_TRACE,
      BOOKING_MAIN_BOOK,
      ORDERING_API_TRACE,
      ORDERING_MAIN_ORDER,
      QUEUEING_APP_FEEDBACK,
      QUEUEING_MAIN_QUEUE,
      QUEUEING_QR_SCAN,
      ORDERING_MOBILE_API_DCB_ONLINE
    )

    def show() = {
      TABLES.foreach(println)
    }
  }

  object transform {
    val TRANSFORM = "transform"

    object booking {
      val BOOKING_SHOP = "booking_shop"
    }

    object cash {

    }

    object customer {

    }

    object member {

    }

    object ordering {

    }

    object queueing {

    }

    object sms {

    }

    object wechat {

    }

    def df(name: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.REPOSITORY_TRANSFORM_HOME}/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, TRANSFORM, name)
      rtn
    }

    def df(name: String, columns: Array[String]) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val path = s"${Constants.REPOSITORY_TRANSFORM_HOME}/${name.toLowerCase()}/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, name, columns)
      rtn
    }

    def df(name: String, date: String) = {
      val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
      val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
      val formattedDate = sdf.format(sdf.parse(date))
      val path = s"${Constants.REPOSITORY_TRANSFORM_HOME}/${name.toLowerCase()}/$formattedDate/*"
      logger.info(s"path:$path")
      val rtn = Utility.registerTableFromPath(sqlContext, path, TRANSFORM, name)
      rtn
    }

    def alias(name: String): String = {
      s"${TRANSFORM}_$name"
    }

    val QUEUE_DAILY = "queue_daily"
    val BOOK_CALL = "book_call"
    val BOOK_DAILY = "book_daily"
    val DIANPING = "dianping"
    val DPCITY = "dpcity"

    val QUEUEING_COMPACT = "queueing_compact"
    val BIG_MEMBER = "big_member"

    val CIRCLE = "circle"
    val DISTRICT = "district"
    val BRAND = "brand"
    val SHOP = "shop"
    val SHOP_GOOD_TYPE = "shop_good_type"

    val SHOP_CIRCLE = "shop_circle"
    val SHOP_AREA = "shop_area"
    val SHOP_MALL = "shop_mall"

    val TABLES = Set(
      SHOP,
      SHOP_GOOD_TYPE,
      QUEUE_DAILY,
      BOOK_DAILY,
      BOOK_CALL,
      BIG_MEMBER
    )

    def show() = {
      TABLES.foreach(println)
    }
  }

  def show() = {
    println(s"+---------------------------kafka---------------------------+")
    kafka.show
    println(s"+-----------------------------------------------------------+")
    println()
    println(s"+---------------------------transform-----------------------+")
    transform.show
    println(s"+-----------------------------------------------------------+")
    println()
  }
}
