package com.gnow.generator

import java.io.File
import java.util

import com.gnow.transform.bean.TransformBean

import scala.io.Source

object TransformGenerator {
  var TRANSFORM_HOME: File = null;
  var CLASSPATH: String = null;
  {
    val root = new File(Thread.currentThread().getContextClassLoader().getResource("").getPath())
    CLASSPATH = root.getParentFile.getParentFile.getParentFile.getPath
    TRANSFORM_HOME = new File(s"$CLASSPATH/src/main/scala/com/gnow/transform")
  }

  def main(args: Array[String]): Unit = {
    val transformBeans = find();
    transformBeans.toArray().foreach(println)
  }


  def preferred(): util.ArrayList[TransformBean] = {
    val transformBeans: util.ArrayList[TransformBean] = new util.ArrayList[TransformBean]()
    TRANSFORM_HOME.listFiles().foreach(file => {
      if (file.isFile && !file.getName.equals(".DS_Store")) {
        val transformBean = TransformGenerator.read(file, TRANSFORM_HOME)
        transformBeans.add(transformBean)
      }
    })
    return transformBeans
  }

  def find(): util.ArrayList[TransformBean] = {
    val transformBeans = new util.ArrayList[TransformBean]()
    findIn(transformBeans, TRANSFORM_HOME)
    transformBeans
  }

  def findIn(transformBeans: util.ArrayList[TransformBean], directory: File): Unit = {
    directory.listFiles().foreach(file => {
      if (file.isFile && !file.getName.equals(".DS_Store")) {
        val transformBean = TransformGenerator.read(file, directory)
        transformBeans.add(transformBean)
      } else if (file.isDirectory) {
        findIn(transformBeans, file)
      }
    })
  }

  def read(file: File, directory: File): TransformBean = {
    val rtn = new TransformBean
    val fileName = file.getName
    var packageName: String = null;
    if ("transform".equals(directory.getName)) {
      packageName = ""
    } else {
      packageName = s"${directory.getName}."
    }
    val key = s"${packageName}${fileName.replaceFirst("\\.scala", "")}"
    rtn.setKey(key)
    Source.fromFile(file).getLines().foreach(line => {
      if (!line.trim.startsWith("//")) {
        guess(rtn, line, key)
      }
    })
    rtn
  }

  def guess(rtn: TransformBean, line: String, key: String): Unit = {
    val pattern = "(\\(repository\\.transform\\.)([a-z\\.]*)([A-Z_]+)".r
    for (pattern(home, pkg, name) <- pattern.findAllIn(line)) {
      if (!key.equals(constant2ClassName(pkg, name)))
        rtn.getValues.add(constant2ClassName(pkg, name))
    }
  }

  def constant2ClassName(pkg: String, fixed: String): String = {
    val sb = new StringBuffer()
    fixed.split("_").foreach(word => {
      sb.append(word.toLowerCase.capitalize)
    })
    return s"${pkg}${sb.toString}Transform"
  }

}

