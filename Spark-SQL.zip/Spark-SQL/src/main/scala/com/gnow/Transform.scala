package com.gnow

import com.gnow.config.{Constants, SaveMode}
import com.gnow.persistence.RDBWriter
import org.apache.spark.sql.DataFrame

trait Transform extends Processor {
  val REPOSITORY_TRANSFORM_HOME = Constants.REPOSITORY_TRANSFORM_HOME

  def save(df: DataFrame, table: String, saveMode: SaveMode): Unit = {
    if (DB.isProduct) {
      RDBWriter.save(df, DB.MYSQL_24_5_TRANSFORM, table, saveMode)
      RDBWriter.save(df, DB.MYSQL_24_6_TRANSFORM, table, saveMode)
      RDBWriter.save(df, DB.MYSQL_24_7_TRANSFORM, table, saveMode)
    } else {
      RDBWriter.save(df, DB.MYSQL_231_TRANSFORM, table, saveMode)
    }
  }
}
