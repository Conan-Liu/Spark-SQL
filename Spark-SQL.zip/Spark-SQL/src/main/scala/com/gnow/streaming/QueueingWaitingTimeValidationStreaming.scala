package com.gnow.streaming

import cn.mwee.util.DateUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.JsonSchemaBuilder
import com.gnow.{DB, Processor}
import kafka.serializer.StringDecoder
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * 预估等待新模型用 评估模型的准确度 "实时" 5分钟更新一次
  *
  */
class QueueingWaitingTimeValidationStreaming extends Processor {

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from queuemode_tmp
      """.stripMargin
    println("begin" + sql)
    DBEraser.remove(DB.MYSQL_24_ASSOCIATOR, sql)
    println("end" + sql)

  }

  def execute(targetDate: String, input: String, output: String) = {
    process(targetDate, input: String, output: String)

  }

  def process(targetDate: String, input: String, output: String) = {
    val today = DateUtils.getToday
    val ssc = new StreamingContext(sqlContext.sparkContext, Seconds(60 * 5))

    val topicsSet = "estimatewaittime-estimwait-validation,QUEUEING-WAITING-TIME".split(",").toSet
//    val kafkaParams = Map[String, String]("metadata.broker.list" -> "10.1.26.8:9092,10.1.26.9:9092,10.1.26.10:9092")
    val kafkaParams = Map[String, String]("metadata.broker.list" -> "10.1.24.159:9092,10.1.24.160:9092,10.1.24.161:9092")
    val messages = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc, kafkaParams, topicsSet)

    //老模型日志
    val queueingWaitingTime = messages.map(_._2)
      .filter(line => line.contains("WAITING") && line.contains("QUEUEING") && line.contains("TIME"))
    queueingWaitingTime.repartition(1).saveAsTextFiles("/tmp/queueing_waiting_time/%s/data".format(today))
    //新模型日志
    val estimatewaittime = messages.map(_._2)
      .filter(line => line.contains("estimatewaittime") && line.contains("estimwait") && line.contains("validation"))
    estimatewaittime.repartition(1).saveAsTextFiles("/tmp/estimatewaittime/%s/data".format(today))

    val ds = estimatewaittime.union(queueingWaitingTime)
    ds.foreachRDD(rdd =>{
      try{
        //老模型的日志
        val schema = "shop_id,queue_id,serial_id,timing_type,waiting_number,estimated_time,create_time"
        val oldDF = sqlContext.read.schema(JsonSchemaBuilder.getJsonSchema(schema))
          .json("/tmp/queueing_waiting_time/%s/data-*/*".format(today))
        val oldCnt = oldDF.count()
        oldDF.createOrReplaceTempView("queueing_waiting_time")
        //新模型的日志
        val schemaNew = StructType(
          List(
            StructField("shopid", IntegerType, true),
            StructField("queueid", IntegerType, true),
            StructField("serialId", StringType, true),
            StructField("currtime", StringType, true),
            StructField("type", StringType, true),
            StructField("estimatetime", IntegerType, true),
            StructField("estimatetime_old", IntegerType, true)
          )
        )
        val newDF = sqlContext.read.schema(schemaNew)
          .json("/tmp/estimatewaittime/%s/data-*/*".format(today))
          .where("serialid != ''")
        val newCnt = newDF.count()
        newDF.createOrReplaceTempView("estimatewaittime_estimwait_validation")

        if(oldCnt > 0 && newCnt > 0){
          val tmpRes = sqlContext.sql(
            """
              |select distinct
              | '0' id,
              | t4.serialId,
              | t4.queueid,
              |	t4.shopid,
              | t5.waiting_number waitpeople,
              | '0' number,
              | t4.lasttime,
              | t4.createdate,
              |	t4.realtime,
              |	t4.estimatetime newtime,
              |	floor(t5.estimated_time/60.0) oldtime
              |from
              |	(select
              |		t2.shopid,
              |		t2.queueid,
              |		t2.serialId,
              |   t2.currtime createdate,
              |   t3.currtime lasttime,
              |		floor((unix_timestamp(t3.currtime) - unix_timestamp(t2.currtime))/60.0) realtime,
              |		t2.estimatetime
              |	from
              |		(select
              |			t1.*
              |		from
              |			estimatewaittime_estimwait_validation t1
              |		where
              |			t1.type = 'alloc') t2
              |	inner join
              |		(select
              |			t1.*
              |		from
              |			estimatewaittime_estimwait_validation t1
              |		where
              |			t1.type = 'call') t3
              |	on
              |		t2.shopid = t3.shopid
              |		and
              |		t2.queueid = t3.queueid
              |		and
              |		t2.serialId = t3.serialId) t4
              |inner join
              |	(select * from queueing_waiting_time where timing_type = '0') t5
              |on
              |	t4.shopid = t5.shop_id
              |	and
              |	t4.queueid = t5.queue_id
              |	and
              |	cast(t4.serialId as double) = t5.serial_id
            """.stripMargin.format(targetDate, targetDate))
          println(oldCnt)
          println(newCnt)
          tmpRes.show(200)
          tmpRes.createOrReplaceTempView("tmp_res")
          val res = sqlContext.sql(
            """
              |select
              |	t2.id,
              |	t2.serialId,
              |	t2.queueid,
              |	t2.shopid,
              |	t2.waitpeople,
              |	t2.number,
              |	t2.lasttime,
              |	t2.createdate,
              |	t2.realtime,
              |	t2.newtime,
              |	t2.oldtime,
              |	(case when
              |		(
              |			unix_timestamp(t2.lasttime) <= t2.lasttime_b1
              |     and
              |			unix_timestamp(t2.lasttime) <= t2.lasttime_b2
              |     and
              |			unix_timestamp(t2.lasttime) <= t2.lasttime_b3
              |     and
              |			unix_timestamp(t2.lasttime) <= t2.lasttime_b4
              |     and
              |			unix_timestamp(t2.lasttime) <= t2.lasttime_b5
              |			and
              |			unix_timestamp(t2.lasttime) >= t2.lasttime_p1
              |     and
              |			unix_timestamp(t2.lasttime) >= t2.lasttime_p2
              |     and
              |			unix_timestamp(t2.lasttime) >= t2.lasttime_p3
              |     and
              |			unix_timestamp(t2.lasttime) >= t2.lasttime_p4
              |     and
              |			unix_timestamp(t2.lasttime) >= t2.lasttime_p5
              |			) then
              |		'2'
              |	else
              |		'1'
              | end) is_noise
              |from
              |	(select
              |		t1.id,
              |		t1.serialId,
              |		t1.queueid,
              |		t1.shopid,
              |		t1.waitpeople,
              |		t1.number,
              |		t1.lasttime,
              |		t1.createdate,
              |		t1.realtime,
              |		t1.newtime,
              |		t1.oldtime,
              |		(lead(unix_timestamp(t1.lasttime), 1, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b1,
              |		(lead(unix_timestamp(t1.lasttime), 2, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b2,
              |		(lead(unix_timestamp(t1.lasttime), 3, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b3,
              |		(lead(unix_timestamp(t1.lasttime), 4, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b4,
              |		(lead(unix_timestamp(t1.lasttime), 5, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b5,
              |		(lag(unix_timestamp(t1.lasttime), 1, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p1,
              |		(lag(unix_timestamp(t1.lasttime), 2, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p2,
              |		(lag(unix_timestamp(t1.lasttime), 3, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p3,
              |		(lag(unix_timestamp(t1.lasttime), 4, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p4,
              |		(lag(unix_timestamp(t1.lasttime), 5, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p5,
              |  (count(1) over(partition by t1.shopid, t1.queueid)) cnt,
              |  (row_number() over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) rn
              |	from
              |		(select * from tmp_res) t1
              |  ) t2
              |where
              | t2.rn <= t2.cnt - 5
            """.stripMargin)
          res.show()

          //操作数据库
          //删除临时表数据
          reset(today)
          //将实时计算结果插入临时表
          RDBWriter.overwrite(res.repartition(1), DB.MYSQL_24_ASSOCIATOR, "queuemode_tmp")
          //通过临时表更新正式表
          val insertSQL = "insert into queuemode(serialId,queueid,shopid,waitpeople,number,lasttime,createdate,realtime,newtime,oldtime,is_noise) select serialId,queueid,shopid,waitpeople,number,lasttime,createdate,realtime,newtime,oldtime,is_noise from queuemode_tmp where serialid not in (select serialid from queuemode)"
          println(insertSQL)
          DBEraser.remove(DB.MYSQL_24_ASSOCIATOR, insertSQL)

        } else {
          println(oldCnt)
          oldDF.show()
          println(newCnt)
          newDF.show()

        }
      }catch {
        case e: Exception => println(e.getMessage)
      }

    })

    // Start the computation
    ssc.start()
    ssc.awaitTermination()

  }
}
