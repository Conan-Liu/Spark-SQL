package com.gnow.merge

import com.gnow.{Mail, Processor}
import com.gnow.config.{Constants, FileFormat, SaveMode}
import com.gnow.persistence.HDFSWriter
import org.apache.hadoop.fs.Path

class FileMerge extends Processor {
  private val NUMBER_OF_PARTITIONS = 5

  def execute(targetDate: String, input: String, output: String) = {
    val inputPath = s"$input/${Constants.MATCHED}/$targetDate"
    val outputPath = s"$output/$targetDate"
    logger.info(s"input path:$inputPath")
    logger.info(s"output path:$outputPath")
    val fs = org.apache.hadoop.fs.FileSystem.get(sqlContext.sparkContext.hadoopConfiguration)
    if (fs.exists(new org.apache.hadoop.fs.Path(inputPath))) {
      val df = sqlContext.read.json(inputPath)
      val result = df.distinct().coalesce(NUMBER_OF_PARTITIONS)
      HDFSWriter.save(result, outputPath, FileFormat.JSON, SaveMode.OVERWRITE)
    } else {
      val subject = s"File Merge: input path $inputPath does not exist."
      logger.warn(subject)
      Mail.send(subject, subject)
      fs.mkdirs(new Path(outputPath))
      fs.create(new Path(s"$outputPath/part-r-00000-00000000-0000-0000-0000-000000000000"))
    }
    logger.info(s"finished merging files.")
  }
}





