package com.gnow.merge

import com.gnow.config.{Constants, FileFormat, SaveMode}
import com.gnow.persistence.HDFSWriter
import com.gnow.{FieldConvert, Processor}

class FieldLowerCase extends Processor {
  def execute(targetDate: String, input: String, output: String) = {
    logger.info(s"input path:$input")
    logger.info(s"output path:$output")
    val df = sqlContext.read.json(input)
    val ndf = FieldConvert.convert(df)
    HDFSWriter.save(ndf, output, FileFormat.JSON, SaveMode.OVERWRITE)
  }
}





