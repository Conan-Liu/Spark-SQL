package com.gnow.util

object Variables {
  def replace(source:String, name: String, value: String): String = {
    source.replaceAll(s"\\$$\\{$name\\}", value)
  }
}
