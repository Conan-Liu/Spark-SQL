package com.gnow.config

object FIXED_WORDS {
  val FIXED = Map(
    "@TIMESTAMP" -> "@TIMESTAMP",
    "@VERSION" -> "@VERSION",
    "USERID" -> "USER_ID",
    "OPENID" -> "OPEN_ID"
  )
}
