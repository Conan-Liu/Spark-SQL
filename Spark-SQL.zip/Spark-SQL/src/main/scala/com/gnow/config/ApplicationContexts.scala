package com.gnow.config

object ApplicationContexts {
  val holder: ApplicationContext = new ApplicationContext

  def getString(field: String): String = {
    holder.config.getString(field).trim()
  }

  def getInt(field: String): Int = {
    holder.config.getInt(field)
  }

  def getBool(field: String): Boolean = {
    holder.config.getBoolean(field)
  }
}
