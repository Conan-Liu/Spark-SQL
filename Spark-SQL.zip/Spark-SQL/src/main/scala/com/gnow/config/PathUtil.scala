package com.gnow.config

import java.text.SimpleDateFormat
import java.util.Calendar

object PathUtil {
  def getPreviousDate(targetDate: String): String = {
    val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
    val currentDate = sdf.format(sdf.parse(targetDate))
    val calendar = Calendar.getInstance()
    calendar.setTime(sdf.parse(currentDate))
    calendar.add(Calendar.DATE, -1)
    val previousDate = sdf.format(calendar.getTime)
    previousDate
  }

  def getPath4TodayAndPrevious(targetDate: String): String = {
    val previousDate = getPreviousDate(targetDate)
    s"{$targetDate,$previousDate}"
  }

  def getPath4Weekly(targetDate: String): String = {
    getPath4Weekly(targetDate, 6)
  }

  def getPath4Weekly14(targetDate: String): String = {
    getPath4Weekly(targetDate, 13)
  }

  def getPath4Someday(startDate: String, endDate: String): String = {
    val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
    val currentDateStart = sdf.format(sdf.parse(startDate))
    val calendarStart = Calendar.getInstance()
    calendarStart.setTime(sdf.parse(currentDateStart))

    val currentDateEnd = sdf.format(sdf.parse(endDate))
    val calendarEnd = Calendar.getInstance()
    calendarEnd.setTime(sdf.parse(currentDateEnd))

    val dateAmount = ((calendarEnd.getTime().getTime() / 1000).toInt - (calendarStart.getTime().getTime() / 1000).toInt) / 3600 / 24
    getPath4Weekly(endDate, dateAmount)
  }


  def getPath4Weekly(targetDate: String, dateAmount: Int): String = {
    var path = s"{$targetDate"
    var currentDate = targetDate
    for (i <- 1 to dateAmount) {
      val previousDate = getPreviousDate(currentDate)
      if (i == dateAmount) {
        path = s"$path,$previousDate}"
      } else {
        path = s"$path,$previousDate"
      }
      currentDate = previousDate
    }
    path
  }

  def getPath4Monthly(targetDate: String): String = {
    val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
    val currentDate = sdf.parse(targetDate)
    val calendar = Calendar.getInstance()
    calendar.setTime(currentDate)
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    //calendar.set(year, month, 1, 0, 0, 0)
    //calendar.add(Calendar.MONTH, -1)
    f"$year-${month + 1}%02d-*"
  }

  def getPath4MonthlyTwo(targetDate: String): String = {
    val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
    val currentDate = sdf.parse(targetDate)
    val calendar = Calendar.getInstance()
    calendar.setTime(currentDate)
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    //calendar.set(year, month, 1, 0, 0, 0)
    calendar.add(Calendar.MONTH, -1)
    val year1 = calendar.get(Calendar.YEAR)
    val month1 = calendar.get(Calendar.MONTH)
    f"{$year-${month + 1}%02d-*,$year1-${month1 + 1}%02d-*}"
  }

}
