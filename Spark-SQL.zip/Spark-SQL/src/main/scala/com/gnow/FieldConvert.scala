package com.gnow

import com.gnow.config.{FIXED_WORDS, MYSQL_KEYWORDS}
import org.apache.spark.sql.DataFrame
import org.slf4j.LoggerFactory

object FieldConvert {
  val logger = LoggerFactory.getLogger("9now")
  
  def convert(df: DataFrame): DataFrame = {
    var rtn = df;
    rtn.columns.foreach(column => {
      val field = column.toString
      val newField = FieldConvert.convert(field)
      rtn = rtn.withColumnRenamed(field, newField)
    })
    rtn
  }

  def convert(field: String): String = {
    if (MYSQL_KEYWORDS.FIXED.contains(field.toUpperCase())) {
      val value = MYSQL_KEYWORDS.FIXED.get(field.toUpperCase)
      return s"${value.get.toLowerCase}"
    } else if (FIXED_WORDS.FIXED.contains(field.toUpperCase())) {
      val value = FIXED_WORDS.FIXED.get(field.toUpperCase)
      return s"${value.get.toLowerCase}"
    } else if (field.matches("^[a-z0-9_]+$")) {
      return field
    } else if (field.matches("^[a-zA-Z0-9_]+$")) {
      regexConvert(field)
    } else {
      logger.warn(s"invalid field:$field")
      return field
    }
  }

  def regexConvert(field: String): String = {
    val capitalize = field.capitalize
    val pattern = "((^_+|[A-Z]+)[a-z0-9_]*)".r
    val matchIterator = pattern.findAllIn(capitalize)
    val sb = new StringBuilder
    matchIterator.foreach(part => {
      sb.append(s"_${part.toLowerCase}")
    })
    val rtn = sb.toString().replaceFirst("^_+", "").replaceAll("_+", "_")
    rtn
  }
}


