package com.gnow

import org.slf4j.LoggerFactory


trait ILogger {
  val logger = LoggerFactory.getLogger("9now")
}
