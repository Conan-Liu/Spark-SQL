package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import com.gnow.sql.{SQLShop, SQLShopDistanceBook}
import com.gnow.{DB, Processor, Utility}

class ShopDistanceBookDaily extends Processor {
  val SHOP_DISTANCE = "shop_distance"

  def reset(targetDate: String): Unit = {

    val sql =
      """
        |delete
        |from shop_distance
        |where create_date='%s'
        |and business_type='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate, "1"))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val tbl = repository.kafka.df(repository.kafka.BOOKING_MAIN_BOOK, targetDate)
    val columns = Array("shop_id", "shop_name", "type_", "shop_type", "city", "manage_shop_id",
      "shoppingmall_shop_id", "longitude", "latitude", "create_date")
    val shopTable = rdb.basic.df(rdb.basic.SHOP_TABLE, columns)
    val shopsql = SQLShop.getSQL(targetDate)
    logger.info(shopsql)
    val shopres = sqlContext.sql(shopsql)
    shopres.registerTempTable("shop_compact")
    val sql = SQLShopDistanceBook.getSQL(targetDate)
    val res = Utility.sql(tbl, sql)
    RDBWriter.save(res, DB.ORACLE_37_BWSWD, SHOP_DISTANCE)
  }
}
