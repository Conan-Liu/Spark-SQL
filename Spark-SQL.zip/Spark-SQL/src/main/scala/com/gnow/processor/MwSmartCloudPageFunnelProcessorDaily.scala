package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.processor.vo.SCNode
import com.gnow.schema.rdb
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}

import scala.collection.mutable.ListBuffer

/**
  * Created by tal on 18/12/2017.
  */
class MwSmartCloudPageFunnelProcessorDaily extends Processor {
  var res1DF: DataFrame = _
  var res2DF: DataFrame = _
  var res3DF: DataFrame = _
  var res4DF: DataFrame = _
  var res5DF: DataFrame = _
  var res6DF: DataFrame = _
  var res7DF: DataFrame = _
  var res8DF: DataFrame = _
  var res9DF: DataFrame = _
  val db = DB.ORACLE_37_BWSWD
  val destTable = "DM_MONITOR_SC_FUNNEL"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where day_id = '%s'".format(destTable, targetDate)
    println("操作数据库：" + db.toString)
    println("执行SQL：" + sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    println("漏斗一")
    if(res1DF.count() > 0){
      RDBWriter.overwrite(res1DF.coalesce(1), db, destTable)
    }
    println("漏斗二")
    if(res2DF.count() > 0){
      RDBWriter.overwrite(res2DF.coalesce(1), db, destTable)
    }
    println("漏斗三")
    if(res3DF.count() > 0){
      RDBWriter.overwrite(res3DF.coalesce(1), db, destTable)
    }
    println("漏斗四")
    if(res4DF.count() > 0){
      RDBWriter.overwrite(res4DF.coalesce(1), db, destTable)
    }
    println("漏斗五")
    if(res5DF.count() > 0){
      RDBWriter.overwrite(res5DF.coalesce(1), db, destTable)
    }
    println("漏斗七")
    if(res7DF.count() > 0){
      RDBWriter.overwrite(res7DF.coalesce(1), db, destTable)
    }
    println("漏斗八")
    if(res8DF.count() > 0){
      RDBWriter.overwrite(res8DF.coalesce(1), db, destTable)
    }
    println("漏斗九")
    if(res9DF.count() > 0){
      RDBWriter.overwrite(res9DF.coalesce(1), db, destTable)
    }
    println("Happy Ending!")
  }

  def process(targetDate: String, input: String, output: String) = {
    //读取日志数据
    val schema = StructType(
      List(
        StructField("business", StringType, true),
        StructField("module", StringType, true),
        StructField("action", StringType, true),
        StructField("mwAuthToken", StringType, true),
        StructField("app_version", StringType, true),
        StructField("device_type", StringType, true),
        StructField("device_info", StringType, true),
        StructField("city_id", StringType, true),
        StructField("mobile", StringType, true),
        StructField("location", StringType, true),
        StructField("event", StringType, true),
        StructField("update_time", DoubleType, true)
      )
    )
    val appOperationLogDF = sqlContext.read.schema(schema).json("/repository/kafka/user_action_app_operation/{date}".replace("{date}", targetDate))
    appOperationLogDF.printSchema()
    appOperationLogDF.registerTempTable("app_operation_log")

    val wechatOperationLogDF = sqlContext.read.schema(schema).json("/repository/kafka/user_action_wechat_operation/{date}".replace("{date}", targetDate))
    wechatOperationLogDF.printSchema()
    wechatOperationLogDF.registerTempTable("wechat_operation_log")

    val operationLogDF = appOperationLogDF.unionAll(wechatOperationLogDF).distinct()
    operationLogDF.registerTempTable("operation_log")

    //获取需要的字段
    val logDF = sqlContext.sql(
      """
        |select
        | business
        | ,t1.module
        | ,t1.action
        | ,t1.app_version
        | ,t1.device_type
        | ,t1.device_info
        | ,t1.city_id
        | ,t1.mobile
        | ,t1.mwAuthToken
        | ,t1.location
        | ,get_json_object(t1.event, '$.page') page
        | ,get_json_object(t1.event, '$.area') area
        | ,get_json_object(t1.event, '$.url') url
        | ,get_json_object(t1.event, '$.keyword') keyword
        | ,get_json_object(t1.event, '$.content_id') contentId
        | ,get_json_object(t1.event, '$.services') services
        | ,get_json_object(t1.event, '$.etype') etype
        | ,get_json_object(t1.event, '$.event') event
        | ,get_json_object(t1.event, '$.order_type') order_type
        | ,get_json_object(t1.event, '$.order_no') order_no
        | ,get_json_object(t1.event, '$.waiting_table') waiting_table
        | ,get_json_object(t1.event, '$.estimated_waiting_time') estimated_waiting_time
        | ,substr(cast(cast(t1.update_time as long) as string), 0, 10) time
        | ,from_unixtime(substr(cast(cast(t1.update_time as long) as string), 0, 10))
        |from
        | operation_log t1
        |order by
        | t1.device_info
        | ,time
      """.stripMargin)

    import sqlContext.implicits._

    //debug start
    //测试数据
//    val tdDF = sqlContext.sparkContext.parallelize(Seq(
//      SCLog("1","","smart_cloud_shopdetail","","","click_shop_image","1510024871")
//      //1
//      ,SCLog("slajdfl","7236","miaofu_payresult","","","page_load","123")
//      ,SCLog("slajdfl","7236","miaofu_comment","","","page_load_2","124")
//      ,SCLog("slajdfl","7236","miaofu_comment","","","comment_redbag","125")
//      ,SCLog("slajdfl","7236","miaofu_comment","","","redbag_share","126")
//      ,SCLog("slajdfl","7236","MMCFissionCouponDetail","","","invite_share","127")
//
//      ,SCLog("slajdfl2","7236","miaofu_payresult","","","page_load","123")
//      ,SCLog("slajdfl2","7236","miaofu_comment","","","page_load_2","124")
//      ,SCLog("slajdfl2","7236","miaofu_comment","","","comment_redbag","125")
//      ,SCLog("slajdfl2","7236","miaofu_comment","","","redbag_share","126")
//
//      ,SCLog("slajdfl3","7236","miaofu_payresult","","","page_load","123")
//      ,SCLog("slajdfl3","7236","miaofu_comment","","","page_load_2","124")
//      ,SCLog("slajdfl3","7236","miaofu_comment","","","comment_redbag","125")
//
//      ,SCLog("slajdfl4","7236","miaofu_payresult","","","page_load","123")
//      ,SCLog("slajdfl4","7236","miaofu_comment","","","page_load_2","124")
//
//      ,SCLog("slajdfl5","7236","miaofu_payresult","","","page_load","123")

//      ,SCLog("slajdfl","4132","miaofu_payresult","","","page_load","1123")
//      ,SCLog("slajdfl","4132","miaofu_comment","","","page_load_2","1124")
//      ,SCLog("slajdfl","4132","miaofu_comment","","","comment_redbag","1125")
//      ,SCLog("slajdfl","4132","miaofu_comment","","","redbag_share","1126")
//      ,SCLog("slajdfl","4132","MMCFissionCouponDetail","","","invite_share","1127")
//
//      ,SCLog("slajdfl2","4132","miaofu_payresult","","","page_load","1123")
//      ,SCLog("slajdfl2","4132","miaofu_comment","","","page_load_2","1124")
//      ,SCLog("slajdfl2","4132","miaofu_comment","","","comment_redbag","1125")
//      ,SCLog("slajdfl2","4132","miaofu_comment","","","redbag_share","1126")

//      ,SCLog("slajdfl3","4132","miaofu_payresult","","","page_load","1123")
//      ,SCLog("slajdfl3","4132","miaofu_comment","","","page_load_2","1124")
//      ,SCLog("slajdfl3","4132","miaofu_comment","","","comment_redbag","1125")
//
//      ,SCLog("slajdfl4","4132","miaofu_payresult","","","page_load","1123")
//      ,SCLog("slajdfl4","4132","miaofu_comment","","","page_load_2","1124")
//
//      ,SCLog("slajdfl5","4132","miaofu_payresult","","","page_load","1123")
//
//      ,SCLog("slajdfl5","4132","miaofu_payresult","","","page_load","1127")
//
//      //2
//      ,SCLog("slajdfl","7236","order_detail_fast","","","fastfood_please_take_dining","2123")
//      ,SCLog("slajdfl","7236","miaofu_comment","","","page_load_3","2124")
//      ,SCLog("slajdfl","7236","miaofu_comment","","","comment_redbag","2125")
//      ,SCLog("slajdfl","7236","miaofu_comment","","","redbag_share","2126")
//      ,SCLog("slajdfl","7236","MMCFissionCouponDetail","","","invite_share","2127")
//
//      ,SCLog("slajdfl2","7236","order_detail_fast","","","fastfood_please_take_dining","2123")
//      ,SCLog("slajdfl2","7236","miaofu_comment","","","page_load_3","2124")
//      ,SCLog("slajdfl2","7236","miaofu_comment","","","comment_redbag","2125")
//      ,SCLog("slajdfl2","7236","miaofu_comment","","","redbag_share","2126")
//
//      ,SCLog("slajdfl3","7236","order_detail_fast","","","fastfood_please_take_dining","2123")
//      ,SCLog("slajdfl3","7236","miaofu_comment","","","page_load_3","2124")
//      ,SCLog("slajdfl3","7236","miaofu_comment","","","comment_redbag","2125")
//
//      ,SCLog("slajdfl4","7236","order_detail_fast","","","fastfood_please_take_dining","2123")
//      ,SCLog("slajdfl4","7236","miaofu_comment","","","page_load_3","124")
//
//      ,SCLog("slajdfl5","7236","order_detail_fast","","","fastfood_please_take_dining","2123")
//
//      ,SCLog("slajdfl3","4132","order_detail_fast","","","fastfood_please_take_dining","22123")
//      ,SCLog("slajdfl3","4132","miaofu_comment","","","page_load_3","22124")
//      ,SCLog("slajdfl3","4132","miaofu_comment","","","comment_redbag","22125")
//
//      ,SCLog("slajdfl4","4132","order_detail_fast","","","fastfood_please_take_dining","22123")
//      ,SCLog("slajdfl4","4132","miaofu_comment","","","page_load_3","22124")
//
//      ,SCLog("slajdfl5","4132","order_detail_fast","","","fastfood_please_take_dining","22123")
//
//      //3
//      ,SCLog("slajdfl","7236","miaofu_comment","","","page_load_4","3133")
//      ,SCLog("slajdfl","7236","miaofu_comment","","","comment_redbag","3134")
//      ,SCLog("slajdfl","7236","miaofu_comment","","","redbag_share","3135")
//      ,SCLog("slajdfl","7236","MMCFissionCouponDetail","","","invite_share","3136")
//
//      ,SCLog("slajdfl2","7236","miaofu_comment","","","page_load_4","3133")
//      ,SCLog("slajdfl2","7236","miaofu_comment","","","comment_redbag","3134")
//
//      ,SCLog("slajdfl2","4132","miaofu_comment","","","page_load_4","33133")
//      ,SCLog("slajdfl2","4132","miaofu_comment","","","comment_redbag","33134")
//
//      //4
//      ,SCLog("slajdfl","wx08b2d81646e57897","MMCFissionCouponDetail","","","open_fission_newuser","137")
//      ,SCLog("slajdfl","wx08b2d81646e57897","MMCFissionCouponDetail","","","open_register","138")
//      ,SCLog("slajdfl","wx08b2d81646e57897","MMCFissionCouponDetail","","","redpacket_newuser_success","139")
//
//      ,SCLog("slajdfl2","wx08b2d81646e57897","MMCFissionCouponDetail","","","open_fission_newuser","137")
//      ,SCLog("slajdfl2","wx08b2d81646e57897","MMCFissionCouponDetail","","","open_register","138")
//
//      //5
//      ,SCLog("slajdfll","wx08b2d81646e57897","MMCFissionCouponDetail","","","invite_share","141")
//      ,SCLog("slajdfll","wx08b2d81646e57897","MMCFissionCouponDetail","","","invite_share","142")
//      ,SCLog("slajdfll","wx08b2d81646e57897","MMCFissionCouponDetail","","","beinvited_share","143")
//      ,SCLog("slajdfll","wx08b2d81646e57897","MMCFissionCouponDetail","","","beinvited_share","144")
////
////      ,SCLog("slajdfl","wx08b2d81646e57897","MMCFissionCouponDetail","","","open_fission","141")
////      ,SCLog("slajdfl","wx08b2d81646e57897","MMCFissionCouponDetail","","","redpacket_success","142")
//
////      ,SCLog("slajdfl2","wx08b2d81646e57897","MMCFissionCouponDetail","","","open_fission","141")
//
//      //7
//      ,SCLog("slajdfl","7236","smart_cloud_shopdetail","","","page_load","143")
//      ,SCLog("slajdfl","7236","webpay","","","webpay","144")
//      ,SCLog("slajdfl","7236","webapp_queue_detail","","","queue","145")
//      //8
//      ,SCLog("slajdfl","7236","smart_cloud_shopdetail","","","page_load","146")
//      ,SCLog("slajdfl","7236","webapp_queue_detail","","","queue","147")
//      //9
//      ,SCLog("slajdfl","7236","smart_cloud_shopdetail","","","page_load","148")
//      ,SCLog("slajdfl","7236","reservation_order","","","reservation","149")
//      ,SCLog("slajdfl","7236","reservation_order_detail","","","reservation","150")
//        )).toDF()
//    tdDF.show(100, false)
    //debug end

    //访问节点标注
    val markedLogDF =
//      tdDF //debug
      logDF //online
        .where("keyword is null")
        .select("mwAuthToken", "url", "page", "contentId", "etype", "event", "time").rdd
        .map(row =>{
          var userId = ""
          if(row.get(0) != null){
            userId = row.get(0).toString
          }
          var url = ""
          if(row.get(1) != null){
            url = row.get(1).toString
          }
          var page = ""
          if(row.get(2) != null){
            page = row.get(2).toString
          }
          var contentId = ""
          if(row.get(3) != null){
            contentId = row.get(3).toString
          }
          var etype = ""
          if(row.get(4) != null){
            etype = row.get(4).toString
          }
          var event = ""
          if(row.get(5) != null){
            event = row.get(5).toString
          }
          var time = "0"
          if(row.get(6) != null){
            time = row.get(6).toString
            if(time.equals("")){
              time = "0"
            }
          }
          if(userId.equals("")){
            userId = time
          }
          //标注
          (page, event) match {
            case  ("miaofu_payresult","page_load") => SCNode(userId, "miaofu_payresult_page_load","miaofu_payresult","支付成功页",contentId,"秒付结果页",0, time.toLong)
            case  ("miaofu_comment","page_load_2") => SCNode(userId, "miaofu_comment_page_load_2","miaofu_comment","发表评论页",contentId,"发表评论页-发表评论(正餐)",0, time.toLong)
            case  ("miaofu_comment","comment_redbag") => SCNode(userId, "miaofu_comment_comment_redbag","miaofu_comment","发表评论页",contentId,"领取红包页",0, time.toLong)
            case  ("miaofu_comment","redbag_share") => SCNode(userId, "miaofu_comment_redbag_share","miaofu_comment","发表评论页",contentId,"评论红包领取页-邀请有礼入口",0, time.toLong)
            case  ("MMCFissionCouponDetail","beinvited_share") => SCNode(userId, "MMCFissionCouponDetail_redbag_share","MMCFissionCouponDetail","收到裂变红包页",url,"裂变红包-分享成功",0, time.toLong)
            case  ("quickorder_order_detail_fast","fastfood_please_take_dining") => SCNode(userId, "quickorder_order_detail_fast_fastfood_please_take_dining","order_detail_fast","请取餐状态页",contentId,"请取餐状态页",0, time.toLong)
            case  ("miaofu_comment","page_load_3") => SCNode(userId, "miaofu_comment_page_load_3","miaofu_comment","发表评论页",contentId,"发表评论页-发表评论(快餐)",0, time.toLong)
            case  ("miaofu_comment","page_load_4") => SCNode(userId, "miaofu_comment_page_load_4","miaofu_comment","发表评论页",contentId,"发表评论页-发表评论(快餐推送)",0, time.toLong)
            case  ("MMCFissionCouponDetail","open_fission_newuser") => SCNode(userId, "MMCFissionCouponDetail_open_fission_newuser","MMCFissionCouponDetail","收到裂变红包页",contentId,"新用户打开裂变红包页",0, time.toLong)
            case  ("MMCFissionCouponDetail","open_register") => SCNode(userId, "MMCFissionCouponDetail_open_register","MMCFissionCouponDetail","收到裂变红包页",contentId,"新用户注册页",0, time.toLong)
            case  ("MMCFissionCouponDetail","redpacket_newuser_success") => SCNode(userId, "MMCFissionCouponDetail_redpacket_newuser_success","MMCFissionCouponDetail","收到裂变红包页",contentId,"新用户领取红包成功",0, time.toLong)
            case  ("MMCFissionCouponDetail","invite_share") => SCNode(userId, "MMCFissionCouponDetail_redbag_share","MMCFissionCouponDetail","邀请有礼页",contentId,"邀请有礼-微信分享成功",0, time.toLong)
            case  ("MMCFissionCouponDetail","open_fission") => SCNode(userId, "MMCFissionCouponDetail_open_fission","MMCFissionCouponDetail","收到裂变红包页",contentId,"收到裂变红包页",0, time.toLong)
            case  ("MMCFissionCouponDetail","redpacket_success") => SCNode(userId, "MMCFissionCouponDetail_redpacket_success","MMCFissionCouponDetail","收到裂变红包页",contentId,"新老用户领取成功",0, time.toLong)
            case  ("smart_cloud_shopdetail","page_load") => SCNode(userId, "smart_cloud_shopdetail_page_load","smart_cloud_shopdetail","商户详情页",contentId,"商户详情页",0, time.toLong)
            case  ("webpay","pay_success") => SCNode(userId, "webpay_pay_success","webpay","支付页",contentId,"支付页",0, time.toLong)
            case  ("webapp_queue_detail","queue") => SCNode(userId, "webapp_queue_detail_queue","webapp_queue_detail","号单详情",contentId,"号单详情",0, time.toLong)
            case  ("reservation_order","reservation") => SCNode(userId, "reservation_order_reservation","reservation_order","在线预约页",contentId,"在线预约页",0, time.toLong)
            case  ("reservation_order_detail","reservation") => SCNode(userId, "reservation_order_detail_reservation","reservation_order_detail","预约单详情",contentId,"预约单详情",0, time.toLong)
            case _ => SCNode(userId, "", "", "", "", "", 0, time.toLong)
          }
        })
    //debug start
//        .toDF()
//        .filter("nodeId != ''")
//    markedLogDF.show(100, false)
//    markedLogDF.registerTempTable("marked_log")
    markedLogDF.toDF().show(100, false)
    //debug end
    markedLogDF.toDF().registerTempTable("marked_log")

    val groupedLog = markedLogDF
      //过滤掉节点为空的数据
      .filter(node => !node.nodeId.equals(""))
      .map(node => (node.userId, node))
      //根据用户groupBy
      .groupByKey()
    //缓存
    groupedLog.cache()
    println("groupedLog cnt: " + groupedLog.count())


    //读取计算漏斗可能用到的db数据
    val shopTableDF = rdb.basic.df(rdb.basic.SHOP_TABLE)
    val cShopBrandDF = rdb.basic.df("c_shop_brand")
    val platWxShopTableDF = rdb.basic.df("plat_wx_shop_table")
    shopTableDF.show(10, false)
    cShopBrandDF.show(10, false)
    platWxShopTableDF.show(10, false)

    //计算漏斗一 正餐评价裂变分享漏斗
    val funnel1 = List(
      SCNode("", "miaofu_payresult_page_load", "", "秒付结果页", "", "", 0, 0),
      SCNode("", "miaofu_comment_page_load_2", "", "发表评论页", "", "", 0, 0),
      SCNode("", "miaofu_comment_comment_redbag", "", "领取红包页", "", "", 0, 0),
      SCNode("", "miaofu_comment_redbag_share", "", "裂变分享页", "", "", 0, 0),
      SCNode("", "MMCFissionCouponDetail_redbag_share", "", "分享成功", "", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val res1Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[SCNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel1.size
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[SCNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel1(j)
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel1(j)
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[SCNode]()
        //对list中数据进行补0处理
        if(list.size > 0){
          val first = list(0)
          val userId = first.userId
          val contentId = first.contentId
          for(i <- 0 to funnel1.size - 1){
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel1(i)
              listBuf.append(SCNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time))
            } else {
              val funnelNode = funnel1(i)
              listBuf.append(SCNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0))
            }
          }
        }
        listBuf
      })
    println("res1 cnt: " + res1Rdd.count())
//    res1Rdd.collect().foreach(println)
    val res1DFTmp = res1Rdd.toDF()
    res1DFTmp.cache()
    res1DFTmp.show(100, false)
    res1DFTmp.registerTempTable("funnel1_res")
    val updateTime = System.currentTimeMillis()
    res1DF = sqlContext.sql(
      """
        |select
        |    '%s' day_id,
        |    csb.brand_id,
        |    csb.brand_name,
        |    fr.contentId shop_id,
        |    st.shop_name,
        |    (case when fr.nodeId = 'miaofu_payresult_page_load' then 1
        |    when fr.nodeId = 'miaofu_comment_page_load_2' then 2
        |    when fr.nodeId = 'miaofu_comment_comment_redbag' then 3
        |    when fr.nodeId = 'miaofu_comment_redbag_share' then 4
        |    when fr.nodeId = 'MMCFissionCouponDetail_redbag_share' then 5 end) page_id,
        |    fr.page page_name,
        |    sum(case when fr.etype = 1 then 0 else 1 end) page_uv,
        |    max('1') funnel_type,
        |    max('%s') update_time
        |from
        |    funnel1_res fr
        |left join
        |    shop_table st
        |on
        |    fr.contentId = st.shop_id
        |left join
        |    c_shop_brand csb
        |on
        |    st.manage_shop_id = csb.brand_id
        |group by
        |    '%s',
        |    csb.brand_id,
        |    csb.brand_name,
        |    fr.contentId,
        |    st.shop_name,
        |    (case when fr.nodeId = 'miaofu_payresult_page_load' then 1
        |    when fr.nodeId = 'miaofu_comment_page_load_2' then 2
        |    when fr.nodeId = 'miaofu_comment_comment_redbag' then 3
        |    when fr.nodeId = 'miaofu_comment_redbag_share' then 4
        |    when fr.nodeId = 'MMCFissionCouponDetail_redbag_share' then 5 end),
        |    fr.page
      """.stripMargin.format(targetDate, updateTime, targetDate))
    res1DF.show()

    //计算漏斗二 快餐评价裂变分享漏斗
    val funnel2 = List(
      SCNode("", "quickorder_order_detail_fast_fastfood_please_take_dining", "", "请取餐状态页", "", "", 0, 0),
      SCNode("", "miaofu_comment_page_load_3", "", "发表评论页", "", "", 0, 0),
      SCNode("", "miaofu_comment_comment_redbag", "", "领取红包页", "", "", 0, 0),
      SCNode("", "miaofu_comment_redbag_share", "", "裂变分享页", "", "", 0, 0),
      SCNode("", "MMCFissionCouponDetail_redbag_share", "", "分享成功", "", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val res2Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[SCNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel2.size //用到配置
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[SCNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel2(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel2(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[SCNode]()
        //对list中数据进行补0处理
        if(list.size > 0){
          val first = list(0)
          val userId = first.userId
          val contentId = first.contentId
          for(i <- 0 to funnel2.size - 1){ //用到配置
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel2(i) //用到配置
              listBuf.append(SCNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time))
            } else {
              val funnelNode = funnel2(i) //用到配置
              listBuf.append(SCNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0))
            }
          }
        }
        listBuf
      })
    println("res2 cnt: " + res2Rdd.count())
//    res2Rdd.collect().foreach(println)
    val res2DFTmp = res2Rdd.toDF()
    res2DFTmp.cache()
    res2DFTmp.show(100, false)
    res2DFTmp.registerTempTable("funnel2_res")
//    val updateTime = System.currentTimeMillis()
    res2DF = sqlContext.sql(
      """
        |select
        |    '%s' day_id,
        |    csb.brand_id,
        |    csb.brand_name,
        |    fr.contentId shop_id,
        |    st.shop_name,
        |    (case when fr.nodeId = 'quickorder_order_detail_fast_fastfood_please_take_dining' then 1
        |    when fr.nodeId = 'miaofu_comment_page_load_3' then 2
        |    when fr.nodeId = 'miaofu_comment_comment_redbag' then 3
        |    when fr.nodeId = 'miaofu_comment_redbag_share' then 4
        |    when fr.nodeId = 'MMCFissionCouponDetail_redbag_share' then 5 end) page_id,
        |    fr.page page_name,
        |    sum(case when fr.etype = 1 then 0 else 1 end) page_uv,
        |    max('2') funnel_type,
        |    max('%s') update_time
        |from
        |    funnel2_res fr
        |left join
        |    shop_table st
        |on
        |    fr.contentId = st.shop_id
        |left join
        |    c_shop_brand csb
        |on
        |    st.manage_shop_id = csb.brand_id
        |group by
        |    '%s',
        |    csb.brand_id,
        |    csb.brand_name,
        |    fr.contentId,
        |    st.shop_name,
        |    (case when fr.nodeId = 'quickorder_order_detail_fast_fastfood_please_take_dining' then 1
        |    when fr.nodeId = 'miaofu_comment_page_load_3' then 2
        |    when fr.nodeId = 'miaofu_comment_comment_redbag' then 3
        |    when fr.nodeId = 'miaofu_comment_redbag_share' then 4
        |    when fr.nodeId = 'MMCFissionCouponDetail_redbag_share' then 5 end),
        |    fr.page
      """.stripMargin.format(targetDate, updateTime, targetDate))
    res2DF.show()

    //计算漏斗三 快餐裂变分享漏斗（评价推送进入）
    val funnel3 = List(
      SCNode("", "miaofu_comment_page_load_4", "", "发表评论页", "", "", 0, 0),
      SCNode("", "miaofu_comment_comment_redbag", "", "领取红包页", "", "", 0, 0),
      SCNode("", "miaofu_comment_redbag_share", "", "裂变分享页", "", "", 0, 0),
      SCNode("", "MMCFissionCouponDetail_redbag_share", "", "分享成功", "", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val res3Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[SCNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel3.size //用到配置
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[SCNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel3(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel3(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[SCNode]()
        //对list中数据进行补0处理
        if(list.size > 0){
          val first = list(0)
          val userId = first.userId
          val contentId = first.contentId
          for(i <- 0 to funnel3.size - 1){ //用到配置
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel3(i) //用到配置
              listBuf.append(SCNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time))
            } else {
              val funnelNode = funnel3(i) //用到配置
              listBuf.append(SCNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0))
            }
          }
        }
        listBuf
      })
    println("res3 cnt: " + res3Rdd.count())
//    res3Rdd.collect().foreach(println)
    val res3DFTmp = res3Rdd.toDF()
    res3DFTmp.cache()
    res3DFTmp.show(100, false)
    res3DFTmp.registerTempTable("funnel3_res")
    //    val updateTime = System.currentTimeMillis()
    res3DF = sqlContext.sql(
      """
        |select
        |    '%s' day_id,
        |    csb.brand_id,
        |    csb.brand_name,
        |    fr.contentId shop_id,
        |    st.shop_name,
        |    (case
        |    when fr.nodeId = 'miaofu_comment_page_load_4' then 1
        |    when fr.nodeId = 'miaofu_comment_comment_redbag' then 2
        |    when fr.nodeId = 'miaofu_comment_redbag_share' then 3
        |    when fr.nodeId = 'MMCFissionCouponDetail_redbag_share' then 4 end) page_id,
        |    fr.page page_name,
        |    sum(case when fr.etype = 1 then 0 else 1 end) page_uv,
        |    max('3') funnel_type,
        |    max('%s') update_time
        |from
        |    funnel3_res fr
        |left join
        |    shop_table st
        |on
        |    fr.contentId = st.shop_id
        |left join
        |    c_shop_brand csb
        |on
        |    st.manage_shop_id = csb.brand_id
        |group by
        |    '%s',
        |    csb.brand_id,
        |    csb.brand_name,
        |    fr.contentId,
        |    st.shop_name,
        |    (case
        |    when fr.nodeId = 'miaofu_comment_page_load_4' then 1
        |    when fr.nodeId = 'miaofu_comment_comment_redbag' then 2
        |    when fr.nodeId = 'miaofu_comment_redbag_share' then 3
        |    when fr.nodeId = 'MMCFissionCouponDetail_redbag_share' then 4 end),
        |    fr.page
      """.stripMargin.format(targetDate, updateTime, targetDate))
    res3DF.show()

    //计算漏斗四 新用户领取红包漏斗
    val funnel4 = List(
      SCNode("", "MMCFissionCouponDetail_open_fission_newuser", "", "新用户打开裂变红包页", "", "", 0, 0),
      SCNode("", "MMCFissionCouponDetail_open_register", "", "新用户注册页", "", "", 0, 0),
      SCNode("", "MMCFissionCouponDetail_redpacket_newuser_success", "", "领取成功", "", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val res4Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        var userActs = new ListBuffer[SCNode]
        var userActsTmp = all._2.toList.sortBy(node => node.time)
        //去除重复日志
        var pastNode = SCNode("", "", "", "", "", "", 0, 0) //之前的节点
        for(i <- 0 to userActsTmp.length - 1){
          val currentNode = userActsTmp(i) //当前访问节点
          if(i > 0){
            if(currentNode.nodeId.equals(pastNode.nodeId)){
            }else{
              userActs.append(currentNode)
              pastNode = currentNode
            }
          }else{
            userActs.append(currentNode)
            pastNode = currentNode
          }
        }
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[SCNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel4.size //用到配置
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[SCNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel4(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel4(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[SCNode]()
        //对list中数据进行补0处理
        if(list.size > 0){
          val first = list(0)
          val userId = first.userId
          val contentId = first.contentId
          for(i <- 0 to funnel4.size - 1){ //用到配置
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel4(i) //用到配置
              listBuf.append(SCNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time))
            } else {
              val funnelNode = funnel4(i) //用到配置
              listBuf.append(SCNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0))
            }
          }
        }
        listBuf
      })
    println("res4 cnt: " + res4Rdd.count())
//    res4Rdd.collect().foreach(println)
    val res4DFTmp = res4Rdd.toDF()
    res4DFTmp.cache()
    res4DFTmp.show(100, false)
    res4DFTmp.registerTempTable("funnel4_res")
    //    val updateTime = System.currentTimeMillis()
    res4DF = sqlContext.sql(
      """
        |select
        |    '%s' day_id,
        |    csb.brand_id,
        |    csb.brand_name,
        |    pwst.shop_id shop_id,
        |    st.shop_name,
        |    (case
        |    when fr.nodeId = 'MMCFissionCouponDetail_open_fission_newuser' then 1
        |    when fr.nodeId = 'MMCFissionCouponDetail_open_register' then 2
        |    when fr.nodeId = 'MMCFissionCouponDetail_redpacket_newuser_success' then 3 end) page_id,
        |    fr.page page_name,
        |    sum(case when fr.etype = 1 then 0 else 1 end) page_uv,
        |    max('4') funnel_type,
        |    max('%s') update_time
        |from
        |    funnel4_res fr
        |left join
        |    plat_wx_shop_table pwst
        |on
        |    pwst.app_id = fr.contentId
        |left join
        |    shop_table st
        |on
        |    pwst.shop_id = st.shop_id
        |left join
        |    c_shop_brand csb
        |on
        |    st.manage_shop_id = csb.brand_id
        |group by
        |    '%s',
        |    csb.brand_id,
        |    csb.brand_name,
        |    pwst.shop_id,
        |    st.shop_name,
        |    (case
        |    when fr.nodeId = 'MMCFissionCouponDetail_open_fission_newuser' then 1
        |    when fr.nodeId = 'MMCFissionCouponDetail_open_register' then 2
        |    when fr.nodeId = 'MMCFissionCouponDetail_redpacket_newuser_success' then 3 end),
        |    fr.page
      """.stripMargin.format(targetDate, updateTime, targetDate))
    res4DF.cache()
    res4DF.show()

    //计算漏斗五 分享红包次数的计算有些特殊
    //计算"分享红包次数"
//    val redBagDF = sqlContext.sql(
//      """
//        |select
//        |    '%s' day_id,
//        |    csb.brand_id,
//        |    csb.brand_name,
//        |    pwst.shop_id shop_id,
//        |    st.shop_name,
//        |    '1' page_id,
//        |    '分享红包次数' page_name,
//        |    count(1) page_uv,
//        |    max('5') funnel_type,
//        |    max('%s') update_time
//        |from
//        |    (select
//        |        *
//        |    from
//        |        marked_log
//        |    where
//        |        nodeId = 'MMCFissionCouponDetail_invite_share'
//        |        or
//        |        nodeId = 'MMCFissionCouponDetail_beinvited_share'
//        |        ) ml
//        |left join
//        |    plat_wx_shop_table pwst
//        |on
//        |    pwst.app_id = ml.contentId
//        |left join
//        |    shop_table st
//        |on
//        |    pwst.shop_id = st.shop_id
//        |left join
//        |    c_shop_brand csb
//        |on
//        |    st.manage_shop_id = csb.brand_id
//        |group by
//        |    '%s',
//        |    csb.brand_id,
//        |    csb.brand_name,
//        |    pwst.shop_id,
//        |    st.shop_name,
//        |    '1',
//        |    '分享红包次数'
//      """.stripMargin.format(targetDate, updateTime, targetDate)).where("brand_id is not null")
//    val redBagDF = sqlContext.sql(
//      """
//        |select
//        |    ml.userId,
//        |    ml.nodeId,
//        |    '分享红包次数' page,
//        |    'MMCFissionCouponDetail_redbag_share' contentId,
//        |    ml.etype,
//        |    ml.time
//        |from
//        |    (select
//        |        *
//        |    from
//        |        marked_log
//        |    where
//        |        nodeId = 'MMCFissionCouponDetail_invite_share'
//        |        or
//        |        nodeId = 'MMCFissionCouponDetail_beinvited_share'
//        |        ) ml
//      """.stripMargin.format(targetDate, updateTime, targetDate))
//    redBagDF.show(100, false)

    val funnel5 = List(
      SCNode("", "MMCFissionCouponDetail_redbag_share", "", "分享红包次数", "", "", 0, 0),
      SCNode("", "MMCFissionCouponDetail_open_fission", "", "收到裂变红包页", "", "", 0, 0),
      SCNode("", "MMCFissionCouponDetail_redpacket_success", "", "领取成功", "", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val res5Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[SCNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel5.size //用到配置
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[SCNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel5(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel5(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[SCNode]()
        //对list中数据进行补0处理
        if(list.size > 0){
          val first = list(0)
          val userId = first.userId
          val contentId = first.contentId
          for(i <- 0 to funnel5.size - 1){ //用到配置
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel5(i) //用到配置
              listBuf.append(SCNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time))
            } else {
              val funnelNode = funnel5(i) //用到配置
              listBuf.append(SCNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0))
            }
          }
        }
        listBuf
      })
    println("res5 cnt: " + res5Rdd.count())
//    res5Rdd.collect().foreach(println)
    val res5DFTmp = res5Rdd.toDF()
    res5DFTmp.cache()
    res5DFTmp.show(100, false)
    res5DFTmp.registerTempTable("funnel5_res")
    //    val updateTime = System.currentTimeMillis()
    res5DF = sqlContext.sql(
      """
        |select
        |    '%s' day_id,
        |    csb.brand_id,
        |    csb.brand_name,
        |    pwst.shop_id shop_id,
        |    st.shop_name,
        |    (case
        |    when fr.nodeId = 'MMCFissionCouponDetail_redbag_share' then 1
        |    when fr.nodeId = 'MMCFissionCouponDetail_open_fission' then 2
        |    when fr.nodeId = 'MMCFissionCouponDetail_redpacket_success' then 3 end) page_id,
        |    fr.page page_name,
        |    sum(case when fr.etype = 1 then 0 else 1 end) page_uv,
        |    max('5') funnel_type,
        |    max('%s') update_time
        |from
        |    funnel5_res fr
        |left join
        |    plat_wx_shop_table pwst
        |on
        |    pwst.app_id = fr.contentId
        |left join
        |    shop_table st
        |on
        |    pwst.shop_id = st.shop_id
        |left join
        |    c_shop_brand csb
        |on
        |    st.manage_shop_id = csb.brand_id
        |group by
        |    '%s',
        |    csb.brand_id,
        |    csb.brand_name,
        |    pwst.shop_id,
        |    st.shop_name,
        |    (case
        |    when fr.nodeId = 'MMCFissionCouponDetail_redbag_share' then 1
        |    when fr.nodeId = 'MMCFissionCouponDetail_open_fission' then 2
        |    when fr.nodeId = 'MMCFissionCouponDetail_redpacket_success' then 3 end),
        |    fr.page
      """.stripMargin.format(targetDate, updateTime, targetDate)).where("brand_id is not null")
    res5DF.cache()
    res5DF.show()

    //计算漏斗六 暂不计算 因为储值还没有前后端分离

    //计算漏斗七，八，九时，先计算哪些门店是免费取号，哪些门店是付费取号
    //logDF online
    val tdFeeNDF =
    logDF
      .select("contentId", "services")
      .where("contentId is not null and services is not null")
      .rdd
      .map(row => {
        val shopId = row.get(0).toString
        val services = row.get(1).toString.replace("[", "").replace("]", "").split(",")
        if(services.contains("2")){
          shopId
        }else{
          ""
        }
      })
      .filter(shop => !shop.equals(""))
      .toDF("shop_id").distinct()
    tdFeeNDF.registerTempTable("shop_fee_needed")
    println("shop_fee_needed:")
    tdFeeNDF.show()

    //计算漏斗七 取号流程漏斗 特殊处理付费取号
    val funnel7 = List(
      SCNode("", "smart_cloud_shopdetail_page_load", "", "商户详情页", "", "", 0, 0),
      SCNode("", "webpay_pay_success", "", "取号支付页", "", "", 0, 0),
      SCNode("", "webapp_queue_detail_queue", "", "号单详情", "", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val res7Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[SCNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel7.size //用到配置
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[SCNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel7(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel7(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[SCNode]()
        //对list中数据进行补0处理
        if(list.size > 0){
          val first = list(0)
          val userId = first.userId
          val contentId = first.contentId
          for(i <- 0 to funnel7.size - 1){ //用到配置
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel7(i) //用到配置
              listBuf.append(SCNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, contentId, node.event, node.etype, node.time))
            } else {
              val funnelNode = funnel7(i) //用到配置
              listBuf.append(SCNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0))
            }
          }
        }
        listBuf
      })
    println("res7 cnt: " + res7Rdd.count())
//    res7Rdd.collect().foreach(println)
    val res7DFTmp = res7Rdd.toDF()
    res7DFTmp.cache()
    res7DFTmp.show(100, false)
    res7DFTmp.registerTempTable("funnel7_res")
    //    val updateTime = System.currentTimeMillis()
    res7DF = sqlContext.sql(
      """
        |select
        |	t1.day_id,
        |	t1.brand_id,
        |	t1.brand_name,
        |	t1.shop_id,
        |	t1.shop_name,
        |	t1.page_id,
        |	t1.page_name,
        |	t1.page_uv,
        |	t1.funnel_type,
        |	t1.update_time
        |from
        |	(select
        |	    '%s' day_id,
        |	    csb.brand_id,
        |	    csb.brand_name,
        |	    st.shop_id shop_id,
        |	    st.shop_name,
        |	    (case
        |	    when fr.nodeId = 'smart_cloud_shopdetail_page_load' then 1
        |	    when fr.nodeId = 'webpay_pay_success' then 2
        |	    when fr.nodeId = 'webapp_queue_detail_queue' then 3 end) page_id,
        |	    fr.page page_name,
        |	    sum(case when fr.etype = 1 then 0 else 1 end) page_uv,
        |	    max('7') funnel_type,
        |	    max('%s') update_time
        |	from
        |	    funnel7_res fr
        |	left join
        |	    shop_table st
        |	on
        |	    fr.contentId = st.shop_id
        |	left join
        |	    c_shop_brand csb
        |	on
        |	    st.manage_shop_id = csb.brand_id
        |	group by
        |	    '%s',
        |	    csb.brand_id,
        |	    csb.brand_name,
        |	    st.shop_id,
        |	    st.shop_name,
        |	    (case
        |	    when fr.nodeId = 'smart_cloud_shopdetail_page_load' then 1
        |	    when fr.nodeId = 'webpay_pay_success' then 2
        |	    when fr.nodeId = 'webapp_queue_detail_queue' then 3 end),
        |	    fr.page) t1
        |inner join
        |	shop_fee_needed sfn
        |on
        |	t1.shop_id = sfn.shop_id
      """.stripMargin.format(targetDate, updateTime, targetDate))
    res7DF.cache()
    res7DF.show()

    //计算漏斗八 取号流程漏斗(无取号费)
    val funnel8 = List(
      SCNode("", "smart_cloud_shopdetail_page_load", "", "商户详情页", "", "", 0, 0),
      SCNode("", "webapp_queue_detail_queue", "", "号单详情", "", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val res8Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[SCNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel8.size //用到配置
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[SCNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel8(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel8(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[SCNode]()
        //对list中数据进行补0处理
        if(list.size > 0){
          val first = list(0)
          val userId = first.userId
          val contentId = first.contentId
          for(i <- 0 to funnel8.size - 1){ //用到配置
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel8(i) //用到配置
              listBuf.append(SCNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time))
            } else {
              val funnelNode = funnel8(i) //用到配置
              listBuf.append(SCNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0))
            }
          }
        }
        listBuf
      })
    println("res8 cnt: " + res8Rdd.count())
//    res8Rdd.collect().foreach(println)
    val res8DFTmp = res8Rdd.toDF()
    res8DFTmp.cache()
    res8DFTmp.show(100, false)
    res8DFTmp.registerTempTable("funnel8_res")
    //    val updateTime = System.currentTimeMillis()
    res8DF = sqlContext.sql(
      """
        |select
        |    '%s' day_id,
        |    csb.brand_id,
        |    csb.brand_name,
        |    st.shop_id shop_id,
        |    st.shop_name,
        |    (case
        |    when fr.nodeId = 'smart_cloud_shopdetail_page_load' then 1
        |    when fr.nodeId = 'webapp_queue_detail_queue' then 2 end) page_id,
        |    fr.page page_name,
        |    sum(case when fr.etype = 1 then 0 else 1 end) page_uv,
        |    max('8') funnel_type,
        |    max('%s') update_time
        |from
        |    funnel8_res fr
        |left join
        |    shop_table st
        |on
        |    fr.contentId = st.shop_id
        |left join
        |    c_shop_brand csb
        |on
        |    st.manage_shop_id = csb.brand_id
        |group by
        |    '%s',
        |    csb.brand_id,
        |    csb.brand_name,
        |    st.shop_id,
        |    st.shop_name,
        |    (case
        |    when fr.nodeId = 'smart_cloud_shopdetail_page_load' then 1
        |    when fr.nodeId = 'webapp_queue_detail_queue' then 2 end),
        |    fr.page
      """.stripMargin.format(targetDate, updateTime, targetDate)).except(res7DF)
    res8DF.cache()
    res8DF.show()

    //计算漏斗九 预约漏斗 TODO
    val tdReserveDF =
      logDF
        .select("contentId", "services")
        .where("contentId is not null and services is not null")
        .rdd
        .map(row => {
          val shopId = row.get(0).toString
          val services = row.get(1).toString.replace("[", "").replace("]", "").split(",")
          if(services.contains("6")){
            shopId
          }else{
            ""
          }
        })
        .filter(shop => !shop.equals(""))
        .toDF("shop_id").distinct()
    tdReserveDF.registerTempTable("shop_reserve")
    println("shop_reserve:")
    tdReserveDF.show()
    val funnel9 = List(
      SCNode("", "smart_cloud_shopdetail_page_load", "", "商户详情页", "", "", 0, 0),
      SCNode("", "reservation_order_reservation", "", "在线预约页", "", "", 0, 0),
      SCNode("", "reservation_order_detail_reservation", "", "预约单详情", "", "", 0, 0)
    )
    //将访问路径切割 并进行漏斗匹配
    val res9Rdd = groupedLog
      .flatMap(all => {
        val userId = all._1
        val userActs = all._2.toList.sortBy(node => node.time)
        //用来保存该用户匹配到的所有路径
        val list = new ListBuffer[List[SCNode]]()
        var i = 0
        val len = userActs.size
        val funnelLen = funnel9.size //用到配置
        import scala.util.control.Breaks._
        while(i < len){
          //用来保存匹配到的访问路径
          val path = new ListBuffer[SCNode]()
          //匹配
          if(len - i > funnelLen){
            breakable{
              for(j <- 0 to (funnelLen - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel9(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }else{ //剩余的不够一个漏斗长度
            breakable{
              for(j <- 0 to (len - i - 1)){
                val cNode = userActs(i + j)
                val fNode = funnel9(j) //用到配置
                if(j == 0 && cNode.nodeId.equals(fNode.nodeId)){
                  path.append(cNode)
                }else if(j == 1 && cNode.nodeId.equals("back")){
                  break()
                }else if(j == 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }else if(j > 1 && cNode.nodeId.equals(fNode.nodeId) && path.size == j){
                  path.append(cNode)
                }
              }
            }
          }
          //向后继续匹配
          if(path.size < 1){
            i = i + 1
          }else{
            list.append(path.toList)
            i = i + path.size
          }
        }
        list
      })
      .flatMap(list => {
        val listBuf = new ListBuffer[SCNode]()
        //对list中数据进行补0处理
        if(list.size > 0){
          val first = list(0)
          val userId = first.userId
          val contentId = first.contentId
          for(i <- 0 to funnel9.size - 1){ //用到配置
            if(i <= list.size - 1){
              val node = list(i)
              val funnelNode = funnel9(i) //用到配置
              listBuf.append(SCNode(node.userId, node.nodeId, funnelNode.pageId, funnelNode.page, node.contentId, node.event, node.etype, node.time))
            } else {
              val funnelNode = funnel9(i) //用到配置
              listBuf.append(SCNode(userId, funnelNode.nodeId, funnelNode.pageId, funnelNode.page, contentId, funnelNode.event, 1, 0))
            }
          }
        }
        listBuf
      })
    println("res9 cnt: " + res9Rdd.count())
//    res9Rdd.collect().foreach(println)
    val res9DFTmp = res9Rdd.toDF()
    res9DFTmp.cache()
    res9DFTmp.show(100, false)
    res9DFTmp.registerTempTable("funnel9_res")
    //    val updateTime = System.currentTimeMillis()
    res9DF = sqlContext.sql(
      """
        |select
        |    t1.day_id,
        |    t1.brand_id,
        |    t1.brand_name,
        |    t1.shop_id,
        |    t1.shop_name,
        |    t1.page_id,
        |    t1.page_name,
        |    t1.page_uv,
        |    t1.funnel_type,
        |    t1.update_time
        |from
        |    (select
        |        '%s' day_id,
        |        csb.brand_id,
        |        csb.brand_name,
        |        st.shop_id shop_id,
        |        st.shop_name,
        |        (case
        |        when fr.nodeId = 'smart_cloud_shopdetail_page_load' then 1
        |        when fr.nodeId = 'reservation_order_reservation' then 2
        |        when fr.nodeId = 'reservation_order_detail_reservation' then 3 end) page_id,
        |        fr.page page_name,
        |        sum(case when fr.etype = 1 then 0 else 1 end) page_uv,
        |        max('9') funnel_type,
        |        max('%s') update_time
        |    from
        |        funnel9_res fr
        |    left join
        |        shop_table st
        |    on
        |        fr.contentId = st.shop_id
        |    left join
        |        c_shop_brand csb
        |    on
        |        st.manage_shop_id = csb.brand_id
        |    group by
        |        '%s',
        |        csb.brand_id,
        |        csb.brand_name,
        |        st.shop_id,
        |        st.shop_name,
        |        (case
        |        when fr.nodeId = 'smart_cloud_shopdetail_page_load' then 1
        |        when fr.nodeId = 'reservation_order_reservation' then 2
        |        when fr.nodeId = 'reservation_order_detail_reservation' then 3 end),
        |        fr.page) t1
        |inner join
        |    shop_reserve sr
        |on
        |    t1.shop_id = sr.shop_id
      """.stripMargin.format(targetDate, updateTime, targetDate))
    res9DF.cache()
    res9DF.show()

  }
}

