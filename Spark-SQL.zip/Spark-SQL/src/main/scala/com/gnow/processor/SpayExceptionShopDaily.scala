package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.{DB, Processor, Utility}
import org.apache.spark.sql.DataFrame

class SpayExceptionShopDaily extends Processor {
  val OUTPUT_TABLE = "SPAY_EXCEPTION_SHOP_DAILY"
  private val SPAY_EXCEPTION_SHOP = "SPAY_EXCEPTION_SHOP"
  private val SPAY_EXCEPTION_SHOP_OUT = "SPAY_EXCEPTION_SHOP_OUT"
  private var targetDateDF: DataFrame = null
  private var targetDateOutDF: DataFrame = null

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from SPAY_EXCEPTION_SHOP_DAILY
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
    RDBWriter.overwrite(targetDateOutDF, DB.ORACLE_37_BWSWD, OUTPUT_TABLE)
  }

  def process(targetDate: String, input: String, output: String) = {
//    targetDateDF = repository.kafka.df(repository.kafka.ORDERING_MOBILE_API_DCB_ONLINE,targetDate)
    val targetDateDF = sqlContext.read.json("/repository/kafka/catonline_mobile-api_dcb-online/%s".format(targetDate))
    targetDateDF.createOrReplaceTempView(SPAY_EXCEPTION_SHOP)

    targetDateOutDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |shopId,
        |count(shopId) excount
        |FROM %s t1
        |where currentState='2'
        |and  hour(currentTime)>10
        |and  hour(currentTime)<22
        |group by shopId
        |having count(shopId)>300
      """.stripMargin.format(
        SPAY_EXCEPTION_SHOP
      ), SPAY_EXCEPTION_SHOP_OUT)    // SPAY_EXCEPTION_SHOP
  }
}
