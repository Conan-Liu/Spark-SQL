package com.gnow.processor

import com.gnow.config.SaveMode
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import com.gnow.{DB, Processor}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext

class QueueingWaitingTimeEvaluationAllDaily extends Processor {
  val QUEUEING_WAITING_TIME = "queueing_waiting_time"
  val QUEUEING_WAITING_TIME_EXT = "queueing_waiting_time_ext"
  val QUEUEING_SHOP = "QUEUEING_SHOP"
  val QUEUE_WAIT_TIME_ACCURACY = "queue_wait_time_accuracy"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from queue_wait_time_accuracy
        |where day_id='%s' and first_or_all='0'
      """.stripMargin
    logger.info(sql.format(targetDate))
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    rdb.queueing.df(rdb.queueing.QUEUEING_TABLE,targetDate)
    rdb.oracle.df(rdb.oracle.ORACLE_QUEUEING_GOOD_SHOP)
    rdb.basic.df(rdb.basic.SHOP_CONFIG_TABLE)
    val schema = "shop_id,queue_id,serial_id,estimated_time,create_time"
    repository.kafka.df(repository.kafka.QUEUEING_WAITING_TIME,targetDate,schema)

    val QUEUEING_WAITING_TIME_EXT_SQL =
      """
        |select
        |t1.shop_id,
        |t1.queue_id,
        |t1.serial_id,
        |t2.estimated_time,
        |ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - t2.create_time/1000) actual_waiting_time,
        |(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - t2.create_time/1000)) delta_time,
        |pow(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - t2.create_time/1000),2) delta_time2
        |from %s t1 join %s t2 on (
        |    t1.serial_id = t2.serial_id
        |    and t1.shop_id = t2.shop_id
        |) join %s t3 on (
        |    t1.shop_id = t3.shop_id
        |) join %s t4 on (
        |    t1.shop_id = t4.shop_id
        |    and t4.estimate_enable = 1
        |)
        |where t2.create_time < (unix_timestamp('%s', 'yyyy-MM-dd') + 86400) * 1000
        |and t1.shop_id in ('24357','97352','112832','111546')
        |and t1.state!='10'
        |group by
        |t1.shop_id,
        |t1.queue_id,
        |t1.serial_id,
        |t2.estimated_time,
        |ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - t2.create_time/1000),
        |(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - t2.create_time/1000)),
        |pow(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - t2.create_time/1000),2)
      """.stripMargin
    val queueingWaitingTimeExtDF = sqlContext.sql(QUEUEING_WAITING_TIME_EXT_SQL.format(
      rdb.queueing.QUEUEING_TABLE,
      repository.kafka.QUEUEING_WAITING_TIME,
      rdb.oracle.ORACLE_QUEUEING_GOOD_SHOP,
      rdb.basic.SHOP_CONFIG_TABLE,
      targetDate))

    queueingWaitingTimeExtDF.registerTempTable(QUEUEING_WAITING_TIME_EXT)
    queueingWaitingTimeExtDF.show()

    val result = sqlContext.sql(
      """
        |select
        |'%s' day_id,
        |shop_id,
        |queue_id,
        |/*count(distinct serial_id) queue_count, */
        |/*count(1) sample_count, */
        |abs(corr(estimated_time,actual_waiting_time)) correlation,
        |max(delta_time) error_max,
        |min(delta_time) error_min,
        |avg(delta_time) error_avg,
        |avg(delta_time2) mse,
        |0 first_or_all,
        |sqrt(avg(delta_time2)) rmse,
        |count(1) data_qty
        |from queueing_waiting_time_ext
        |group by
        |shop_id,
        |queue_id
        |
      """.stripMargin.format(targetDate)).cache()
    result.show()

    RDBWriter.save(result, DB.ORACLE_37_BWSWD, QUEUE_WAIT_TIME_ACCURACY, SaveMode.APPEND)
  }
}
