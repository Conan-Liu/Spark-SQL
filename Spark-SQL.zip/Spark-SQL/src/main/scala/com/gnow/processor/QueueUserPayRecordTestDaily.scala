package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.{SQLUserPayRecordTest, SQLUserOrder}
import com.gnow.{DB, Processor, Utility}
import org.apache.spark.sql.DataFrame

class QueueUserPayRecordTestDaily extends Processor {
  val QUEUE_USER_PAY_RECORD = "queue_user_pay_record"
  var df: DataFrame = null
  var shopAndBaseDateDF: DataFrame = null

  val OUTPUT_TABLE = "queue_user_pay_record"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from flash_quit
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    //reset(targetDate)
    process(targetDate, input: String, output: String)
    RDBWriter.save(shopAndBaseDateDF, DB.ORACLE_37_BWSWD, OUTPUT_TABLE)
  }

  def process(targetDate: String, input: String, output: String) = {
    df = rdb.queueing.df(rdb.queueing.QUEUE_USER_PAY_RECORD)

    shopAndBaseDateDF = Utility.registerTableWithSQL(sqlContext,
      SQLUserPayRecordTest.SQL.format(
        rdb.queueing.QUEUE_USER_PAY_RECORD
      ), QUEUE_USER_PAY_RECORD)
  }
}
