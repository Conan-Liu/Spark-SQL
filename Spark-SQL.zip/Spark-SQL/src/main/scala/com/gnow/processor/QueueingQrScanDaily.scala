package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import com.gnow.sql.{SQLFlashQuit, SQLQueueingQrScan}
import com.gnow.{DB, Processor, Utility}
import org.apache.spark.sql.DataFrame

class QueueingQrScanDaily extends Processor {
  val QUEUEING_QR_SCAN = "queueing_qr_scan"
  var warnWarningsDF: DataFrame = null
  var shopAndBaseDateDF: DataFrame = null

  val QR_SCAN = "qr_scan"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from queueing_qr_scan
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
    RDBWriter.save(shopAndBaseDateDF, DB.ORACLE_37_BWSWD, QR_SCAN)
  }

  def process(targetDate: String, input: String, output: String) = {
    warnWarningsDF = repository.kafka.df(repository.kafka.QUEUEING_QR_SCAN,targetDate)
    shopAndBaseDateDF = Utility.registerTableWithSQL(sqlContext,
      SQLQueueingQrScan.SQL.format(
        targetDate,
        QUEUEING_QR_SCAN
      ), QUEUEING_QR_SCAN)
  }
}
