package com.gnow.processor

import com.gnow.config.SaveMode
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import com.gnow.{DB, Processor}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.DataFrame
//import org.apache.spark.rdd.RDD[String]
import com.gnow.Mail

class QueueingWaitingTimeDailyUnassociationGoodShop extends Processor {

  val QUEUEING_WAITING_DAY_ALL = "queueing_waiting_day_all"
  val QUEUEING_WAITING_TIME_COMPACT = "queueing_waiting_time_compact"
  val QUEUEING_WAITING_TIME_EXT = "queueing_waiting_time_ext"
  val QUEUEING_WAITING_SHOP = "queueing_waiting_shop"
  val QUEUEING_WAITING_OVERLIMIT = "queueing_waiting_overlimit"
  //val TABLE = "table_one"
  //val TABLE_TWO = "table_two"
  
  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from queueing_waiting_day_all
		|where create_date='%s'
      """.stripMargin
    logger.info(sql.format(targetDate))      
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
	
	val sqlLimit =
      """
        |delete
        |from queueing_waiting_overlimit
		|where create_date='%s'
      """.stripMargin
    logger.info(sqlLimit.format(targetDate))      
    DBEraser.remove(DB.ORACLE_37_BWSWD, sqlLimit.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    rdb.queueing.df(rdb.queueing.QUEUEING_TABLE,targetDate)
    rdb.basic.df(rdb.basic.SHOP_CONFIG_TABLE)
    val schema = "shop_id,serial_id,estimated_time,create_time"
    repository.kafka.df(repository.kafka.QUEUEING_WAITING_TIME,targetDate,schema)
	rdb.basic.df(rdb.basic.SHOP_TABLE)

    val QUEUEING_WAITING_TIME_EXT_SQL =
      """
        |select
        |t1.shop_id,
        |t1.serial_id,
        |t2.estimated_time,
        |from_unixtime(t2.create_time/1000, 'yyyy-MM-dd') create_date,
        |abs(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - unix_timestamp(regexp_replace(t1.create_date, 'T', ' ')))) abs_delta_time,
        |min(t2.create_time) create_time
        |from %s t1 join %s t2 on (
        |    t1.serial_id = t2.serial_id
        |    and t1.shop_id = t2.shop_id
        |) join %s t3 on (
        |    t1.shop_id = t3.shop_id
        |    and t3.estimate_enable = 1 /*estimate_enable = 号单  and t3.open_qwait = 1*/
        |)
        |where t2.create_time < (unix_timestamp('%s', 'yyyy-MM-dd') + 86400) * 1000
        |group by
        |t1.shop_id,
        |t1.serial_id,
        |t2.estimated_time,
        |from_unixtime(t2.create_time/1000, 'yyyy-MM-dd'),
        |abs(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - unix_timestamp(regexp_replace(t1.create_date, 'T', ' '))))
      """.stripMargin
    val queueingWaitingTimeExtDF = sqlContext.sql(QUEUEING_WAITING_TIME_EXT_SQL.format(
      rdb.queueing.QUEUEING_TABLE,
      repository.kafka.QUEUEING_WAITING_TIME,
      rdb.basic.SHOP_CONFIG_TABLE,
      targetDate))
      logger.info(QUEUEING_WAITING_TIME_EXT_SQL.format(
        rdb.queueing.QUEUEING_TABLE,
        repository.kafka.QUEUEING_WAITING_TIME,
        rdb.basic.SHOP_CONFIG_TABLE,
        targetDate))
      queueingWaitingTimeExtDF.registerTempTable(QUEUEING_WAITING_TIME_EXT)


    val QUEUEING_WAITING_TIME_SQL =
      """
        |select
        |t2.create_date,
        |t2.QUALIFIED_SHOP_ID_COUNT_D,
        |t2.QUALIFIED_SERIAL_ID_COUNT_D,
        |t2.SERIAL_ID_COUNT_D,
        |t2.QUALIFIED_SHOP_COUNT,
        |t2.QUALIFIED_SERIAL_COUNT
        |from (
        |    select
        |    '%s' create_date,
        |    count(
        |        distinct
        |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and create_date = '%s')
        |        then t1.shop_id
        |        else null
        |        end
        |    ) QUALIFIED_SHOP_ID_COUNT_D,
        |    count(
        |        distinct
        |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time <= 900 and create_date = '%s')
        |        then t1.serial_id
        |        else null
        |        end
        |    ) QUALIFIED_SERIAL_ID_COUNT_D,
        |    count(
        |        distinct
        |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and create_date = '%s')
        |        then t1.serial_id
        |        else null
        |        end
        |    ) SERIAL_ID_COUNT_D,
        |    count(
        |        distinct
        |        case when (create_date = '%s')
        |        then t1.shop_id
        |        else null
        |        end
        |    ) QUALIFIED_SHOP_COUNT,
        |    count(
        |        distinct
        |        case when (create_date = '%s')
        |        then t1.serial_id
        |        else null
        |        end
        |    ) QUALIFIED_SERIAL_COUNT
        |    from %s t1
        |    group by
        |    '%s'
        |) t2  
      """.stripMargin
    val result = sqlContext.sql(QUEUEING_WAITING_TIME_SQL.format(
      targetDate,
      targetDate,
      targetDate,
      targetDate,
      targetDate,
      targetDate,
      QUEUEING_WAITING_TIME_EXT,
      targetDate))
    logger.info(QUEUEING_WAITING_TIME_SQL.format(
      targetDate,
      targetDate,
      targetDate,
      targetDate,
      targetDate,
      targetDate,
      QUEUEING_WAITING_TIME_EXT,
      targetDate))
    RDBWriter.save(result, DB.ORACLE_37_BWSWD, QUEUEING_WAITING_DAY_ALL, SaveMode.APPEND)
	
	val QUEUEING_WAITING_TIME_SHOP =
      """
        |select
		|t2.shop_id,
		|t3.shop_name,
        |t2.create_date,
		|t2.shop_id_accurate_count,
		|t2.shop_id_all_count,
		|t2.shop_time_sum    shop_time_all,
		|t2.shop_time_sum_count
        |from (
        |    select
		|    t1.shop_id   shop_id,
        |    '%s' create_date,
        |    count(
        |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time <= 900 and create_date = '%s')
        |        then t1.shop_id  
        |        else null
        |        end
        |    ) shop_id_accurate_count,
        |    count(t1.shop_id)  shop_id_all_count,
        |    sum(
        |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time >= 900 and create_date = '%s')
        |        then t1.abs_delta_time 
        |        else null
        |        end
        |    ) shop_time_sum,
		|    count(
        |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time >= 900 and create_date = '%s')
        |        then t1.shop_id
        |        else null
        |        end
        |    ) shop_time_sum_count
        |    from %s t1 
        |    group by
        |    '%s',t1.shop_id
        |) t2  join  %s t3  on (
		|t2.shop_id = t3.shop_id )
		|group by t2.shop_id,t3.shop_name,t2.create_date,
		|t2.shop_id_accurate_count,
		|t2.shop_id_all_count,
		|t2.shop_time_sum,
		|t2.shop_time_sum_count
		
      """.stripMargin
    val resultShop = sqlContext.sql(QUEUEING_WAITING_TIME_SHOP.format(
      targetDate,
      targetDate,
      targetDate,
      targetDate,
      QUEUEING_WAITING_TIME_EXT,
      targetDate,
	  rdb.basic.SHOP_TABLE))
	  
	 // RDBWriter.save(resultShop, DB.ORACLE_37_BWSWD, TABLE_TWO, SaveMode.APPEND)
	  
	resultShop.registerTempTable(QUEUEING_WAITING_SHOP)
	
	val QUEUEING_WAITING_SHOP_RATE = 
	  """
	  |select 
	  |distinct t1.shop_id,
	  |t1.shop_name,
	  |round(t1.shop_id_accurate_count/t1.shop_id_all_count,2)  time_rate,
	  |round(t1.shop_time_all/t1.shop_time_sum_count,2)    aver_value,
	  |t1.create_date,
	  |t1.shop_id_accurate_count,
	  |t1.shop_id_all_count,
	  |t1.shop_time_all,
	  |t1.shop_time_sum_count
	  |from %s t1  
	  |where round(t1.shop_id_accurate_count/t1.shop_id_all_count,2) < 0.5
	  |group by t1.shop_id,t1.shop_name,
	  |round(t1.shop_id_accurate_count/t1.shop_id_all_count,2),
	  |round(t1.shop_time_all/t1.shop_time_sum_count,2),t1.create_date,t1.shop_id_accurate_count,t1.shop_id_all_count,t1.shop_time_all,t1.shop_time_sum_count
	  """.stripMargin
	
	val shopRate = sqlContext.sql(QUEUEING_WAITING_SHOP_RATE.format(QUEUEING_WAITING_SHOP))
	//.toJSON.collect().toList
	//Mail.send("Shops listing:",shopRate.toString)
	RDBWriter.save(shopRate, DB.ORACLE_37_BWSWD, QUEUEING_WAITING_OVERLIMIT, SaveMode.APPEND)

  }
}



