package com.gnow.processor

import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.sql.{SQLUserAccess, SQLUserRetention}
import com.gnow.{DB, Processor, Utility}

class UserAccessDaily extends Processor {
  val USER_ACCESS = "user_access"

  def reset(targetDate: String): Unit = {

  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLUserAccess.getSQL4APPManyMonthly(targetDate)
    val df = repository.kafka.df(repository.kafka.BASIC_APP_TRACE)
    val res = Utility.sql(df, sql)
    RDBWriter.overwrite(res, DB.MYSQL_231_SPARK, USER_ACCESS)
  }

}
