package com.gnow.processor.vo

/**
  * 用来存放测试数据 一条log
  *
  * @param mwAuthToken
  * @param url
  * @param page
  * @param contentId
  * @param etype
  * @param event
  * @param time
  */
case class AppLog(device_id: String, url: String, page: String, content_id: String, etype: String, event: String, time: String, city_id: Long, area: String)
