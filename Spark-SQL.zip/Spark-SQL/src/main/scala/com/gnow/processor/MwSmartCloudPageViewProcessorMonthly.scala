package com.gnow.processor

import com.gnow.config.PathUtil
import com.gnow.eraser.DBEraser
import com.gnow.persistence.{RDBReader, RDBWriter}
import com.gnow.processor.vo.SCNode
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}

/**
  * Created by tal on 18/12/2017.
  */
class MwSmartCloudPageViewProcessorMonthly extends Processor {
  var res: DataFrame = _
  val db = DB.ORACLE_37_BWSWD
  val destTable = "DM_MONITOR_SC_PVUV_M"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where month_id = '%s'".format(destTable, targetDate.substring(0,7))
    println("操作数据库：" + db.toString)
    println("执行SQL：" + sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res.coalesce(1), db, destTable)
    println("Happy Ending!")

  }

  def process(targetDate: String, input: String, output: String) = {
    val monthly = PathUtil.getPath4Monthly(targetDate)

    //读取日志数据
    val schema = StructType(
      List(
        StructField("business", StringType, true),
        StructField("module", StringType, true),
        StructField("action", StringType, true),
        StructField("mwAuthToken", StringType, true),
        StructField("app_version", StringType, true),
        StructField("device_type", StringType, true),
        StructField("device_info", StringType, true),
        StructField("city_id", StringType, true),
        StructField("mobile", StringType, true),
        StructField("location", StringType, true),
        StructField("event", StringType, true),
        StructField("update_time", DoubleType, true)
      )
    )
    val appOperationLogDF = sqlContext.read.schema(schema).json("/repository/kafka/user_action_app_operation/{{date}}/*".replace("{date}", monthly))
    appOperationLogDF.printSchema()
    appOperationLogDF.registerTempTable("app_operation_log")

    val wechatOperationLogDF = sqlContext.read.schema(schema).json("/repository/kafka/user_action_wechat_operation/{{date}}/*".replace("{date}", monthly))
    wechatOperationLogDF.printSchema()
    wechatOperationLogDF.registerTempTable("wechat_operation_log")

    val operationLogDF = wechatOperationLogDF.distinct()
    operationLogDF.registerTempTable("operation_log")

    //获取需要的字段
    val logDF = sqlContext.sql(
      """
        |select
        | business
        | ,t1.module
        | ,t1.action
        | ,t1.app_version
        | ,t1.device_type
        | ,t1.device_info
        | ,t1.city_id
        | ,t1.mobile
        | ,t1.mwAuthToken
        | ,t1.location
        | ,get_json_object(t1.event, '$.page') page
        | ,get_json_object(t1.event, '$.area') area
        | ,get_json_object(t1.event, '$.url') url
        | ,get_json_object(t1.event, '$.keyword') keyword
        | ,get_json_object(t1.event, '$.content_id') contentId
        | ,get_json_object(t1.event, '$.etype') etype
        | ,get_json_object(t1.event, '$.event') event
        | ,get_json_object(t1.event, '$.order_type') order_type
        | ,get_json_object(t1.event, '$.order_no') order_no
        | ,get_json_object(t1.event, '$.waiting_table') waiting_table
        | ,get_json_object(t1.event, '$.estimated_waiting_time') estimated_waiting_time
        | ,substr(cast(cast(t1.update_time as long) as string), 0, 10) time
        | ,from_unixtime(substr(cast(cast(t1.update_time as long) as string), 0, 10))
        |from
        | operation_log t1
        |order by
        | t1.device_info
        | ,time
      """.stripMargin)


    import sqlContext.implicits._

    //debug start
//    //测试数据
//    val tdDF = sqlContext.sparkContext.parallelize(Seq(
//      SCLog("1","","smart_cloud_shopdetail","","","click_shop_image","1510024871")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","page_load","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","click_shop_image","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","click_shop_address","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","click_call","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","get_queue","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","get_queue_number","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","reserve","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","reserve_more","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","reserve_by_time","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","takout","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","quick_order","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","scan","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","recommend_more","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","recommend_image","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","comment_more","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","comment_tag_all","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","comment_tag_good","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","comment_tag_normal","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","comment_tag_other","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","click_comment_image","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","click_comment_other","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","info_more","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","feedback","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","nav_index","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","nav_quickorder","123")
//      ,SCLog("slajdfl","","smart_cloud_shopdetail","","","nav_member","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","load_page","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","overview_avg","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","tags_total","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","tags_good","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","tags_normal","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","tags_other","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","overview_pic","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","open_nav","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","nav_index","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","nav_quickorder","123")
//      ,SCLog("slajdfl","","MMCShopEvaluation","","","nav_member","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","load_page_invite","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","load_page_redpacket","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","invite_share","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","qr_close","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","redpacket_open","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","activity_rule","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","beinvited_share","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","btn_code","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","btn_receive_reward","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","top_rule","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","show_invite_qr","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","tab_reward","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","view_privileges","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","open_fission","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","open_register","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","open_fission_newuser","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","redpacket_newuser_success","123")
//      ,SCLog("slajdfl","","MMCFissionCouponDetail","","","redpacket_success","123")
//      ,SCLog("slajdfl","","miaofu_payresult","","","comment_service_cloud","123")
//      ,SCLog("slajdfl","","miaofu_payresult","","","page_load","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","redbag_loaded","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","page_load_1","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","page_load_2","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","page_load_3","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","page_load_4","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","close_redbag","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","redbag_detail","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","redbag_share","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","comment_redbag","123")
//      ,SCLog("slajdfl","","miaofu_comment","","","comment_normal","123")
//        )).toDF()
//    tdDF.show(100, false)
    //debug end

    //访问节点标注
    val markedLogDF =
//      tdDF //debug
      logDF //online
        .where("keyword is null")
        .select("mwAuthToken", "url", "page", "contentId", "etype", "event", "time").rdd
        .map(row =>{
          var userId = ""
          if(row.get(0) != null){
            userId = row.get(0).toString
          }
          var url = ""
          if(row.get(1) != null){
            url = row.get(1).toString
          }
          var page = ""
          if(row.get(2) != null){
            page = row.get(2).toString
          }
          var area = ""
          if(row.get(3) != null){
            area = row.get(3).toString
          }
          var etype = ""
          if(row.get(4) != null){
            etype = row.get(4).toString
          }
          var event = ""
          if(row.get(5) != null){
            event = row.get(5).toString
          }
          var time = "0"
          if(row.get(6) != null){
            time = row.get(6).toString
            if(time.equals("")){
              time = "0"
            }
          }
          if(userId.equals("")){
            userId = time
          }
          //标注
          (page, event) match {
            case  ("smart_cloud_shopdetail","page_load") => SCNode(userId, "smart_cloud_shopdetail_page_load","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"智慧餐厅商户详情页-页面加载",0, time.toLong)
            case  ("smart_cloud_shopdetail","click_shop_image") => SCNode(userId, "smart_cloud_shopdetail_click_shop_image","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"查看餐厅照片",0, time.toLong)
            case  ("smart_cloud_shopdetail","click_shop_address") => SCNode(userId, "smart_cloud_shopdetail_click_shop_address","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"查看餐厅地址",0, time.toLong)
            case  ("smart_cloud_shopdetail","click_call") => SCNode(userId, "smart_cloud_shopdetail_click_call","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"拨打电话",0, time.toLong)
            case  ("smart_cloud_shopdetail","get_queue") => SCNode(userId, "smart_cloud_shopdetail_get_queue","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"立即取号",0, time.toLong)
            case  ("smart_cloud_shopdetail","get_queue_number") => SCNode(userId, "smart_cloud_shopdetail_get_queue_number","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"选择就餐人数",0, time.toLong)
            case  ("smart_cloud_shopdetail","reserve") => SCNode(userId, "smart_cloud_shopdetail_reserve","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"预约订座（开通排队）",0, time.toLong)
            case  ("smart_cloud_shopdetail","reserve_more") => SCNode(userId, "smart_cloud_shopdetail_reserve_more","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"预约订座（未开通排队）",0, time.toLong)
            case  ("smart_cloud_shopdetail","reserve_by_time") => SCNode(userId, "smart_cloud_shopdetail_reserve_by_time","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"预约订座选择时间",0, time.toLong)
            case  ("smart_cloud_shopdetail","takout") => SCNode(userId, "smart_cloud_shopdetail_takout","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"外卖",0, time.toLong)
            case  ("smart_cloud_shopdetail","quick_order") => SCNode(userId, "smart_cloud_shopdetail_quick_order","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"提前点菜",0, time.toLong)
            case  ("smart_cloud_shopdetail","scan") => SCNode(userId, "smart_cloud_shopdetail_scan","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"扫码下单",0, time.toLong)
            case  ("smart_cloud_shopdetail","recommend_more") => SCNode(userId, "smart_cloud_shopdetail_recommend_more","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"商家推荐查看全部",0, time.toLong)
            case  ("smart_cloud_shopdetail","recommend_image") => SCNode(userId, "smart_cloud_shopdetail_recommend_image","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"商家推荐查看图片",0, time.toLong)
            case  ("smart_cloud_shopdetail","comment_more") => SCNode(userId, "smart_cloud_shopdetail_comment_more","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"评论查看全部",0, time.toLong)
            case  ("smart_cloud_shopdetail","comment_tag_all") => SCNode(userId, "smart_cloud_shopdetail_comment_tag_all","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"评论标签全部 ",0, time.toLong)
            case  ("smart_cloud_shopdetail","comment_tag_good") => SCNode(userId, "smart_cloud_shopdetail_comment_tag_good","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"评论标签好评",0, time.toLong)
            case  ("smart_cloud_shopdetail","comment_tag_normal") => SCNode(userId, "smart_cloud_shopdetail_comment_tag_normal","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"评论标签有待改进",0, time.toLong)
            case  ("smart_cloud_shopdetail","comment_tag_other") => SCNode(userId, "smart_cloud_shopdetail_comment_tag_other","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"评论标签其他标签",0, time.toLong)
            case  ("smart_cloud_shopdetail","click_comment_image") => SCNode(userId, "smart_cloud_shopdetail_click_comment_image","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"评论点击图片区域",0, time.toLong)
            case  ("smart_cloud_shopdetail","click_comment_other") => SCNode(userId, "smart_cloud_shopdetail_click_comment_other","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"评论点击其他区域",0, time.toLong)
            case  ("smart_cloud_shopdetail","info_more") => SCNode(userId, "smart_cloud_shopdetail_info_more","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"更多信息查看全部",0, time.toLong)
            case  ("smart_cloud_shopdetail","feedback") => SCNode(userId, "smart_cloud_shopdetail_feedback","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"吐槽",0, time.toLong)
            case  ("smart_cloud_shopdetail","nav_index") => SCNode(userId, "smart_cloud_shopdetail_nav_index","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"导航首页",0, time.toLong)
            case  ("smart_cloud_shopdetail","nav_quickorder") => SCNode(userId, "smart_cloud_shopdetail_nav_quickorder","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"导航点菜",0, time.toLong)
            case  ("smart_cloud_shopdetail","nav_member") => SCNode(userId, "smart_cloud_shopdetail_nav_member","smart_cloud_shopdetail","智慧餐厅商户详情页",url,"导航个人中心",0, time.toLong)
            case  ("MMCShopEvaluation","load_page") => SCNode(userId, "MMCShopEvaluation_load_page","MMCShopEvaluation","餐厅评价详情页",url,"餐厅评价详情页-页面加载",0, time.toLong)
            case  ("MMCShopEvaluation","overview_avg") => SCNode(userId, "MMCShopEvaluation_overview_avg","MMCShopEvaluation","餐厅评价详情页",url,"查看平均分入口",0, time.toLong)
            case  ("MMCShopEvaluation","tags_total") => SCNode(userId, "MMCShopEvaluation_tags_total","MMCShopEvaluation","餐厅评价详情页",url,"选择全部标签",0, time.toLong)
            case  ("MMCShopEvaluation","tags_good") => SCNode(userId, "MMCShopEvaluation_tags_good","MMCShopEvaluation","餐厅评价详情页",url,"选择好评标签",0, time.toLong)
            case  ("MMCShopEvaluation","tags_normal") => SCNode(userId, "MMCShopEvaluation_tags_normal","MMCShopEvaluation","餐厅评价详情页",url,"选择有待改进标签",0, time.toLong)
            case  ("MMCShopEvaluation","tags_other") => SCNode(userId, "MMCShopEvaluation_tags_other","MMCShopEvaluation","餐厅评价详情页",url,"选择其他标签",0, time.toLong)
            case  ("MMCShopEvaluation","overview_pic") => SCNode(userId, "MMCShopEvaluation_overview_pic","MMCShopEvaluation","餐厅评价详情页",url,"查看图片入口",0, time.toLong)
            case  ("MMCShopEvaluation","open_nav") => SCNode(userId, "MMCShopEvaluation_open_nav","MMCShopEvaluation","餐厅评价详情页",url,"导航入口",0, time.toLong)
            case  ("MMCShopEvaluation","nav_index") => SCNode(userId, "MMCShopEvaluation_nav_index","MMCShopEvaluation","餐厅评价详情页",url,"导航-首页入口",0, time.toLong)
            case  ("MMCShopEvaluation","nav_quickorder") => SCNode(userId, "MMCShopEvaluation_nav_quickorder","MMCShopEvaluation","餐厅评价详情页",url,"导航-点菜入口",0, time.toLong)
            case  ("MMCShopEvaluation","nav_member") => SCNode(userId, "MMCShopEvaluation_nav_member","MMCShopEvaluation","餐厅评价详情页",url,"导航-个人中心入口",0, time.toLong)
            case  ("MMCFissionCouponDetail","load_page_invite") => SCNode(userId, "MMCFissionCouponDetail1_load_page_invite","MMCFissionCouponDetail1","邀请有礼页",url,"邀请有礼页-页面加载",0, time.toLong)
            case  ("MMCFissionCouponDetail","load_page_redpacket") => SCNode(userId, "MMCFissionCouponDetail2_load_page_redpacket","MMCFissionCouponDetail2","收到裂变红包页",url,"收到裂变红包页-页面加载",0, time.toLong)
            case  ("MMCFissionCouponDetail","invite_share") => SCNode(userId, "MMCFissionCouponDetail1_redbag_share","MMCFissionCouponDetail1","邀请有礼页",url,"邀请有礼-微信分享成功",0, time.toLong)
            case  ("MMCFissionCouponDetail","qr_close") => SCNode(userId, "MMCFissionCouponDetail1_qr_close","MMCFissionCouponDetail1","邀请有礼页",url,"邀请有礼-关闭弹窗",0, time.toLong)
            case  ("MMCFissionCouponDetail","redpacket_open") => SCNode(userId, "MMCFissionCouponDetail2_redpacket_open","MMCFissionCouponDetail2","收到裂变红包页",url,"裂变红包-打开红包",0, time.toLong)
            case  ("MMCFissionCouponDetail","activity_rule") => SCNode(userId, "MMCFissionCouponDetail2_activity_rule","MMCFissionCouponDetail2","收到裂变红包页",url,"裂变红包-活动详情",0, time.toLong)
            case  ("MMCFissionCouponDetail","beinvited_share") => SCNode(userId, "MMCFissionCouponDetail2_redbag_share","MMCFissionCouponDetail2","收到裂变红包页",url,"裂变红包-分享成功",0, time.toLong)
            case  ("MMCFissionCouponDetail","btn_code") => SCNode(userId, "MMCFissionCouponDetail2_btn_code","MMCFissionCouponDetail2","收到裂变红包页",url,"裂变红包-获取验证码",0, time.toLong)
            case  ("MMCFissionCouponDetail","btn_receive_reward") => SCNode(userId, "MMCFissionCouponDetail2_btn_receive_reward","MMCFissionCouponDetail2","收到裂变红包页",url,"裂变红包-领取奖励",0, time.toLong)
            case  ("MMCFissionCouponDetail","top_rule") => SCNode(userId, "MMCFissionCouponDetail1_top_rule","MMCFissionCouponDetail1","邀请有礼页",url,"邀请有礼-活动规则",0, time.toLong)
            case  ("MMCFissionCouponDetail","show_invite_qr") => SCNode(userId, "MMCFissionCouponDetail1_show_invite_qr","MMCFissionCouponDetail1","邀请有礼页",url,"邀请有礼-邀请好友",0, time.toLong)
            case  ("MMCFissionCouponDetail","tab_reward") => SCNode(userId, "MMCFissionCouponDetail1_tab_reward","MMCFissionCouponDetail1","邀请有礼页",url,"邀请有礼-奖励明细",0, time.toLong)
            case  ("MMCFissionCouponDetail","view_privileges") => SCNode(userId, "MMCFissionCouponDetail1_view_privileges","MMCFissionCouponDetail1","邀请有礼页",url,"邀请有礼-查看更多",0, time.toLong)
            case  ("MMCFissionCouponDetail","open_fission") => SCNode(userId, "MMCFissionCouponDetail2_open_fission","MMCFissionCouponDetail2","收到裂变红包页",url,"收到裂变红包页",0, time.toLong)
            case  ("MMCFissionCouponDetail","open_register") => SCNode(userId, "MMCFissionCouponDetail2_open_register","MMCFissionCouponDetail2","收到裂变红包页",url,"新用户注册页",0, time.toLong)
            case  ("MMCFissionCouponDetail","open_fission_newuser") => SCNode(userId, "MMCFissionCouponDetail2_open_fission_newuser","MMCFissionCouponDetail2","收到裂变红包页",url,"新用户打开裂变红包页",0, time.toLong)
            case  ("MMCFissionCouponDetail","redpacket_newuser_success") => SCNode(userId, "MMCFissionCouponDetail2_redpacket_newuser_success","MMCFissionCouponDetail2","收到裂变红包页",url,"新用户领取红包成功",0, time.toLong)
            case  ("MMCFissionCouponDetail","redpacket_success") => SCNode(userId, "MMCFissionCouponDetail2_redpacket_success","MMCFissionCouponDetail2","收到裂变红包页",url,"新老用户领取成功",0, time.toLong)
            case  ("miaofu_payresult","page_load") => SCNode(userId, "miaofu_payresult_page_load","miaofu_payresult","正餐支付成功页",url,"正餐支付成功页-页面加载",0, time.toLong)
            case  ("miaofu_payresult","comment_service_cloud") => SCNode(userId, "miaofu_payresult_comment_service_cloud","miaofu_payresult","正餐支付成功页",url,"裂变红包-评论入口",0, time.toLong)
            case  ("miaofu_comment","page_load_1") => SCNode(userId, "miaofu_comment1_page_load","miaofu_comment1","发表评论页",url,"发表评论页-页面加载",0, time.toLong)
            case  ("miaofu_comment","page_load_2") => SCNode(userId, "miaofu_comment1_page_load","miaofu_comment1","发表评论页",url,"发表评论页-页面加载",0, time.toLong)
            case  ("miaofu_comment","page_load_3") => SCNode(userId, "miaofu_comment1_page_load","miaofu_comment1","发表评论页",url,"发表评论页-页面加载",0, time.toLong)
            case  ("miaofu_comment","page_load_4") => SCNode(userId, "miaofu_comment1_page_load","miaofu_comment1","发表评论页",url,"发表评论页-页面加载",0, time.toLong)
            case  ("miaofu_comment","redbag_loaded") => SCNode(userId, "miaofu_comment2_redbag_loaded","miaofu_comment2","评价领取红包页",url,"评价领取红包页-页面加载",0, time.toLong)
            case  ("miaofu_comment","close_redbag") => SCNode(userId, "miaofu_comment2_close_redbag","miaofu_comment2","评价领取红包页",url,"评论红包领取页-关闭弹窗",0, time.toLong)
            case  ("miaofu_comment","redbag_detail") => SCNode(userId, "miaofu_comment2_redbag_detail","miaofu_comment2","评价领取红包页",url,"评论红包领取页-活动详情",0, time.toLong)
            case  ("miaofu_comment","redbag_share") => SCNode(userId, "miaofu_comment2_redbag_share","miaofu_comment2","评价领取红包页",url,"评论红包领取页-邀请有礼入口",0, time.toLong)
            case  ("miaofu_comment","comment_redbag") => SCNode(userId, "miaofu_comment1_comment","miaofu_comment1","发表评论页",url,"发表评论页-发表评论",0, time.toLong)
            case  ("miaofu_comment","comment_normal") => SCNode(userId, "miaofu_comment1_comment","miaofu_comment1","发表评论页",url,"发表评论页-发表评论",0, time.toLong)
            case  ("order_detail_fast","fastfood_please_take_dining") => SCNode(userId, "order_detail_fast_fastfood_please_take_dining","order_detail_fast","请取餐状态页",url,"请取餐状态页",0, time.toLong)
            case  ("smart_cloud_shopdetail","page_load") => SCNode(userId, "smart_cloud_shopdetail_page_load","smart_cloud_shopdetail","商户详情页",url,"商户详情页",0, time.toLong)
            case  ("webapp_queue_detail","queue") => SCNode(userId, "webapp_queue_detail_queue","webapp_queue_detail","号单详情",url,"号单详情",0, time.toLong)
            case  ("reservation_order","reservation") => SCNode(userId, "reservation_order_reservation","reservation_order","在线预约页",url,"在线预约页",0, time.toLong)
            case  ("reservation_order_detail","reservation") => SCNode(userId, "reservation_order_detail_reservation","reservation_order_detail","预约单详情",url,"预约单详情",0, time.toLong)
            case  ("webpay","webpay") => SCNode(userId, "webpay_webpay","webpay","支付页",url,"支付页",0, time.toLong)
            case _ => SCNode(userId, "", "", "", "", "", 0, time.toLong)
          }
        })
        .toDF()
        .filter("nodeId != ''")
    markedLogDF.show(100, false)
    markedLogDF.registerTempTable("marked_log")

    //纬度表
    val pageEventDF = RDBReader.read(db, "DM_MONITOR_SC_PAGE_EVENT")
    pageEventDF.registerTempTable("page_event")
    pageEventDF.show(100, false)

    //计算PVUV
    val monthId = targetDate.substring(0,7)
    val updateTime = System.currentTimeMillis()
    res = sqlContext.sql(
      """
        |select
        |  '%s' MONTH_ID,
        |  pe.PAGE_ID,
        |  pe.PAGE_NAME,
        |  nvl(t2.pv,0) PAGE_PV,
        |  nvl(t2.uv,0) PAGE_UV,
        |  pe.EVENT_ID EVENT_ID,
        |  pe.EVENT_NAME EVENT_NAME,
        |  nvl(t1.pv,0) EVENT_PV,
        |  nvl(t1.uv,0) EVENT_UV,
        |  '%s' UPDATE_TIME
        |from
        |   page_event pe
        |left join
        |  (select
        |      ml.nodeId,
        |      ml.pageId,
        |      ml.page,
        |      ml.event,
        |      count(1) pv,
        |      count(distinct ml.userId) uv
        |    from
        |      (select * from marked_log) ml
        |    group by
        |      ml.nodeId,
        |      ml.pageId,
        |      ml.page,
        |      ml.event) t1
        |on
        |pe.EVENT_ID = t1.nodeId
        |left join
        |  (select
        |          ml.nodeId,
        |          ml.pageId,
        |          ml.page,
        |          count(1) pv,
        |          count(distinct ml.userId) uv
        |      from
        |        (select * from marked_log
        |          where
        |          nodeId in(
        |                       'smart_cloud_shopdetail_page_load',
        |                       'MMCShopEvaluation_load_page',
        |                       'miaofu_payresult_page_load',
        |                       'miaofu_comment1_page_load',
        |                       'miaofu_comment2_redbag_loaded',
        |                       'MMCFissionCouponDetail1_load_page_invite',
        |                       'MMCFissionCouponDetail2_load_page_redpacket'
        |                       )
        |
        |          ) ml
        |        group by
        |          ml.nodeId,
        |          ml.pageId,
        |          ml.page) t2
        |on
        |pe.PAGE_ID = t2.pageId
        |
        |
      """.stripMargin.format(monthId, updateTime))
    res.cache()
    res.show(100, false)

  }
}






