package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.SQLBookingDeposit
import com.gnow.{DB, Processor, Utility}

class BookingDepositDaily extends Processor {
  val BOOKING_DEPOSIT = "booking_deposit"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from booking_deposit
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLBookingDeposit.getSQL(targetDate)
    val tbl = rdb.booking.df(rdb.booking.BOOKING_DEPOSIT, targetDate)
    val res = Utility.sql(tbl, sql)
    RDBWriter.save(res, DB.ORACLE_37_BWSWD, BOOKING_DEPOSIT)
  }
}
