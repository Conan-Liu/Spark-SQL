package com.gnow.processor

import com.gnow.config.SaveMode
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import com.gnow.{DB, Processor}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import com.gnow.eraser.DBEraser

class BasicMemberTableDaily extends Processor {

  val BASIC_MEMBER_TABLE = "basic_member_table"
  //var basicMemberTable: DataFrame = null

  def reset(targetDate: String): Unit = {
  
    val sql =
      """
        |delete
        |from basic_member_table
        |where create_date='%s'
      """.stripMargin
    logger.info(sql.format(targetDate))
	
    DBEraser.remove(DB.MYSQL_249_RESTAURANT, sql.format(targetDate))

  }

  def execute(targetDate: String, input: String, output: String) = {
  
    reset(targetDate)
    process(targetDate, input: String, output: String)
	
  }

  def process(targetDate: String, input: String, output: String) = {
  
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
	repository.kafka.df(repository.kafka.BASIC_MEMBER_TABLE,targetDate)
		
	val DATA =
      """
    |select
    |t1.business          business,
    |t1.module            module,
    |t1.action            action,
    |t1.environment       environment,
    |t1.`@version`        version,
    |t1.create_date       create_date,
    |t1.shop_id           shop_id,
    |t1.website_id        website_id,
    |t1.function_id       function_id,
    |t1.online            online,
	|t1.b_version         b_version
    |from %s t1
    """.stripMargin
	
	
    val basicMemberTable= sqlContext.sql(DATA.format(repository.kafka.BASIC_MEMBER_TABLE))
    
    RDBWriter.save(basicMemberTable.repartition(100), DB.MYSQL_249_RESTAURANT, BASIC_MEMBER_TABLE, SaveMode.APPEND)
  }
}
