package com.gnow.processor

import com.gnow.config.{Constants, SaveMode}
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.SQLApplySign
import com.gnow.{DB, Processor, Utility}

class ApplySignDaily extends Processor {
  val APPLY_SIGN = "apply_sign"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from apply_sign
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLApplySign.getSQL(targetDate)
    val df = rdb.booking.df(rdb.booking.BOOKING_APPLY_SIGN, targetDate)
    val res = Utility.sql(df, sql)
    RDBWriter.save(res, DB.ORACLE_37_BWSWD, APPLY_SIGN, SaveMode.APPEND)
  }
}
