package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.{SQLFlashQuit, SQLUserOrder}
import com.gnow.{DB, Processor, Utility}
import org.apache.spark.sql.DataFrame

class QueueUserOrderDaily extends Processor {
  val QUEUE_USER_ORDER = "queue_user_order"
  var df: DataFrame = null
  var shopAndBaseDateDF: DataFrame = null

  val OUTPUT_TABLE = "shop_queue_config"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from flash_quit
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    //reset(targetDate)
    process(targetDate, input: String, output: String)
    RDBWriter.save(shopAndBaseDateDF, DB.ORACLE_37_BWSWD, OUTPUT_TABLE)
  }

  def process(targetDate: String, input: String, output: String) = {
    df = rdb.queueing.df(rdb.queueing.QUEUE_USER_ORDER)

    shopAndBaseDateDF = Utility.registerTableWithSQL(sqlContext,
      SQLUserOrder.SQL.format(
        rdb.queueing.QUEUE_USER_ORDER
      ), QUEUE_USER_ORDER)
  }
}
