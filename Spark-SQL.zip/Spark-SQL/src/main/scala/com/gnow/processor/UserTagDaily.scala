package com.gnow.processor

import com.gnow.UserTagMail._send
import com.gnow._
import com.gnow.config.SaveMode
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import org.apache.spark.sql.DataFrame

class UserTagDaily extends Processor {
  private val USER_TAG_COMPACT = "user_tag_compact"
  private val USER_TAG_COMPACT_MWBYD = "user_tag_compact_mwbyd"
  private val USER_TAG_LAST_MWBYD = "user_tag_last_mwbyd"
  private val USER_TAG_DISTINCT = "user_tag_distinct"
  private val USER_TAG_LATEST_CITY = "user_tag_latest_city"
  private val USER_TAG_LATEST_MISC = "user_tag_latest_misc"
  private val USER_TAG_CITIES = "user_tag_cities"
  private val USER_TAG_CITY = "user_tag_city"
  private val USER_TAG_QUEUEING = "user_tag_queueing"
  private val USER_TAG_QUEUEING_LATEST = "user_tag_queueing_latest"
  private val USER_TAG_QUEUEING_COUNT = "user_tag_queueing_count"
  private val USER_TAG_BOOKING = "user_tag_booking"
  private val USER_TAG_BOOKING_LATEST = "user_tag_booking_latest"
  private val USER_TAG_BOOKING_COUNT = "user_tag_booking_count"
  private val USER_TAG_ORDERING = "user_tag_ordering"
  private val USER_TAG_ORDERING_LATEST = "user_tag_ordering_latest"
  private val USER_TAG_ORDERING_COUNT = "user_tag_ordering_count"
  private val USER_TAG_MWBYD = "user_tag_mwbyd"
  private val USER_TAG_MWBYD0 = "user_tag_mwbyd0"
  private val USER_TAG_MWBYD1 = "user_tag_mwbyd1"
  private val USER_TAG_MWBYD2 = "user_tag_mwbyd2"
  private val USER_TAG_APP = "user_tag_app"
  private val TARGET_DATE_USER_ID_TMP = "user_tag_user_id_tmp"
  private val TARGET_USER_ID = "target_user_id"
  val USER_TAG = "user_tag"
  val USER_TAG_TMP = "user_tag_tmp"
  private val TARGET_DATE_USER_ID = "user_tag_user_id"
  private val BASIC_USER_TAG_ALL = "basic_user_tag_all"
  private val BASIC_USER_TAG_ALL_TMP = "basic_user_tag_all_tmp"
  private val BASIC_USER_TAG_ALL0 = "basic_user_tag_all0"
  private val BASIC_USER_TAG_ALL1 = "basic_user_tag_all1"
  private val BASIC_USER_TAG_ALL2 = "basic_user_tag_all2"
  private val USER_TAG_DATE = "user_tag_date"

  private var USER_TAG_OPEN = "user_tag_open"
  private var USER_TAG_OPEN0 = "user_tag_open0"
  private var USER_TAG_OPEN1 = "user_tag_open1"
  private var USER_TAG_OPEN2 = "user_tag_open2"
  private var USER_TAG_OPEN_NULL = "user_tag_open_null"
  private var USER_TAG_OPEN_ALL = "user_tag_open_all"
  private var USER_TAG_OPEN_NULL_ALL = "user_tag_open_null_all"
  private var USER_TAG_TOTLE = "user_tag"
  private val USER_DEVICE_ID = "user_device_id"
  private val USER_APNS = "user_apns"
  private val USER_STATUS = "user_status"

  private var userTagOpen : DataFrame = _
  private var userTagOpen0 : DataFrame = _
  private var userTagOpen1 : DataFrame = _
  private var userTagOpen2 : DataFrame = _
  private var userTagOpenNull :DataFrame = _
  private var userTagOpenAll : DataFrame = _
  private var userTagOpenNullALL :DataFrame = _
  private var userTagTOTLE :DataFrame = _
  private var userDeviceId :DataFrame = _
  private var userApns :DataFrame = _
  private var userStatus :DataFrame = _

  private var userTagMWBYDDF: DataFrame = null
  private var userTagMWBYDDF0: DataFrame = null
  private var userTagMWBYDDF1: DataFrame = null
  private var userTagMWBYDDF2: DataFrame = null
  private var userTagAPPDF: DataFrame = null
  private var userTagQueueingDF: DataFrame = null
  private var userTagQueueingLatestDF: DataFrame = null
  private var userTagQueueingCountDF: DataFrame = null
  private var userTagBookingDF: DataFrame = null
  private var userTagBookingLatestDF: DataFrame = null
  private var userTagBookingCountDF: DataFrame = null
  private var userTagOrderingDF: DataFrame = null
  private var userTagOrderingLatestDF: DataFrame = null
  private var userTagOrderingCountDF: DataFrame = null
  private var userTagLastMwbydDF: DataFrame = null

  private var userTagCityDF: DataFrame = null
  private var basicUserLabelDF: DataFrame = null
  private var userTagDistinctDF: DataFrame = null
  private var userTagCompactDF: DataFrame = null
  private var userTagCompactMwbydDF: DataFrame = null
  private var userTagLatestCityDF: DataFrame = null
  private var userTagLatestMiscDF: DataFrame = null
  private var userTagCitiesDF: DataFrame = null
  private var targetDateDF: DataFrame = null
  private var targetDateAllDF: DataFrame = null
  private var targetDateAllTmpDF: DataFrame = null
  private var targetDateAllDF0: DataFrame = null
  private var targetDateAllDF1: DataFrame = null
  private var targetDateAllTmpDF1: DataFrame = null
  private var targetDateAllDF2: DataFrame = null
  private var targetDateAllTmpDF2: DataFrame = null
  private var targetDateUserIdDF: DataFrame = null
  private var targetUserIdDF: DataFrame = null
  var userResultDF: DataFrame = null


  def reset(targetDate: String): Unit = {
    val sql_user_id = "delete from user_tag_tmp;"
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_user_id)
    //val sql_user_id = "delete from user_tag_user_id;"
  }

  def execute(targetDate: String, input: String, output: String) = {
    process(targetDate, input: String, output: String)
    logger.warn("begin reset")
    reset(targetDate)
    logger.warn("begin RDBWriter user_tag_tmp")
    RDBWriter.overwrite(userResultDF, DB.MYSQL_50_ASSOCIATOR, USER_TAG_TMP)
    logger.warn("begin delete user_tag")
    val sql = "delete from user_tag where user_id in (select user_id from user_tag_tmp);" //exists
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql)
    logger.warn("begin RDBWriter USER_TAG")
    val sql_insert = "insert into user_tag select * from user_tag_tmp;" //exists
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_insert)
    logger.warn("end RDBWriter USER_TAG")
    _send("UserTag Job Run Success", targetDate + " UserTag新增或更新的UserID数量为：" + userResultDF.count)
    //logger.warn("end reset begin RDBWriter user_tag_user_id")
    //RDBWriter.overwrite(targetUserIdDF, DB.MYSQL_50_ASSOCIATOR, TARGET_DATE_USER_ID)
    //logger.warn("end RDBWriter user_tag_user_id begin delete user_tag")
    //val sql = "delete from user_tag where user_id in (select user_id from user_tag_user_id);" //exists
    //DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql)
    //logger.warn("end delete user_tag begin RDBWriter USER_TAG")
    //RDBWriter.overwrite(userResultDF, DB.MYSQL_50_ASSOCIATOR, USER_TAG)
    //logger.warn("end RDBWriter USER_TAG")
  }

  def process(targetDate: String, input: String, output: String) = {
    val udafConcat = new UDAFConcat()
    sqlContext.udf.register("udafConcat", udafConcat)

    //尝试手动指定schema
    val schema = "user_id,label,create_time,device_id,device_type,mobile,attributes.city_id,attributes.city_name,mwbyd_status,apnstoken"
    targetDateAllTmpDF = repository.kafka.dfBeginAndEnd(repository.kafka.BASIC_USER_TAG,targetDate,schema)
    val basicUserTagTmpPath = "/tmp/repository/kafka/basic_user_tag"
    targetDateAllTmpDF.coalesce(200).write.mode(SaveMode.OVERWRITE.toString).parquet(basicUserTagTmpPath)
    targetDateAllDF = sqlContext.read.parquet(basicUserTagTmpPath)
    targetDateAllDF.registerTempTable(BASIC_USER_TAG_ALL)

    targetDateDF = repository.kafka.df(repository.kafka.BASIC_USER_TAG,targetDate)
    targetDateDF.registerTempTable(USER_TAG_DATE)

    val schema1 = "user_id,open_id,mwbyd_status,create_time,label"
    targetDateAllTmpDF1 = repository.kafka.dfBeginAndEnd1(repository.kafka.BASIC_USER_TAG,"2017-03-13",schema1)
    val basicUserTagTmpPath1 = "/tmp/repository/kafka/basic_user_tag1"
    targetDateAllTmpDF1.coalesce(200).write.mode(SaveMode.OVERWRITE.toString).parquet(basicUserTagTmpPath1)
    targetDateAllDF1 = sqlContext.read.parquet(basicUserTagTmpPath1)
    targetDateAllDF1.registerTempTable(BASIC_USER_TAG_ALL1)

    val schema2 = "user_id,openId,mwbyd_status,create_time,label"
    targetDateAllTmpDF2 = repository.kafka.dfBeginAndEnd2(repository.kafka.BASIC_USER_TAG,targetDate,schema2)
    val basicUserTagTmpPath2 = "/tmp/repository/kafka/basic_user_tag2"
    targetDateAllTmpDF2.coalesce(200).write.mode(SaveMode.OVERWRITE.toString).parquet(basicUserTagTmpPath2)
    targetDateAllDF2 = sqlContext.read.parquet(basicUserTagTmpPath2)
    targetDateAllDF2.registerTempTable(BASIC_USER_TAG_ALL2)

    targetDateUserIdDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id
        |FROM %s t1
        |WHERE t1.user_id IS NOT NULL
      """.stripMargin.format(
        USER_TAG_DATE
      ), TARGET_DATE_USER_ID_TMP)    // 建立临时表TARGET_DATE_USER_ID_TMP
    logger.warn("targetDateUserIdDF count:" + targetDateUserIdDF.count)

    //basicUserLabelDF = repository.kafka.df(repository.kafka.BASIC_USER_TAG)
    //basicUserLabelDF.printSchema()


    userTagCityDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT *
        |FROM %s t1
        |WHERE t1.label = '城市'
      """.stripMargin.format(
        BASIC_USER_TAG_ALL
      ), USER_TAG_CITY)
    logger.warn("userTagCityDF count:" /*+ userTagCityDF.count*/)
    /*AND t1.mobile IS NOT NULL*/

    //userTagMWBYDDF0 = Utility.registerTableWithSQL(sqlContext,
    //  """
    //    |SELECT
    //   |cast(t1.user_id as int) user_id,
    //   |'美味不用等'              user_tag,
    //    |t1.openId                open_id,
    //  t1.mwbyd_status           mwbyd_status,
    //    |cast(t1.create_time as int) create_time
    //    |FROM %s t1
    //    |WHERE t1.label = '美味不用等'
    //  """.stripMargin.format(
    //    BASIC_USER_TAG_ALL0
    //  ), USER_TAG_MWBYD0)
    //logger.warn("userTagMWBYDDF0 count:" + userTagMWBYDDF0.count)

    userTagMWBYDDF1 = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |'美味不用等'              user_tag,
        |t1.open_id                open_id,
        |t1.mwbyd_status           mwbyd_status,
        |cast(t1.create_time as int) create_time
        |FROM %s t1
        |WHERE t1.label = '美味不用等'
      """.stripMargin.format(
        BASIC_USER_TAG_ALL1
      ), USER_TAG_MWBYD1)
    logger.warn("userTagMWBYDDF1 count:" /*+ userTagMWBYDDF1.count*/)

    userTagMWBYDDF2 = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |'美味不用等'              user_tag,
        |t1.openId                open_id,
        |t1.mwbyd_status           mwbyd_status,
        |cast(t1.create_time as int) create_time
        |FROM %s t1
        |WHERE t1.label = '美味不用等'
      """.stripMargin.format(
        BASIC_USER_TAG_ALL2
      ), USER_TAG_MWBYD2)
    logger.warn("userTagMWBYDDF2 count:" /*+ userTagMWBYDDF2.count*/)

    userTagMWBYDDF = Utility.registerTableWithSQL(sqlContext,
      """
         select * from %s t1
         union
         select * from %s t2

      """.stripMargin.format(
        //USER_TAG_MWBYD0,
        USER_TAG_MWBYD1,
        USER_TAG_MWBYD2
      ), USER_TAG_MWBYD)
    logger.warn("userTagMWBYDDF count:" /*+ userTagMWBYDDF.count*/)
    //select * from %s t0
    //union


    //  userTagMWBYDDF = Utility.registerTableWithSQL(sqlContext,
    //    """
    //      |SELECT
    //      |cast(t1.user_id as int) user_id,
    //      |'美味不用等'              user_tag,
    //      |t1.openId                open_id,
    //      |cast(t1.create_time as int) create_time
    //      |FROM %s t1
    //      |WHERE t1.label = '美味不用等'
    //    """.stripMargin.format(
    //      BASIC_USER_TAG_ALL
    //   ), USER_TAG_MWBYD)
    //  logger.warn("userTagMWBYDDF count:" + userTagMWBYDDF.count)

    //userTagOpen0 = Utility.registerTableWithSQL(sqlContext,
    //  """
    //    |select
    //    |cast(t1.user_id as int)  user_id,
    //   |'美味不用等'  user_tag,
    //    |max(cast(t1.create_time as int)) create_time
    //    |from %s t1
    //    |where t1.openId is not null
    //    |and  t1.label = '美味不用等'
    //    |group by cast(t1.user_id as int)
    //  """.stripMargin.format(
    //    BASIC_USER_TAG_ALL0
    //  ), USER_TAG_OPEN0)
    //logger.warn("userTagOpen0 count:" + userTagOpen0.count)

    userTagOpen1 = Utility.registerTableWithSQL(sqlContext,
      """
        |select
        |cast(t1.user_id as int)  user_id,
        |'美味不用等'  user_tag,
        |max(cast(t1.create_time as int)) create_time
        |from %s t1
        |where t1.open_id is not null
        |and  t1.label = '美味不用等'
        |group by cast(t1.user_id as int)
      """.stripMargin.format(
        BASIC_USER_TAG_ALL1
      ), USER_TAG_OPEN1)
    logger.warn("userTagOpen1 count:" /*+ userTagOpen1.count*/)

    userTagOpen2 = Utility.registerTableWithSQL(sqlContext,
      """
        |select
        |cast(t1.user_id as int)  user_id,
        |'美味不用等'  user_tag,
        |max(cast(t1.create_time as int)) create_time
        |from %s t1
        |where t1.openId is not null
        |and  t1.label = '美味不用等'
        |group by cast(t1.user_id as int)
      """.stripMargin.format(
        BASIC_USER_TAG_ALL2
      ), USER_TAG_OPEN2)
    logger.warn("userTagOpen2 count:" /*+ userTagOpen2.count*/)

    userTagOpen = Utility.registerTableWithSQL(sqlContext,
      """
         select * from %s t1
         union
         select * from %s t2

      """.stripMargin.format(
        //USER_TAG_OPEN0,
        USER_TAG_OPEN1,
        USER_TAG_OPEN2
      ), USER_TAG_OPEN)
    logger.warn("userTagOpen count:" /*+ userTagOpen.count*/)
    //select * from %s t0
    //union

    //userTagOpen = Utility.registerTableWithSQL(sqlContext,
    // """
    //    |select
    //   |cast(t1.user_id as int)  user_id,
    //   |'美味不用等'  user_tag,
    //    |max(cast(t1.create_time as int)) create_time
    //    |from %s t1
    //   |where t1.req_data.openId is not null
    //   |and  t1.label = '美味不用等'
    //   |group by cast(t1.user_id as int)
    // """.stripMargin.format(
    //   BASIC_USER_TAG_ALL
    // ), USER_TAG_OPEN)
    //logger.warn("userTagOpen count:" + userTagOpen.count)
    //where t1.openId is not null

    userTagOpenNull = Utility.registerTableWithSQL(sqlContext,
      """
        |select distinct
        |cast(t1.user_id as int) user_id
        |from %s t1  left join  %s t2
        |on cast(t1.user_id as int) = cast(t2.user_id as int)
        |where t2.user_id is null
      """.stripMargin.format(
        USER_TAG_MWBYD,
        USER_TAG_OPEN
      ), USER_TAG_OPEN_NULL)
    logger.warn("userTagOpenNull count:" /*+ userTagOpenNull.count*/)


    userTagOpenNullALL =  Utility.registerTableWithSQL(sqlContext,
      """
        |select distinct
        |cast(t1.user_id as int) user_id,
        |'美味不用等'  user_tag,
        |''    open_id
        |from %s t1  left join %s t2
        |on cast(t1.user_id as int) = cast(t2.user_id as int)
      """.stripMargin.format(
        USER_TAG_OPEN_NULL,
        USER_TAG_MWBYD
      ), USER_TAG_OPEN_NULL_ALL)
    logger.warn("userTagOpenNullALL count:" /*+ userTagOpenNullALL.count*/)


    userTagOpenAll = Utility.registerTableWithSQL(sqlContext,
      """
        |select
        |cast(t1.user_id as int) user_id,
        |t1.user_tag,
        |t2.open_id
        |from %s t1 left join %s t2
        |on cast(t1.user_id as int) = cast(t2.user_id as int)
        |and cast(t1.create_time as int) = cast(t2.create_time as int)
      """.stripMargin.format(
        USER_TAG_OPEN,
        USER_TAG_MWBYD
      ), USER_TAG_OPEN_ALL)
    logger.warn("userTagOpenAll count:" /*+ userTagOpenAll.count*/)

    userTagTOTLE = Utility.registerTableWithSQL(sqlContext,
      """
         select * from %s t1
         union
         select * from %s t2

      """.stripMargin.format(
        USER_TAG_OPEN_ALL,
        USER_TAG_OPEN_NULL_ALL
      ), USER_TAG_TOTLE)
    logger.warn("userTagTOTLE count:" /*+ userTagTOTLE.count*/)

    userTagAPPDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |'APP'              user_tag
        |FROM %s t1
        |WHERE t1.label = 'APP'
      """.stripMargin.format(
        BASIC_USER_TAG_ALL
      ), USER_TAG_APP)
    logger.warn("userTagAPPDF count:" /*+ userTagAPPDF.count*/)

    userTagQueueingDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |cast(t1.create_time as int) create_time
        |FROM %s t1
        |WHERE t1.label = '排队'
      """.stripMargin.format(
        BASIC_USER_TAG_ALL
      ), USER_TAG_QUEUEING)
    logger.warn("userTagQueueingDF count:" /*+ userTagQueueingDF.count*/)
//    userTagQueueingDF.cache()

    userTagQueueingLatestDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT  distinct
        |cast(t1.user_id as int) user_id,
        |'排队'              user_tag,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_QUEUEING
      ), USER_TAG_QUEUEING_LATEST)
    logger.warn("userTagQueueingLatestDF count:" /*+ userTagQueueingLatestDF.count*/)

    userTagQueueingCountDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |count(cast(t1.user_id as int)) user_id_count
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_QUEUEING
      ), USER_TAG_QUEUEING_COUNT)
    logger.warn("userTagQueueingCountDF count:" /*+ userTagQueueingCountDF.count*/)

    userTagBookingDF = Utility.registerTableWithSQL(sqlContext,
      """
        SELECT DISTINCT
        cast(t1.user_id as int) user_id,
        cast(t1.create_time as int) create_time
        FROM %s t1
        WHERE t1.label = '预订'
      """.stripMargin.format(
        BASIC_USER_TAG_ALL
      ), USER_TAG_BOOKING)
    logger.warn("userTagBookingDF count:" /*+ userTagBookingDF.count*/)
//    userTagBookingDF.cache()

    userTagBookingLatestDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int) user_id,
        |'预订'              user_tag,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_BOOKING
      ), USER_TAG_BOOKING_LATEST)
    logger.warn("userTagBookingLatestDF count:" /*+ userTagBookingLatestDF.count*/)

    userTagBookingCountDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |count(cast(t1.user_id as int)) user_id_count
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_BOOKING
      ), USER_TAG_BOOKING_COUNT)
    logger.warn("userTagBookingCountDF count:" /*+ userTagBookingCountDF.count*/)

    userTagOrderingDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |cast(t1.create_time as int) create_time
        |FROM %s t1
        |WHERE t1.label = '点菜'
      """.stripMargin.format(
        BASIC_USER_TAG_ALL
      ), USER_TAG_ORDERING)
    logger.warn("userTagOrderingDF count:" /*+ userTagOrderingDF.count*/)
//    userTagOrderingDF.cache()

    userTagOrderingLatestDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |'点菜'              user_tag,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_ORDERING
      ), USER_TAG_ORDERING_LATEST)
    logger.warn("userTagOrderingLatestDF count:" /*+ userTagOrderingLatestDF.count*/)

    userTagOrderingCountDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |count(cast(t1.user_id as int)) user_id_count
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_ORDERING
      ), USER_TAG_ORDERING_COUNT)
    logger.warn("userTagOrderingCountDF count:" /*+ userTagOrderingCountDF.count*/)

    userTagCityDF.printSchema()

    userTagCompactDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |t1.device_id,
        |t1.device_type,
        |t1.mobile,
        |t1.attributes.city_id city_id,
        |t1.attributes.city_name city_name,
        |t1.create_time,
        |t1.mwbyd_status
        |FROM %s t1
        |WHERE 1 = 1
        |AND t1.attributes.city_id IS NOT NULL
      """.stripMargin.format(
        USER_TAG_CITY
      ), USER_TAG_COMPACT)
    logger.warn("userTagCompactDF count:" /*+ userTagCompactDF.count*/)
//    userTagCompactDF.cache()

    userDeviceId = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |max(case when (instr(t1.device_id,'xmpp') = 0) then t1.device_id else '' END)   device_id,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |WHERE 1 = 1
        |AND t1.attributes.city_id IS NOT NULL
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_CITY
      ), USER_DEVICE_ID)
    logger.warn("userDeviceId count:" /*+ userDeviceId.count*/)


    userApns = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |max(NVL(t1.apnstoken,''))   apnstoken,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |WHERE 1 = 1
        |AND t1.attributes.city_id IS NOT NULL
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_CITY
      ), USER_APNS)
    logger.warn("userApns count:" /*+ userApns.count*/)

    userTagDistinctDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int) user_id,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |WHERE 1 = 1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_COMPACT
      ), USER_TAG_DISTINCT)
    logger.warn("userTagDistinctDF count:" /*+ userTagDistinctDF.count*/)

    userTagCompactMwbydDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |t1.user_id,
        |t1.mwbyd_status,
        |t1.create_time
        |FROM %s t1
        |WHERE 1 = 1
      """.stripMargin.format(
        USER_TAG_MWBYD
      ), USER_TAG_COMPACT_MWBYD)
    logger.warn("userTagCompactMwbydDF count:" /*+ userTagCompactMwbydDF.count*/)

    userTagLastMwbydDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int) user_id,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |WHERE 1 = 1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_MWBYD
      ), USER_TAG_LAST_MWBYD)
    logger.warn("userTagLastMwbydDF count:" /*+ userTagLastMwbydDF.count*/)

    userTagLatestCityDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t2.user_id as int) user_id,
        |max(cast(t2.create_time as int)) max_create_time,
        |min(NVL(t2.mwbyd_status,1))   mwbyd_status
        |FROM %s t1 left join %s t2 on (
        |  cast(t1.user_id as int) = cast(t2.user_id as int)
        |  AND t1.max_create_time = cast(t2.create_time as int)
        |)
        |WHERE 1=1
        |AND t2.create_time is not NULL
        |GROUP BY
        |cast(t2.user_id as int)
      """.stripMargin.format(USER_TAG_LAST_MWBYD,
        USER_TAG_COMPACT_MWBYD), USER_TAG_LATEST_CITY)
    logger.warn("userTagLatestCityDF count:" /*+ userTagLatestCityDF.count*/)

    userTagLatestMiscDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT  distinct
        |cast(t2.user_id as int) user_id,
        |max(cast(t2.create_time as int)) max_create_time,
        |max(concat_ws(',',
        |t3.device_id,
        |t4.apnstoken))      device_id,
        |max(t2.device_type) device_type,
        |max(t2.mobile)      mobile,
        |max(t2.city_id)     city_id
        |FROM %s t1 join %s t2 on (
        |  cast(t1.user_id as int) = cast(t2.user_id as int)
        |  AND t1.max_create_time = cast(t2.create_time as int)
        |)join %s t3 on (
        |cast(t1.user_id as int) = cast(t3.user_id as int)
        |)join %s t4 on (
        |cast(t1.user_id as int) = cast(t4.user_id as int)
        |)
        |WHERE 1=1
        |AND t1.max_create_time is not NULL
        |GROUP BY
        |cast(t2.user_id as int)
      """.stripMargin.format(USER_TAG_DISTINCT, USER_TAG_COMPACT,USER_DEVICE_ID,USER_APNS
      ), USER_TAG_LATEST_MISC)
    logger.warn("userTagLatestMiscDF count:" /*+ userTagLatestMiscDF.count*/)

    userTagCitiesDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |t1.user_id,
        |concat_ws(",", udafConcat(t1.city_name)) city_names
        |FROM %s t1
        |WHERE 1=1
        |GROUP BY
        |t1.user_id
      """.stripMargin.format(USER_TAG_COMPACT), USER_TAG_CITIES)
    logger.warn("userTagCitiesDF count:" /*+ userTagCitiesDF.count*/)

    userResultDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int)          user_id,
        |max(concat_ws(',',
        |t4.city_names,
        |t5.user_tag,
        |t7.user_tag,
        |t9.user_tag,
        |t11.user_tag,
        |t12.user_tag))                    user_tags,
        |max(t2.city_id)                       city,
        |max(t1.max_create_time)               createtime,
        |max(NVL(t5.max_create_time, 0))       queue_last,
        |max(NVL(t6.user_id_count, 0))         queue_total,
        |max(NVL(t7.max_create_time, 0))       book_last,
        |max(NVL(t8.user_id_count, 0))         book_total,
        |max(NVL(t9.max_create_time, 0))       order_last,
        |max(NVL(t10.user_id_count, 0))        order_total,
        |0                                pay_last,
        |0                                pay_total,
        |0                                pay_amount,
        |max(t2.device_type)                   device_type,
        |max(IF(length(t2.device_id)=1,"",t2.device_id))     last_device,
        |max(NVL(t2.mobile, '0'))              mobile,
        |max(NVL(t11.open_id, '0'))             mwbyd,
        |max(NVL(t3.mwbyd_status,1))           mwbyd_status,
        |0                                mwbyd_last_valid_op,
        |'%s'                             create_date
        |FROM %s t1 join %s t13 on (
        |  cast(t1.user_id as int)  = cast(t13.user_id as int)
        |) join %s t2 on (
        |  cast(t1.user_id as int)  = cast(t2.user_id as int)
        |) join %s t4 on (
        |  cast(t1.user_id as int)  = cast(t4.user_id as int)
        |) left join %s t3 on (
        |  cast(t1.user_id as int)  = cast(t3.user_id as int)
        |) left join %s t5 on (
        |  cast(t1.user_id as int)  = cast(t5.user_id as int)
        |) left join %s t6 on (
        |  cast(t1.user_id as int)  = cast(t6.user_id as int)
        |) left join %s t7 on (
        |  cast(t1.user_id as int)  = cast(t7.user_id as int)
        |) left join %s t8 on (
        |  cast(t1.user_id as int)  = cast(t8.user_id as int)
        |) left join %s t9 on (
        |  cast(t1.user_id as int)  = cast(t9.user_id as int)
        |) left join %s t10 on (
        |  cast(t1.user_id as int)  = cast(t10.user_id as int)
        |) left join %s t11 on (
        |  cast(t1.user_id as int)  = cast(t11.user_id as int)
        |) left join %s t12 on (
        |  cast(t1.user_id as int)  = cast(t12.user_id as int)
        |)
        |WHERE 1=1
        		|group by cast(t1.user_id as int)
      """.stripMargin.format(
        targetDate,
        USER_TAG_DISTINCT,
        TARGET_DATE_USER_ID_TMP,
        USER_TAG_LATEST_MISC,
        USER_TAG_CITIES,
        USER_TAG_LATEST_CITY,
        USER_TAG_QUEUEING_LATEST,
        USER_TAG_QUEUEING_COUNT,
        USER_TAG_BOOKING_LATEST,
        USER_TAG_BOOKING_COUNT,
        USER_TAG_ORDERING_LATEST,
        USER_TAG_ORDERING_COUNT,
        USER_TAG_TOTLE,
        USER_TAG_APP
      ), USER_TAG)
    logger.warn("userResultDF count:" /*+ userResultDF.count*/)

    //used twice later,save to memory and disk
    userResultDF.cache()

    /*targetUserIdDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id
        |FROM %s t1
      """.stripMargin.format(
        USER_TAG
      ), TARGET_USER_ID)
    logger.warn("targetUserIdDF count:" + targetUserIdDF.count)*/
  }
}
