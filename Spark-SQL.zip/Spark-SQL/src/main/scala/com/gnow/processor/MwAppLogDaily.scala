package com.gnow.processor

import com.gnow.{DB, Processor}
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}

/**
  * Created by tal on 10/04/2018.
  */
class MwAppLogDaily extends Processor {

  def reset(targetDate: String): Unit = {

  }

  def execute(targetDate: String, input: String, output: String) = {
    process(targetDate, input: String, output: String)

  }

  def process(targetDate: String, input: String, output: String) = {
    //读取用户轨迹日志数据
    val locationSchema = StructType(
      List(
        StructField("business", StringType, true),
        StructField("module", StringType, true),
        StructField("action", StringType, true),
        StructField("app_version", StringType, true),
        StructField("app_src", StringType, true),
        StructField("device_type", StringType, true),
        StructField("device_info", StringType, true),
        StructField("os_version", StringType, true),
        StructField("device_model", StringType, true),
        StructField("city_id", StringType, true),
        StructField("open_id", StringType, true),
        StructField("mobile", DoubleType, true),
        StructField("location", StringType, true),
        StructField("update_time", DoubleType, true)
      )
    )
    val appLocationLogDF = sqlContext.read.schema(locationSchema).json("/repository/kafka/user_action_app_operation/{date}".replace("{date}", targetDate))
    appLocationLogDF.printSchema()
    appLocationLogDF.createOrReplaceTempView("location_log")
    val locationRes = sqlContext.sql(
      """
        |select
        | '%s' day_id
        | ,t1.module platform
        | ,cast(t1.mobile as long) mobile
        | ,t1.open_id
        | ,cast(t1.device_type as int) device_type
        | ,(case when instr(t1.device_info, ',') > 0 then
        |       substr(t1.device_info, 0, instr(t1.device_info, ',') - 1)
        |    else
        |       t1.device_info
        |    end) device_id
        |  ,(case when instr(t1.device_info, ',') > 0 then
        |       substr(t1.device_info, instr(t1.device_info, ',') + 1, length(t1.device_info) - instr(t1.device_info, ','))
        |    else
        |       ''
        |    end) apns_token
        | ,cast(t1.city_id as int) city_id
        | ,cast((case when instr(t1.location, '') > 0 and t1.location != 'undefined,undefined' then
        |     substr(t1.location, 0, instr(t1.location, ',') - 1)
        |   else
        |     0.0
        |   end
        |   ) as double) latitude
        | ,cast((case when instr(t1.location, '') > 0 and t1.location != 'undefined,undefined' then
        |     substr(t1.location, instr(t1.location, ',') + 1, length(t1.location) - instr(t1.location, ','))
        |   else
        |     0.0
        |   end
        |   ) as double) longitude
        | ,cast(t1.update_time as long) update_time
        |from
        | location_log t1
      """.stripMargin.format(targetDate))

    //读取用户行为日志数据
    val actionSchema = StructType(
      List(
        StructField("business", StringType, true),
        StructField("module", StringType, true),
        StructField("action", StringType, true),
        StructField("app_version", StringType, true),
        StructField("app_src", StringType, true),
        StructField("device_type", StringType, true),
        StructField("device_info", StringType, true),
        StructField("os_version", StringType, true),
        StructField("device_model", StringType, true),
        StructField("city_id", StringType, true),
        StructField("open_id", StringType, true),
        StructField("mobile", DoubleType, true),
        StructField("location", StringType, true),
        StructField("event", StringType, true),
        StructField("update_time", DoubleType, true)
      )
    )
    val appOperationLogDF = sqlContext.read.schema(actionSchema).json("/repository/kafka/user_action_app_operation/{date}".replace("{date}", targetDate))
    val wechatOperationLogDF = sqlContext.read.schema(actionSchema).json("/repository/kafka/user_action_wechat_operation/{date}".replace("{date}", targetDate))
    appOperationLogDF.union(wechatOperationLogDF).printSchema()
    appOperationLogDF.union(wechatOperationLogDF).createOrReplaceTempView("operation_log")

    val actionRes = sqlContext.sql(
      """
        |select
        | '%s' day_id
        | ,t1.module platform
        | ,cast(t1.mobile as long) mobile
        | ,t1.open_id
        | ,cast(t1.device_type as int) device_type
        | ,(case when instr(t1.device_info, ',') > 0 then
        |       substr(t1.device_info, 0, instr(t1.device_info, ',') - 1)
        |    else
        |       t1.device_info
        |    end) device_id
        |  ,(case when instr(t1.device_info, ',') > 0 then
        |       substr(t1.device_info, instr(t1.device_info, ',') + 1, length(t1.device_info) - instr(t1.device_info, ','))
        |    else
        |       ''
        |    end) apns_token
        | ,t1.device_model
        | ,t1.os_version
        | ,t1.app_version
        | ,t1.app_src
        | ,cast(t1.city_id as int) city_id
        | ,cast((case when instr(t1.location, '') > 0 and t1.location != 'undefined,undefined' then
        |     substr(t1.location, 0, instr(t1.location, ',') - 1)
        |   else
        |     0.0
        |   end
        |   ) as double) latitude
        | ,cast((case when instr(t1.location, '') > 0 and t1.location != 'undefined,undefined' then
        |     substr(t1.location, instr(t1.location, ',') + 1, length(t1.location) - instr(t1.location, ','))
        |   else
        |     0.0
        |   end
        |   ) as double) longitude
        | ,get_json_object(t1.event, '$.page') page
        | ,get_json_object(t1.event, '$.area') area
        | ,get_json_object(t1.event, '$.url') url
        | ,get_json_object(t1.event, '$.content_id') content_id
        | ,get_json_object(t1.event, '$.content') content
        | ,get_json_object(t1.event, '$.content_list') content_list
        | ,get_json_object(t1.event, '$.etype') etype
        | ,get_json_object(t1.event, '$.event') event
        | ,get_json_object(t1.event, '$.order_type') order_type
        | ,get_json_object(t1.event, '$.order_no') order_no
        | ,get_json_object(t1.event, '$.order_taken') order_taken
        | ,get_json_object(t1.event, '$.keyword') keyword
        | ,get_json_object(t1.event, '$.ctype') ctype
        | ,get_json_object(t1.event, '$.click') click
        | ,get_json_object(t1.event, '$.bc_id') bc_id
        | ,get_json_object(t1.event, '$.food_type_id') food_type_id
        | ,get_json_object(t1.event, '$.shop_type') shop_type
        | ,get_json_object(t1.event, '$.avg_range') avg_range
        | ,get_json_object(t1.event, '$.table_num') table_num
        | ,get_json_object(t1.event, '$.waiting_table') waiting_table
        | ,get_json_object(t1.event, '$.estimated_waiting_time') estimated_waiting_time
        | ,cast(t1.update_time as long) update_time
        | ,'' reserve_1f
        | ,'' reserve_2f
        | ,'' reserve_3f
        | ,'' reserve_4f
        | ,'' reserve_5f
        |from
        | operation_log t1
      """.stripMargin.format(targetDate))
    actionRes.cache()
    actionRes.createOrReplaceTempView("user_action")
    //保存用户行为日志到hdfs
    actionRes.repartition(1).write.mode("overwrite").parquet("/dw/log/c/user_action/" + targetDate)

    //保存用户轨迹数据到hdfs
    locationRes.union(actionRes.select(
      "day_id", "platform", "mobile", "open_id", "device_type", "device_id", "apns_token", "city_id", "latitude", "longitude", "update_time"
    ))
      .where("latitude != 0.0 and longitude != 0.0")
      .distinct().repartition(1).write.mode("overwrite").parquet("/dw/log/c/user_trace/" + targetDate)

    //从行为日志提取用户基本信息(每天)
    val userTableDetail = sqlContext.sql(
      """
        |select distinct
        |	t1.day_id
        |	,cast('0' as long) user_id
        |	,t1.device_type
        |	,t1.device_id
        |	,max(t1.device_model) device_model
        |	,max(t1.apns_token) apns_token
        |	,max(t1.mobile) mobile
        |	,t1.open_id
        |	,max(t1.os_version) os_version
        |	,max(t1.app_version) app_version
        |	,max(t1.app_src) app_src
        |	,max(t1.city_id) city_id
        |	,max(t1.update_time) active_time
        |from
        |	user_action t1
        |group by
        |	t1.day_id
        |	,cast('0' as long)
        |	,t1.device_type
        |	,t1.device_id
        |	,t1.open_id
      """.stripMargin).dropDuplicates(Seq("app_src", "device_type", "device_id", "open_id"))
    //保存用户基本信息(每天)到hdfs
    userTableDetail.createOrReplaceTempView("user_table_detail")
    println("userTableDetail cnt: " + userTableDetail.count())
    userTableDetail.repartition(1).write.mode("overwrite").parquet("/dw/log/c/user_table_detail/" + targetDate)

    //对用户基本信息表进行更新
    //读取历史用户信息
    val userTablePath = "/dw/log/c/user_table"
    val userTable = sqlContext.read.parquet(userTablePath)
    userTable.cache()
    println("userTable cnt: " + userTable.count())
    userTable.createOrReplaceTempView("user_table")
    //找出每天出现的新用户
    val userTableNew = sqlContext.sql(
      """
        |select
        | t3.day_id
        |	,t3.user_id
        |	,t3.device_type
        |	,t3.device_id
        |	,t3.device_model
        |	,t3.apns_token
        |	,t3.mobile
        |	,t3.open_id
        |	,t3.os_version
        |	,t3.app_version
        |	,t3.app_src
        |	,t3.city_id
        |	,t3.active_time
        |from
        |	(select
        |   t1.day_id
        |		,cast('0' as long) user_id
        |		,t1.device_type
        |		,t1.device_id
        |		,t1.device_model
        |		,t1.apns_token
        |		,t1.mobile
        |		,t1.open_id
        |		,t1.os_version
        |		,t1.app_version
        |		,t1.app_src
        |		,t1.city_id
        |		,t1.active_time
        |		,t2.device_type device_type2
        |		,t2.device_id device_id2
        |	from
        |		(select * from user_table_detail where device_id is not null and device_id != '') t1
        |	left join
        |		(select * from user_table where device_id is not null and device_id != '') t2
        |	on
        |		t1.device_type = t2.device_type
        |		and
        |		t1.device_id = t2.device_id) t3
        |where
        |	t3.device_type2 is null
        |	and
        |	t3.device_id2 is null
      """.stripMargin).dropDuplicates(Seq("app_src", "device_type", "device_id", "open_id"))
    //保存
    userTableNew.cache()
    userTableNew.printSchema()
    val userTableNewCnt = userTableNew.count()
    println("userTableNew cnt: " + userTableNewCnt)
    userTableNew.repartition((userTableNewCnt / 3000000 + 1).toInt).write.mode("overwrite").parquet("/dw/log/c/user_table_new/" + targetDate)

    //将新用户与老用户合并
    val userTableAll = sqlContext.sql(
      """
        |select distinct
        |	cast('0' as long) user_id
        |	,t1.device_type
        |	,t1.device_id
        |	,t1.device_model
        |	,t1.apns_token
        |	,t1.mobile
        |	,t1.open_id
        |	,t1.os_version
        |	,t1.app_version
        |	,t1.app_src
        |	,'' city_id_list
        |	,t1.city_id
        |	,cast('0' as long) create_time
        |	,t1.active_time
        |from
        |	user_table_detail t1
      """.stripMargin)
      .union(userTable)
      .dropDuplicates(Seq("app_src", "device_type", "device_id", "open_id"))
    //保存
    userTableAll.cache()
    userTableAll.printSchema()
    val userTableCnt = userTableAll.count()
    println("userTableAll cnt: " + userTableCnt)
    userTableAll.repartition((userTableCnt / 3000000 + 1).toInt).write.mode("overwrite").parquet(userTablePath)

  }
}



