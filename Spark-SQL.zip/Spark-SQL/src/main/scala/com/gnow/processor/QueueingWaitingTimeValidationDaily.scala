package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import com.gnow.{DB, Processor}
import org.apache.spark.sql.types._

/**
  * 预估等待新模型用 评估模型的准确度 从日志计算得到
  *
  */
class QueueingWaitingTimeValidationDaily extends Processor {

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from queuemode
        |where createdate like 'datedate%'
      """.stripMargin.toString.replaceAll("datedate", targetDate)
    println("begin" + sql)
    DBEraser.remove(DB.MYSQL_24_ASSOCIATOR, sql)
    println("end" + sql)

  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

  }

  def process(targetDate: String, input: String, output: String) = {
    //订单表
    rdb.queueing.df(rdb.queueing.QUEUEING_TABLE,targetDate)
    //老模型的日志
    val schema = "shop_id,queue_id,serial_id,timing_type,waiting_number,estimated_time,create_time"
    repository.kafka.df(repository.kafka.QUEUEING_WAITING_TIME, targetDate, schema)
    //新模型的日志
    val schemaNew = StructType(
      List(
        StructField("shopid", IntegerType, true),
        StructField("queueid", IntegerType, true),
        StructField("serialId", StringType, true),
        StructField("currtime", StringType, true),
        StructField("type", StringType, true),
        StructField("estimatetime", IntegerType, true),
        StructField("estimatetime_old", IntegerType, true)
      )
    )
    val newModelDF = sqlContext.read.schema(schemaNew)
      .json("/repository/kafka/estimatewaittime_estimwait_validation/%s/*".format(targetDate))
      .where("serialid != ''")
    newModelDF.cache()
    newModelDF.printSchema()
    newModelDF.createOrReplaceTempView("estimatewaittime_estimwait_validation")
    newModelDF.show(200, false)

    //只使用日志来算
    val tmpRes = sqlContext.sql(
      """
        |select distinct
        | cast(null as int) id,
        | t4.serialId,
        | t4.queueid,
        |	t4.shopid,
        | t5.waiting_number waitpeople,
        | '0' number,
        | t4.lasttime,
        | t4.createdate,
        |	t4.realtime,
        |	t4.estimatetime newtime,
        |	floor(t5.estimated_time/60.0) oldtime
        |from
        |	(select
        |		t2.shopid,
        |		t2.queueid,
        |		t2.serialId,
        |   t2.currtime createdate,
        |   t3.currtime lasttime,
        |		floor((unix_timestamp(t3.currtime) - unix_timestamp(t2.currtime))/60.0) realtime,
        |		t2.estimatetime
        |	from
        |		(select
        |			t1.*
        |		from
        |			estimatewaittime_estimwait_validation t1
        |		where
        |			t1.type = 'alloc') t2
        |	inner join
        |		(select
        |			t1.*
        |		from
        |			estimatewaittime_estimwait_validation t1
        |		where
        |			t1.type = 'call') t3
        |	on
        |		t2.shopid = t3.shopid
        |		and
        |		t2.queueid = t3.queueid
        |		and
        |		t2.serialId = t3.serialId) t4
        |inner join
        |	(select * from queueing_waiting_time where timing_type = '0') t5
        |on
        |	t4.shopid = t5.shop_id
        |	and
        |	t4.queueid = t5.queue_id
        |	and
        |	cast(t4.serialId as double) = t5.serial_id
      """.stripMargin.format(targetDate, targetDate))
    tmpRes.show(200)
    tmpRes.createOrReplaceTempView("tmp_res")
    val tmpRes2 = sqlContext.sql(
      """
        |select
        |	t2.id,
        |	t2.serialId,
        |	t2.queueid,
        |	t2.shopid,
        |	t2.waitpeople,
        |	t2.number,
        |	t2.lasttime,
        |	t2.createdate,
        |	t2.realtime,
        |	t2.newtime,
        |	t2.oldtime,
        |	(case when
        |		(
        |			unix_timestamp(t2.lasttime) <= t2.lasttime_b1
        |     and
        |			unix_timestamp(t2.lasttime) <= t2.lasttime_b2
        |     and
        |			unix_timestamp(t2.lasttime) <= t2.lasttime_b3
        |     and
        |			unix_timestamp(t2.lasttime) <= t2.lasttime_b4
        |     and
        |			unix_timestamp(t2.lasttime) <= t2.lasttime_b5
        |			and
        |			unix_timestamp(t2.lasttime) >= t2.lasttime_p1
        |     and
        |			unix_timestamp(t2.lasttime) >= t2.lasttime_p2
        |     and
        |			unix_timestamp(t2.lasttime) >= t2.lasttime_p3
        |     and
        |			unix_timestamp(t2.lasttime) >= t2.lasttime_p4
        |     and
        |			unix_timestamp(t2.lasttime) >= t2.lasttime_p5
        |			) then
        |		'2'
        |	else
        |		'1'
        | end) is_noise
        |from
        |	(select
        |		t1.id,
        |		t1.serialId,
        |		t1.queueid,
        |		t1.shopid,
        |		t1.waitpeople,
        |		t1.number,
        |		t1.lasttime,
        |		t1.createdate,
        |		t1.realtime,
        |		t1.newtime,
        |		t1.oldtime,
        |		(lead(unix_timestamp(t1.lasttime), 1, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b1,
        |		(lead(unix_timestamp(t1.lasttime), 2, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b2,
        |		(lead(unix_timestamp(t1.lasttime), 3, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b3,
        |		(lead(unix_timestamp(t1.lasttime), 4, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b4,
        |		(lead(unix_timestamp(t1.lasttime), 5, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_b5,
        |		(lag(unix_timestamp(t1.lasttime), 1, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p1,
        |		(lag(unix_timestamp(t1.lasttime), 2, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p2,
        |		(lag(unix_timestamp(t1.lasttime), 3, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p3,
        |		(lag(unix_timestamp(t1.lasttime), 4, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p4,
        |		(lag(unix_timestamp(t1.lasttime), 5, unix_timestamp(t1.lasttime)) over(partition by t1.shopid, t1.queueid order by unix_timestamp(t1.createdate))) lasttime_p5
        |	from
        |		tmp_res t1) t2
      """.stripMargin)
    tmpRes2.show()
    tmpRes2.createOrReplaceTempView("tmp_res2")

    val res = sqlContext.sql(
      """
        |select
        |	t1.id,
        |	t1.serialId,
        |	t1.queueid,
        |	t1.shopid,
        |	t1.waitpeople,
        |	nvl(t2.number_, t1.number) number,
        |	t1.lasttime,
        |	t1.createdate,
        |	t1.realtime,
        |	t1.newtime,
        |	t1.oldtime,
        |	t1.is_noise
        |from
        |	tmp_res2 t1
        |left join
        |	(select distinct serial_id, number_ from queueing_table) t2
        |on
        |	t1.serialId = t2.serial_id
      """.stripMargin)
    res.show()

    RDBWriter.overwrite(res.repartition(1), DB.MYSQL_24_ASSOCIATOR, "queuemode")

  }
}
