package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.SQLSecondPayBack
import com.gnow.{DB, Processor, Utility}

class SecondPayBackDaily extends Processor {
  val SECOND_PAY_BACK = "second_pay_back"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from second_pay_back
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLSecondPayBack.getSQL(targetDate)
    val tbl = rdb.paying.df(rdb.paying.COM_PAY_BACK)
    val res = Utility.sql(tbl, sql)
    RDBWriter.save(res, DB.ORACLE_37_BWSWD, SECOND_PAY_BACK)
  }
}
