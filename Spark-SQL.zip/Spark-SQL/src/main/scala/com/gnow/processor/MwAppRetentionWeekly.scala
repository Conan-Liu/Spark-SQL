package com.gnow.processor

import cn.mwee.util.DateUtils
import com.gnow.config.PathUtil
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 10/04/2018.
  */
class MwAppRetentionWeekly extends Processor {
  var res: DataFrame = _
  val db = DB.ORACLE_37_BWSWD
  val destTable = "DM_MONITOR_APP_USER_RETEN_W"

  def reset(targetDate: String): Unit = {

  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

  }

  def process(targetDate: String, input: String, output: String) = {
    //计算日期
    val dayM1 = DateUtils.getDay(targetDate, -7)
    val dayM2 = DateUtils.getDay(targetDate, -14)
    val dayM3 = DateUtils.getDay(targetDate, -21)
    val dayM4 = DateUtils.getDay(targetDate, -28)
    val dayM5 = DateUtils.getDay(targetDate, -35)
    val dayM6 = DateUtils.getDay(targetDate, -42)
    val dayM7 = DateUtils.getDay(targetDate, -49)
    val dayM8 = DateUtils.getDay(targetDate, -56)
    val dayM9 = DateUtils.getDay(targetDate, -63)
    val dayM10 = DateUtils.getDay(targetDate, -70)
    //读取日志数据
    //新用户数据
    val dayM0NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(targetDate))
    val dayM1NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM1))
    val dayM2NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM2))
    val dayM3NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM3))
    val dayM4NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM4))
    val dayM5NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM5))
    val dayM6NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM6))
    val dayM7NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM7))
    val dayM8NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM8))
    val dayM9NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM9))
    val dayM10NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(dayM10))
    dayM0NewDF.createOrReplaceTempView("day_m0_new")
    dayM1NewDF.createOrReplaceTempView("day_m1_new")
    dayM2NewDF.createOrReplaceTempView("day_m2_new")
    dayM3NewDF.createOrReplaceTempView("day_m3_new")
    dayM4NewDF.createOrReplaceTempView("day_m4_new")
    dayM5NewDF.createOrReplaceTempView("day_m5_new")
    dayM6NewDF.createOrReplaceTempView("day_m6_new")
    dayM7NewDF.createOrReplaceTempView("day_m7_new")
    dayM8NewDF.createOrReplaceTempView("day_M8_new")
    dayM9NewDF.createOrReplaceTempView("day_M9_new")
    dayM10NewDF.createOrReplaceTempView("day_M10_new")
    //活跃用户数据
    val dayM0ActiveDF = sqlContext.read.parquet("/dw/log/c/user_table_detail/" + PathUtil.getPath4Weekly(targetDate))
    dayM0ActiveDF.createOrReplaceTempView("day_m0_active")

    //从hdfs读取历史计算结果
    val userRetenHisDF = sqlContext.read.parquet("/dw/log/c/user_retention_weekly")
    userRetenHisDF.cache()
    println("userRetenHisDF cnt: " + userRetenHisDF.count())
    userRetenHisDF.createOrReplaceTempView("user_retention_weekly")
    val userRetenOldDF = userRetenHisDF.where("day_id not in ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')".format(targetDate, dayM1, dayM2, dayM3, dayM4, dayM5, dayM6, dayM7, dayM8, dayM9, dayM10))

    //计算上周新用户数
    val dayM0RetenDF = sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	t3.app_src src_id,
        |	t3.users_new,
        |	cast(null as long) reten_1w,
        |	cast(null as long) reten_2w,
        |	cast(null as long) reten_3w,
        |	cast(null as long) reten_4w,
        |	cast(null as long) reten_5w,
        |	cast(null as long) reten_6w,
        |	cast(null as long) reten_7w,
        |	cast(null as long) reten_8w,
        |	cast(null as long) reten_9w,
        |	cast(null as long) reten_10w
        |from
        |	(select
        |		'%s' day_id,
        |		t2.app_src,
        |		count(distinct t2.device_id) users_new
        |	from
        |		(select
        |			t1.day_id,
        |			t1.app_src,
        |			t1.device_id
        |		from
        |			day_m0_new t1
        |		where
        |			t1.app_src is not null
        |			and
        |			t1.device_id is not null
        |			and
        |			t1.device_id != ''
        |			) t2
        |	group by
        |		'%s',
        |		t2.app_src) t3
      """.stripMargin.format(targetDate, targetDate))
    dayM0RetenDF.printSchema()
    dayM0RetenDF.show()

    //计算用户留存
    //过去1周
    val dayM1RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t4.reten_1w,
        |	t5.reten_2w,
        |	t5.reten_3w,
        |	t5.reten_4w,
        |	t5.reten_5w,
        |	t5.reten_6w,
        |	t5.reten_7w,
        |	t5.reten_8w,
        |	t5.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_1w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m1_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM1, dayM1))
    dayM1RetenDF.show()
    //过去2周
    val dayM2RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t4.reten_2w,
        |	t5.reten_3w,
        |	t5.reten_4w,
        |	t5.reten_5w,
        |	t5.reten_6w,
        |	t5.reten_7w,
        |	t5.reten_8w,
        |	t5.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_2w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m2_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM2, dayM2))
    dayM2RetenDF.show()
    //过去3周
    val dayM3RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t5.reten_2w,
        |	t4.reten_3w,
        |	t5.reten_4w,
        |	t5.reten_5w,
        |	t5.reten_6w,
        |	t5.reten_7w,
        |	t5.reten_8w,
        |	t5.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_3w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m3_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM3, dayM3))
    dayM3RetenDF.show()
    //过去4周
    val dayM4RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t5.reten_2w,
        |	t5.reten_3w,
        |	t4.reten_4w,
        |	t5.reten_5w,
        |	t5.reten_6w,
        |	t5.reten_7w,
        |	t5.reten_8w,
        |	t5.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_4w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m4_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM4, dayM4))
    dayM4RetenDF.show()
    //过去5周
    val dayM5RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t5.reten_2w,
        |	t5.reten_3w,
        |	t5.reten_4w,
        |	t4.reten_5w,
        |	t5.reten_6w,
        |	t5.reten_7w,
        |	t5.reten_8w,
        |	t5.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_5w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m5_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM5, dayM5))
    dayM5RetenDF.show()
    //过去6周
    val dayM6RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t5.reten_2w,
        |	t5.reten_3w,
        |	t5.reten_4w,
        |	t5.reten_5w,
        |	t4.reten_6w,
        |	t5.reten_7w,
        |	t5.reten_8w,
        |	t5.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_6w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m6_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM6, dayM6))
    dayM6RetenDF.show()
    //过去7周
    val dayM7RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t5.reten_2w,
        |	t5.reten_3w,
        |	t5.reten_4w,
        |	t5.reten_5w,
        |	t5.reten_6w,
        |	t4.reten_7w,
        |	t5.reten_8w,
        |	t5.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_7w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m7_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM7, dayM7))
    dayM7RetenDF.show()
    //过去8周
    val dayM8RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t5.reten_2w,
        |	t5.reten_3w,
        |	t5.reten_4w,
        |	t5.reten_5w,
        |	t5.reten_6w,
        |	t5.reten_7w,
        |	t4.reten_8w,
        |	t5.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_8w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_M8_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM8, dayM8))
    dayM8RetenDF.show()
    //过去9周
    val dayM9RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t5.reten_2w,
        |	t5.reten_3w,
        |	t5.reten_4w,
        |	t5.reten_5w,
        |	t5.reten_6w,
        |	t5.reten_7w,
        |	t5.reten_8w,
        |	t4.reten_9w,
        |	t5.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_9w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_M9_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM9, dayM9))
    dayM9RetenDF.show()
    //过去10周
    val dayM10RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1w,
        |	t5.reten_2w,
        |	t5.reten_3w,
        |	t5.reten_4w,
        |	t5.reten_5w,
        |	t5.reten_6w,
        |	t5.reten_7w,
        |	t5.reten_8w,
        |	t5.reten_9w,
        |	t4.reten_10w
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_10w
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_M10_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_weekly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM9, dayM9))
    dayM10RetenDF.show()

    //将新计算的用户留存和历史值合并
    res =
      userRetenOldDF
      .union(dayM0RetenDF)
      .union(dayM1RetenDF)
      .union(dayM2RetenDF)
      .union(dayM3RetenDF)
      .union(dayM4RetenDF)
      .union(dayM5RetenDF)
      .union(dayM6RetenDF)
      .union(dayM7RetenDF)
      .union(dayM8RetenDF)
      .union(dayM9RetenDF)
      .union(dayM10RetenDF)
    res.show()

    //保存新结果到hdfs
    res.repartition(1).write.mode("overwrite").parquet("/dw/log/c/user_retention_weekly")

    //保存新结果到Oracle(先删除历史数据)
    val sql = "delete from %s where day_id in ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')".format(destTable, targetDate, dayM1, dayM2, dayM3, dayM4, dayM5, dayM6, dayM7, dayM8, dayM9, dayM10)
    println("操作数据库：" + db.toString)
    println("执行SQL：" + sql)
    DBEraser.remove(db, sql)

    println("保存到db")
    RDBWriter.overwrite(res.coalesce(1), db, destTable)
    println("Happy Ending!")

  }
}




