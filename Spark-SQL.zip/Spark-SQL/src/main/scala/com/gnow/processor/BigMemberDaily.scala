package com.gnow.processor

import java.util.UUID

import com.gnow.config.{Constants, FileFormat, SaveMode}
import com.gnow.persistence.HDFSWriter
import com.gnow.schema.rdb
import com.gnow.{Processor, Utility}
import org.apache.spark.SparkContext
import org.apache.spark.sql.{DataFrame, SQLContext}

class BigMemberDaily extends Processor with Serializable {
  var allByUion: DataFrame = null
  var commonMobile: DataFrame = null
  var joinResultWithMobile: DataFrame = null
  var withoutMobile: DataFrame = null
  var joinResultWithoutMobile: DataFrame = null
  var memberID: DataFrame = null
  var finalResult: DataFrame = null
  var userTableDF: DataFrame = null
  var bookTableDF: DataFrame = null
  var optimizedUserTable: DataFrame = null
  var optimizedWechatTable: DataFrame = null
  var optimizedBookTable: DataFrame = null
  var wechatTableDF: DataFrame = null
  var memberIDWithoutMobile: DataFrame = null

  def reset(targetDate: String): Unit = {

  }

  def execute(targetDate: String, input: String, output: String) = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    reset(targetDate)
    process()
  }

  def process() = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    def uuid(): String = {
      UUID.randomUUID().toString()
    }
    sqlContext.udf.register("uuid", uuid)
    userTableDF = rdb.basic.df(rdb.basic.USER_TABLE)
    val OPTIMIZED_USER_TABLE = "OPTIMIZED_USER_TABLE"
    optimizedUserTable = Utility.registerTableWithSQL(sqlContext,
      """
      select
      distinct
      "QUEUEING" as business, concat('{\"user_id\":\"', user_id, '\"}') as pk,
      mobile_phone_bind as mobile
      from %s
      """.format(rdb.basic.USER_TABLE), OPTIMIZED_USER_TABLE)

    wechatTableDF = rdb.basic.df(rdb.basic.WX_ACCOUNT_TABLE)
    val OPTIMIZED_WECHAT_TABLE = "OPTIMIZED_WECHAT_TABLE"
    optimizedWechatTable = Utility.registerTableWithSQL(sqlContext,
      """
      select
      distinct
      "WECHAT" as business, concat('{\"open_id\":\"', open_id, '\"}') as pk,
      phone as mobile
      from %s
      """.format(rdb.basic.WX_ACCOUNT_TABLE), OPTIMIZED_WECHAT_TABLE)

    bookTableDF = rdb.booking.df(rdb.booking.BOOKING_TABLE)
    val BOOKING_USER_TABLE = Utility.registerTableWithSQL(sqlContext,
      """
      select
      distinct
      name_, sex, user_id, phone
      from %s
      """.format(rdb.booking.BOOKING_TABLE), "booking_user_table")

    //bookTableDF = rdb.booking.df(sqlContext, rdb.booking.BOOKING_USER_TABLE)
    val OPTIMIZED_BOOK_TABLE = "OPTIMIZED_BOOK_TABLE"
    optimizedBookTable = Utility.registerTableWithSQL(sqlContext,
      """
      select
      distinct
      "BOOKING" as business, concat('{\"phone\":\"', trim(phone), '\"}') as pk,
      trim(phone) as mobile
      from booking_user_table
      """, OPTIMIZED_BOOK_TABLE)

    val uniontmp = optimizedUserTable.unionAll(optimizedWechatTable)
    allByUion = uniontmp.unionAll(optimizedBookTable)
    val ALL_BY_UNION = "ALL_BY_UNION"
    allByUion.registerTempTable(ALL_BY_UNION)

    val COMMON_MOBILE = "COMMON_MOBILE"
    commonMobile = Utility.registerTableWithSQL(sqlContext,
      """
       select
       mobile,count(distinct business) count
       from %s
       where mobile is not null
       and mobile != ""
       group by mobile
      """.format(ALL_BY_UNION), COMMON_MOBILE)

    val MEMBER_ID = "MEMBER_ID"
    memberID = Utility.registerTableWithSQL(sqlContext,
      """
        select
        uuid() big_member_id,
        *
        from
        %s
        where 1 = 1
      """.format(COMMON_MOBILE), MEMBER_ID)

    val JOIN_RESULT_WITH_MOBILE = "JOIN_RESULT_WITH_MOBILE"
    joinResultWithMobile = Utility.registerTableWithSQL(sqlContext,
      """
      select
      a.big_member_id,
      b.mobile,
      b.business,
      b.pk
      from
      %s b
      join
      %s a
      on b.mobile = a.mobile
      """.format(ALL_BY_UNION, MEMBER_ID), JOIN_RESULT_WITH_MOBILE)


    val WITHOUT_MOBILE = "WITHOUT_MOBILE"
    withoutMobile = Utility.registerTableWithSQL(sqlContext,
      """
      select
        *
        from %s
        where
        mobile is null
        or
        mobile = ""
      """.format(ALL_BY_UNION), WITHOUT_MOBILE)

    val MEMBER_ID_WITHOUT_MOBILE = "MEMBER_ID_WITHOUT_MOBILE"
    memberIDWithoutMobile = Utility.registerTableWithSQL(sqlContext,
      """
        select
        uuid() big_member_id,
        *
        from
        %s
        where 1 = 1
      """.format(WITHOUT_MOBILE), MEMBER_ID_WITHOUT_MOBILE)

    val JOIN_RESULT_WITHOUT_MOBILE = "JOIN_RESULT_WITHOUT_MOBILE"
    joinResultWithoutMobile = Utility.registerTableWithSQL(sqlContext,
      """
        select
        b.big_member_id,
        a.mobile,
        a.business,
        a.pk
        from
        %s a
        join
        %s b
        on a.pk = b.pk
        and (a.mobile is null or a.mobile = "")
      """.format(ALL_BY_UNION, MEMBER_ID_WITHOUT_MOBILE), JOIN_RESULT_WITHOUT_MOBILE)

    finalResult = joinResultWithMobile.unionAll(joinResultWithoutMobile)
    val NEED_FORMATTING: String = "need_formatting"
    finalResult.registerTempTable(NEED_FORMATTING)

    val ready4save = Utility.registerTableWithSQL(sqlContext,
      """
        select
        t.big_member_id,
        t.mobile,
        t.business,
        named_struct(
          "user_id", get_json_object(t.pk, "$.user_id"),
          "open_id", get_json_object(t.pk, "$.open_id"),
          "phone", get_json_object(t.pk, "$.phone")
          ) pk
        from
        %s t
      """.format(NEED_FORMATTING), "ready4save")
    val outPath = s"${Constants.REPOSITORY_TRANSFORM_HOME}/big_member"
    HDFSWriter.save(ready4save, outPath, FileFormat.JSON, SaveMode.OVERWRITE, 10)

    finalResult.count()
  }
}
