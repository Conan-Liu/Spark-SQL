package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.sql.SQLUserAmount
import com.gnow.{DB, Processor, Utility}

class UserAmount4AppDaily extends Processor {
  val USER_AMOUNT = "user_amount"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from user_amount
        |where create_date='%s'
        |and c_type='%s'
        |and device_type='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate, "0", "0"))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLUserAmount.getSQL4APP(targetDate)
    val schema = "device_id,create_time,phase"
    val df = repository.kafka.df(repository.kafka.BASIC_APP_TRACE, targetDate,schema)
    val res = Utility.sql(df, sql)
    RDBWriter.save(res, DB.ORACLE_37_BWSWD, USER_AMOUNT)
  }
}
