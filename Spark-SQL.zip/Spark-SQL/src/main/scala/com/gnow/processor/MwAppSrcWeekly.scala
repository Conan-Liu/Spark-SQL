package com.gnow.processor

import com.gnow.config.PathUtil
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 10/04/2018.
  */
class MwAppSrcWeekly extends Processor {
  var res: DataFrame = _
  val db = DB.ORACLE_37_BWSWD
  val destTable = "DM_MONITOR_APP_USER_SRC"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where day_id = '%s' and interval_type = '1'".format(destTable, targetDate)
    println("操作数据库：" + db.toString)
    println("执行SQL：" + sql)
    DBEraser.remove(db, sql)

  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res.coalesce(1), db, destTable)
    println("Happy Ending!")

  }

  def process(targetDate: String, input: String, output: String) = {
    //读取日志数据
    val newDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Weekly(targetDate))
    newDF.createOrReplaceTempView("user_table_new")
    val activeDF = sqlContext.read.parquet("/dw/log/c/user_table_detail/" + PathUtil.getPath4Weekly(targetDate))
    activeDF.createOrReplaceTempView("user_table_detail")

    //计算每天的渠道情况
    res = sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	'1' interval_type,
        |	t3.app_src src_id,
        |	t3.users_new,
        |	t4.users_active
        |from
        |	(select
        |		'%s' day_id,
        |		t1.app_src,
        |		count(distinct t1.device_id) users_new
        |	from
        |		(select * from user_table_new where device_id is not null and device_id != '' and app_src not in('inhouse', 'InHouse')) t1
        |	group by
        |		'%s',
        |		t1.app_src) t3
        |join
        |	(select
        |		'%s' day_id,
        |		t2.app_src,
        |		count(distinct t2.device_id) users_active
        |	from
        |		(select * from user_table_detail where device_id is not null and device_id != '' and app_src not in('inhouse', 'InHouse')) t2
        |	group by
        |		'%s',
        |		t2.app_src) t4
        |on
        |	t3.day_id = t4.day_id
        |	and
        |	t3.app_src = t4.app_src
      """.stripMargin.format(targetDate, targetDate, targetDate, targetDate))

  }
}




