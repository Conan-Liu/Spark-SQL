package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.sql.SQLUserActive
import com.gnow.{DB, Processor, Utility}

class UserActive4WechatWeekly extends Processor {
  val USER_ACTIVE_RATE = "user_active_rate"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from user_active_rate
        |where create_date='%s'
        |and device_type='%s'
        |and time_interval='%s'
        |and phase != '-2'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate, "1", "1"))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLUserActive.getSQL4WechatWeekly(targetDate)
    val schema = "phase,open_id,create_time"
    val df = repository.kafka.df4Weekly(repository.kafka.BASIC_WECHAT_TRACE, targetDate, schema)
    val res = Utility.sql(df, sql)
    RDBWriter.save(res, DB.ORACLE_37_BWSWD, USER_ACTIVE_RATE)
  }
}
