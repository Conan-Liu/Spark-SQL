package com.gnow.processor

import cn.mwee.util.FunnelUtils
import com.gnow.config.PathUtil
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.processor.vo.{AppLog, AppNode}
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 10/04/2018.
  */
class MwAppFunnelWeekly extends Processor {
  var res: DataFrame = _
  val db = DB.ORACLE_37_BWSWD
  val destTable = "DM_MONITOR_APP_FUNNEL"

  def reset(targetDate: String): Unit = {
    val sql = "delete from %s where day_id = '%s' and interval_type = '1'".format(destTable, targetDate)
    println("操作数据库：" + db.toString)
    println("执行SQL：" + sql)
    DBEraser.remove(db, sql)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res.coalesce(1), db, destTable)
    println("Happy Ending!")

  }

  def process(targetDate: String, input: String, output: String) = {
    import sqlContext.implicits._
    //读取日志数据
    val userActionDF = sqlContext.read.parquet("/dw/log/c/user_action/" + PathUtil.getPath4Weekly(targetDate))
    //构造测试数据
    val tdDF = sqlContext.sparkContext.parallelize(Seq(
      //开屏广告
      AppLog("user1", "", "app_launch", "", "", "click_btn_ad", "1", 258, "")
      ,AppLog("user1", "7236", "webapp_guess_list", "", "", "", "2", 258, "")
      ,AppLog("user1", "7236", "detail_shop", "", "", "controller_init", "3", 258, "")
      ,AppLog("user1", "", "app_launch", "", "", "click_btn_ad", "4", 258, "")
      ,AppLog("user1", "7236", "webapp_guess_list", "", "", "", "5", 258, "")


    )).toDF()
    tdDF.show(100, false)
    //访问节点标注
    val markedLogDF =
    //      tdDF
      userActionDF
        .select("device_id", "url", "page", "content_id", "etype", "event", "update_time", "city_id", "area", "ctype").rdd
        .flatMap(row =>{
          var userId = ""
          if(row.get(0) != null){
            userId = row.get(0).toString
          }
          var url = ""
          if(row.get(1) != null){
            url = row.get(1).toString
          }
          var page = ""
          if(row.get(2) != null){
            page = row.get(2).toString
          }
          var contentId = ""
          if(row.get(3) != null){
            contentId = row.get(3).toString
          }
          var etype = ""
          if(row.get(4) != null){
            etype = row.get(4).toString
          }
          var event = ""
          if(row.get(5) != null){
            event = row.get(5).toString
          }
          var time = "0"
          if(row.get(6) != null){
            time = row.get(6).toString
            if(time.equals("")){
              time = "0"
            }
          }
          var cityId = "0"
          if(row.get(7) != null){
            cityId = row.get(7).toString
            if(time.equals("")){
              cityId = "0"
            }
          }
          var area = "0"
          if(row.get(8) != null){
            area = row.get(8).toString
            if(area.equals("")){
              area = ""
            }
          }
          var ctype = ""
          if(row.get(9) != null){
            ctype = row.get(9).toString
          }
          //标注
          (page, area, event, ctype) match {
            /**
              * 标识访问路径，切割访问路径，隔离访问路径相关
              */
            //TabBar点击
            case (_, "TabBar", "click_item", _) => List(AppNode(userId, "TabBar","","TabBar点击",contentId,"",0, time.toLong, cityId.toLong, area))

            /**
              * 详情页转化率与排队转化率相关
              */
            //开屏广告
            case ("app_launch", _, "click_btn_ad", _) => List(AppNode(userId, "app_launch_click_btn_ad","","开屏广告",contentId,"",0, time.toLong, cityId.toLong, area))
            //搜索页面
            case ("search_normal", _, "click_navi_searchbar_inputting", _) => List(AppNode(userId, "search_page","","搜索页面",contentId,"",0, time.toLong, cityId.toLong, area))
            case ("search_senior", _, "click_btn_senior", _) => List(AppNode(userId, "search_page","","搜索页面",contentId,"",0, time.toLong, cityId.toLong, area))
            //首页banner位
            case ("tb_home", "banner", _, _) => List(AppNode(userId, "tb_home_banner","","首页banner位",contentId,"",0, time.toLong, cityId.toLong, area))
            //4大场景
            case ("tb_home", "action", _, _) => List(AppNode(userId, "tb_home_action","","4大场景",contentId,"",0, time.toLong, cityId.toLong, area))
            //首页运营位
            case ("tb_home", "home_ad", _, _) => List(AppNode(userId, "tb_home_home_ad","","首页运营位",contentId,"",0, time.toLong, cityId.toLong, area))
            //首页商圈区域
            case ("tb_home", "business_circle", _, _) => List(AppNode(userId, "tb_home_business_circle","","首页商圈区域",contentId,"",0, time.toLong, cityId.toLong, area))
            //所有菜系
            case ("tb_home", "cooking", _, _) => List(AppNode(userId, "tb_home_cooking","","所有菜系",contentId,"",0, time.toLong, cityId.toLong, area))
            //普通运营位
            case ("tb_home", "operation", _, _) => List(AppNode(userId, "tb_home_operation","","普通运营位",contentId,"",0, time.toLong, cityId.toLong, area))
            //猜你喜欢
            case ("webapp_guess_list", _, "click_guess_list", _) => List(
              AppNode(userId, "webapp_guess_list_click_guess_list","","猜你喜欢",contentId,"",0, time.toLong, cityId.toLong, area),
              AppNode(userId, "shop_list","","餐厅列表页",contentId,"",0, time.toLong + 1, cityId.toLong, area))
            case ("tb_home", "guess_you_like", _, _) => List(AppNode(userId, "tb_home_guess_you_like","","猜你喜欢",contentId,"",0, time.toLong, cityId.toLong, area))
            //热门餐厅区域
            case ("tb_home", "hot_shop", _, _) => List(AppNode(userId, "tb_home_hot_shop","","热门餐厅区域",contentId,"",0, time.toLong, cityId.toLong, area))
            //精选商家
            case ("tb_home", "main_shop", _, _) => List(
              AppNode(userId, "tb_home_main_shop","","精选餐厅区域",contentId,"",0, time.toLong, cityId.toLong, area))
            //附近餐厅列表
            case ("tb_near", _, "TabBar", _) => List(AppNode(userId, "tb_near","","附近餐厅列表",contentId,"",0, time.toLong, cityId.toLong, area))
            //预约订座列表
            case ("list_shops_book", _, "controller_init", _) => List(AppNode(userId, "list_shops_book","","预约订座列表",contentId,"",0, time.toLong, cityId.toLong, area))
            //排队取号列表
            case ("list_shops_queue", _, "controller_init", _) => List(AppNode(userId, "list_shops_queue","","排队取号列表",contentId,"",0, time.toLong, cityId.toLong, area))
            //排行榜
            case ("webapp_rank", _, "click_top3_rank", _) => List(AppNode(userId, "tb_ranking","","排行榜",contentId,"",0, time.toLong, cityId.toLong, area))
            //感兴趣的餐厅
            case ("list_shops_fave", _, "controller_init", _) => List(
              AppNode(userId, "list_shops_fave","","感兴趣的餐厅",contentId,"",0, time.toLong, cityId.toLong, area),
              AppNode(userId, "shop_list","","餐厅列表页",contentId,"",0, time.toLong + 1, cityId.toLong, area))
            //餐厅列表页 9种
            case ("search_result", _, "controller_init", _) => List(AppNode(userId, "shop_list","","餐厅列表页",contentId,"",0, time.toLong, cityId.toLong, area))//搜索结果页
            case ("search_normal", _, "click_item", "1") => List(
              AppNode(userId, "search_page","","搜索页面",contentId,"",0, time.toLong, cityId.toLong, area),
              AppNode(userId, "shop_list","","餐厅列表页",contentId,"",0, time.toLong + 1, cityId.toLong, area))//搜索栏提示点击
            case ("list_shops_branch", _, "controller_init", _) => List(AppNode(userId, "shop_list","","餐厅列表页",contentId,"",0, time.toLong, cityId.toLong, area))//品牌分店列表
            //餐厅详情页
            case ("detail_shop", _, "controller_init", _) => List(AppNode(userId, "detail_shop","","餐厅详情页",contentId,"",0, time.toLong, cityId.toLong, area))

            /**
              * 排队转化率相关
              */
            //推荐餐厅
            case ("search_result", "recommend_shop", _, _) => List(
              AppNode(userId, "shop_recommend","","推荐餐厅",contentId,"",0, time.toLong, cityId.toLong, area),
              AppNode(userId, "shop_list","","餐厅列表页",contentId,"",0, time.toLong + 1, cityId.toLong, area))
            case ("search_result_senior", "recommend_shop", _, _) => List(
              AppNode(userId, "shop_recommend","","推荐餐厅",contentId,"",0, time.toLong, cityId.toLong, area),
              AppNode(userId, "shop_list","","餐厅列表页",contentId,"",0, time.toLong + 1, cityId.toLong, area))
            //免费取号订单
            case ("detail_order_queue", _, _, _) => List(AppNode(userId, "queue_free","","免费取号订单",contentId,"",0, time.toLong, cityId.toLong, area))
            //支付页
            case ("pay_queue_service", _, "click_btn_pay", _) => List(AppNode(userId, "pay_queue","","支付页",contentId,"",0, time.toLong, cityId.toLong, area))
            //付费取号订单
            case ("queue_service", _, "queue_success", _) => List(AppNode(userId, "queue_fee","","付费取号订单",contentId,"",0, time.toLong, cityId.toLong, area))

            /**
              * 预订转化率相关
              */
            //专题页
            case ("h5_special_V1", _, _, _) => List(AppNode(userId, "h5_special","","专题页",contentId,"",0, time.toLong, cityId.toLong, area))
            case ("h5_special_V2", _, _, _) => List(AppNode(userId, "h5_special","","专题页",contentId,"",0, time.toLong, cityId.toLong, area))
            //在线预约页
            case ("detail_shop", "Book", _, _) => List(AppNode(userId, "reservation_order","","在线预约页",contentId,"",0, time.toLong, cityId.toLong, area))
            //普通预订订单
            case ("reservation_order_detail", _, "reservation", _) => List(AppNode(userId, "reservation_order_free","","普通预订订单",contentId,"",0, time.toLong, cityId.toLong, area))
            //定金支付页
            case ("pay_book", _, "click_btn_pay", _) => List(AppNode(userId, "pay_book","","定金支付页",contentId,"",0, time.toLong, cityId.toLong, area))
            //定金预订订单
            case ("book_service", _, "book_success", _) => List(AppNode(userId, "reservation_order_fee","","定金预订订单",contentId,"",0, time.toLong, cityId.toLong, area))

            //默认
            case _ => List(AppNode(userId, "", "", "", "", "", 0, time.toLong, 0, ""))
          }
        })
        .map(node => AppNode(node.userId, node.nodeId, node.pageId, node.page, node.contentId, node.event, node.etype, node.time, node.cityId, node.area))

    markedLogDF.toDF().createOrReplaceTempView("marked_log")

    val groupedLog = markedLogDF
      //过滤掉节点为空的数据
      .filter(node => !node.nodeId.equals(""))
      .map(node => (node.userId, node))
      //根据用户groupBy
      .groupByKey()
    //缓存
    groupedLog.cache()
    println("groupedLog cnt: " + groupedLog.count())

    /**
      * 详情页转化率
      */
    //开屏广告
    val funnel1f1 = List(
      AppNode("", "app_launch_click_btn_ad", "", "开屏广告", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f1 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f1).toDF()
    val resUsers1f1 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f1).toDF()
    //搜索页面
    val funnel1f2 = List(
      AppNode("", "search_page", "", "搜索页面", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f2 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f2).toDF()
    val resUsers1f2 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f2).toDF()
    //首页banner位
    val funnel1f3 = List(
      AppNode("", "tb_home_banner", "", "首页banner位", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f3 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f3).toDF()
    val resUsers1f3 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f3).toDF()
    //4大场景
    val funnel1f4 = List(
      AppNode("", "tb_home_action", "", "4大场景", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f4 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f4).toDF()
    val resUsers1f4 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f4).toDF()
    //首页运营位
    val funnel1f5 = List(
      AppNode("", "tb_home_home_ad", "", "首页运营位", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f5 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f5).toDF()
    val resUsers1f5 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f5).toDF()
    //首页商圈区域
    val funnel1f6 = List(
      AppNode("", "tb_home_business_circle", "", "首页商圈区域", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f6 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f6).toDF()
    val resUsers1f6 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f6).toDF()
    //所有菜系
    val funnel1f7 = List(
      AppNode("", "tb_home_cooking", "", "所有菜系", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f7 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f7).toDF()
    val resUsers1f7 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f7).toDF()
    //普通运营位
    val funnel1f8 = List(
      AppNode("", "tb_home_operation", "", "普通运营位", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f8 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f8).toDF()
    val resUsers1f8 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f8).toDF()
    //猜你喜欢
    val funnel1f9 = List(
      AppNode("", "tb_home_guess_you_like", "", "猜你喜欢", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f9 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f9).toDF()
    val resUsers1f9 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f9).toDF()
    //热门餐厅区域
    val funnel1f10 = List(
      AppNode("", "tb_home_hot_shop", "", "热门餐厅区域", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f10 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f10).toDF()
    val resUsers1f10 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f10).toDF()
    //精选餐厅区域
    val funnel1f11 = List(
      AppNode("", "tb_home_main_shop", "", "精选餐厅区域", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f11 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f11).toDF()
    val resUsers1f11 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f11).toDF()
    //附近餐厅列表
    val funnel1f12 = List(
      AppNode("", "tb_near", "", "附近餐厅列表", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f12 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f12).flatMap(node =>{
      if(node.nodeId.equals("tb_near")){
        List(AppNode(node.userId, node.nodeId, node.pageId, node.page, node.contentId, node.event, node.etype, node.time, node.cityId, node.area),
          AppNode(node.userId, "shop_list", node.pageId, "餐厅列表页", node.contentId, node.event, node.etype, node.time + 1, node.cityId, node.area))
      }else{
        List(node)
      }
    }).toDF()
    val resUsers1f12 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f12).flatMap(node =>{
      if(node.nodeId.equals("tb_near")){
        List(AppNode(node.userId, node.nodeId, node.pageId, node.page, node.contentId, node.event, node.etype, node.time, node.cityId, node.area),
          AppNode(node.userId, "shop_list", node.pageId, "餐厅列表页", node.contentId, node.event, node.etype, node.time + 1, node.cityId, node.area))
      }else{
        List(node)
      }
    }).toDF()
    //预约订座列表
    val funnel1f13 = List(
      AppNode("", "tb_near", "", "附近餐厅列表", "", "", 0, 0, 0, ""),
      AppNode("", "list_shops_book", "", "预约订座列表", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f13 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f13).toDF()
    val resUsers1f13 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f13).toDF()
    //排队取号列表
    val funnel1f14 = List(
      AppNode("", "tb_near", "", "附近餐厅列表", "", "", 0, 0, 0, ""),
      AppNode("", "list_shops_queue", "", "排队取号列表", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f14 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f14).toDF()
    val resUsers1f14 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f14).toDF()
    //排行榜
    val funnel1f15 = List(
      AppNode("", "tb_ranking", "", "排行榜", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f15 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f15).toDF()
    val resUsers1f15 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f15).toDF()
    //感兴趣的餐厅
    val funnel1f16 = List(
      AppNode("", "list_shops_fave", "", "感兴趣的餐厅", "", "", 0, 0, 0, ""),
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, "")
    )
    val resTimes1f16 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel1f16).toDF()
    val resUsers1f16 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel1f16).toDF()

    //详情页转化率 汇总计算
    val res1Raw = sqlContext.sparkContext.parallelize(Seq(
      ("app_launch_click_btn_ad", "开屏广告"),
      ("search_page", "搜索页面"),
      ("tb_home_banner", "首页banner位"),
      ("tb_home_action", "4大场景"),
      ("tb_home_home_ad", "首页运营位"),
      ("tb_home_business_circle", "首页商圈区域"),
      ("tb_home_cooking", "所有菜系"),
      ("tb_home_operation", "普通运营位"),
      ("tb_home_guess_you_like", "猜你喜欢"),
      ("tb_home_hot_shop", "热门餐厅区域"),
      ("tb_home_main_shop", "精选餐厅区域"),
      ("tb_near", "附近餐厅列表"),
      ("list_shops_book", "预约订座列表"),
      ("list_shops_queue", "排队取号列表"),
      ("tb_ranking", "排行榜"),
      ("list_shops_fave", "感兴趣的餐厅"),
      ("shop_list", "餐厅列表页"),
      ("detail_shop", "餐厅详情页")
    )).toDF("page_id", "page_name")
    res1Raw.createOrReplaceTempView("res1_raw")

    val resTimes1Raw = resTimes1f1
                      .union(resTimes1f2)
                      .union(resTimes1f3)
                      .union(resTimes1f4)
                      .union(resTimes1f5)
                      .union(resTimes1f6)
                      .union(resTimes1f7)
                      .union(resTimes1f8)
                      .union(resTimes1f9)
                      .union(resTimes1f10)
                      .union(resTimes1f11)
                      .union(resTimes1f12)
                      .union(resTimes1f13)
                      .union(resTimes1f14)
                      .union(resTimes1f15)
                      .union(resTimes1f16)
    resTimes1Raw.createOrReplaceTempView("res_times1")
    val resUsers1Raw = resUsers1f1
                      .union(resUsers1f2)
                      .union(resUsers1f3)
                      .union(resUsers1f4)
                      .union(resUsers1f5)
                      .union(resUsers1f6)
                      .union(resUsers1f7)
                      .union(resUsers1f8)
                      .union(resUsers1f9)
                      .union(resUsers1f10)
                      .union(resUsers1f11)
                      .union(resUsers1f12)
                      .union(resUsers1f13)
                      .union(resUsers1f14)
                      .union(resUsers1f15)
                      .union(resUsers1f16)
    resUsers1Raw.createOrReplaceTempView("res_users1")
    var res1 = sqlContext.sql(
      """
        |select
        | '%s' day_id,
        | '1' interval_type,
        | '0' funnel_type,
        |	t2.city_id,
        |	t2.page_id,
        |	t2.page_name,
        |	t2.page_pv,
        |	t3.page_uv
        |from
        |	(select
        |		t1.cityId city_id,
        |		t1.nodeId page_id,
        |		t1.page page_name,
        |		sum(case when t1.etype = 1 then 0 else 1 end) page_pv
        |	from
        |		res_times1 t1
        |	group by
        |		t1.cityId,
        |		t1.nodeId,
        |		t1.page) t2
        |inner join
        |	(select
        |		t1.cityId city_id,
        |		t1.nodeId page_id,
        |		t1.page page_name,
        |		sum(case when t1.etype = 1 then 0 else 1 end) page_uv
        |	from
        |		res_users1 t1
        |	group by
        |		t1.cityId,
        |		t1.nodeId,
        |		t1.page) t3
        |on
        |	t2.city_id = t3.city_id
        |	and
        |	t2.page_id = t3.page_id
        |	and
        |	t2.page_name = t3.page_name
      """.stripMargin.format(targetDate))
    res1.cache()
    res1.createOrReplaceTempView("res1")
    //补0
    res1 = sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	t3.interval_type,
        |	t3.funnel_type,
        |	t3.city_id,
        |	t3.page_id,
        |	t3.page_name,
        |	nvl(t4.page_pv, 0) page_pv,
        |	nvl(t4.page_uv, 0) page_uv
        |from
        |	(select
        |		t2.day_id,
        |		t2.interval_type,
        |		t2.funnel_type,
        |		t2.city_id,
        |		t1.page_id,
        |		t1.page_name
        |	from
        |		res1_raw t1
        |	cross join
        |	 (select distinct day_id, interval_type, funnel_type, city_id from res1) t2
        |	order by
        |		t2.city_id) t3
        |left join
        |	res1 t4
        |on
        |	t3.city_id = t4.city_id
        |	and
        |	t3.page_id = t4.page_id
      """.stripMargin)
    res1.show(100, false)

    /**
      * 排队转化率
      */
    //-----------------------------------免费取号---------------------------------
    //开屏广告
    val funnel21f1 = List(
      AppNode("", "app_launch_click_btn_ad", "", "开屏广告", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f1 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f1).toDF()
    val resUsers21f1 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f1).toDF()
    //餐厅列表页
    val funnel21f2 = List(
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f2 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f2).toDF()
    val resUsers21f2 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f2).toDF()
    //首页banner位
    val funnel21f3 = List(
      AppNode("", "tb_home_banner", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f3 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f3).toDF()
    val resUsers21f3 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f3).toDF()
    //首页运营位
    val funnel21f4 = List(
      AppNode("", "tb_home_home_ad", "", "首页运营位", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f4 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f4).toDF()
    val resUsers21f4 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f4).toDF()
    //普通运营位
    val funnel21f5 = List(
      AppNode("", "tb_home_operation", "", "普通运营位", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f5 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f5).toDF()
    val resUsers21f5 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f5).toDF()
    //猜你喜欢
    val funnel21f6 = List(
      AppNode("", "tb_home_guess_you_like", "", "猜你喜欢", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f6 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f6).toDF()
    val resUsers21f6 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f6).toDF()
    //热门餐厅
    val funnel21f7 = List(
      AppNode("", "tb_home_hot_shop", "", "热门餐厅", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f7 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f7).toDF()
    val resUsers21f7 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f7).toDF()
    //精选餐厅
    val funnel21f8 = List(
      AppNode("", "tb_home_main_shop", "", "精选餐厅", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f8 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f8).toDF()
    val resUsers21f8 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f8).toDF()
    //推荐餐厅
    val funnel21f9 = List(
      AppNode("", "shop_recommend", "", "推荐餐厅", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f9 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f9).toDF()
    val resUsers21f9 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f9).toDF()
    //专题页
    val funnel21f10 = List(
      AppNode("", "h5_special", "", "专题页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_free", "", "免费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes21f10 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel21f10).toDF()
    val resUsers21f10 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel21f10).toDF()

    //-----------------------------------付费取号---------------------------------
    //开屏广告
    val funnel22f1 = List(
      AppNode("", "app_launch_click_btn_ad", "", "开屏广告", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f1 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f1).toDF()
    val resUsers22f1 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f1).toDF()
    //餐厅列表页
    val funnel22f2 = List(
      AppNode("", "shop_list", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f2 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f2).toDF()
    val resUsers22f2 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f2).toDF()
    //首页banner位
    val funnel22f3 = List(
      AppNode("", "tb_home_banner", "", "餐厅列表页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f3 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f3).toDF()
    val resUsers22f3 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f3).toDF()
    //首页运营位
    val funnel22f4 = List(
      AppNode("", "tb_home_home_ad", "", "首页运营位", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f4 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f4).toDF()
    val resUsers22f4 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f4).toDF()
    //普通运营位
    val funnel22f5 = List(
      AppNode("", "tb_home_operation", "", "普通运营位", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f5 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f5).toDF()
    val resUsers22f5 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f5).toDF()
    //猜你喜欢
    val funnel22f6 = List(
      AppNode("", "tb_home_guess_you_like", "", "猜你喜欢", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f6 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f6).toDF()
    val resUsers22f6 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f6).toDF()
    //热门餐厅
    val funnel22f7 = List(
      AppNode("", "tb_home_hot_shop", "", "热门餐厅", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f7 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f7).toDF()
    val resUsers22f7 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f7).toDF()
    //精选餐厅
    val funnel22f8 = List(
      AppNode("", "tb_home_main_shop", "", "精选餐厅", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f8 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f8).toDF()
    val resUsers22f8 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f8).toDF()
    //推荐餐厅
    val funnel22f9 = List(
      AppNode("", "shop_recommend", "", "推荐餐厅", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f9 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f9).toDF()
    val resUsers22f9 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f9).toDF()
    //专题页
    val funnel22f10 = List(
      AppNode("", "h5_special", "", "专题页", "", "", 0, 0, 0, ""),
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_queue", "", "支付页", "", "", 0, 0, 0, ""),
      AppNode("", "queue_fee", "", "付费取号订单", "", "", 0, 0, 0, "")
    )
    val resTimes22f10 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel22f10).toDF()
    val resUsers22f10 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel22f10).toDF()

    //排队转化率 汇总计算
    val res2Raw = sqlContext.sparkContext.parallelize(Seq(
      ("app_launch_click_btn_ad", "开屏广告"),
      ("search_page", "搜索页面"),
      ("shop_list", "餐厅列表页"),
      ("tb_home_banner", "首页banner位"),
      ("tb_home_home_ad", "首页运营位"),
      ("tb_home_operation", "普通运营位"),
      ("tb_home_guess_you_like", "猜你喜欢"),
      ("tb_home_hot_shop", "热门餐厅区域"),
      ("tb_home_main_shop", "精选餐厅区域"),
      ("shop_recommend", "推荐餐厅"),
      ("h5_special", "专题页"),
      ("detail_shop", "餐厅详情页"),
      ("queue_free", "免费取号订单"),
      ("pay_queue", "支付页"),
      ("queue_fee", "付费取号订单")
    )).toDF("page_id", "page_name")
    res2Raw.createOrReplaceTempView("res2_raw")

    val resTimes2Raw = resTimes21f1
                      .union(resTimes21f2)
                      .union(resTimes21f3)
                      .union(resTimes21f4)
                      .union(resTimes21f5)
                      .union(resTimes21f6)
                      .union(resTimes21f7)
                      .union(resTimes21f8)
                      .union(resTimes21f9)
                      .union(resTimes21f10)
                      .union(resTimes22f1)
                      .union(resTimes22f2)
                      .union(resTimes22f3)
                      .union(resTimes22f4)
                      .union(resTimes22f5)
                      .union(resTimes22f6)
                      .union(resTimes22f7)
                      .union(resTimes22f8)
                      .union(resTimes22f9)
                      .union(resTimes22f10)
    resTimes2Raw.createOrReplaceTempView("res_times2")
    val resUsers2Raw = resUsers21f1
                      .union(resUsers21f2)
                      .union(resUsers21f3)
                      .union(resUsers21f4)
                      .union(resUsers21f5)
                      .union(resUsers21f6)
                      .union(resUsers21f7)
                      .union(resUsers21f8)
                      .union(resUsers21f9)
                      .union(resUsers21f10)
                      .union(resUsers22f1)
                      .union(resUsers22f2)
                      .union(resUsers22f3)
                      .union(resUsers22f4)
                      .union(resUsers22f5)
                      .union(resUsers22f6)
                      .union(resUsers22f7)
                      .union(resUsers22f8)
                      .union(resUsers22f9)
                      .union(resUsers22f10)
    resUsers2Raw.createOrReplaceTempView("res_users2")
    var res2 = sqlContext.sql(
      """
        |select
        | '%s' day_id,
        | '1' interval_type,
        | '1' funnel_type,
        |	t2.city_id,
        |	t2.page_id,
        |	t2.page_name,
        |	t2.page_pv,
        |	t3.page_uv
        |from
        |	(select
        |		t1.cityId city_id,
        |		t1.nodeId page_id,
        |		t1.page page_name,
        |		sum(case when t1.etype = 1 then 0 else 1 end) page_pv
        |	from
        |		res_times2 t1
        |	group by
        |		t1.cityId,
        |		t1.nodeId,
        |		t1.page) t2
        |inner join
        |	(select
        |		t1.cityId city_id,
        |		t1.nodeId page_id,
        |		t1.page page_name,
        |		sum(case when t1.etype = 1 then 0 else 1 end) page_uv
        |	from
        |		res_users2 t1
        |	group by
        |		t1.cityId,
        |		t1.nodeId,
        |		t1.page) t3
        |on
        |	t2.city_id = t3.city_id
        |	and
        |	t2.page_id = t3.page_id
        |	and
        |	t2.page_name = t3.page_name
      """.stripMargin.format(targetDate))
    res2.cache()
    res2.createOrReplaceTempView("res2")
    //补0
    res2 = sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	t3.interval_type,
        |	t3.funnel_type,
        |	t3.city_id,
        |	t3.page_id,
        |	t3.page_name,
        |	nvl(t4.page_pv, 0) page_pv,
        |	nvl(t4.page_uv, 0) page_uv
        |from
        |	(select
        |		t2.day_id,
        |		t2.interval_type,
        |		t2.funnel_type,
        |		t2.city_id,
        |		t1.page_id,
        |		t1.page_name
        |	from
        |		res2_raw t1
        |	cross join
        |	 (select distinct day_id, interval_type, funnel_type, city_id from res2) t2
        |	order by
        |		t2.city_id) t3
        |left join
        |	res2 t4
        |on
        |	t3.city_id = t4.city_id
        |	and
        |	t3.page_id = t4.page_id
      """.stripMargin)
    res2.show(100, false)

    /**
      * 预订转化率
      */
    //-----------------------------------免费预订---------------------------------
    //餐厅详情页
    val funnel31f1 = List(
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "reservation_order", "", "在线预约页", "", "", 0, 0, 0, ""),
      AppNode("", "reservation_order_free", "", "普通预订订单", "", "", 0, 0, 0, "")
    )
    val resTimes31f1 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel31f1).toDF()
    val resUsers31f1 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel31f1).toDF()
    //专题页
    val funnel31f2 = List(
      AppNode("", "h5_special", "", "专题页", "", "", 0, 0, 0, ""),
      AppNode("", "reservation_order", "", "在线预约页", "", "", 0, 0, 0, ""),
      AppNode("", "reservation_order_free", "", "普通预订订单", "", "", 0, 0, 0, "")
    )
    val resTimes31f2 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel31f2).toDF()
    val resUsers31f2 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel31f2).toDF()

    //-----------------------------------付费预订---------------------------------
    //餐厅详情页
    val funnel32f1 = List(
      AppNode("", "detail_shop", "", "餐厅详情页", "", "", 0, 0, 0, ""),
      AppNode("", "reservation_order", "", "在线预约页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_book", "", "定金支付页", "", "", 0, 0, 0, ""),
      AppNode("", "reservation_order_fee", "", "定金预订订单", "", "", 0, 0, 0, "")
    )
    val resTimes32f1 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel32f1).toDF()
    val resUsers32f1 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel32f1).toDF()
    //专题页
    val funnel32f2 = List(
      AppNode("", "h5_special", "", "专题页", "", "", 0, 0, 0, ""),
      AppNode("", "reservation_order", "", "在线预约页", "", "", 0, 0, 0, ""),
      AppNode("", "pay_book", "", "定金支付页", "", "", 0, 0, 0, ""),
      AppNode("", "reservation_order_fee", "", "定金预订订单", "", "", 0, 0, 0, "")
    )
    val resTimes32f2 = FunnelUtils.getAppFunnelByTimes(groupedLog, funnel32f2).toDF()
    val resUsers32f2 = FunnelUtils.getAppFunnelByUsers(groupedLog, funnel32f2).toDF()

    //预订转化率 汇总计算
    val res3Raw = sqlContext.sparkContext.parallelize(Seq(
      ("detail_shop", "餐厅详情页"),
      ("h5_special", "专题页"),
      ("reservation_order", "在线预约页"),
      ("reservation_order_free", "普通预订订单"),
      ("pay_book", "定金支付页"),
      ("reservation_order_fee", "定金预订订单")
    )).toDF("page_id", "page_name")
    res3Raw.createOrReplaceTempView("res3_raw")

    val resTimes3Raw = resTimes31f1
                      .union(resTimes31f2)
                      .union(resTimes32f1)
                      .union(resTimes32f2)
    resTimes3Raw.createOrReplaceTempView("res_times3")
    val resUsers3Raw = resUsers31f1
                      .union(resUsers31f2)
                      .union(resUsers32f1)
                      .union(resUsers32f2)
    resUsers3Raw.createOrReplaceTempView("res_users3")
    var res3 = sqlContext.sql(
      """
        |select
        | '%s' day_id,
        | '1' interval_type,
        | '2' funnel_type,
        |	t2.city_id,
        |	t2.page_id,
        |	t2.page_name,
        |	t2.page_pv,
        |	t3.page_uv
        |from
        |	(select
        |		t1.cityId city_id,
        |		t1.nodeId page_id,
        |		t1.page page_name,
        |		sum(case when t1.etype = 1 then 0 else 1 end) page_pv
        |	from
        |		res_times3 t1
        |	group by
        |		t1.cityId,
        |		t1.nodeId,
        |		t1.page) t2
        |inner join
        |	(select
        |		t1.cityId city_id,
        |		t1.nodeId page_id,
        |		t1.page page_name,
        |		sum(case when t1.etype = 1 then 0 else 1 end) page_uv
        |	from
        |		res_users3 t1
        |	group by
        |		t1.cityId,
        |		t1.nodeId,
        |		t1.page) t3
        |on
        |	t2.city_id = t3.city_id
        |	and
        |	t2.page_id = t3.page_id
        |	and
        |	t2.page_name = t3.page_name
      """.stripMargin.format(targetDate))
    res3.cache()
    res3.createOrReplaceTempView("res3")
    //补0
    res3 = sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	t3.interval_type,
        |	t3.funnel_type,
        |	t3.city_id,
        |	t3.page_id,
        |	t3.page_name,
        |	nvl(t4.page_pv, 0) page_pv,
        |	nvl(t4.page_uv, 0) page_uv
        |from
        |	(select
        |		t2.day_id,
        |		t2.interval_type,
        |		t2.funnel_type,
        |		t2.city_id,
        |		t1.page_id,
        |		t1.page_name
        |	from
        |		res3_raw t1
        |	cross join
        |	 (select distinct day_id, interval_type, funnel_type, city_id from res3) t2
        |	order by
        |		t2.city_id) t3
        |left join
        |	res3 t4
        |on
        |	t3.city_id = t4.city_id
        |	and
        |	t3.page_id = t4.page_id
      """.stripMargin)
    res3.show(100, false)

    //汇总
    res = res1.union(res2).union(res3)

  }
}



