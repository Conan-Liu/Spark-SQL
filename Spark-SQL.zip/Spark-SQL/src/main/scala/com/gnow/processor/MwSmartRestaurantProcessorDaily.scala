package com.gnow.processor

import cn.mwee.udf.StringUDF
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.processor.vo.SCNode
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}

/**
  * Created by tal on 18/12/2017.
  */
class MwSmartRestaurantProcessorDaily extends Processor {
    var resDF: DataFrame = _
    val db = DB.ORACLE_37_BWSWD
    val destTable = "MW_SMART_RESTAURANT_DETAIL"

    def reset(targetDate: String): Unit = {
        val sql = "delete from %s where day_id = '%s'".format(destTable, targetDate)
        println("操作数据库：" + db.toString)
        println("执行SQL：" + sql)
        DBEraser.remove(db, sql)

    }

    def execute(targetDate: String, input: String, output: String) = {
        reset(targetDate)
        process(targetDate, input: String, output: String)

        println("保存到db")
        RDBWriter.overwrite(resDF.coalesce(1), db, destTable)
        println("Happy Ending!")

    }

    def process(targetDate: String, input: String, output: String) = {
        //读取日志数据
        //计算裂变比用到
        val schema = StructType(
            List(
                StructField("business", StringType, true),
                StructField("module", StringType, true),
                StructField("action", StringType, true),
                StructField("mwAuthToken", StringType, true),
                StructField("app_version", StringType, true),
                StructField("device_type", StringType, true),
                StructField("device_info", StringType, true),
                StructField("city_id", StringType, true),
                StructField("mobile", StringType, true),
                StructField("location", StringType, true),
                StructField("event", StringType, true),
                StructField("update_time", DoubleType, true)
            )
        )

        val appOperationLogDF = sqlContext.read.schema(schema).json("/repository/kafka/user_action_app_operation/{date}".replace("{date}", targetDate))
        appOperationLogDF.printSchema()
        appOperationLogDF.createOrReplaceTempView("app_operation_log")

        val wechatOperationLogDF = sqlContext.read.schema(schema).json("/repository/kafka/user_action_wechat_operation/{date}".replace("{date}", targetDate))
        wechatOperationLogDF.printSchema()
        wechatOperationLogDF.createOrReplaceTempView("wechat_operation_log")

        val operationLogDF = appOperationLogDF.union(wechatOperationLogDF).distinct()
        operationLogDF.createOrReplaceTempView("operation_log")

        operationLogDF.select("update_time").show()

        //计算会员资料完善需要
        val memberSchema = StructType(
            List(
                StructField("business", StringType, true),
                StructField("module", StringType, true),
                StructField("action", StringType, true),
                StructField("brand_id", StringType, true),
                StructField("mobile", StringType, true),
                StructField("location", StringType, true),
                StructField("event", StringType, true),
                StructField("update_time", DoubleType, true)
            )
        )
        val memberLogDF = sqlContext.read.schema(memberSchema).json("/repository/kafka/smart_restaurant_member_operation/{date}".replace("{date}", targetDate))
        memberLogDF.createOrReplaceTempView("member_log")

        //获取需要的字段
        val logDF = sqlContext.sql(
            """
              |select
              | business
              | ,t1.module
              | ,t1.action
              | ,t1.app_version
              | ,t1.device_type
              | ,t1.device_info
              | ,t1.city_id
              | ,t1.mobile
              | ,t1.mwAuthToken
              | ,t1.location
              | ,get_json_object(t1.event, '$.page') page
              | ,get_json_object(t1.event, '$.area') area
              | ,get_json_object(t1.event, '$.url') url
              | ,get_json_object(t1.event, '$.keyword') keyword
              | ,get_json_object(t1.event, '$.content_id') content_id
              | ,get_json_object(t1.event, '$.shop_id') shop_id
              | ,get_json_object(t1.event, '$.services') services
              | ,get_json_object(t1.event, '$.etype') etype
              | ,get_json_object(t1.event, '$.event') event
              | ,get_json_object(t1.event, '$.order_type') order_type
              | ,get_json_object(t1.event, '$.order_no') order_no
              | ,get_json_object(t1.event, '$.waiting_table') waiting_table
              | ,get_json_object(t1.event, '$.estimated_waiting_time') estimated_waiting_time
              | ,substr(cast(cast(t1.update_time as long) as string), 0, 13) time
              | ,from_unixtime(substr(cast(cast(t1.update_time as long) as string), 0, 10))
              |from
              | operation_log t1
              |order by
              | t1.device_info
              | ,time
            """.stripMargin)

        //    logDF.where("event in ('mf_register_seccess', 'mf_share_seccess')").show()
        //    logDF.where("event in ('new_fission_share_success', 'register_success')").show()

        import sqlContext.implicits._

        //访问节点标注
        //        val markedLogDF =
        //        logDF //online
        //            .where("keyword is null")
        //            .select("mwAuthToken", "url", "page", "content_id", "shop_id", "etype", "event", "time").rdd
        logDF.where("keyword is null").createOrReplaceTempView("content_shop")
        val markedLogDF = sqlContext.sql(
            """
              |select mwAuthToken, url, page, content_id as content_id, etype, concat(event,'_brand'), time from content_shop
              |union all
              |select mwAuthToken, url, page, shop_id as content_id, etype, concat(event,'_shop'), time from content_shop
              | """.stripMargin).rdd
            .map(row => {
                var userId = ""
                if (row.get(0) != null) {
                    userId = row.get(0).toString
                }
                var url = ""
                if (row.get(1) != null) {
                    url = row.get(1).toString
                }
                var page = ""
                if (row.get(2) != null) {
                    page = row.get(2).toString
                }
                var content_id = ""
                if (row.get(3) != null) {
                    content_id = row.get(3).toString
                }
                var etype = ""
                if (row.get(4) != null) {
                    etype = row.get(4).toString
                }
                var event = ""
                if (row.get(5) != null) {
                    event = row.get(5).toString
                }
                var time = "0"
                if (row.get(6) != null) {
                    time = row.get(6).toString
                    if (time.equals("")) {
                        time = "0"
                    }
                }
                if (userId.equals("")) {
                    userId = time
                }
                //标注
                //http://wiki.mwbyd.cn/pages/viewpage.action?pageId=10490557
                //                (page, event) match {
                //                    case ("MMCFissionCouponDetail", "mf_register_seccess") => SCNode(userId, "fissionCouponDetail_mf_register_seccess", "MMCFissionCouponDetail", "裂变分享页", content_id, "秒付跳转到裂变红包注册成功", 0, time.toLong)
                //                    case ("MMCFissionCouponDetail", "mf_share_seccess") => SCNode(userId, "fissionCouponDetail_mf_share_seccess", "MMCFissionCouponDetail", "裂变分享页", content_id, "秒付跳转到裂变红包分享成功", 0, time.toLong)
                //                    case _ => SCNode(userId, "", "", "", "", "", 0, time.toLong)
                //                }

                (page, event) match {
                    case ("MMCNEWFissionCouponDetail", "register_success_brand") =>
                        SCNode(userId, "newFissionCouponDetail_register_success_brand", "MMCNEWFissionCouponDetail", "裂变分享页", content_id, "品牌秒付跳转到裂变红包注册成功", 0, time.toLong)
                    case ("MMCNEWFissionCouponDetail", "register_success_shop") =>
                        SCNode(userId, "newFissionCouponDetail_register_success_shop", "MMCNEWFissionCouponDetail", "裂变分享页", content_id, "门店秒付跳转到裂变红包注册成功", 0, time.toLong)
                    case ("MMCNEWFissionCouponDetail", "new_fission_share_success_brand") =>
                        SCNode(userId, "newFissionCouponDetail_new_fission_share_success_brand", "MMCNEWFissionCouponDetail", "裂变分享页", content_id, "品牌秒付跳转到裂变红包分享成功", 0, time.toLong)
                    case ("MMCNEWFissionCouponDetail", "new_fission_share_success_shop") =>
                        SCNode(userId, "newFissionCouponDetail_new_fission_share_success_shop", "MMCNEWFissionCouponDetail", "裂变分享页", content_id, "门店秒付跳转到裂变红包分享成功", 0, time.toLong)
                    case _ => SCNode(userId, "", "", "", "", "", 0, time.toLong)
                }
            }).filter(node => (node.nodeId != "" && node.contentId != ""))

        markedLogDF.toDF().show(100, false)
        markedLogDF.toDF().createOrReplaceTempView("marked_log")

        //读取计算漏斗可能用到的db数据
        //        val shopTableDF = rdb.basic.df(rdb.basic.SHOP_TABLE)
        //        val cShopBrandDF = rdb.basic.df("c_shop_brand")

        //注册udf
        sqlContext.udf.register("isNumber", StringUDF.isNumber(_: String))

        //裂变比相关
        val res1DF = sqlContext.sql(
            """
              |select
              |	   '%s' day_id,
              |	   isNumber(ml.contentId) shop_id,
              |	   ml.nodeId event_id,
              |	   ml.time event_time
              |from
              |	   (select * from marked_log where nodeId in ('newFissionCouponDetail_new_fission_share_success_shop', 'newFissionCouponDetail_new_fission_share_success_brand') and contentId != '0') ml
            """.stripMargin.format(targetDate))

        val res2DF = sqlContext.sql(
            """
              |select
              |    t1.day_id,
              |    isNumber(t1.contentId) shop_id,
              |    t1.event_id,
              |    t1.event_time
              |from
              |    (select distinct
              |           '%s' day_id,
              |           ml.contentId,
              |           ml.userId,
              |           ml.nodeId event_id,
              |           max(ml.time) event_time
              |    from
              |           (select * from marked_log where nodeId in ('newFissionCouponDetail_register_success_shop', 'newFissionCouponDetail_register_success_brand') and contentId != '0') ml
              |    group by
              |          '%s',
              |           ml.contentId,
              |           ml.userId,
              |           ml.nodeId
              |    ) t1
            """.stripMargin.format(targetDate, targetDate))

        //会员资料完善相关
        val res3DF = sqlContext.sql(
            """
              |select
              |	'%s' day_id,
              |	t2.brand_id shop_id,
              |	'member_operation_birth_update' event_id,
              |	t2.event_time
              |
              |from
              |	(select
              |		business
              |		,t1.module
              |		,t1.action
              |		,t1.brand_id
              |		,t1.mobile
              |		,get_json_object(t1.event, '$.event') event
              |		,substr(cast(cast(t1.update_time as long) as string), 0, 13) event_time
              |	from
              |		member_log t1) t2
              |where
              |	t2.mobile != 0
              |	and
              |	t2.event = 'birth_update'
            """.stripMargin.format(targetDate))

        resDF = res1DF.union(res2DF).union(res3DF)

        println("resDF cnt: " + resDF.count())
        //        res3DF.show()
        //        resDF.show()

        //        resDF.show(false)

//        res1DF.show(100, false)
//        res2DF.show(100, false)

    }
}


