package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.SQLUserOrder
import com.gnow.{DB, Processor, Utility}
import org.apache.spark.sql.DataFrame

class ShopQueueReserveRuleDaily extends Processor {
  val SHOP_QUEUE_RESERVE_RULE = "shop_queue_reserve_rule"
  var df: DataFrame = null
  var shopAndBaseDateDF: DataFrame = null

  val OUTPUT_TABLE = "shop_queue_reserve_rule"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from shop_queue_reserve_rule
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    //reset(targetDate)
    process(targetDate, input: String, output: String)
    RDBWriter.save(shopAndBaseDateDF, DB.ORACLE_37_BWSWD, OUTPUT_TABLE)
  }

  def process(targetDate: String, input: String, output: String) = {
    df = rdb.queueing.df(rdb.queueing.SHOP_QUEUE_RESERVE_RULE)

    shopAndBaseDateDF = Utility.registerTableWithSQL(sqlContext,
      SQLUserOrder.SQL.format(
        rdb.queueing.SHOP_QUEUE_RESERVE_RULE
      ), SHOP_QUEUE_RESERVE_RULE)
  }
}
