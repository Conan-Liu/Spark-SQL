package com.gnow.processor

import cn.mwee.util.DateUtils
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 10/04/2018.
  */
class MwAppRetentionDaily extends Processor {
  var res: DataFrame = _
  val db = DB.ORACLE_37_BWSWD
  val destTable = "DM_MONITOR_APP_USER_RETEN_D"

  def reset(targetDate: String): Unit = {

  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

  }

  def process(targetDate: String, input: String, output: String) = {
    //计算日期
    val dayM1 = DateUtils.getDay(targetDate, -1)
    val dayM2 = DateUtils.getDay(targetDate, -2)
    val dayM3 = DateUtils.getDay(targetDate, -3)
    val dayM4 = DateUtils.getDay(targetDate, -4)
    val dayM5 = DateUtils.getDay(targetDate, -5)
    val dayM6 = DateUtils.getDay(targetDate, -6)
    val dayM7 = DateUtils.getDay(targetDate, -7)
    val dayM14 = DateUtils.getDay(targetDate, -14)
    val dayM30 = DateUtils.getDay(targetDate, -30)
    val dayM60 = DateUtils.getDay(targetDate, -60)
    //读取日志数据
    //新用户数据
    val dayM0NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + targetDate)
    val dayM1NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM1)
    val dayM2NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM2)
    val dayM3NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM3)
    val dayM4NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM4)
    val dayM5NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM5)
    val dayM6NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM6)
    val dayM7NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM7)
    val dayM14NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM14)
    val dayM30NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM30)
    val dayM60NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + dayM60)
    dayM0NewDF.createOrReplaceTempView("day_m0_new")
    dayM1NewDF.createOrReplaceTempView("day_m1_new")
    dayM2NewDF.createOrReplaceTempView("day_m2_new")
    dayM3NewDF.createOrReplaceTempView("day_m3_new")
    dayM4NewDF.createOrReplaceTempView("day_m4_new")
    dayM5NewDF.createOrReplaceTempView("day_m5_new")
    dayM6NewDF.createOrReplaceTempView("day_m6_new")
    dayM7NewDF.createOrReplaceTempView("day_m7_new")
    dayM14NewDF.createOrReplaceTempView("day_m14_new")
    dayM30NewDF.createOrReplaceTempView("day_m30_new")
    dayM60NewDF.createOrReplaceTempView("day_m60_new")
    //活跃用户数据
    val dayM0ActiveDF = sqlContext.read.parquet("/dw/log/c/user_table_detail/" + targetDate)
    dayM0ActiveDF.createOrReplaceTempView("day_m0_active")

    //从hdfs读取历史计算结果
    val userRetenHisDF = sqlContext.read.parquet("/dw/log/c/user_retention_daily")
    userRetenHisDF.cache()
    println("userRetenHisDF cnt: " + userRetenHisDF.count())
    userRetenHisDF.createOrReplaceTempView("user_retention_daily")
    val userRetenOldDF = userRetenHisDF.where("day_id not in ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')".format(targetDate, dayM1, dayM2, dayM3, dayM4, dayM5, dayM6, dayM7, dayM14, dayM30, dayM60))

    //计算昨天新用户数
    val dayM0RetenDF = sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	t3.app_src src_id,
        | t3.new_users users_new,
        |	cast(null as long) reten_1d,
        |	cast(null as long) reten_2d,
        |	cast(null as long) reten_3d,
        |	cast(null as long) reten_4d,
        |	cast(null as long) reten_5d,
        |	cast(null as long) reten_6d,
        |	cast(null as long) reten_7d,
        |	cast(null as long) reten_14d,
        |	cast(null as long) reten_30d,
        |	cast(null as long) reten_60d
        |from
        |	(select
        |		t2.day_id,
        |		t2.app_src,
        |		count(distinct t2.device_id) new_users
        |	from
        |		(select
        |			t1.day_id,
        |			t1.app_src,
        |			t1.device_id
        |		from
        |			day_m0_new t1
        |		where
        |			t1.app_src is not null
        |			and
        |			t1.device_id is not null
        |			and
        |			t1.device_id != ''
        |			) t2
        |	group by
        |		t2.day_id,
        |		t2.app_src) t3
        |
      """.stripMargin)
    dayM0RetenDF.printSchema()
    dayM0RetenDF.show()

    //计算用户留存
    //过去1天
    sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	t3.app_src src_id,
        |	count(distinct t3.device_id) reten_1d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m1_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src
      """.stripMargin).show()
    val dayM1RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t4.reten_1d,
        |	t5.reten_2d,
        |	t5.reten_3d,
        |	t5.reten_4d,
        |	t5.reten_5d,
        |	t5.reten_6d,
        |	t5.reten_7d,
        |	t5.reten_14d,
        |	t5.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_1d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m1_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM1RetenDF.show()
    //过去2天
    val dayM2RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t4.reten_2d,
        |	t5.reten_3d,
        |	t5.reten_4d,
        |	t5.reten_5d,
        |	t5.reten_6d,
        |	t5.reten_7d,
        |	t5.reten_14d,
        |	t5.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_2d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m2_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM2RetenDF.show()
    //过去3天
    val dayM3RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t5.reten_2d,
        |	t4.reten_3d,
        |	t5.reten_4d,
        |	t5.reten_5d,
        |	t5.reten_6d,
        |	t5.reten_7d,
        |	t5.reten_14d,
        |	t5.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_3d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m3_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM3RetenDF.show()
    //过去4天
    val dayM4RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t5.reten_2d,
        |	t5.reten_3d,
        |	t4.reten_4d,
        |	t5.reten_5d,
        |	t5.reten_6d,
        |	t5.reten_7d,
        |	t5.reten_14d,
        |	t5.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_4d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m4_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM4RetenDF.show()
    //过去5天
    val dayM5RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t5.reten_2d,
        |	t5.reten_3d,
        |	t5.reten_4d,
        |	t4.reten_5d,
        |	t5.reten_6d,
        |	t5.reten_7d,
        |	t5.reten_14d,
        |	t5.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_5d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m5_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM5RetenDF.show()
    //过去6天
    val dayM6RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t5.reten_2d,
        |	t5.reten_3d,
        |	t5.reten_4d,
        |	t5.reten_5d,
        |	t4.reten_6d,
        |	t5.reten_7d,
        |	t5.reten_14d,
        |	t5.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_6d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m6_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM6RetenDF.show()
    //过去7天
    val dayM7RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t5.reten_2d,
        |	t5.reten_3d,
        |	t5.reten_4d,
        |	t5.reten_5d,
        |	t5.reten_6d,
        |	t4.reten_7d,
        |	t5.reten_14d,
        |	t5.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_7d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m7_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM7RetenDF.show()
    //过去14天
    val dayM14RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t5.reten_2d,
        |	t5.reten_3d,
        |	t5.reten_4d,
        |	t5.reten_5d,
        |	t5.reten_6d,
        |	t5.reten_7d,
        |	t4.reten_14d,
        |	t5.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_14d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m14_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM14RetenDF.show()
    //过去30天
    val dayM30RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t5.reten_2d,
        |	t5.reten_3d,
        |	t5.reten_4d,
        |	t5.reten_5d,
        |	t5.reten_6d,
        |	t5.reten_7d,
        |	t5.reten_14d,
        |	t4.reten_30d,
        |	t5.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_30d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m30_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM30RetenDF.show()
    //过去60天
    val dayM60RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new users_new,
        |	t5.reten_1d,
        |	t5.reten_2d,
        |	t5.reten_3d,
        |	t5.reten_4d,
        |	t5.reten_5d,
        |	t5.reten_6d,
        |	t5.reten_7d,
        |	t5.reten_14d,
        |	t5.reten_30d,
        |	t4.reten_60d
        |from
        |(select
        |	t3.day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_60d
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m60_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	t3.day_id,
        |	t3.app_src) t4
        |join
        |	user_retention_daily t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin)
    dayM60RetenDF.show()
    //将新计算的用户留存和历史值合并
    res =
      userRetenOldDF
      .union(dayM0RetenDF)
      .union(dayM1RetenDF)
      .union(dayM2RetenDF)
      .union(dayM3RetenDF)
      .union(dayM4RetenDF)
      .union(dayM5RetenDF)
      .union(dayM6RetenDF)
      .union(dayM7RetenDF)
      .union(dayM14RetenDF)
      .union(dayM30RetenDF)
      .union(dayM60RetenDF)
    res.show()

    //保存新结果到hdfs
    res.repartition(1).write.mode("overwrite").parquet("/dw/log/c/user_retention_daily")

    //保存新结果到Oracle(先删除历史数据)
    val sql = "delete from %s where day_id in ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')".format(destTable, targetDate, dayM1, dayM2, dayM3, dayM4, dayM5, dayM6, dayM7, dayM14, dayM30, dayM60)
    println("操作数据库：" + db.toString)
    println("执行SQL：" + sql)
    DBEraser.remove(db, sql)

    println("保存到db")
    RDBWriter.overwrite(res.coalesce(1), db, destTable)
    println("Happy Ending!")

  }
}




