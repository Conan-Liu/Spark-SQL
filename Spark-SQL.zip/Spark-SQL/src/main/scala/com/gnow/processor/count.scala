package com.gnow.processor

import com.gnow.config.SaveMode
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import com.gnow.{DB, Processor}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import com.gnow.eraser.DBEraser
import com.gnow._


class count extends Processor {

	var aver_shop_latitude_bcid5 = 0.0
	var aver_shop_longitude_bcid5  = 0.0
	var s = 0.0
    var cue = (0.0,0.0,0.0,0.0)
	var str = ""

  val QUEUEING_MAIN_QUEUE = "queueing_main_queue"
  private var ODS = "ods"
  val oracleDriverUrl = "jdbc:oracle:thin:@10.0.24.11:1521/BQSWD"
  

  val jdbcMap = Map("url" -> oracleDriverUrl,
                  "user" -> "pmadw",
                  "password" -> "pmadev021",
                  "dbtable" -> "ODS_SHOPTABLE",
                  "driver" -> "oracle.jdbc.driver.OracleDriver")

  val jdbcDF = sqlContext.read.options(jdbcMap).format("jdbc").load
  jdbcDF.registerTempTable(ODS)
  
  
  def getDistatce(lat1:Double,lon1:Double,lat2:Double,lon2:Double): Double = {


            val R =  6378.137
            val C = Math.sin(lat1)*Math.sin(lat2)+ Math.cos(lon1- lon2)* Math.cos(lat1)*Math.cos(lat2)
            val distance = R * Math.acos(C)*Math.PI/180

            distance
    }
 
  
  def reset(targetDate: String): Unit = {
  

  }

  def execute(targetDate: String, input: String, output: String) = {
  
    //reset(targetDate)
    process(targetDate, input: String, output: String)
	
  }

  def process(targetDate: String, input: String, output: String) = {
  
 
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
	repository.kafka.dfBeginAndEnd(repository.kafka.QUEUEING_MAIN_QUEUE,targetDate)
	//rdb.basic.df(rdb.basic.SHOP_TABLE)
		
    
    //RDBWriter.save(basicMemberTable, DB.MYSQL_249_RESTAURANT, BASIC_MEMBER_TABLE, SaveMode.APPEND)
	
	
	
	// 餐饮门店数 
	val countOne =
      """
    |select
	|count(distinct(t1.shop_id)) shop_count 
    |from %s t1 join %s t2
	|on t1.shop_id = t2.SHOPID
    |where 	FIND_IN_SET('44',t2.BCID) > 0
    |and t2.TYPE = 2
    |and t2.TIYANDIAN = 0
    |and t2.SHOPID != t2.MANAGESHOPID
    |and t2.MANAGESHOPID != 43	
    """.stripMargin
	
	//  or FIND_IN_SET('44',t1.BCID) > 0      |group by t2.BCID  	|t2.BCID   bcid,


	 val one= sqlContext.sql(countOne.format(repository.kafka.QUEUEING_MAIN_QUEUE,ODS))
	 
	 val s1= one.toJSON.collect().toList.toString
	 
	 logger.info(s1)
	 
	 val countTwo =
      """
    |select
	|count(distinct(t1.shop_id)) shop_count 
    |from %s t1 join %s t2
	|on t1.shop_id = t2.SHOPID
    |where 	t2.SHOPPINGMALLSHOPID = 4544 
	|and t2.TYPE = 2
    |and t2.TIYANDIAN = 0
    |and t2.SHOPID != t2.MANAGESHOPID
    |and t2.MANAGESHOPID != 43
    """.stripMargin
		
	
	 val two= sqlContext.sql(countTwo.format(repository.kafka.QUEUEING_MAIN_QUEUE,ODS))
	 
	 
	 val s2= two.toJSON.collect().toList.toString
	 
	 logger.info(s2)
	 
	 //在当前商圈(或商场)内门店线上取号，每个用户下单时刻的经纬度和与门店距离   
	 
	 val countThree  =
      """
    |select
	|t1.user_id,
	|t1.latitude    user_latitude,
	|t1.longitude   user_longitude,
	|t2.LATITUDE    shop_latitude,
	|t2.LONGITUDE   shop_longitude
    |from %s t1 join %s t2
	|on t1.shop_id = t2.SHOPID
    |where 	t2.SHOPPINGMALLSHOPID = 4544
	|and t2.TYPE = 2
    |and t2.TIYANDIAN = 0
    |and t2.SHOPID != t2.MANAGESHOPID
    |and t2.MANAGESHOPID != 43
    """.stripMargin
	
	//	|t2.SHOPPINGMALLSHOPID   shoppingmallshopid,
	//|group by t2.SHOPPINGMALLSHOPID,t1.user_id,t1.latitude,t1.longitude,t2.LATITUDE,t2.LONGITUDE
	
	
    val three= sqlContext.sql(countThree.format(repository.kafka.QUEUEING_MAIN_QUEUE,ODS))
	//or t2.BCID = 44
	
	val res = three.select("*")
	.collect.toList.filter(x => x != null)
	.filter(x => x(0) != null && x(1) != null && x(2) != null && x(3) != null && x(4) != null )
	.map(x => (4544,x(0),x(1),x(2),	getDistatce(x(1).toString.toDouble,
	x(2).toString.toDouble,x(3).toString.toDouble,x(4).toString.toDouble)))
	
	val  q = res.toString
	
	logger.info(q)
	 
	 
	 
	 //求平均中心经纬度
	  val countfive  =
      """
    |select
	|avg(t1.LATITUDE)    aver_shop_latitude,
	|avg(t1.LONGITUDE)   aver_shop_longitude
    |from %s t1 
    |where  t1.SHOPPINGMALLSHOPID = 4544
	|and t1.TYPE = 2
    |and t1.TIYANDIAN = 0
    |and t1.SHOPID != t1.MANAGESHOPID
    |and t1.MANAGESHOPID != 43
    """.stripMargin
	
	 //|and t1.shopid not like '%测试%'  	|group by t1.BCID  	|t1.BCID   bcid,
	
	
	val five = sqlContext.sql(countfive.format(ODS))
	
	
	five.select("*").collect.foreach(x => {

			aver_shop_latitude_bcid5 = x(0).toString.toDouble
			aver_shop_longitude_bcid5 = x(1).toString.toDouble


		})
		
	logger.info("999:"+ aver_shop_latitude_bcid5+":::::"+aver_shop_longitude_bcid5)

	val countsix  =
		"""
	|select
    |t1.shop_id  shop_id,
    |NVL(t1.people_count,'')  people_count,
	|NVL(t1.latitude,'')    shop_latitude,
    |NVL(t1.longitude,'')    shop_longitude
	|from %s t1 join %s t2
    |on t1.shop_id = t2.SHOPID 
    |where  t2.SHOPPINGMALLSHOPID = 4544
	|and t2.TYPE = 2
    |and t2.TIYANDIAN = 0
    |and t2.SHOPID != t2.MANAGESHOPID
    |and t2.MANAGESHOPID != 43
		""".stripMargin
		
	// |t2.BCID   bcid,

	val six = sqlContext.sql(countsix.format(repository.kafka.QUEUEING_MAIN_QUEUE,ODS))
	
	//求半径
	six.select("*").collect.toList.filter(x => x != null && x != "" && x !=())
	    .filter(x => x(0) != null && x(1) != null && x(1) != "" && x(2) != null && x(2) != "" && x(3) != null  && x(3) != "" )
			.map(x => (x(1),			getDistatce(x(2).toString.toDouble,x(3).toString.toDouble,aver_shop_latitude_bcid5,aver_shop_longitude_bcid5)))
			.sortBy(x => x._2).map(x => {
        s += x._1.toString.toDouble
        (s,x._2)
      }).map(x => {
       if (x._1.toDouble / s > 0.75 && x._1.toDouble / s < 0.85) {
          cue = (x._1.toDouble,s,x._1.toDouble / s ,x._2)
        } else {
          cue = (0.0,0.0,0.0,0.0)
        }
          cue
      }).filter(x => x._1 != 0.0).foreach(x => {
	  str += x.toString 
	  })
	  
	  
	logger.info(str)

	
	 
  }
}
