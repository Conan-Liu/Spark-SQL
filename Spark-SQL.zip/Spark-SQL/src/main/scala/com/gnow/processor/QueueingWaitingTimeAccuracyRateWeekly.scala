package com.gnow.processor

import com.gnow.config.SaveMode
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import com.gnow.{DB, Processor}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext

/**
  *
  *
  周报：

  所有排队门店15分钟预估准确率：上周第一次预估的等位时间与实际等位时间的差值不超过15分钟的线上和线下扫码号单数/上周美味线上和线下扫码号单取号总数（实际等位时间=第一次叫号的时刻-第一次获取预估时间的时刻；分子分母均不包含已取消的号单）

  优质排队门店15分钟预估准确率：上周第一次预估的等位时间与实际等位时间的差值不超过15分钟的线上和线下扫码号单数/上周美味线上和线下扫码号单取号总数（实际等位时间=第一次叫号的时刻-第一次获取预估时间的时刻；分子分母只统计优质门店的号单；分子分母均不包含已取消的号单）

  所有排队门店10分钟预估准确率：上周第一次预估的等位时间与实际等位时间的差值不超过10分钟的线上和线下扫码号单数/上周美味线上和线下扫码号单取号总数（实际等位时间=第一次叫号的时刻-第一次获取预估时间的时刻；分子分母均不包含已取消的号单）

  优质排队门店10分钟预估准确率：上周第一次预估的等位时间与实际等位时间的差值不超过10分钟的线上和线下扫码号单数/上周美味线上和线下扫码号单取号总数（实际等位时间=第一次叫号的时刻-第一次获取预估时间的时刻；分子分母只统计优质门店的号单；分子分母均不包含已取消的号单）

  预估次数准确率：上周预估等位时间与实际等位时间的差值不超过15分钟的预估次数/上周总预估次数（实际等位时间=第一次叫号的时刻-第一次获取预估时间的时刻；不区分线上线下；分子分母均不包含已取消的号单）

  *
  *
  */
class QueueingWaitingTimeAccuracyRateWeekly extends Processor {
val QUEUEING_WAITING_TIME_ACCURACY = "queueing_waiting_time_accuracy"
val QUEUEING_WAITING_TIME_EXT_GOOD_SHOP = "queueing_waiting_time_ext_good_shop"
val QUEUEING_WAITING_TIME_EXT_ALL_SHOP = "queueing_waiting_time_ext_all_shop"
val QUEUEING_WAITING_TIME_EXT_ALL = "queueing_waiting_time_ext_all"
val GOOD_SHOP_RES = "good_shop_res"
val ALL_SHOP_RES = "all_shop_res"
val ALL_SERIAL_ID_RES = "all_serial_id_res"

def reset(targetDate: String): Unit = {
  val sql =
    """
      |delete
      |from queueing_waiting_time_accuracy
      |where create_date='%s' and interval_type='1'
    """.stripMargin
  logger.info(sql.format(targetDate))
  DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
}

def execute(targetDate: String, input: String, output: String) = {
  reset(targetDate)
  process(targetDate, input: String, output: String)
}

def process(targetDate: String, input: String, output: String) = {
  val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
  //排队表
  rdb.queueing.df4Weekly(rdb.queueing.QUEUEING_TABLE,targetDate)
  //debug
//    println("count: " + sqlContext.sql("select type_,qrscan,weixin_view,shop_id,serial_id,state from queueing_table").count())
//    sqlContext.sql("select type_,qrscan,weixin_view,shop_id,serial_id,state from queueing_table").show()
  //优质门店表
  rdb.oracle.df(rdb.oracle.ORACLE_QUEUEING_GOOD_SHOP)
  //表格配置表
  rdb.basic.df(rdb.basic.SHOP_CONFIG_TABLE).cache()
  //等位时间日志
  val schema = "shop_id,serial_id,estimated_time,create_time,timing_type"
  repository.kafka.df4Weekly(repository.kafka.QUEUEING_WAITING_TIME,targetDate,schema)

  //1.计算优质门店的准确率(10分钟和15分钟)
  val QUEUEING_WAITING_TIME_EXT_GOOD_SHOP_SQL =
    """
      |select
      |t1.shop_id,
      |t1.serial_id,
      |t2.estimated_time,
      |from_unixtime(t2.create_time/1000, 'yyyy-MM-dd') create_date,
      |abs(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - unix_timestamp(regexp_replace(t1.create_date, 'T', ' ')))) abs_delta_time,
      |min(t2.create_time) create_time
      |from %s t1 join %s t2 on (
      |    t1.serial_id = t2.serial_id
      |    and t1.shop_id = t2.shop_id
      |) join %s t3 on (
      |    t1.shop_id = t3.shop_id
      |) join %s t4 on (
      |    t1.shop_id = t4.shop_id
      |    and t4.estimate_enable = 1
      |)
      |where t2.create_time < (unix_timestamp('%s', 'yyyy-MM-dd') + 86400) * 1000
      |and t2.timing_type='0'
      |and t1.state!='10'
      |and ((t1.type_ in ('1','4') and (t1.qrscan='1' or t1.weixin_view='1')) or t1.type_ in ('2','5','6','7','8'))
      |group by
      |t1.shop_id,
      |t1.serial_id,
      |t2.estimated_time,
      |from_unixtime(t2.create_time/1000, 'yyyy-MM-dd'),
      |abs(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - unix_timestamp(regexp_replace(t1.create_date, 'T', ' '))))
    """.stripMargin
  val queueingWaitingTimeExtGoodShopDF = sqlContext.sql(QUEUEING_WAITING_TIME_EXT_GOOD_SHOP_SQL.format(
    rdb.queueing.QUEUEING_TABLE,
    repository.kafka.QUEUEING_WAITING_TIME,
    rdb.oracle.ORACLE_QUEUEING_GOOD_SHOP,
    rdb.basic.SHOP_CONFIG_TABLE,
    targetDate))
  logger.info(QUEUEING_WAITING_TIME_EXT_GOOD_SHOP_SQL.format(
    rdb.queueing.QUEUEING_TABLE,
    repository.kafka.QUEUEING_WAITING_TIME,
    rdb.oracle.ORACLE_QUEUEING_GOOD_SHOP,
    rdb.basic.SHOP_CONFIG_TABLE,
    targetDate))
  queueingWaitingTimeExtGoodShopDF.registerTempTable(QUEUEING_WAITING_TIME_EXT_GOOD_SHOP)
  //debug
//    println("count: " + queueingWaitingTimeExtGoodShopDF.count())
//    queueingWaitingTimeExtGoodShopDF.show()

  val QUEUEING_WAITING_TIME_GOOD_SHOP_SQL =
    """
      |select
      |'%s' create_date,
      |t2.qualified_count_good_shop_10,
      |t2.qualified_count_good_shop_15,
      |t2.serial_id_count_good_shop
      |from (
      |    select
      |    count(
      |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time <= 600)
      |        then t1.serial_id
      |        else null
      |        end
      |    ) qualified_count_good_shop_10,
      |    count(
      |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time <= 900)
      |        then t1.serial_id
      |        else null
      |        end
      |    ) qualified_count_good_shop_15,
      |    count(
      |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200)
      |        then t1.serial_id
      |        else null
      |        end
      |    ) serial_id_count_good_shop
      |    from %s t1
      |    group by
      |    '%s'
      |) t2
    """.stripMargin
  val goodShopResult = sqlContext.sql(QUEUEING_WAITING_TIME_GOOD_SHOP_SQL.format(
    targetDate,
    QUEUEING_WAITING_TIME_EXT_GOOD_SHOP,
    targetDate))
  logger.info(QUEUEING_WAITING_TIME_GOOD_SHOP_SQL.format(
    targetDate,
    QUEUEING_WAITING_TIME_EXT_GOOD_SHOP,
    targetDate))

  goodShopResult.registerTempTable(GOOD_SHOP_RES)
  goodShopResult.cache()
  //debug
//    goodShopResult.show()

  //2.计算所有门店的准确率(10分钟和15分钟)
  val QUEUEING_WAITING_TIME_EXT_ALL_SHOP_SQL =
    """
      |select
      |t1.shop_id,
      |t1.serial_id,
      |t2.estimated_time,
      |from_unixtime(t2.create_time/1000, 'yyyy-MM-dd') create_date,
      |abs(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - unix_timestamp(regexp_replace(t1.create_date, 'T', ' ')))) abs_delta_time,
      |min(t2.create_time) create_time
      |from %s t1 join %s t2 on (
      |    t1.serial_id = t2.serial_id
      |    and t1.shop_id = t2.shop_id
      |) join %s t3 on (
      |    t1.shop_id = t3.shop_id
      |    and t3.estimate_enable = 1
      |)
      |where t2.create_time < (unix_timestamp('%s', 'yyyy-MM-dd') + 86400) * 1000
      |and t2.timing_type='0'
      |and t1.state!='10'
      |and ((t1.type_ in ('1','4') and (t1.qrscan='1' or t1.weixin_view='1')) or t1.type_ in ('2','5','6','7','8'))
      |group by
      |t1.shop_id,
      |t1.serial_id,
      |t2.estimated_time,
      |from_unixtime(t2.create_time/1000, 'yyyy-MM-dd'),
      |abs(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - unix_timestamp(regexp_replace(t1.create_date, 'T', ' '))))
    """.stripMargin
  val queueingWaitingTimeExtAllShopDF = sqlContext.sql(QUEUEING_WAITING_TIME_EXT_ALL_SHOP_SQL.format(
    rdb.queueing.QUEUEING_TABLE,
    repository.kafka.QUEUEING_WAITING_TIME,
    rdb.basic.SHOP_CONFIG_TABLE,
    targetDate))
  logger.info(QUEUEING_WAITING_TIME_EXT_ALL_SHOP_SQL.format(
    rdb.queueing.QUEUEING_TABLE,
    repository.kafka.QUEUEING_WAITING_TIME,
    rdb.basic.SHOP_CONFIG_TABLE,
    targetDate))
  queueingWaitingTimeExtAllShopDF.registerTempTable(QUEUEING_WAITING_TIME_EXT_ALL_SHOP)


  val QUEUEING_WAITING_TIME_ALL_SHOP_SQL =
    """
      |select
      |'%s' create_date,
      |t2.qualified_count_all_shop_10,
      |t2.qualified_count_all_shop_15,
      |t2.serial_id_count_all_shop
      |from (
      |    select
      |    count(
      |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time <= 600)
      |        then t1.serial_id
      |        else null
      |        end
      |    ) qualified_count_all_shop_10,
      |    count(
      |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time <= 900)
      |        then t1.serial_id
      |        else null
      |        end
      |    ) qualified_count_all_shop_15,
      |    count(
      |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200)
      |        then t1.serial_id
      |        else null
      |        end
      |    ) serial_id_count_all_shop
      |    from %s t1
      |    group by
      |    '%s'
      |) t2
    """.stripMargin
  val allShopResult = sqlContext.sql(QUEUEING_WAITING_TIME_ALL_SHOP_SQL.format(
    targetDate,
    QUEUEING_WAITING_TIME_EXT_ALL_SHOP,
    targetDate))
  logger.info(QUEUEING_WAITING_TIME_ALL_SHOP_SQL.format(
    targetDate,
    QUEUEING_WAITING_TIME_EXT_ALL_SHOP,
    targetDate))
  allShopResult.registerTempTable(ALL_SHOP_RES)
  allShopResult.cache()
  //debug
//    allShopResult.show()

  //3.计算预估次数准确率
  val QUEUEING_WAITING_TIME_EXT_ALL_SQL =
    """
      |select
      |t1.shop_id,
      |t1.serial_id,
      |t2.estimated_time,
      |from_unixtime(t2.create_time/1000, 'yyyy-MM-dd') create_date,
      |abs(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - unix_timestamp(regexp_replace(t1.create_date, 'T', ' ')))) abs_delta_time,
      |min(t2.create_time) create_time
      |from %s t1 join %s t2 on (
      |    t1.serial_id = t2.serial_id
      |    and t1.shop_id = t2.shop_id
      |) join %s t3 on (
      |    t1.shop_id = t3.shop_id
      |    and t3.estimate_enable = 1
      |)
      |where t2.create_time < (unix_timestamp('%s', 'yyyy-MM-dd') + 86400) * 1000
      |and t2.timing_type='0'
      |and t1.state!='10'
      |and t1.type_ in ('1','2','4','5','6','7','8')
      |group by
      |t1.shop_id,
      |t1.serial_id,
      |t2.estimated_time,
      |from_unixtime(t2.create_time/1000, 'yyyy-MM-dd'),
      |abs(t2.estimated_time - ceil(unix_timestamp(regexp_replace(t1.last_time, 'T', ' ')) - unix_timestamp(regexp_replace(t1.create_date, 'T', ' '))))
    """.stripMargin
  val queueingWaitingTimeExtAllDF = sqlContext.sql(QUEUEING_WAITING_TIME_EXT_ALL_SQL.format(
    rdb.queueing.QUEUEING_TABLE,
    repository.kafka.QUEUEING_WAITING_TIME,
    rdb.basic.SHOP_CONFIG_TABLE,
    targetDate))
  logger.info(QUEUEING_WAITING_TIME_EXT_ALL_SQL.format(
    rdb.queueing.QUEUEING_TABLE,
    repository.kafka.QUEUEING_WAITING_TIME,
    rdb.basic.SHOP_CONFIG_TABLE,
    targetDate))
  queueingWaitingTimeExtAllDF.registerTempTable(QUEUEING_WAITING_TIME_EXT_ALL_SHOP)


  val QUEUEING_WAITING_TIME_ALL_SQL =
    """
      |select
      |'%s' create_date,
      |t2.qualified_id_all,
      |t2.serial_id_count_all
      |from (
      |    select
      |    count(
      |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200 and t1.abs_delta_time <= 900)
      |        then t1.serial_id
      |        else null
      |        end
      |    ) qualified_id_all,
      |    count(
      |        case when (t1.estimated_time > -1 and t1.estimated_time <= 7200)
      |        then t1.serial_id
      |        else null
      |        end
      |    ) serial_id_count_all
      |    from %s t1
      |    group by
      |    '%s'
      |) t2
    """.stripMargin
  val allSerialIdResult = sqlContext.sql(QUEUEING_WAITING_TIME_ALL_SQL.format(
    targetDate,
    QUEUEING_WAITING_TIME_EXT_ALL_SHOP,
    targetDate))
  logger.info(QUEUEING_WAITING_TIME_ALL_SQL.format(
    targetDate,
    QUEUEING_WAITING_TIME_EXT_ALL_SHOP,
    targetDate))
  allSerialIdResult.registerTempTable(ALL_SERIAL_ID_RES)
  allSerialIdResult.cache()
  //debug
//    allSerialIdResult.show()

  //4.保存结果
  val QUEUEING_WAITING_TIME_ACCURACY_SQL =
    """
      |select
      |t1.create_date,
      |t1.qualified_count_good_shop_10,
      |t1.qualified_count_good_shop_15,
      |t1.serial_id_count_good_shop,
      |t2.qualified_count_all_shop_10,
      |t2.qualified_count_all_shop_15,
      |t2.serial_id_count_all_shop,
      |t3.qualified_id_all,
      |t3.serial_id_count_all,
      |'1' interval_type
      |from %s t1 left join %s t2 on(
      | t1.create_date = t2.create_date
      |)left join %s t3 on(
      | t1.create_date = t3.create_date)
      |where 1=1
    """.stripMargin
  val result = sqlContext.sql(QUEUEING_WAITING_TIME_ACCURACY_SQL.format(
    GOOD_SHOP_RES,
    ALL_SHOP_RES,
    ALL_SERIAL_ID_RES
  ))
  logger.info(QUEUEING_WAITING_TIME_ALL_SQL.format(
    GOOD_SHOP_RES,
    ALL_SHOP_RES,
    ALL_SERIAL_ID_RES))
  result.cache()
  //debug
  result.registerTempTable("result")
  result.show()
  sqlContext.sql(
    """
      |select
      |qualified_count_good_shop_10/serial_id_count_good_shop,
      |qualified_count_good_shop_15/serial_id_count_good_shop,
      |qualified_count_all_shop_10/serial_id_count_all_shop,
      |qualified_count_all_shop_15/serial_id_count_all_shop,
      |qualified_id_all/serial_id_count_all
      |from result
    """.stripMargin).show()
  //save to DB
  RDBWriter.save(result, DB.ORACLE_37_BWSWD, QUEUEING_WAITING_TIME_ACCURACY, SaveMode.APPEND)



}

}
