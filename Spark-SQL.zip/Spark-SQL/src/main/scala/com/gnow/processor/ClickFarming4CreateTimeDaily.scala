package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.{SQLClickFarming, SQLClickFarming4CreateTime}
import com.gnow.{DB, Processor}

class ClickFarming4CreateTimeDaily extends Processor {
  val CLICK_FARMING = "click_farming"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from click_farming
        |where create_date='%s'
        |and type='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate, "1"))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    rdb.queueing.df(rdb.queueing.QUEUEING_TABLE, targetDate)
    val clickFarmingSQL = SQLClickFarming.getSQL(targetDate)
    sqlContext.sql(clickFarmingSQL).registerTempTable(CLICK_FARMING)

    val clickFarmingExt = sqlContext.sql(SQLClickFarming4CreateTime.CLICK_FARMING_EXT.format(
      CLICK_FARMING,
      CLICK_FARMING
    ))
    clickFarmingExt.registerTempTable("click_farming_ext")
    clickFarmingExt.cache()
    logger.info(SQLClickFarming4CreateTime.CLICK_FARMING_EXT)

    val orderOccurrence = sqlContext.sql(SQLClickFarming4CreateTime.ORDER_OCCURRENCE)
    orderOccurrence.registerTempTable("order_occurrence")
    orderOccurrence.cache()
    logger.info(SQLClickFarming4CreateTime.ORDER_OCCURRENCE)

    val orderQualified = sqlContext.sql(SQLClickFarming4CreateTime.ORDER_QUALIFIED)
    orderQualified.registerTempTable("order_qualified")
    orderQualified.cache()
    logger.info(SQLClickFarming4CreateTime.ORDER_QUALIFIED)

    val orderDetail = sqlContext.sql(SQLClickFarming4CreateTime.ORDER_DETAIL)
    orderDetail.registerTempTable("click_farming_detail")
    orderDetail.cache()
    logger.info(SQLClickFarming4CreateTime.ORDER_DETAIL)

    val clickFarmingRange = sqlContext.sql(SQLClickFarming4CreateTime.CLICK_FARMING_RANGE)
    clickFarmingRange.registerTempTable("click_farming_range")
    clickFarmingRange.cache()
    logger.info(SQLClickFarming4CreateTime.CLICK_FARMING_RANGE)

    val clickFarmingMinute = sqlContext.sql(SQLClickFarming4CreateTime.CLICK_FARMING_MINUTE)
    clickFarmingMinute.registerTempTable("click_farming_minute")
    clickFarmingMinute.cache()
    logger.info(SQLClickFarming4CreateTime.CLICK_FARMING_MINUTE)

    val clickFarmingReadable = sqlContext.sql(SQLClickFarming4CreateTime.CLICK_FARMING_READABLE)
    clickFarmingReadable.registerTempTable("click_farming_readable")
    clickFarmingReadable.cache()
    logger.info(SQLClickFarming4CreateTime.CLICK_FARMING_READABLE)

    val clickFarmingFinal = sqlContext.sql(SQLClickFarming4CreateTime.CLICK_FARMING_FINAL.format(CLICK_FARMING))
    clickFarmingFinal.registerTempTable("click_farming_final")
    clickFarmingFinal.cache()
    logger.info(SQLClickFarming4CreateTime.CLICK_FARMING_FINAL)

    val clickFarmingEnd = sqlContext.sql(SQLClickFarming4CreateTime.CLICK_FARMING_END)
    clickFarmingEnd.registerTempTable("click_farming_end")
    clickFarmingEnd.cache()
    logger.info(SQLClickFarming4CreateTime.CLICK_FARMING_END)

    val df = sqlContext.sql("select * from click_farming_end")
    RDBWriter.save(df, DB.ORACLE_37_BWSWD, "click_farming")
  }
}
