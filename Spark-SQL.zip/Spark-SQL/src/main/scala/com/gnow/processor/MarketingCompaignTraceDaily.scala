package com.gnow.processor

import com.gnow.config.{Constants, SaveMode}
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.sql.SQLMarketingCompaignTrace
import com.gnow.{DB, Processor, Utility}

class MarketingCompaignTraceDaily extends Processor {
  val OUTPUT_TABLE = "marketing_compaign_trace"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from marketing_compaign_trace
        |where date_ like '%s'
      """.stripMargin
    DBEraser.remove(DB.MYSQL_231_MARKETING, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLMarketingCompaignTrace.getSQL(targetDate)
    val tbl = repository.kafka.df(repository.kafka.MARKETING_COMPAIGN_TRACE, targetDate)
    val res = Utility.sql(tbl, sql)
    RDBWriter.save(res, DB.MYSQL_231_MARKETING, OUTPUT_TABLE, SaveMode.APPEND)
  }
}
