package com.gnow.processor

import com.gnow.UserTagMail._send
import com.gnow._
import com.gnow.eraser.DBEraser
import com.gnow.persistence.{RDBReader, RDBWriter}
import com.gnow.schema.repository
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}

class UserTagUpdateIncreDaily extends Processor {
  private val USER_TAG_COMPACT = "user_tag_compact"
  private val USER_TAG_COMPACT_MWBYD = "user_tag_compact_mwbyd"
  private val USER_TAG_LAST_MWBYD = "user_tag_last_mwbyd"
  private val USER_TAG_DISTINCT = "user_tag_distinct"
  private val USER_TAG_LATEST_CITY = "user_tag_latest_city"
  private val USER_TAG_LATEST_MISC = "user_tag_latest_misc"
  private val USER_TAG_CITIES = "user_tag_cities"
  private val USER_TAG_CITY = "user_tag_city"
  private val USER_TAG_QUEUEING = "user_tag_queueing"
  private val USER_TAG_QUEUEING_LATEST = "user_tag_queueing_latest"
  private val USER_TAG_QUEUEING_COUNT = "user_tag_queueing_count"
  private val USER_TAG_BOOKING = "user_tag_booking"
  private val USER_TAG_BOOKING_LATEST = "user_tag_booking_latest"
  private val USER_TAG_BOOKING_COUNT = "user_tag_booking_count"
  private val USER_TAG_ORDERING = "user_tag_ordering"
  private val USER_TAG_ORDERING_LATEST = "user_tag_ordering_latest"
  private val USER_TAG_ORDERING_COUNT = "user_tag_ordering_count"
  private val USER_TAG_MWBYD = "user_tag_mwbyd"
  private val USER_TAG_MWBYD0 = "user_tag_mwbyd0"
  private val USER_TAG_MWBYD1 = "user_tag_mwbyd1"
  private val USER_TAG_MWBYD2 = "user_tag_mwbyd2"
  private val USER_TAG_APP = "user_tag_app"
  private val USER_TAG_APP_DETAIL = "user_tag_app_detail"
  private val TARGET_DATE_USER_ID_TMP = "user_tag_user_id_tmp"
  private val TARGET_USER_ID = "target_user_id"
  // MySQL中表
  val USER_TAG = "user_tag_new" //最终的user_tag
  val USER_TAG_RES = "user_tag_res" //当日计算的最终的user_tag
  val USER_TAG_TMP0 = "user_tag_tmp" //临时表-只用来存每天要更新的user_id，表结构特殊
  val USER_TAG_TMP = "user_tag_tmp1" //临时表-用来存计算好的中间结果
  val USER_TAG_DEVICE_INFO = "user_tag_device_id" //保存有设备信息的user_tag
  private val TARGET_DATE_USER_ID = "user_tag_user_id"
  private val BASIC_USER_TAG_ALL = "basic_user_tag_all"
  private val BASIC_USER_TAG_ALL_TMP = "basic_user_tag_all_tmp"
  private val BASIC_USER_TAG_ALL0 = "basic_user_tag_all0"
  private val BASIC_USER_TAG_ALL1 = "basic_user_tag_all1"
  private val BASIC_USER_TAG_ALL2 = "basic_user_tag_all2"
  private val USER_TAG_DATE = "user_tag_date" //

  private var USER_TAG_OPEN = "user_tag_open"
  private var USER_TAG_OPEN0 = "user_tag_open0"
  private var USER_TAG_OPEN1 = "user_tag_open1"
  private var USER_TAG_OPEN2 = "user_tag_open2"
  private var USER_TAG_OPEN_NULL = "user_tag_open_null"
  private var USER_TAG_OPEN_ALL = "user_tag_open_all"
  private var USER_TAG_OPEN_NULL_ALL = "user_tag_open_null_all"
  private var USER_TAG_TOTLE = "user_tag"
  private val USER_DEVICE_ID = "user_device_id"
  private val USER_APNS = "user_apns"
  private val USER_MOBILE = "user_mobile"
  private val USER_STATUS = "user_status"

  private var userTagOpen : DataFrame = _
  private var userTagOpen0 : DataFrame = _
  private var userTagOpen1 : DataFrame = _
  private var userTagOpen2 : DataFrame = _
  private var userTagOpenNull :DataFrame = _
  private var userTagOpenAll : DataFrame = _
  private var userTagOpenNullALL :DataFrame = _
  private var userTagTOTLE :DataFrame = _
  private var userDeviceId :DataFrame = _
  private var userApns :DataFrame = _
  private var userMobile :DataFrame = _
  private var userStatus :DataFrame = _

  private var userTagMWBYDDF: DataFrame = null
  private var userTagMWBYDDF0: DataFrame = null
  private var userTagMWBYDDF1: DataFrame = null
  private var userTagMWBYDDF2: DataFrame = null
  private var userTagAPPDF: DataFrame = null
  private var userTagAPPDetailDF: DataFrame = null
  private var userTagQueueingDF: DataFrame = null
  private var userTagQueueingLatestDF: DataFrame = null
  private var userTagQueueingCountDF: DataFrame = null
  private var userTagBookingDF: DataFrame = null
  private var userTagBookingLatestDF: DataFrame = null
  private var userTagBookingCountDF: DataFrame = null
  private var userTagOrderingDF: DataFrame = null
  private var userTagOrderingLatestDF: DataFrame = null
  private var userTagOrderingCountDF: DataFrame = null
  private var userTagLastMwbydDF: DataFrame = null

  private var userTagCityDF: DataFrame = null
  private var basicUserLabelDF: DataFrame = null
  private var userTagDistinctDF: DataFrame = null
  private var userTagCompactDF: DataFrame = null
  private var userTagCompactMwbydDF: DataFrame = null
  private var userTagLatestCityDF: DataFrame = null
  private var userTagLatestMiscDF: DataFrame = null
  private var userTagCitiesDF: DataFrame = null
  private var userTagTmpDF: DataFrame = null //临时表中的user_tag
  private var userTagTmpAllDF: DataFrame = null //临时表中的user_tag和新的数据join产生
  private var targetDateDFTmp: DataFrame = null //要计算的当天的日志数据tmp
  private var targetDateDF: DataFrame = null //要计算的当天的日志数据
  private var targetDateAllDF: DataFrame = null
  private var targetDateAllTmpDF: DataFrame = null
  private var targetDateAllDF0: DataFrame = null
  private var targetDateAllDF1: DataFrame = null
  private var targetDateAllTmpDF1: DataFrame = null
  private var targetDateAllDF2: DataFrame = null
  private var targetDateAllTmpDF2: DataFrame = null
  private var targetDateUserIdDF: DataFrame = null
  private var targetUserIdDF: DataFrame = null
  private var userResultDF: DataFrame = null //当天计算的结果
  private var userResultAllDF: DataFrame = null //当天计算的结果与历史数据的Join结果
  private var userDeviceResultDF: DataFrame = null
  private var userTagDeviceInfo: DataFrame = null

  def reset(targetDate: String): Unit = {
    val sql_user_id0 = "delete from %s;".format(USER_TAG_TMP0)
    val sql_user_id = "delete from %s;".format(USER_TAG_TMP)
    println(sql_user_id0)
    println(sql_user_id)
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_user_id0)
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_user_id)

  }

  def execute(targetDate: String, input: String, output: String) = {
    //清空临时表
    logger.warn("begin reset")
    reset(targetDate)

    //read log data to DataFrame
    //尝试手动指定schema
    //读取日志数据
    val schema = StructType(
      List(
        StructField("user_id", DoubleType, true),
        StructField("openId", StringType, true),
        StructField("label", StringType, true),
        StructField("create_time", DoubleType, true),
        StructField("device_id", StringType, true),
        StructField("device_status", StringType, true),
        StructField("device_type", StringType, true),
        StructField("mobile", StringType, true),
        StructField("attributes", StringType, true),
        StructField("mwbyd_status", StringType, true),
        StructField("apnstoken", StringType, true)
      )
    )
    targetDateDFTmp = repository.kafka.df(repository.kafka.BASIC_USER_TAG,targetDate, schema)

    //当所有的device_type为0的时候，device_id和apnstoken列没有，补上
    if(!targetDateDFTmp.columns.toList.contains("device_id")){
      targetDateDF = targetDateDFTmp.withColumn("device_id",targetDateDFTmp("device_type")).withColumn("apnstoken",targetDateDFTmp("device_type"))
    }else{
      targetDateDF = targetDateDFTmp
    }

    //注册临时表，cache到内存(多次用到)
    val path = "/tmp/repository/kafka/user_biz_user_tag/" + targetDate
    targetDateDF.write.mode("overwrite").parquet(path)
    targetDateDF = sqlContext.read.parquet(path)
    targetDateDF.createOrReplaceTempView(USER_TAG_DATE)
    targetDateDF.show()
    targetDateDF.cache()

    //get user_id from log 老用户和新用户一起
    targetDateUserIdDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |'' user_tags,
        |'0' city,
        |'0' createtime,
        |'0' queue_last,
        |'0' queue_total,
        |'0' book_last,
        |'0' book_total,
        |'0' order_last,
        |'0' order_total,
        |'0' pay_last,
        |'0' pay_total,
        |'0' pay_amount,
        |'0' device_type,
        |'' last_device,
        |'' mobile,
        |'' mwbyd,
        |'0' mwbyd_status,
        |'0' mwbyd_last_valid_op,
        |'' create_date
        |FROM %s t1
        |WHERE t1.user_id IS NOT NULL
      """.stripMargin.format(
        USER_TAG_DATE
      ), TARGET_DATE_USER_ID)    // 建立临时表TARGET_DATE_USER_ID

    //insert user_id to mysql
    RDBWriter.overwrite(targetDateUserIdDF, DB.MYSQL_50_ASSOCIATOR, USER_TAG_TMP0)

    //read data from user_tag to user_tag_tmp
    //这条sql运行会占内存和cpu么？ 到时测试一下 跑五分钟多一点
    val tansSQL = "insert into user_tag_tmp1 select * from user_tag_new where user_id in (select user_id from user_tag_tmp);"
    println(tansSQL)
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, tansSQL)

    //read user_tag_tmp data to DataFrame  老用户
    userTagTmpDF = RDBReader.read(DB.MYSQL_50_ASSOCIATOR,USER_TAG_TMP)
    //记录每天更新前的状态
    val pathRdb = "/tmp/rdb/basic/user_biz_user_tag/" + targetDate
    userTagTmpDF.write.mode("overwrite").parquet(pathRdb)
    userTagTmpDF = sqlContext.read.parquet(pathRdb)
    userTagTmpDF.createOrReplaceTempView(USER_TAG_TMP)
    userTagTmpDF.cache() //避免重复读数据库

    //将新用户的各个字段初始化
    userTagTmpAllDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int)          user_id,
        |NVL(t2.user_tags,'')             user_tags,
        |NVL(t2.city,0)                 city,
        |NVL(t2.createtime,0)          createtime,
        |NVL(t2.queue_last, 0)       queue_last,
        |NVL(t2.queue_total, 0)         queue_total,
        |NVL(t2.book_last, 0)       book_last,
        |NVL(t2.book_total, 0)         book_total,
        |NVL(t2.order_last, 0)       order_last,
        |NVL(t2.order_total, 0)         order_total,
        |0                                pay_last,
        |0                                pay_total,
        |0                                pay_amount,
        |NVL(t2.device_type,0)           device_type,
        |NVL(t2.device_id,'')           device_id,
        |NVL(t2.device_status,0)           device_status,
        |NVL(t2.last_device,'')             last_device,
        |NVL(t2.mobile, '')              mobile,
        |NVL(t2.mwbyd, '')             mwbyd,
        |NVL(t2.mwbyd_status,0)           mwbyd_status,
        |0                                mwbyd_last_valid_op,
        |'%s'                             create_date
        |from %s t1 left outer join %s t2
        |on cast(t1.user_id as int) = cast(t2.user_id as int)
      """.stripMargin.format(
        targetDate,
        TARGET_DATE_USER_ID,
        USER_TAG_TMP
      ), USER_TAG_TMP)

    //debug
    println("历史数据")
    println("老用户：" + userTagTmpAllDF.where("user_tags != ''").count())
    userTagTmpAllDF.where("user_tags != ''").select("user_id", "user_tags", "city", "device_type", "device_id", "device_status", "last_device", "mobile", "mwbyd", "mwbyd_status", "create_date").where("user_id in (310077, 4693810)").show(100, false)
    println("新用户：" + userTagTmpAllDF.select("user_tags", "city", "device_type", "device_id", "device_status", "last_device", "mobile", "mwbyd", "mwbyd_status", "create_date").where("user_tags = ''").count())
    userTagTmpAllDF.where("user_tags = ''").select("user_id", "user_tags", "city", "device_type", "device_id", "device_status", "last_device", "mobile", "mwbyd", "mwbyd_status", "create_date").where("user_id in (310077, 4693810)").show(100, false)

    /**
      * 计算当天的user_tag
      */
    process(targetDate, input: String, output: String)

    //将当天计算的user_tag插入到一个临时表
    logger.warn("begin reset")
    reset(targetDate)
    logger.warn("begin RDBWriter user_tag_tmp1")
    RDBWriter.overwrite(userResultAllDF, DB.MYSQL_50_ASSOCIATOR, USER_TAG_TMP)

    //删除历史的数据
    logger.warn("begin delete user_tag")
    val sql = "delete from %s where user_id in (select user_id from %s);".format(USER_TAG,USER_TAG_TMP)
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql)

    //在设备表中删除历史数据
    logger.warn("begin delete user_tag_device_info")
    val sql_device1 = "delete from %s where user_id in (select user_id from %s);".format(USER_TAG_DEVICE_INFO,USER_TAG_TMP)
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_device1)

    //插入新数据
    logger.warn("begin RDBWriter USER_TAG")
    val sql_insert = "insert into %s select * from %s;".format(USER_TAG, USER_TAG_TMP) //exists
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_insert)
    logger.warn("end RDBWriter USER_TAG")

    //在设备表中插入新数据
    logger.warn("begin RDBWriter USER_TAG_DEVICE_INFO")
    val sql_insert_device1 = "insert into %s select * from %s where length(last_device)>3;".format(USER_TAG_DEVICE_INFO, USER_TAG_TMP) //exists
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_insert_device1)
    logger.warn("end RDBWriter USER_TAG_DEVICE_INFO")

    /**
      * 根据device_id去重
      */
    processDeviceInfo(targetDate, input, output)

    logger.warn("begin reset")
    reset(targetDate)
    //将去重结果插入临时表
    logger.warn("begin RDBWriter user_tag_tmp1")
    RDBWriter.overwrite(userDeviceResultDF, DB.MYSQL_50_ASSOCIATOR, USER_TAG_TMP)

    //删除历史的数据
    logger.warn("begin delete user_tag")
    val sql_user_tag = "delete from %s where user_id in (select user_id from %s);".format(USER_TAG,USER_TAG_TMP) //exists
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_user_tag)

    //在设备表中删除历史数据
    logger.warn("begin delete user_tag_device_info")
    val sql_device2 = "delete from %s where user_id in (select user_id from %s);".format(USER_TAG_DEVICE_INFO,USER_TAG_TMP)
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_device2)

    //插入新数据
    logger.warn("begin RDBWriter USER_TAG")
    val sql_insert_user_tag = "insert into %s select * from %s;".format(USER_TAG,USER_TAG_TMP) //exists
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_insert_user_tag)
    logger.warn("end RDBWriter USER_TAG")

    //在设备表中插入新数据
    logger.warn("begin RDBWriter USER_TAG_DEVICE_INFO")
    val sql_insert_device2 = "insert into %s select * from %s;".format(USER_TAG_DEVICE_INFO, USER_TAG_TMP)
    DBEraser.remove(DB.MYSQL_50_ASSOCIATOR, sql_insert_device2)
    logger.warn("end RDBWriter USER_TAG_DEVICE_INFO")

    //发送邮件
    _send("UserTag Job Run Success", targetDate + "UserTag新增或更新的UserID数量为：" + userResultAllDF.count + ", " + "UserTag根据device去重的UserID数量为：" + userDeviceResultDF.count)

    println("Happy Ending!")

  }

  def process(targetDate: String, input: String, output: String) = {
    //注册tag聚合函数
    val udafConcat = new UDAFConcat()
    sqlContext.udf.register("udafConcat", udafConcat)

    //注册tag合并udf函数
    sqlContext.udf.register("removeDP", UDF.removeDP(_: String, _: String))

    targetDateUserIdDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id
        |FROM %s t1
        |WHERE t1.user_id IS NOT NULL
      """.stripMargin.format(
        USER_TAG_DATE
      ), TARGET_DATE_USER_ID_TMP)    // 建立临时表TARGET_DATE_USER_ID_TMP
    logger.warn("targetDateUserIdDF count:" + targetDateUserIdDF.count)

    userTagCityDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT *
        |FROM %s t1
        |WHERE t1.label = '城市'
      """.stripMargin.format(
        USER_TAG_DATE
      ), USER_TAG_CITY)
    logger.warn("userTagCityDF count:" /*+ userTagCityDF.count*/)

    userTagMWBYDDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |'美味不用等'              user_tag,
        |t1.openId                open_id,
        |t1.mwbyd_status           mwbyd_status,
        |cast(t1.create_time as int) create_time
        |FROM %s t1
        |WHERE t1.label = '美味不用等'
      """.stripMargin.format(
        USER_TAG_DATE
      ), USER_TAG_MWBYD)
    logger.warn("userTagMWBYDDF1 count:" /*+ userTagMWBYDDF1.count*/)

    userTagOpen = Utility.registerTableWithSQL(sqlContext,
      """
        |select
        |cast(t1.user_id as int)  user_id,
        |'美味不用等'  user_tag,
        |max(cast(t1.create_time as int)) create_time
        |from %s t1
        |where t1.openId is not null
        |and  t1.label = '美味不用等'
        |group by cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_DATE
      ), USER_TAG_OPEN)
    logger.warn("userTagOpen1 count:" /*+ userTagOpen1.count*/)

    userTagOpenNull = Utility.registerTableWithSQL(sqlContext,
      """
        |select distinct
        |cast(t1.user_id as int) user_id
        |from %s t1  left join  %s t2
        |on cast(t1.user_id as int) = cast(t2.user_id as int)
        |where t2.user_id is null
      """.stripMargin.format(
        USER_TAG_MWBYD,
        USER_TAG_OPEN
      ), USER_TAG_OPEN_NULL)
    logger.warn("userTagOpenNull count:" /*+ userTagOpenNull.count*/)

    userTagOpenNullALL =  Utility.registerTableWithSQL(sqlContext,
      """
        |select distinct
        |cast(t1.user_id as int) user_id,
        |'美味不用等'  user_tag,
        |''    open_id
        |from %s t1  left join %s t2
        |on cast(t1.user_id as int) = cast(t2.user_id as int)
      """.stripMargin.format(
        USER_TAG_OPEN_NULL,
        USER_TAG_MWBYD
      ), USER_TAG_OPEN_NULL_ALL)
    logger.warn("userTagOpenNullALL count:" /*+ userTagOpenNullALL.count*/)

    userTagOpenAll = Utility.registerTableWithSQL(sqlContext,
      """
        |select
        |cast(t1.user_id as int) user_id,
        |t1.user_tag,
        |t2.open_id
        |from %s t1 left join %s t2
        |on cast(t1.user_id as int) = cast(t2.user_id as int)
        |and cast(t1.create_time as int) = cast(t2.create_time as int)
      """.stripMargin.format(
        USER_TAG_OPEN,
        USER_TAG_MWBYD
      ), USER_TAG_OPEN_ALL)
    logger.warn("userTagOpenAll count:" /*+ userTagOpenAll.count*/)

    userTagTOTLE = Utility.registerTableWithSQL(sqlContext,
      """
         select * from %s t1
         union
         select * from %s t2

      """.stripMargin.format(
        USER_TAG_OPEN_ALL,
        USER_TAG_OPEN_NULL_ALL
      ), USER_TAG_TOTLE)
    logger.warn("userTagTOTLE count:" /*+ userTagTOTLE.count*/)

    userTagAPPDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |'APP'              user_tag
        |FROM %s t1
        |WHERE t1.label = 'APP'
      """.stripMargin.format(
        USER_TAG_DATE
      ), USER_TAG_APP)
    logger.warn("userTagAPPDF count:" /*+ userTagAPPDF.count*/)

    userTagAPPDetailDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |  cast(t2.user_id as int) user_id,
        |  t2.apnstoken,
        |  t2.device_id,
        |  t2.device_status,
        |  t2.device_type,
        |  t2.create_time
        |FROM
        |  (
        |  SELECT
        |    *
        |  FROM
        |    %s t1
        |  WHERE
        |    t1.label = 'APP'
        |  ) t2
      """.stripMargin.format(
        USER_TAG_DATE
      ), USER_TAG_APP_DETAIL)
    logger.warn("userTagAPPDF count:" /*+ userTagAPPDF.count*/)

    userTagQueueingDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |cast(t1.create_time as int) create_time
        |FROM %s t1
        |WHERE t1.label = '排队'
      """.stripMargin.format(
        USER_TAG_DATE
      ), USER_TAG_QUEUEING)
    logger.warn("userTagQueueingDF count:" /*+ userTagQueueingDF.count*/)
//    userTagQueueingDF.cache()

    userTagQueueingLatestDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT  distinct
        |cast(t1.user_id as int) user_id,
        |'排队'              user_tag,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_QUEUEING
      ), USER_TAG_QUEUEING_LATEST)
    logger.warn("userTagQueueingLatestDF count:" /*+ userTagQueueingLatestDF.count*/)

    userTagQueueingCountDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |count(cast(t1.user_id as int)) user_id_count
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_QUEUEING
      ), USER_TAG_QUEUEING_COUNT)
    logger.warn("userTagQueueingCountDF count:" /*+ userTagQueueingCountDF.count*/)

    userTagBookingDF = Utility.registerTableWithSQL(sqlContext,
      """
        SELECT DISTINCT
        cast(t1.user_id as int) user_id,
        cast(t1.create_time as int) create_time
        FROM %s t1
        WHERE t1.label = '预订'
      """.stripMargin.format(
        USER_TAG_DATE
      ), USER_TAG_BOOKING)
    logger.warn("userTagBookingDF count:" /*+ userTagBookingDF.count*/)
//    userTagBookingDF.cache()

    userTagBookingLatestDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int) user_id,
        |'预订'              user_tag,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_BOOKING
      ), USER_TAG_BOOKING_LATEST)
    logger.warn("userTagBookingLatestDF count:" /*+ userTagBookingLatestDF.count*/)

    userTagBookingCountDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |count(cast(t1.user_id as int)) user_id_count
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_BOOKING
      ), USER_TAG_BOOKING_COUNT)
    logger.warn("userTagBookingCountDF count:" /*+ userTagBookingCountDF.count*/)

    userTagOrderingDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |cast(t1.create_time as int) create_time
        |FROM %s t1
        |WHERE t1.label = '点菜'
      """.stripMargin.format(
        USER_TAG_DATE
      ), USER_TAG_ORDERING)
    logger.warn("userTagOrderingDF count:" /*+ userTagOrderingDF.count*/)
//    userTagOrderingDF.cache()

    userTagOrderingLatestDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |'点菜'              user_tag,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_ORDERING
      ), USER_TAG_ORDERING_LATEST)
    logger.warn("userTagOrderingLatestDF count:" /*+ userTagOrderingLatestDF.count*/)

    userTagOrderingCountDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |count(cast(t1.user_id as int)) user_id_count
        |FROM %s t1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_ORDERING
      ), USER_TAG_ORDERING_COUNT)
    logger.warn("userTagOrderingCountDF count:" /*+ userTagOrderingCountDF.count*/)

    userTagCityDF.printSchema()

    userTagCompactDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |cast(t1.user_id as int) user_id,
        |t1.device_id,
        |t1.device_type,
        |t1.mobile,
        |get_json_object(t1.attributes, '$.city_id') city_id,
        |get_json_object(t1.attributes, '$.city_name') city_name,
        |t1.create_time,
        |t1.mwbyd_status
        |FROM %s t1
        |WHERE 1 = 1
        |AND get_json_object(t1.attributes, '$.city_id') IS NOT NULL
      """.stripMargin.format(
        USER_TAG_CITY
      ), USER_TAG_COMPACT)
    logger.warn("userTagCompactDF count:" /*+ userTagCompactDF.count*/)

    userTagDistinctDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int) user_id,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |WHERE 1 = 1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_COMPACT
      ), USER_TAG_DISTINCT)
    logger.warn("userTagDistinctDF count:" /*+ userTagDistinctDF.count*/)

    userMobile = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |  t1.user_id      user_id,
        |  NVL(t1.mobile,'') mobile
        |FROM %s t1 JOIN
        |  (
        |  SELECT
        |    cast(t0.user_id as int) user_id,
        |    max(cast(t0.create_time as int)) max_create_time
        |  FROM %s t0
        |    WHERE t0.mobile is not null
        |  GROUP BY
        |    cast(t0.user_id as int)
        |  ) t2
        |ON
        |  cast(t1.user_id as int) = cast(t2.user_id as int)
        |  AND t1.create_time = cast(t2.max_create_time as int)
      """.stripMargin.format(
        USER_TAG_COMPACT,USER_TAG_COMPACT
      ), USER_MOBILE)
    logger.warn("userMobile count:" /*+ userApns.count*/)

    userDeviceId = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |cast(t1.user_id as int) user_id,
        |max(case when (instr(t1.device_id,'xmpp') = 0) then t1.device_id else '' END)   device_id,
        |max(t1.device_type) device_type,
        |max(t1.device_status) device_status,
        |max(NVL(t1.apnstoken,''))  apnstoken,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1 join (
        |  SELECT
        |    cast(t0.user_id as int) user_id,
        |    max(cast(t0.create_time as int)) max_create_time
        |  FROM %s t0
        |    WHERE t0.device_id is not null
        |  GROUP BY
        |    cast(t0.user_id as int)
        |)  t2 on
        |   (cast(t1.user_id as int) = cast(t2.user_id as int)
        |    AND t1.create_time = cast(t2.max_create_time as int)
        |   )
        |WHERE 1 = 1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_APP_DETAIL, USER_TAG_APP_DETAIL
      ), USER_DEVICE_ID)
    logger.warn("userDeviceId count:" /*+ userDeviceId.count*/)

    userApns = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |  t1.user_id      user_id,
        |  NVL(t1.apnstoken,'') apnstoken
        |FROM %s t1 JOIN
        |  (
        |  SELECT
        |    cast(t0.user_id as int) user_id,
        |    max(cast(t0.create_time as int)) max_create_time
        |  FROM %s t0
        |    WHERE t0.apnstoken is not null
        |  GROUP BY
        |    cast(t0.user_id as int)
        |  ) t2
        |ON
        |  cast(t1.user_id as int) = cast(t2.user_id as int)
        |  AND t1.create_time = cast(t2.max_create_time as int)
      """.stripMargin.format(
        USER_TAG_APP_DETAIL,USER_TAG_APP_DETAIL
      ), USER_APNS)
    logger.warn("userApns count:" /*+ userApns.count*/)

    userTagCompactMwbydDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT DISTINCT
        |t1.user_id,
        |t1.mwbyd_status,
        |t1.create_time
        |FROM %s t1
        |WHERE 1 = 1
      """.stripMargin.format(
        USER_TAG_MWBYD
      ), USER_TAG_COMPACT_MWBYD)
    logger.warn("userTagCompactMwbydDF count:" /*+ userTagCompactMwbydDF.count*/)

    userTagLastMwbydDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int) user_id,
        |max(cast(t1.create_time as int)) max_create_time
        |FROM %s t1
        |WHERE 1 = 1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        USER_TAG_MWBYD
      ), USER_TAG_LAST_MWBYD)
    logger.warn("userTagLastMwbydDF count:" /*+ userTagLastMwbydDF.count*/)

    userTagLatestCityDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t2.user_id as int) user_id,
        |max(cast(t2.create_time as int)) max_create_time,
        |min(NVL(t2.mwbyd_status,1))   mwbyd_status
        |FROM %s t1 left join %s t2 on (
        |  cast(t1.user_id as int) = cast(t2.user_id as int)
        |  AND t1.max_create_time = cast(t2.create_time as int)
        |)
        |WHERE 1=1
        |AND t2.create_time is not NULL
        |GROUP BY
        |cast(t2.user_id as int)
      """.stripMargin.format(USER_TAG_LAST_MWBYD,
        USER_TAG_COMPACT_MWBYD), USER_TAG_LATEST_CITY)
    logger.warn("userTagLatestCityDF count:" /*+ userTagLatestCityDF.count*/)

    userTagLatestMiscDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT  distinct
        |cast(t1.user_id as int) user_id,
        |max(cast(t2.create_time as int))  max_create_time,
        |max(concat_ws(',',
        |t3.device_id,
        |t4.apnstoken))                      last_device,
        |max(t3.device_type)                 device_type,
        |max(
        |  case t3.device_type
        |  when 0 then t4.apnstoken
        |  when 1 then t3.device_id
        |  else ''
        |  end)                              device_id,
        |max(t3.device_status)               device_status,
        |max(t5.mobile)                      mobile,
        |max(t2.city_id)                     city_id
        |FROM %s t1 left join %s t2 on (
        |  cast(t1.user_id as int) = cast(t2.user_id as int)
        |) left join %s t3 on (
        |  cast(t1.user_id as int) = cast(t3.user_id as int)
        |) left join %s t4 on (
        |  cast(t1.user_id as int) = cast(t4.user_id as int)
        |) left join %s t5 on (
        |  cast(t1.user_id as int) = cast(t5.user_id as int)
        |)
        |WHERE 1=1
        |GROUP BY
        |cast(t1.user_id as int)
      """.stripMargin.format(
        TARGET_DATE_USER_ID_TMP,  //t1
        USER_TAG_COMPACT,   //t2
        USER_DEVICE_ID,  //t3
        USER_APNS,  //t4
        USER_MOBILE)    //t5
      , USER_TAG_LATEST_MISC)
    logger.warn("userTagLatestMiscDF count:" /*+ userTagLatestMiscDF.count*/)
    userTagLatestMiscDF.where("user_id in (41549389)").show()

    userTagCitiesDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |t1.user_id,
        |concat_ws(",", udafConcat(t1.city_name)) city_names
        |FROM %s t1
        |WHERE 1=1
        |GROUP BY
        |t1.user_id
      """.stripMargin.format(USER_TAG_COMPACT), USER_TAG_CITIES)
    logger.warn("userTagCitiesDF count:" /*+ userTagCitiesDF.count*/)

    userResultDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT distinct
        |cast(t1.user_id as int)          user_id,
        |max(concat_ws(',',
        |t4.city_names,
        |t5.user_tag,
        |t7.user_tag,
        |t9.user_tag,
        |t11.user_tag,
        |t12.user_tag))                    user_tags,
        |max(t2.city_id)                       city,
        |max(t13.max_create_time)               createtime,
        |max(NVL(t5.max_create_time, 0))       queue_last,
        |max(NVL(t6.user_id_count, 0))         queue_total,
        |max(NVL(t7.max_create_time, 0))       book_last,
        |max(NVL(t8.user_id_count, 0))         book_total,
        |max(NVL(t9.max_create_time, 0))       order_last,
        |max(NVL(t10.user_id_count, 0))        order_total,
        |0                                pay_last,
        |0                                pay_total,
        |0                                pay_amount,
        |max(t2.device_type)                   device_type,
        |max(t2.device_id)                  device_id,
        |max(t2.device_status)                device_status,
        |max(IF(length(t2.last_device)=1,"",t2.last_device))     last_device,
        |max(NVL(t2.mobile, '0'))              mobile,
        |max(NVL(t11.open_id, '0'))             mwbyd,
        |max(NVL(t3.mwbyd_status,1))           mwbyd_status,
        |0                                mwbyd_last_valid_op,
        |'%s'                             create_date
        |FROM %s t1 left join %s t13 on (
        |  cast(t1.user_id as int)  = cast(t13.user_id as int)
        |) left join %s t2 on (
        |  cast(t1.user_id as int)  = cast(t2.user_id as int)
        |) left join %s t4 on (
        |  cast(t1.user_id as int)  = cast(t4.user_id as int)
        |) left join %s t3 on (
        |  cast(t1.user_id as int)  = cast(t3.user_id as int)
        |) left join %s t5 on (
        |  cast(t1.user_id as int)  = cast(t5.user_id as int)
        |) left join %s t6 on (
        |  cast(t1.user_id as int)  = cast(t6.user_id as int)
        |) left join %s t7 on (
        |  cast(t1.user_id as int)  = cast(t7.user_id as int)
        |) left join %s t8 on (
        |  cast(t1.user_id as int)  = cast(t8.user_id as int)
        |) left join %s t9 on (
        |  cast(t1.user_id as int)  = cast(t9.user_id as int)
        |) left join %s t10 on (
        |  cast(t1.user_id as int)  = cast(t10.user_id as int)
        |) left join %s t11 on (
        |  cast(t1.user_id as int)  = cast(t11.user_id as int)
        |) left join %s t12 on (
        |  cast(t1.user_id as int)  = cast(t12.user_id as int)
        |)
        |WHERE 1=1
        |group by cast(t1.user_id as int)
      """.stripMargin.format(
        targetDate,
        TARGET_DATE_USER_ID_TMP, //t1
        USER_TAG_DISTINCT, //t13
        USER_TAG_LATEST_MISC, //t2
        USER_TAG_CITIES, //t4
        USER_TAG_LATEST_CITY, //t5
        USER_TAG_QUEUEING_LATEST, //t6
        USER_TAG_QUEUEING_COUNT, //t5
        USER_TAG_BOOKING_LATEST, //t7
        USER_TAG_BOOKING_COUNT, //t8
        USER_TAG_ORDERING_LATEST, //t9
        USER_TAG_ORDERING_COUNT, //t10
        USER_TAG_TOTLE, //t11
        USER_TAG_APP //t12
      ), USER_TAG_RES)
    logger.warn("userResultDF count:" /*+ userResultDF.count*/)

    //used twice later,save to memory and disk
    userResultDF.createOrReplaceTempView(USER_TAG_RES)
    userResultDF.cache()
    //debug
    println("当天计算结果：" + userResultDF.count())
    userResultDF.select("user_id", "user_tags", "city", "device_type", "device_id", "device_status", "last_device", "mobile", "mwbyd", "mwbyd_status", "create_date")
      .where("user_id in (310077, 4693810)").show(50, false)

    //合并历史值，与当天计算值
    userResultAllDF = sqlContext.sql(
      """
        |select
        |  t1.user_id,
        |  removeDP(t1.user_tags, NVL(t2.user_tags, ''))    user_tags,
        |  NVL(t2.city, t1.city)    city,
        |  IF(NVL(t2.createtime, 0) = 0, t1.createtime, NVL(t2.createtime, 0))   createtime,
        |  NVL(t2.queue_last, t1.queue_last)    queue_last,
        |  cast(NVL(t2.queue_total, 0) as int) + cast(t1.queue_total as int)    queue_total,
        |  NVL(t2.book_last, t1.book_last)    book_last,
        |  cast(NVL(t2.book_total, 0) as int) + cast(t1.book_total as int)    book_total,
        |  NVL(t2.order_last, t1.order_last)    order_last,
        |  cast(NVL(t2.order_total, 0) as int) + cast(t1.order_total as int)    order_total,
        |  t1.pay_last,
        |  t1.pay_total,
        |  t1.pay_amount,
        |  NVL(t2.device_type, t1.device_type)    device_type,
        |  (case when (t2.device_id= '' or t2.device_id is null) then t1.device_id else t2.device_id end)    device_id,
        |  NVL(t2.device_status, t1.device_status)    device_status,
        |  IF(length(NVL(t2.last_device,'0,0'))<=3, t1.last_device, NVL(t2.last_device,''))    last_device,
        |  (case when (t2.mobile = '0' or t2.mobile is null) then t1.mobile else t2.mobile end)    mobile,
        |  (case when (t2.mwbyd = '0' or t2.mwbyd is null) then t1.mwbyd else t2.mwbyd end)    mwbyd,
        |  NVL(t2.mwbyd_status, t1.mwbyd_status)    mwbyd_status,
        |  t1.mwbyd_last_valid_op,
        |  '%s'    create_date
        |from
        |  %s t1
        |left join
        |  %s t2
        |on
        |  t1.user_id = t2.user_id
      """.stripMargin.format(targetDate ,USER_TAG_TMP, USER_TAG_RES))
    userResultAllDF.createOrReplaceTempView(USER_TAG)
    //debug
    println("与历史合并后结果：" + userResultAllDF.count())
    userResultAllDF.select("user_id", "user_tags", "city", "device_type", "device_id", "device_status", "last_device", "mobile", "mwbyd", "mwbyd_status", "create_date")
      .where("user_id in (310077, 4693810)").show(50, false)
  }

  //计算出一个device对应多个用户的用户，并把历史用户的device清除
  def processDeviceInfo(targetDate: String, input: String, output: String): Unit = {
    //获取历史设备信息
    userTagDeviceInfo = RDBReader.read(DB.MYSQL_50_ASSOCIATOR,USER_TAG_DEVICE_INFO)
    userTagDeviceInfo.createOrReplaceTempView(USER_TAG_DEVICE_INFO)

    //历史重复的device直接设为空
    val userTagHistoryDeviceInfoDF = sqlContext.sql(
      """
        |select
        |  t1.user_id,
        |  t1.user_tags,
        |  t1.city,
        |  t1.createtime,
        |  t1.queue_last,
        |  t1.queue_total,
        |  t1.book_last,
        |  t1.book_total,
        |  t1.order_last,
        |  t1.order_total,
        |  t1.pay_last,
        |  t1.pay_total,
        |  t1.pay_amount,
        |  t1.device_type,
        |  t1.device_id device_id,
        |  '2' device_status,
        |  t1.last_device,
        |  t1.mobile,
        |  t1.mwbyd,
        |  t1.mwbyd_status,
        |  t1.mwbyd_last_valid_op,
        |  '%s' create_date
        |from
        |  %s t1,%s t2
        |where
        |  t1.device_id is not null
        |  and
        |  t2.device_id is not null
        |  and
        |  t1.device_id != ''
        |  and
        |  t2.device_id != ''
        |  and
        |  t1.device_id = t2.device_id
        |  and
        |  t1.user_id!=t2.user_id
      """.stripMargin.format(targetDate,USER_TAG_DEVICE_INFO,USER_TAG))
    //debug
    println("userTagHistoryDeviceInfo: " + userTagHistoryDeviceInfoDF.count())
    println("userTagHistoryDeviceInfo: " + userTagHistoryDeviceInfoDF.dropDuplicates("user_id").count())
    userTagHistoryDeviceInfoDF.show()

    //获取当日新增的device重复的user_id
    val userTagDuplicateDeviceDailyDF = sqlContext.sql(
      """
        |select
        |  t0.user_id,
        |  t0.user_tags,
        |  t0.city,
        |  t0.createtime,
        |  t0.queue_last,
        |  t0.queue_total,
        |  t0.book_last,
        |  t0.book_total,
        |  t0.order_last,
        |  t0.order_total,
        |  t0.pay_last,
        |  t0.pay_total,
        |  t0.pay_amount,
        |  t0.device_type,
        |  t0.device_id device_id,
        |  '1' device_status,
        |  t0.last_device,
        |  t0.mobile,
        |  t0.mwbyd,
        |  t0.mwbyd_status,
        |  t0.mwbyd_last_valid_op,
        |  '%s' create_date
        |from
        |  %s t0
        |join
        | (
        | select
        |    utt.*
        | from
        |    (select
        |       device_id,
        |       max(createtime) max_createtime,
        |       count(1) cnt
        |    from
        |       %s
        |    group by
        |       device_id
        |    ) utt
        | where
        |    utt.cnt >= 1
        | ) t1
        |on
        |  t0.device_id is not null
        |  and
        |  t1.device_id is not null
        |  and
        |  t0.device_id != ''
        |  and
        |  t1.device_id != ''
        |  and
        |  t0.device_id = t1.device_id
        |  and
        |  t0.createtime = t1.max_createtime
      """.stripMargin.format(targetDate, USER_TAG, USER_TAG))
    println("userTagDuplicateDeviceDailyDF: " + userTagDuplicateDeviceDailyDF.count())
    userTagDuplicateDeviceDailyDF.show()

    //合并历史去重和当日去重
    userDeviceResultDF = userTagHistoryDeviceInfoDF.except(userTagDuplicateDeviceDailyDF).union(userTagDuplicateDeviceDailyDF)
    userDeviceResultDF = userDeviceResultDF.dropDuplicates("user_id")
    //debug
    println("userDeviceResultDF: " + userDeviceResultDF.count())
    userDeviceResultDF.show()
    userDeviceResultDF.cache()

  }
}
