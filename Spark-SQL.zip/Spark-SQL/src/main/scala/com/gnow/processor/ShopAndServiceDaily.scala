package com.gnow.processor

import java.io.{PrintWriter, StringWriter}

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.sql.SQLShopAndService
import com.gnow.{DB, Processor, Utility}

class ShopAndServiceDaily extends Processor {
  val OUTPUT_TABLE = "shop_and_service"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from shop_and_service
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLShopAndService.getSQL(targetDate)
    val tbl = repository.kafka.df(repository.kafka.BASIC_SHOP_SERVICE, targetDate)
    val res = Utility.sql(tbl, sql)
    RDBWriter.save(res, DB.ORACLE_37_BWSWD, OUTPUT_TABLE)
  }
}
