package com.gnow.processor.vo

/**
  * 用来存放测试数据 一条log
  *
  * @param mwAuthToken
  * @param url
  * @param page
  * @param contentId
  * @param etype
  * @param event
  * @param time
  */
case class SCLog(mwAuthToken: String, url: String, page: String, contentId: String, etype: String, event: String, time: String)
