package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.SQLSecondPayEstimate
import com.gnow.{DB, Processor}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext

class SecondPayEstimateWeekly extends Processor {
  val OUTPUT_TABLE = "second_pay_estimate"

  def reset(targetDate: String, interval_type: String): Unit = {
    val sql =
      """
        |delete
        |from second_pay_estimate
        |where create_date= '%s'
        |and interval_type = '%s'
      """.stripMargin
    DBEraser.remove(DB.MYSQL_231_SPARK, sql.format(targetDate, interval_type))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate, "1")
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    rdb.basic.df(rdb.basic.WX_ACCOUNT_TABLE)
    rdb.paying.df4Weekly(rdb.paying.COM_PAY, targetDate)
    val sql = SQLSecondPayEstimate.getSQLWeek(targetDate).format(rdb.paying.COM_PAY,
      rdb.paying.COM_PAY, rdb.basic.WX_ACCOUNT_TABLE, rdb.basic.SHOP_TABLE)

    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    val week_detail = sqlContext.sql(sql)

    week_detail.registerTempTable("detail")
    val ressql = SQLSecondPayEstimate.getRes(targetDate).format("detail", rdb.basic.SHOP_TABLE)
    val res = sqlContext.sql(ressql)

    RDBWriter.save(res, DB.MYSQL_231_SPARK, OUTPUT_TABLE)
  }
}
