package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 10/04/2018.
  */
class MwAppSrcDaily extends Processor {
  var res1: DataFrame = _
  var res2: DataFrame = _
  val db = DB.ORACLE_37_BWSWD
  val destTable1 = "DM_MONITOR_APP_USER_SRC"
  val destTable2 = "DM_MONITOR_APP_USER_SRC_A"

  def reset(targetDate: String): Unit = {
    val sql1 = "delete from %s where day_id = '%s' and interval_type = '0'".format(destTable1, targetDate)
    val sql2 = "delete from %s".format(destTable2)
    println("操作数据库：" + db.toString)
    println("执行SQL：" + sql1)
    DBEraser.remove(db, sql1)

    println("执行SQL：" + sql2)
    DBEraser.remove(db, sql2)
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

    println("保存到db")
    RDBWriter.overwrite(res1.coalesce(1), db, destTable1)
    RDBWriter.overwrite(res2.coalesce(1), db, destTable2)
    println("Happy Ending!")

  }

  def process(targetDate: String, input: String, output: String) = {
    //读取日志数据
    val newDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + targetDate)
    newDF.createOrReplaceTempView("user_table_new")
    val activeDF = sqlContext.read.parquet("/dw/log/c/user_table_detail/" + targetDate)
    activeDF.createOrReplaceTempView("user_table_detail")
    val userTableDF = sqlContext.read.parquet("/dw/log/c/user_table/")
    userTableDF.createOrReplaceTempView("user_table")

    //计算每天的渠道情况
    res1 = sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	'0' interval_type,
        |	t3.app_src src_id,
        |	t3.users_new,
        |	t4.users_active
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		count(distinct t1.device_id) users_new
        |	from
        |		(select * from user_table_new where device_id is not null and device_id != '' and app_src not in('inhouse', 'InHouse')) t1
        |	group by
        |		t1.day_id,
        |		t1.app_src) t3
        |join
        |	(select
        |		t2.day_id,
        |		t2.app_src,
        |		count(distinct t2.device_id) users_active
        |	from
        |		(select * from user_table_detail where device_id is not null and device_id != '' and app_src not in('inhouse', 'InHouse')) t2
        |	group by
        |		t2.day_id,
        |		t2.app_src) t4
        |on
        |	t3.day_id = t4.day_id
        |	and
        |	t3.app_src = t4.app_src
      """.stripMargin)

    //计算渠道累计用户数
    res2 = sqlContext.sql(
      """
        |select
        |		t1.app_src src_id,
        |		count(distinct t1.device_id) users_all
        |	from
        |		(select * from user_table where app_src is not null and device_id is not null and device_id != '' and app_src not in('inhouse', 'InHouse')) t1
        |	group by
        |		t1.app_src
      """.stripMargin)

  }
}


