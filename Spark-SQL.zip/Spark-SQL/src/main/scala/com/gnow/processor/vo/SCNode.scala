package com.gnow.processor.vo

/**
  * 用来标识每个访问节点
  *
  * @param userId
  * @param page
  * @param contentId
  * @param etype
  * @param time
  */
case class SCNode(userId: String, nodeId: String, pageId: String, page: String, contentId: String, event: String, etype: Int, time: Long)
