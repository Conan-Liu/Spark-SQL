package com.gnow.processor

import cn.mwee.util.DateUtils
import com.gnow.config.PathUtil
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.{DB, Processor}
import org.apache.spark.sql.DataFrame

/**
  * Created by tal on 10/04/2018.
  */
class MwAppRetentionMonthly extends Processor {
  var res: DataFrame = _
  val db = DB.ORACLE_37_BWSWD
  val destTable = "DM_MONITOR_APP_USER_RETEN_M"

  def reset(targetDate: String): Unit = {

  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)

  }

  def process(targetDate: String, input: String, output: String) = {
    //计算日期
    val dayM1 = DateUtils.getMonthLastDay(targetDate, -1)
    val dayM2 = DateUtils.getMonthLastDay(targetDate, -2)
    val dayM3 = DateUtils.getMonthLastDay(targetDate, -3)
    //读取日志数据
    //新用户数据
    val dayM0NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Monthly(targetDate))
    val dayM1NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Monthly(dayM1))
    val dayM2NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Monthly(dayM2))
    val dayM3NewDF = sqlContext.read.parquet("/dw/log/c/user_table_new/" + PathUtil.getPath4Monthly(dayM3))
    dayM0NewDF.createOrReplaceTempView("day_m0_new")
    dayM1NewDF.createOrReplaceTempView("day_m1_new")
    dayM2NewDF.createOrReplaceTempView("day_m2_new")
    dayM3NewDF.createOrReplaceTempView("day_m3_new")
    //活跃用户数据
    val dayM0ActiveDF = sqlContext.read.parquet("/dw/log/c/user_table_detail/" + targetDate)
    dayM0ActiveDF.createOrReplaceTempView("day_m0_active")

    //从hdfs读取历史计算结果
    val userRetenHisDF = sqlContext.read.parquet("/dw/log/c/user_retention_monthly")
    userRetenHisDF.cache()
    println("userRetenHisDF cnt: " + userRetenHisDF.count())
    userRetenHisDF.createOrReplaceTempView("user_retention_monthly")
    val userRetenOldDF = userRetenHisDF.where("day_id not in ('%s', '%s', '%s', '%s')".format(targetDate, dayM1, dayM2, dayM3))

    //计算上个月新用户数
    val dayM0RetenDF = sqlContext.sql(
      """
        |select
        |	t3.day_id,
        |	t3.app_src src_id,
        |	t3.users_new,
        |	cast(null as long) reten_1m,
        |	cast(null as long) reten_2m,
        |	cast(null as long) reten_3m
        |from
        |	(select
        |		'%s' day_id,
        |		t2.app_src,
        |		count(distinct t2.device_id) users_new
        |	from
        |		(select
        |			t1.day_id,
        |			t1.app_src,
        |			t1.device_id
        |		from
        |			day_m0_new t1
        |		where
        |			t1.app_src is not null
        |			and
        |			t1.device_id is not null
        |			and
        |			t1.device_id != ''
        |			) t2
        |	group by
        |		'%s',
        |		t2.app_src) t3
      """.stripMargin.format(targetDate, targetDate))
    dayM0RetenDF.printSchema()
    dayM0RetenDF.show()
    dayM0RetenDF.repartition(1).write.mode("overwrite").parquet("/dw/log/c/user_retention_monthly")

    //计算用户留存
    //过去1个月
    val dayM1RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t4.reten_1m,
        |	t5.reten_2m,
        |	t5.reten_3m
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_1m
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m1_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_monthly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM1, dayM1))
    dayM1RetenDF.show()
    //过去2个月
    val dayM2RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1m,
        |	t4.reten_2m,
        |	t5.reten_3m
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_2m
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m2_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_monthly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM2, dayM2))
    dayM2RetenDF.show()
    //过去3个月
    val dayM3RetenDF = sqlContext.sql(
      """
        |select
        |	t5.day_id,
        |	t5.src_id src_id,
        | t5.users_new,
        |	t5.reten_1m,
        |	t5.reten_2m,
        |	t4.reten_3m
        |from
        |(select
        |	'%s' day_id,
        |	t3.app_src,
        |	count(distinct t3.device_id) reten_3m
        |from
        |	(select
        |		t1.day_id,
        |		t1.app_src,
        |		t1.device_id
        |	from
        |		day_m3_new t1, day_m0_active t2
        |	where
        |		t1.device_id = t2.device_id
        |		and
        |		t1.app_src is not null
        |		and
        |		t1.device_id is not null
        |		and
        |		t1.device_id != ''
        |		and
        |		t2.device_id is not null
        |		and
        |		t2.device_id != '') t3
        |group by
        |	'%s',
        |	t3.app_src) t4
        |join
        |	user_retention_monthly t5
        |on
        |	t4.day_id = t5.day_id
        |	and
        |	t4.app_src = t5.src_id
      """.stripMargin.format(dayM3, dayM3))
    dayM3RetenDF.show()

    //将新计算的用户留存和历史值合并
    res =
      userRetenOldDF
        .union(dayM0RetenDF)
        .union(dayM1RetenDF)
        .union(dayM2RetenDF)
        .union(dayM3RetenDF)
    res.show()

    //保存新结果到hdfs
    res.repartition(1).write.mode("overwrite").parquet("/dw/log/c/user_retention_monthly")

    //保存新结果到Oracle(先删除历史数据)
    val sql = "delete from %s where day_id in ('%s', '%s', '%s', '%s')".format(destTable, targetDate, dayM1, dayM2, dayM3)
    println("操作数据库：" + db.toString)
    println("执行SQL：" + sql)
    DBEraser.remove(db, sql)

    println("保存到db")
    RDBWriter.overwrite(res.coalesce(1), db, destTable)
    println("Happy Ending!")


  }
}




