package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.sql.SQLUserRetention
import com.gnow.{DB, Processor, Utility}

class UserRetention4AppAndroidDaily extends Processor {
  val USER_RETENTION = "user_retention"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from user_retention
        |where create_date='%s'
        |and device_type='%s'
        |and c_type='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate, "12", "0"))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLUserRetention.getSQL4AppDailyAndroid(targetDate)
    val schema = "device_id,device_type,phase,create_time"
    val df = repository.kafka.df4TodayAndPrevious(repository.kafka.BASIC_APP_TRACE, targetDate, schema)
    val res = Utility.sql(df, sql)
    RDBWriter.save(res, DB.ORACLE_37_BWSWD, USER_RETENTION)
  }

}
