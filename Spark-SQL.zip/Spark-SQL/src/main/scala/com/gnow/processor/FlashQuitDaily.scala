package com.gnow.processor


import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.rdb
import com.gnow.sql.SQLFlashQuit
import com.gnow.{DB, Processor, Utility}
import org.apache.spark.sql.DataFrame

class FlashQuitDaily extends Processor {
  val FLASH_QUIT_SHOP = "flash_quit_shop"
  var warnWarningsDF: DataFrame = null
  var shopAndBaseDateDF: DataFrame = null

  val FLASH_QUIT = "flash_quit"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from flash_quit
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
    RDBWriter.save(shopAndBaseDateDF, DB.ORACLE_37_BWSWD, FLASH_QUIT)
  }

  def process(targetDate: String, input: String, output: String) = {
    warnWarningsDF = rdb.paying.df(rdb.paying.WARN_WARNINGS, targetDate)
    shopAndBaseDateDF = Utility.registerTableWithSQL(sqlContext,
      SQLFlashQuit.SQL.format(
        rdb.paying.WARN_WARNINGS
      ), FLASH_QUIT_SHOP)
  }
}
