package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.sql.SQLUserActiveDetail
import com.gnow.{DB, Processor, Utility}

class UserActiveDetailDaily extends Processor {
  val USER_ACTIVE_DETAIL = "user_active_detail"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from user_active_detail
        |where create_time like '%s%%'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_7_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val appsql = SQLUserActiveDetail.getSQL4AppDetailDaily(targetDate)
    val schemaApp = "device_id,device_type,phase,mobile,create_time"
    val appdf = repository.kafka.df(repository.kafka.BASIC_APP_TRACE, targetDate, schemaApp)
    val appres = Utility.sql(appdf, appsql)
    RDBWriter.save(appres, DB.ORACLE_7_BWSWD, USER_ACTIVE_DETAIL)

    val wechatsql = SQLUserActiveDetail.getSQL4WechatDetailDaily(targetDate)
    val schemaWechat = "device_id,device_type,phase,open_id,create_time"
    val wechatdf = repository.kafka.df(repository.kafka.BASIC_WECHAT_TRACE, targetDate, schemaWechat)
    val wechatres = Utility.sql(wechatdf, wechatsql)
    RDBWriter.save(wechatres, DB.ORACLE_7_BWSWD, USER_ACTIVE_DETAIL)
  }

}
