package com.gnow.processor

import com.gnow.config.SaveMode
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.sql.SQLSecondPayFailRate
import com.gnow.{DB, Processor, Utility}

class SecondPayFailRateDaily extends Processor {
  val OUTPUT_TABLE = "second_pay_fail_rate"

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from second_pay_fail_rate
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
  }

  def process(targetDate: String, input: String, output: String) = {
    val sql = SQLSecondPayFailRate.SQL.format(
      targetDate,
      repository.kafka.PAYING_SECOND_PAY,
      repository.kafka.PAYING_SECOND_PAY
    )
    val tbl = repository.kafka.df(repository.kafka.PAYING_SECOND_PAY, targetDate)
    val result = Utility.sql(tbl, sql)
    RDBWriter.save(result, DB.ORACLE_37_BWSWD, OUTPUT_TABLE, SaveMode.APPEND)
  }
}
