package com.gnow.processor

import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.repository
import com.gnow.{DB, Processor, Utility}
import org.apache.spark.sql.DataFrame

class SpayOnlineShopDaily extends Processor {
  val OUTPUT_TABLE = "SPAY_ONLINE_SHOP_DAILY"
  private val SPAY_ONLINE_SHOP = "SPAY_ONLINE_SHOP"
  private val SPAY_ONLINE_SHOP_OUT = "SPAY_ONLINE_SHOP_OUT"
  private var targetDateDF: DataFrame = null
  private var targetDateOutDF: DataFrame = null

  def reset(targetDate: String): Unit = {
    val sql =
      """
        |delete
        |from SPAY_ONLINE_SHOP_DAILY
        |where create_date='%s'
      """.stripMargin
    DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format(targetDate))
  }

  def execute(targetDate: String, input: String, output: String) = {
    reset(targetDate)
    process(targetDate, input: String, output: String)
    RDBWriter.overwrite(targetDateOutDF, DB.ORACLE_37_BWSWD, OUTPUT_TABLE)
  }

  def process(targetDate: String, input: String, output: String) = {
//    targetDateDF = repository.kafka.df(repository.kafka.ORDERING_MOBILE_API_DCB_ONLINE,targetDate)
    val targetDateDF = sqlContext.read.json("/repository/kafka/catonline_mobile-api_dcb-online/%s".format(targetDate))
    targetDateDF.createOrReplaceTempView(SPAY_ONLINE_SHOP)

    targetDateOutDF = Utility.registerTableWithSQL(sqlContext,
      """
        |SELECT
        |'%s' create_date,
        |shopId shop_id,
        |count(shopId) online_qty
        |FROM %s t1
        |where syncType in(0,2) and currentState='1'
        |group by shopId
      """.stripMargin.format(
        targetDate,
        SPAY_ONLINE_SHOP
      ), SPAY_ONLINE_SHOP_OUT)    // 建立临时表TARGET_DATE_USER_ID_TMP
  }
}
