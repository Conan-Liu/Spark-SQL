package com.gnow

import org.codehaus.jackson.map.ObjectMapper

object Terminal {

  def main(args: Array[String]): Unit = {
    try {
      val data: java.util.Map[String, String] = new java.util.HashMap[String, String]()
      data.put("1", "tom")
      data.put("2", "jerry")
      val json = new ObjectMapper().writeValueAsString(data);
      println(json)
    } catch {
      case e: Throwable => {
        println(e.getCause)
      }
    }
  }
}
