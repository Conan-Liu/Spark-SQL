package com.gnow

import org.apache.spark.{SparkConf, SparkContext}
import org.slf4j.LoggerFactory

object Dispatcher {
  val logger = LoggerFactory.getLogger("9now")

  def execute(className: String, targetDate: String, input: String, output: String) = {
    val shortClassName = className.replaceFirst("^.*\\.", "")
    val sparkConf = new SparkConf().setAppName(s"$shortClassName:$targetDate")
    val sc = new SparkContext(sparkConf)
    val clazz = Class.forName(className)
    val instance = clazz.newInstance().asInstanceOf[Processor]
    instance.execute(targetDate, input, output)
    //sc.stop()
  }
}
