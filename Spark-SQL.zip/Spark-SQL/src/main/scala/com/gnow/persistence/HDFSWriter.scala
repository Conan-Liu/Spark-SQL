package com.gnow.persistence

import com.gnow.FieldConvert
import com.gnow.config.{Constants, FileFormat, SaveMode}
import org.apache.spark.sql.DataFrame
import org.slf4j.LoggerFactory

object HDFSWriter {
  val logger = LoggerFactory.getLogger("9now")
  private val NUMBER_OF_PARTITIONS = 5

  def save(df: DataFrame, outPath: String, format: FileFormat, mode: SaveMode): Unit = {
    save(df, outPath, format, mode, NUMBER_OF_PARTITIONS)
  }

  def save(df: DataFrame, outPath: String, format: FileFormat, mode: SaveMode, numPartitions: Int): Unit = {
    logger.info(s"path:$outPath")
    val ndf = FieldConvert.convert(df)
    if (FileFormat.PARQUET.equals(format)) {
      ndf.coalesce(numPartitions).write.mode(mode.toString.toLowerCase()).parquet(outPath)
    } else {
      ndf.coalesce(numPartitions).write.mode(mode.toString.toLowerCase()).json(outPath)
    }
  }
}
