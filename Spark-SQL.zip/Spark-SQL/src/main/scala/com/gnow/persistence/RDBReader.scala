package com.gnow.persistence

import com.gnow.DB
import org.apache.spark.SparkContext
import org.apache.spark.sql.{DataFrame, SQLContext}

object RDBReader {
  def read(db: DB, table: String): DataFrame = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    val df = sqlContext.read.jdbc(db.url, table, db.properties)
    df
  }
}
