package com.gnow.persistence

import com.gnow.DB
import com.gnow.config.{ApplicationContexts, Constants, SaveMode}
import org.apache.spark.sql.DataFrame
import org.slf4j.LoggerFactory

object RDBWriter {
  val logger = LoggerFactory.getLogger("9now")

  def save1(df: DataFrame, table: String): Unit = {
    save(df, DB.ORACLE_37_BWSWD, table)
  }

  def save(df: DataFrame, host: DB, table: String): Unit = {
    save(df, host, table, SaveMode.APPEND)
  }

  def overwrite(df: DataFrame, host: DB, table: String): Unit = {
    save(df, host, table, SaveMode.APPEND)
  }

  def save(dfSrc: DataFrame, db: DB, table: String, mode: SaveMode): Unit = {
    var df = dfSrc
    if (df != null) {
      val schema = df.schema
      for(i <- 0 to schema.size - 1){
        df = df.withColumn(schema(i).name.toUpperCase(), df(schema(i).name))
      }
      val runtimeDB = DB.getRuntimeDB(db)
      df.write.mode(mode.toString.toLowerCase()).jdbc(runtimeDB.url, table, runtimeDB.properties)
    }
  }
}
