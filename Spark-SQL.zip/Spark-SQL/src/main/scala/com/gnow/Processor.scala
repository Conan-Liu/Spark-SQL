package com.gnow


trait Processor extends ILogger with ISQLContext {
  def execute(targetDate: String, input: String, output: String): Unit
}
