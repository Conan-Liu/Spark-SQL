package com.gnow.transform

import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.{rdb, repository}
import com.gnow.sql.SQLBrand
import com.gnow.{DB, Transform}

class BrandTransform extends Transform {
  val BRAND = "brand"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$BRAND"

  def execute(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    repository.transform.df(repository.transform.SHOP_GOOD_TYPE)
    val sql = SQLBrand.SQL.format(
      rdb.basic.SHOP_TABLE,
      rdb.basic.SHOP_TABLE,
      repository.transform.alias(repository.transform.SHOP_GOOD_TYPE),
      rdb.basic.SHOP_TABLE)
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, BRAND, SaveMode.OVERWRITE)
  }
}
