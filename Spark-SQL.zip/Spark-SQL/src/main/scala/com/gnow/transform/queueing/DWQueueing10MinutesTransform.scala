package com.gnow.transform.queueing

import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.HDFSWriter
import com.gnow.schema.{rdb, repository, setting}
import com.gnow.sql.SQLDWQueueingDaily10Minutes
import com.gnow.{Transform, Utility}

class DWQueueing10MinutesTransform extends Transform {
  val OUTPUT_TABLE = "dw_queueing_10minutes"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$OUTPUT_TABLE"


  def execute(targetDate: String, input: String, output: String) = {
    val queueingCompactDF = repository.transform.df(repository.transform.QUEUEING_COMPACT)
    Utility.appendColumnIfNotExists(queueingCompactDF, repository.transform.alias(repository.transform.QUEUEING_COMPACT), "appview")
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    setting.df(setting.CITY)
    repository.transform.df(repository.transform.DISTRICT)
    repository.transform.df(repository.transform.CIRCLE)
    rdb.basic.df(rdb.basic.SHOP_CONFIG_TABLE)
    repository.transform.df(repository.transform.BRAND)
    repository.transform.df(repository.transform.SHOP_GOOD_TYPE)
    setting.df(setting.QUEUEING_STATE)
    setting.df(setting.QUEUEING_CHANNEL)
    rdb.basic.df(rdb.basic.QUEUE_TABLE)
    repository.transform.df(repository.transform.SHOP)
    setting.df(setting.QUEUEING_QUEUE_TYPE)
    setting.df(setting.QUEUEING_USER_ACTION)
    setting.df(setting.QUEUEING_DEVICE_TYPE)
    val sql = SQLDWQueueingDaily10Minutes.SQL.format(
      repository.transform.alias(repository.transform.QUEUEING_COMPACT), //1
      rdb.basic.SHOP_TABLE, //2
      setting.CITY, //3
      repository.transform.alias(repository.transform.DISTRICT), //4
      repository.transform.alias(repository.transform.CIRCLE), //5
      repository.transform.alias(repository.transform.BRAND), //7
      repository.transform.alias(repository.transform.SHOP_GOOD_TYPE), //8
      setting.QUEUEING_STATE, //9
      setting.QUEUEING_CHANNEL, //10
      rdb.basic.QUEUE_TABLE, //11
      repository.transform.alias(repository.transform.SHOP), //12
      setting.QUEUEING_QUEUE_TYPE, //13
      setting.QUEUEING_USER_ACTION, //14
      setting.QUEUEING_DEVICE_TYPE //15
    )
    logger.info(sql)
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, OUTPUT_TABLE, SaveMode.OVERWRITE)
  }
}
