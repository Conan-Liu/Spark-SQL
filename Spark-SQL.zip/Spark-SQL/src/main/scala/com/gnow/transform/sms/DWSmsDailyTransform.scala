package com.gnow.transform.sms

import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.{DB, Transform}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.{rdb, repository, setting}
import com.gnow.sql.SQLSmsDaily

class DWSmsDailyTransform extends Transform {
  val OUTPUT_TABLE = "dw_sms_daily"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$OUTPUT_TABLE"

  def execute(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.SMS_LOG_TABLE)
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    setting.df(setting.CITY)
    repository.transform.df(repository.transform.DISTRICT)
    repository.transform.df(repository.transform.CIRCLE)
    repository.transform.df(repository.transform.BRAND)
    repository.transform.df(repository.transform.SHOP_GOOD_TYPE)
    setting.df(setting.BOOKING_SMS_STATUS)
    setting.df(setting.BOOKING_SMS_TYPE)
    repository.transform.df(repository.transform.booking.BOOKING_SHOP)

    val sql = SQLSmsDaily.SQL.format(
      rdb.basic.SMS_LOG_TABLE,
      rdb.basic.SHOP_TABLE,
      setting.CITY,
      repository.transform.alias(repository.transform.DISTRICT),
      repository.transform.alias(repository.transform.CIRCLE),
      repository.transform.alias(repository.transform.BRAND),
      repository.transform.alias(repository.transform.SHOP_GOOD_TYPE),
      repository.transform.alias(repository.transform.booking.BOOKING_SHOP),
      setting.BOOKING_SMS_STATUS,
      setting.BOOKING_SMS_TYPE
    )
    logger.info(sql)
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, OUTPUT_TABLE, SaveMode.OVERWRITE)
  }
}
