package com.gnow.transform.booking

import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.{DB, Transform}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.{rdb, repository, setting}
import com.gnow.sql.SQLDWBookingDaily

class DWBookingDailyTransform extends Transform {
  val OUTPUT_TABLE = "dw_booking_daily"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$OUTPUT_TABLE"

  def execute(targetDate: String, input: String, output: String) = {
    rdb.booking.df(rdb.booking.BOOKING_TABLE)
    repository.transform.df(repository.transform.booking.BOOKING_SHOP)
    setting.df(setting.CITY)
    repository.transform.df(repository.transform.DISTRICT)
    repository.transform.df(repository.transform.CIRCLE)
    setting.df(setting.BOOKING_SOURCE)
    setting.df(setting.BOOKING_TO_PHONE)
    setting.df(setting.BOOKING_TO_SMS)
    setting.df(setting.BOOKING_IS_SURE)
    setting.df(setting.BOOKING_STATUS)
    setting.df(setting.QUEUEING_QUEUE_TYPE)

    val sql = SQLDWBookingDaily.SQL.format(
      rdb.booking.BOOKING_TABLE,
      repository.transform.alias(repository.transform.booking.BOOKING_SHOP),
      setting.CITY,
      repository.transform.alias(repository.transform.DISTRICT),
      repository.transform.alias(repository.transform.CIRCLE),
      setting.BOOKING_SOURCE,
      setting.BOOKING_TO_PHONE,
      setting.BOOKING_TO_SMS,
      setting.BOOKING_IS_SURE,
      setting.BOOKING_STATUS,
      setting.QUEUEING_QUEUE_TYPE)
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, OUTPUT_TABLE, SaveMode.OVERWRITE)
  }
}
