package com.gnow.transform.ordering

import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.{DB, Transform}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.{rdb, repository, setting}
import com.gnow.sql.SQLOrderingDaily

class DWOrderingDailyTransform extends Transform {
  val OUTPUT_TABLE = "dw_ordering_daily"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$OUTPUT_TABLE"


  def execute(targetDate: String, input: String, output: String) = {
    rdb.booking.df(rdb.booking.BOOKING_TABLE)
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    setting.df(setting.CITY)
    repository.transform.df(repository.transform.BRAND)
    val sql = SQLOrderingDaily.SQL.format(
      rdb.ordering.ORDERING,
      rdb.basic.SHOP_TABLE,
      setting.CITY,
      repository.transform.alias(repository.transform.BRAND)
    )
    logger.info(sql)
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, OUTPUT_TABLE, SaveMode.OVERWRITE)
  }
}
