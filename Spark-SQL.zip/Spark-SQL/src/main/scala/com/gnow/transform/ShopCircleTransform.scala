package com.gnow.transform

import com.gnow.{DB, Transform}
import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.rdb
import com.gnow.sql.SQLShopCircle

class ShopCircleTransform extends Transform {
  val SHOP_CIRCLE = "shop_circle"
  val SHOP_CIRCLE_RAW = "shop_circle_raw"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$SHOP_CIRCLE"

  def execute(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    val shopCircleRawSQL = SQLShopCircle.SQL.format(rdb.basic.SHOP_TABLE)
    val df = sqlContext.sql(shopCircleRawSQL)
    val ndf = df.explode("circle_ids", "circle_id")((circleId: String) => circleId.split(","))
    ndf.registerTempTable(SHOP_CIRCLE_RAW)
    val shopCircleSql = SQLShopCircle.SQL2.format(SHOP_CIRCLE_RAW)
    val result = sqlContext.sql(shopCircleSql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, SHOP_CIRCLE, SaveMode.OVERWRITE)
  }
}
