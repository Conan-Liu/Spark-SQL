package com.gnow.transform.customer

import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.rdb
import com.gnow.sql.SQLDWCustomerRegular
import com.gnow.{DB, Transform}

class DWCustomerRegularTransform extends Transform {
  val OUTPUT_TABLE = "dw_customer_regular"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$OUTPUT_TABLE"

  def execute(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.SHOP_TABLE).cache()
    rdb.basic.df(rdb.basic.USER_TABLE).cache()
    rdb.basic.df(rdb.basic.WX_ACCOUNT_TABLE).cache()
    rdb.basic.df(rdb.basic.MOBILE_TABLE).cache()

    rdb.queueing.df(rdb.queueing.QUEUEING_TABLE)
    val queueingAndServedCompactSQL = SQLDWCustomerRegular.QUEUEING_AND_SERVED_COMPACT.format(
      rdb.queueing.QUEUEING_TABLE,
      rdb.basic.SHOP_TABLE,
      rdb.basic.USER_TABLE,
      rdb.basic.WX_ACCOUNT_TABLE)
    val queueingAndServedCompactDF = sqlContext.sql(queueingAndServedCompactSQL)
    val QUEUEING_AND_SERVED_COMPACT= "queueing_and_served_compact"
    queueingAndServedCompactDF.registerTempTable(QUEUEING_AND_SERVED_COMPACT)

    val queueingAndServedSQL = SQLDWCustomerRegular.QUEUEING_AND_SERVED.format(QUEUEING_AND_SERVED_COMPACT)
    val queueingAndServedDF = sqlContext.sql(queueingAndServedSQL)
    HDFSWriter.save(queueingAndServedDF, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    RDBWriter.save(queueingAndServedDF, DB.MYSQL_231_TRANSFORM, OUTPUT_TABLE, SaveMode.OVERWRITE)

    val queueingAndNotServedSQL = SQLDWCustomerRegular.QUEUEING_AND_NOT_SERVED.format(
      rdb.queueing.QUEUEING_TABLE,
      rdb.basic.SHOP_TABLE,
      rdb.basic.USER_TABLE,
      rdb.basic.WX_ACCOUNT_TABLE)
    val queueingAndNotServedDF = sqlContext.sql(queueingAndNotServedSQL)
    val QUEUEING_AND_NOT_SERVED_COMPACT= "queueing_and_not_served_compact"
    queueingAndNotServedDF.registerTempTable(QUEUEING_AND_NOT_SERVED_COMPACT)
    val sqlQueueingAndNotServedSQL = SQLDWCustomerRegular.SQL_QUEUEING_AND_NOT_SERVED.format(QUEUEING_AND_NOT_SERVED_COMPACT)
    val sqlQueueingAndNotServedDF = sqlContext.sql(sqlQueueingAndNotServedSQL)
    HDFSWriter.save(sqlQueueingAndNotServedDF, OUTPUT_PATH, FileFormat.JSON, SaveMode.APPEND)
    RDBWriter.save(sqlQueueingAndNotServedDF, DB.MYSQL_231_TRANSFORM, OUTPUT_TABLE, SaveMode.APPEND)


    rdb.booking.df(rdb.booking.BOOKING_TABLE)
    val bookingCompactSQL = SQLDWCustomerRegular.BOOKING_COMPACT.format(
      rdb.basic.USER_TABLE,
      rdb.basic.MOBILE_TABLE,
      rdb.basic.WX_ACCOUNT_TABLE,
      rdb.booking.BOOKING_TABLE)
    val bookingCompactDF = sqlContext.sql(bookingCompactSQL)
    val BOOKING_COMPACT = "booking_compact"
    bookingCompactDF.registerTempTable(BOOKING_COMPACT)

    val bookingAndServedCompactSQL = SQLDWCustomerRegular.BOOKING_AND_SERVED_COMPACT.format(
      rdb.booking.BOOKING_TABLE,
      rdb.basic.SHOP_TABLE,
      BOOKING_COMPACT)
    val bookingAndServedCompactDF = sqlContext.sql(bookingAndServedCompactSQL)
    val BOOKING_AND_SERVED_COMPACT = "booking_and_served_compact"
    bookingAndServedCompactDF.registerTempTable(BOOKING_AND_SERVED_COMPACT)
    val bookingAndServedSQL = SQLDWCustomerRegular.BOOKING_AND_SERVED.format(BOOKING_AND_SERVED_COMPACT)
    val bookingAndServedDF = sqlContext.sql(bookingAndServedSQL)
    HDFSWriter.save(bookingAndServedDF, OUTPUT_PATH, FileFormat.JSON, SaveMode.APPEND)
    RDBWriter.save(bookingAndServedDF, DB.MYSQL_231_TRANSFORM, OUTPUT_TABLE, SaveMode.APPEND)

    val bookingAndNotServedCompactSQL = SQLDWCustomerRegular.BOOKING_AND_NOT_SERVED_COMPACT.format(
      rdb.booking.BOOKING_TABLE,
      rdb.basic.SHOP_TABLE,
      BOOKING_COMPACT)
    val bookingAndNotServedCompactDF = sqlContext.sql(bookingAndNotServedCompactSQL)
    val BOOKING_AND_NOT_SERVED_COMPACT = "booking_and_not_served_compact"
    bookingAndNotServedCompactDF.registerTempTable(BOOKING_AND_NOT_SERVED_COMPACT)
    val bookingAndNotServedSQL = SQLDWCustomerRegular.BOOKING_AND_NOT_SERVED.format(BOOKING_AND_NOT_SERVED_COMPACT)
    val bookingAndNotServedDF = sqlContext.sql(bookingAndNotServedSQL)
    HDFSWriter.save(bookingAndNotServedDF, OUTPUT_PATH, FileFormat.JSON, SaveMode.APPEND)
    RDBWriter.save(bookingAndNotServedDF, DB.MYSQL_231_TRANSFORM, OUTPUT_TABLE, SaveMode.APPEND)


    rdb.ordering.df(rdb.ordering.APP_ORDER)
    val orderingCompactSQL = SQLDWCustomerRegular.ORDERING_COMPACT.format(
      rdb.ordering.APP_ORDER,
      rdb.basic.SHOP_TABLE,
      rdb.basic.USER_TABLE,
      rdb.basic.WX_ACCOUNT_TABLE,
      rdb.basic.MOBILE_TABLE)
    val orderingCompactDF = sqlContext.sql(orderingCompactSQL)
    val ORDERING_COMPACT = "ordering_compact"
    orderingCompactDF.registerTempTable(ORDERING_COMPACT)
    val orderingSQL = SQLDWCustomerRegular.ORDERING.format(ORDERING_COMPACT)
    val orderingDF = sqlContext.sql(orderingSQL)
    HDFSWriter.save(orderingDF, OUTPUT_PATH, FileFormat.JSON, SaveMode.APPEND)
    RDBWriter.save(orderingDF, DB.MYSQL_231_TRANSFORM, OUTPUT_TABLE, SaveMode.APPEND)
  }
}
