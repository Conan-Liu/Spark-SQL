package com.gnow.transform

import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.HDFSWriter
import com.gnow.schema.rdb
import com.gnow.sql.SQLQueueingCompact
import com.gnow.{Transform, Utility}

class QueueingCompactTransform extends Transform {
  val QUEUEING_COMPACT = "queueing_compact"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$QUEUEING_COMPACT"

  def execute(targetDate: String, input: String, output: String) = {
    val queueingTableDF = rdb.queueing.df(rdb.queueing.QUEUEING_TABLE, targetDate)
    Utility.appendColumnIfNotExists(queueingTableDF, rdb.queueing.QUEUEING_TABLE, "appview")
    rdb.basic.df(rdb.basic.SHOP_CONFIG_TABLE)

    val sql = SQLQueueingCompact.SQL.format(
      rdb.queueing.QUEUEING_TABLE,
      rdb.basic.SHOP_CONFIG_TABLE
    )
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
  }
}
