package com.gnow.transform.cash

import com.gnow.Transform
import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.HDFSWriter

class DWCashDailyNewTransform extends Transform {
  val OUTPUT_TABLE = "dw_cash_daily_new"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$OUTPUT_TABLE"


  def execute(targetDate: String, input: String, output: String) = {
    val sql =
      """
      select 1
      """
    logger.info(sql)
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
  }
}
