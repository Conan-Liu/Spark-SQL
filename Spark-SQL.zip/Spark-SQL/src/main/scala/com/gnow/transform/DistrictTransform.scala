package com.gnow.transform

import com.gnow.{DB, Transform}
import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.rdb
import com.gnow.sql.SQLDistrict

class DistrictTransform extends Transform {
  val DISTRICT = "district"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$DISTRICT"

  def execute(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.CITY_AREA_TABLE)
    val sql = SQLDistrict.SQL.format(rdb.basic.CITY_AREA_TABLE)
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, DISTRICT, SaveMode.OVERWRITE)
  }
}
