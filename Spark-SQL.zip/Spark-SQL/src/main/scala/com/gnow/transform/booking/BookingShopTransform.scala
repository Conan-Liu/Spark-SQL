package com.gnow.transform.booking

import com.gnow.Transform
import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.HDFSWriter
import com.gnow.schema.{rdb, repository, setting}
import com.gnow.sql.SQLBookingShop

class BookingShopTransform extends Transform {
  val BOOKING_SHOP = repository.transform.booking.BOOKING_SHOP
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$BOOKING_SHOP"

  def execute(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    setting.df(setting.SHOP_GOOD_TYPE)
    setting.df(setting.CITY)
    repository.transform.df(repository.transform.DISTRICT)
    repository.transform.df(repository.transform.CIRCLE)
    val sql = SQLBookingShop.SQL.format(
      rdb.basic.SHOP_TABLE,
      setting.SHOP_GOOD_TYPE,
      setting.CITY,
      repository.transform.alias(repository.transform.DISTRICT),
      repository.transform.alias(repository.transform.CIRCLE))
    val res = sqlContext.sql(sql)
    HDFSWriter.save(res, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
  }
}
