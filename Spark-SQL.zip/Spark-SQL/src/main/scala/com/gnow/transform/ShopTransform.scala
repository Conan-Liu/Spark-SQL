package com.gnow.transform

import com.gnow.{DB, Transform}
import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.{rdb, repository, setting}
import com.gnow.sql.SQLShopInformation

class ShopTransform extends Transform {
  val SHOP_INFORMATION = "shop"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$SHOP_INFORMATION"


  def execute(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    repository.transform.df(repository.transform.SHOP_GOOD_TYPE)
    setting.df(setting.CITY)
    repository.transform.df(repository.transform.DISTRICT)
    repository.transform.df(repository.transform.CIRCLE)
    rdb.basic.df(rdb.basic.SHOP_CONFIG_TABLE)
    rdb.basic.df(rdb.basic.QUEUE_TABLE)
    setting.df(setting.QUEUEING_QUEUE_TYPE)
    val sql = SQLShopInformation.SHOP.format(
      rdb.basic.SHOP_TABLE,
      repository.transform.alias(repository.transform.SHOP_GOOD_TYPE),
      setting.CITY,
      repository.transform.alias(repository.transform.DISTRICT),
      repository.transform.alias(repository.transform.CIRCLE),
      rdb.basic.SHOP_CONFIG_TABLE,
      rdb.basic.QUEUE_TABLE,
      setting.QUEUEING_QUEUE_TYPE
    )
    val result = sqlContext.sql(sql)
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, SHOP_INFORMATION, SaveMode.OVERWRITE)
  }
}
