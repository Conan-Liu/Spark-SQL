package com.gnow.transform

import com.gnow.{DB, Transform}
import com.gnow.config.{FileFormat, SaveMode}
import com.gnow.persistence.{HDFSWriter, RDBWriter}
import com.gnow.schema.rdb
import com.gnow.sql.SQLMall

class MallTransform extends Transform {
  val MALL = "mall"
  val OUTPUT_PATH = s"$REPOSITORY_TRANSFORM_HOME/$MALL"

  def execute(targetDate: String, input: String, output: String) = {
    rdb.basic.df(rdb.basic.SHOP_TABLE)
    val result = sqlContext.sql(SQLMall.SQL_MALL.format(rdb.basic.SHOP_TABLE))
    HDFSWriter.save(result, OUTPUT_PATH, FileFormat.JSON, SaveMode.OVERWRITE)
    save(result, MALL, SaveMode.OVERWRITE)
  }
}
