package com.gnow

import java.io.{PrintWriter, StringWriter}
import java.text.SimpleDateFormat

import com.gnow.config.Constants
import org.apache.commons.cli._
import org.slf4j.LoggerFactory

object Main {
  val logger = LoggerFactory.getLogger("9now")

  def main(args: Array[String]): Unit = {
    logger.info("+START--------------------------------------------------------------------------")
    val options = new Options()
    options.addOption("c", true, "class name.")
    options.addOption("d", true, "target date.")
    options.addOption("i", true, "input path for merger only.")
    options.addOption("o", true, "output path for merger only.")
    val formatter = new HelpFormatter()
    var subject: String = ""
    try {
      val parser = new BasicParser()
      val cmd = parser.parse(options, args)

      val className = cmd.getOptionValue("c")
      logger.info(s"$className")
      val yyyyMMdd = cmd.getOptionValue("d")
      var input = ""
      if (cmd.hasOption("i")) {
        input = cmd.getOptionValue("i")
      }
      var output = ""
      if (cmd.hasOption("o")) {
        output = cmd.getOptionValue("o")
      }
      val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
      val targetDate = sdf.format(sdf.parse(yyyyMMdd))
      logger.info(s"class name:$className, target date:$targetDate")

      subject = s"SparkSQL class:$className, date:$targetDate"
      Dispatcher.execute(s"$className", targetDate, input, output)
    } catch {
      case pe: ParseException => {

        val sw = new StringWriter()
        val pw = new PrintWriter(sw)
        pe.printStackTrace(pw)
        logger.error(sw.toString())
        subject = s"SparkSQL Wrong Parameters: ${args.mkString(" ")}"
        logger.info(s"sending mails...$subject")
        formatter.printHelp("spark-sql", options)
        Mail.send(subject, sw.toString)
      }
      case e: Throwable => {
        val sw = new StringWriter()
        val pw = new PrintWriter(sw)
        e.printStackTrace(pw)
        subject = s"SparkSQL Parameters: ${args.mkString(" ")}"
        logger.error(sw.toString())
        Mail.send(subject, sw.toString)
      }
    }
    logger.info("+END----------------------------------------------------------------------------")
  }
}
