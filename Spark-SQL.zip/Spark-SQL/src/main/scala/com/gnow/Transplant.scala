package com.gnow

import com.gnow.config.{Constants, FileFormat, SaveMode}
import com.gnow.persistence.HDFSWriter

trait Transplant extends ILogger with ISQLContext {
  def execute(targetDate: String, input: String, output: String): Unit

  def transplant(targetDate: String,
                 db: DB,
                 business: String,
                 fromTable: String,
                 toTable: String,
                 columns: String,
                 whereClause: String
                ): Unit = {
    val tomorrow = Utility.nextDate(targetDate)

    if (whereClause == null || whereClause.trim.isEmpty) {
      val df = sqlContext.read.jdbc(db.url, fromTable, db.properties)
      logger.info(s"table:$fromTable")
      df.registerTempTable(fromTable)
      val filtered = sqlContext.sql(s"SELECT $columns FROM $fromTable")
      val outputPath = s"${Constants.RDB_HOME}/$business/${toTable}"
      logger.info(s"path:$outputPath")
      HDFSWriter.save(filtered, outputPath, FileFormat.JSON, SaveMode.OVERWRITE)
    } else {
      val condition = whereClause.format(targetDate, tomorrow)
      val conditions = Array(condition)
      val df = sqlContext.read.jdbc(db.url, fromTable, conditions, db.properties)
      logger.info(s"table:$fromTable")
      df.registerTempTable(fromTable)
      val filtered = sqlContext.sql(s"SELECT $columns FROM $fromTable")
      val outputPath = s"${Constants.RDB_HOME}/$business/${toTable}/$targetDate"
      logger.info(s"path:$outputPath")
      HDFSWriter.save(filtered, outputPath, FileFormat.JSON, SaveMode.OVERWRITE)
    }
  }
}
