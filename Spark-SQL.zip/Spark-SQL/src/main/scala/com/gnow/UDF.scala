package com.gnow

/**
  * Created by tal on 24/05/2017.
  */
object UDF {
  //合并新旧user tags，去掉重复的tag
  def removeDP(tags_old: String, tags_new: String): String ={
    //一般这种情况下是新用户
    if(tags_old.length==0){
      tags_new
    }else{
      val new_tags = tags_new.split(",")
      val tmpTags = new StringBuilder()
      tmpTags.append(tags_old)
      for(tag <- new_tags){
        //历史数据不存在的时候在后面追加
        if(!tmpTags.toString().contains(tag))
          tmpTags.append("," + tag)
      }
      tmpTags.toString()
    }
  }
}


