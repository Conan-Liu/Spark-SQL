package com.gnow

import com.gnow.schema.repository
import com.gnow.util.Variables
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.streaming.{Seconds, StreamingContext, Time}
import org.slf4j.LoggerFactory

object Syntax {
  val logger = LoggerFactory.getLogger("9now")
  var df: DataFrame = null;
  var df1: DataFrame = null;
  var df2: DataFrame = null;

  def fn: Unit = {
    repository.kafka.df(repository.kafka.BASIC_WECHAT_TRACE)
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    val sql =
      """
        |select
        |device_id as did,
        |min(create_time)
        |from
        |basic_wechat_trace
        |where
        |phase_ = '-2'
        |group by
        |device_id      """.stripMargin
    df = sqlContext.sql(sql)
  }

  def fn11: Unit = {
    val targetDate = "2016-07-28"
    repository.kafka.df4TodayAndPrevious(repository.kafka.BASIC_APP_TRACE, targetDate)
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    val tmpl1 =
      """
        |select
        |distinct device_id as did
        |from
        |basic_app_trace
        |where
        |phase_ = 0
        |and
        |device_type = 1
        |and
        |create_time >= unix_timestamp(concat(date_sub('${dt}',1),' 0:0:0'))
        |and
        |create_time < unix_timestamp(concat('${dt}',' 0:0:0'))
      """.stripMargin

    val tmpl2 =
      """
        |select
        |distinct device_id
        |from
        |basic_app_trace
        |where
        |phase_ != 0
        |and
        |device_type = 1
        |and
        |create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
        |and
        |create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
      """.stripMargin
    val sql1 = Variables.replace(tmpl1, "dt", targetDate)
    val sql2 = Variables.replace(tmpl2, "dt", targetDate)
    df1 = sqlContext.sql(sql1)
    df2 = sqlContext.sql(sql2)
    com.gnow.persistence.RDBWriter.save(df1, com.gnow.DB.MYSQL_231_SPARK, "df1", com.gnow.config.SaveMode.OVERWRITE)
    com.gnow.persistence.RDBWriter.save(df2, com.gnow.DB.MYSQL_231_SPARK, "df2", com.gnow.config.SaveMode.OVERWRITE)
  }

  def fn1(): Unit = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    repository.kafka.df4TodayAndPrevious(repository.kafka.BASIC_APP_TRACE, "2016-07-27")
    com.gnow.schema.repository.kafka.df(com.gnow.schema.repository.kafka.BASIC_APP_TRACE, "2016-07-27")
    val sqlt1 =
      """
        |select
        |distinct device_id as did
        |from
        |basic_app_trace
        |where
        |phase_ = 0
        |and
        |device_type = 1
        |and
        |    create_time >= unix_timestamp(concat(date_sub('${dt}',1),' 0:0:0'))
        |    and
        |    create_time < unix_timestamp(concat('${dt}',' 0:0:0'))
      """.stripMargin
    val sqlt2 =
      """
        |select
        |distinct device_id
        |from
        |basic_app_trace
        |where
        |phase_ != 0
        |and
        |device_type = 1
        |and
        |    create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
        |    and
        |    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
      """.stripMargin
    val sqlt3 =
      """
        |select
        |  *
        |  from
        |    (select
        |    distinct device_id as did
        |    from
        |    basic_app_trace
        |    where
        |    phase_ = 0
        |    and
        |    device_type = 1
        |    and
        |    create_time >= unix_timestamp(concat(date_sub('${dt}',1),' 0:0:0'))
        |    and
        |    create_time < unix_timestamp(concat('${dt}',' 0:0:0')))
        |    tmp
        |  left join
        |    (select
        |    distinct device_id
        |    from
        |    basic_app_trace
        |    where
        |    phase_ != 0
        |    and
        |    device_type = 1
        |    and
        |    create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
        |    and
        |    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
        |    relogin
        |  on
        |  tmp.did = relogin.device_id
      """.stripMargin
    val dft1 = sqlContext.sql(sqlt1)
    val dft2 = sqlContext.sql(sqlt2)
    val dft3 = sqlContext.sql(sqlt3)

    com.gnow.persistence.RDBWriter.save(dft1, com.gnow.DB.MYSQL_231_SPARK, "dft1", com.gnow.config.SaveMode.OVERWRITE)
    com.gnow.persistence.RDBWriter.save(dft2, com.gnow.DB.MYSQL_231_SPARK, "dft2", com.gnow.config.SaveMode.OVERWRITE)
  }

  def f0(): Unit = {
    val appName = s"Syntax"
    val sc = SparkContext.getOrCreate()
    sc.getConf.setAppName(appName)

    val dataDirectory = "/repository/kafka/queueing_waiting_time/2016-07-23"
    val sqlContext = SQLContext.getOrCreate(sc)
    val all = sqlContext.read.json(dataDirectory)
    all.count()
  }

  def f1(): Unit = {
    val appName = s"Syntax"
    val sc = SparkContext.getOrCreate()
    sc.getConf.setAppName(appName)
    val ssc = new StreamingContext(sc, Seconds(10))

    val dataDirectory = "/trash/foo"
    val sqlContext = SQLContext.getOrCreate(sc)
    var all = sqlContext.read.json(dataDirectory)
    val dStream = ssc.textFileStream(dataDirectory)
    dStream.transform { (rdd: RDD[(String)], time: Time) =>
      rdd
    }.foreachRDD({ rdd => {
      if (!rdd.isEmpty()) {
        val sqlContext = SQLContext.getOrCreate(rdd.sparkContext)
        val df = sqlContext.read.json(rdd)
        logger.info("+-------------------------------------+")
        all = all.unionAll(df)
        all.show
      }
    }
    })
    ssc.start()
    ssc.awaitTermination()
  }
}
