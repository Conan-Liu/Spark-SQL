package com.gnow

import java.text.SimpleDateFormat
import java.util.Calendar

import com.gnow.config.Constants
import org.apache.spark.SparkContext
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SQLContext, functions}

object Utility extends ILogger {
  def registerTableFromPath(sqlContext: SQLContext, path: String, table: String): DataFrame = {
    val df = sqlContext.read.json(path)
    df.registerTempTable(table)
    df
  }

  def registerTableFromPath(sqlContext: SQLContext, path: String, table: String, columns: Array[String]): DataFrame = {
    val df = sqlContext.read.json(path)
    df.selectExpr(columns: _*)
    df.registerTempTable(table)
    df
  }

  //通过自定义schema读取json数据
  def registerTableFromPath(sqlContext: SQLContext, path: String, table: String, schema: StructType): DataFrame = {
    val df = sqlContext.read.schema(schema).json(path)
    df.registerTempTable(table)
    df
  }

  def appendColumnIfNotExists(df: DataFrame, table: String, column: String): DataFrame = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    if (!df.columns.contains(column)) {
      val ndf = df.withColumn(column, functions.lit(null: String));
      ndf.registerTempTable(table)
      return ndf
    }
    df
  }

  def registerTableFromPath(sqlContext: SQLContext, path: String, prefix: String, table: String): DataFrame = {
    val df = sqlContext.read.json(path)
    df.registerTempTable(s"${prefix}_${table}")
    df
  }

  def registerTableWithSQL(sqlContext: SQLContext, sql: String, table: String): DataFrame = {
    val df = sqlContext.sql(sql)
    df.registerTempTable(table)
    df
  }

  def nextDate(targetDate: String): String = {
    val sdf = new SimpleDateFormat(Constants.YYYY_MM_DD)
    val calendar = Calendar.getInstance()
    calendar.setTime(sdf.parse(targetDate))
    calendar.add(Calendar.DATE, 1)
    sdf.format(calendar.getTime)
  }

  def sql(df: DataFrame, sql: String): DataFrame = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    if (df.columns.length > 1) {
      val res = sqlContext.sql(sql)
      res
    } else {
      val subject = s"Warning: Empty SQL Result"
      logger.warn(subject)
      logger.warn(s"SQL is as following:$sql")
      Mail.send(subject, sql)
      null
    }
  }
}
