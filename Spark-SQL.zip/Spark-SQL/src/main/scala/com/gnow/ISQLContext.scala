package com.gnow

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext


trait ISQLContext {
  val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    
   
}
