package com.gnow.sql

object SQLDWQueueingDaily10Minutes {
  val SQL =
    """
SELECT
COUNT(tm1.serial_id)         queue_quality,
SUM(tm1.people)              people_quality,
SUM(tm1.delta_time)          sum_time,
AVG(tm1.delta_time)          avg_time,
MAX(tm1.delta_time)          max_time,
MIN(tm1.delta_time)          min_time,
SUM(tm1.real_delta_time)     sum_time_real,
AVG(tm1.real_delta_time)     avg_time_real,
MAX(tm1.real_delta_time)     max_time_real,
MIN(tm1.real_delta_time)     min_time_real,
SUM(tm1.call_quality)        call_quality,
tt3.city_id,
tt4.district_id,
tt5.circle_id,
tt6.brand_id,
tt7.good_type_id,
ts8.queue_state_id,
ts9.channel_id,
tt11.shop_id,
ts12.queue_type_id,
ts13.user_action_id,
ts14.device_type_id,
(CAST((tm1.delta_time/(10*60)) AS BIGINT) + 1) interval_id
FROM %s tm1 join %s tm2 on (
  tm2.tiyan_dian = 0
  AND tm1.shop_id = tm2.shop_id
) join %s tt3 on (
  NVL (tm2.city, 0) = tt3.city_id
) join %s tt4 on (
  NVL (tm2.city_area_id, '0') = tt4.district_id
) join %s tt5 on (
  NVL (tm2.bcid, '0') = tt5.circle_id
) join %s tt6 on (
  NVL (tm2.manage_shop_id, 0) = tt6.brand_id
) join %s tt7 on (
  NVL (tm2.shop_type, 0) = tt7.good_type_id
) join %s ts8 on (
  tm1.state = ts8.queue_state_id
) join %s ts9 on (
  tm1.channel_id = ts9.channel_id
) join %s tm10 on (
  tm1.queue_id = tm10.queue_id
) join %s tt11 on (
  tm2.shop_id = tt11.shop_id
  AND tm10.queue_id = tt11.table_id
) join %s ts12 on (
  tm1.queue_type_id = ts12.queue_type_id
  AND tt11.queue_type_id = ts12.queue_type_id
) join %s ts13 on (
  tm1.is_qr_scan = ts13.is_qr_scan
  AND tm1.is_sms_view = ts13.is_sms_view
  AND tm1.is_wechat_view = ts13.is_wechat_view
  AND tm1.is_app_view = ts13.is_app_view
) join %s ts14 on (
  tm1.device_type_id = ts14.device_type_id
)
WHERE 1=1
GROUP BY
tt3.city_id,
tt4.district_id,
tt5.circle_id,
tt6.brand_id,
tt7.good_type_id,
ts8.queue_state_id,
ts9.channel_id,
tt11.shop_id,
ts12.queue_type_id,
ts13.user_action_id,
ts14.device_type_id,
(CAST((tm1.delta_time/(10*60)) AS BIGINT) + 1)
    """
}
