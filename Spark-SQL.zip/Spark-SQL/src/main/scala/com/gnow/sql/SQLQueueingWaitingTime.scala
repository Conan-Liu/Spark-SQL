package com.gnow.sql

import com.gnow.util.Variables

object SQLQueueingWaitingTime {
  val SQL =
    """
select
t.shop_id,
t.timing_type,
t.serial_id,
t.queue_id,
t.waiting_number,
t.estimated_time,
t.create_time,
'${dt}'
from
queueing_waiting_time t
where
floor(rpad(t.create_time, 13, '0')/1000) >= unix_timestamp(concat('${dt}',' 0:0:0'))
and floor(rpad(t.create_time, 13, '0')/1000)  < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
