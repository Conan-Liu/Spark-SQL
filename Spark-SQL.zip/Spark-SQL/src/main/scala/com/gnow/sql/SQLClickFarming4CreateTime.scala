package com.gnow.sql

object SQLClickFarming4CreateTime {

  val CLICK_FARMING_EXT =
    """
select
t1.serial_number start_serial_number,
t2.serial_number end_serial_number,
t1.shop_id,
date_format(t1.create_time, 'yyyy-MM-dd') base_date,
t1.create_time start_time,
t2.create_time end_time,
unix_timestamp(t2.create_time) - unix_timestamp(t1.create_time)
from
%s t1,
%s t2
where t1.shop_id = t2.shop_id
and unix_timestamp(t2.create_time) - unix_timestamp(t1.create_time) > 0
and unix_timestamp(t2.create_time) - unix_timestamp(t1.create_time) <= 60
    """
  val ORDER_OCCURRENCE =
    """
select
t.start_serial_number,
t.shop_id,
t.start_time,
count(*) occurrence
from click_farming_ext t
group by
t.start_serial_number,
t.shop_id,
t.start_time
    """
  val ORDER_QUALIFIED =
    """
select
t.start_serial_number,
t.shop_id,
t.start_time,
t.occurrence
from order_occurrence t
where t.occurrence >= 20
group by
t.start_serial_number,
t.shop_id,
t.start_time,
t.occurrence
    """
  val ORDER_DETAIL =
    """
select
oq.shop_id,
cfe.base_date,
oq.start_serial_number,
cfe.end_serial_number,
oq.occurrence,
oq.start_time,
cfe.end_time
from order_qualified oq, click_farming_ext cfe
where oq.shop_id = cfe.shop_id
and oq.start_serial_number = cfe.start_serial_number
and oq.start_time = cfe.start_time
    """
  val CLICK_FARMING_RANGE =
    """
select
maxsn.shop_id,
maxsn.base_date,
min(maxsn.start_serial_number) min_start_serial_number,
maxsn.max_end_serial_number
from (
  SELECT
  t.shop_id,
  t.base_date,
  t.start_serial_number,
  max(t.end_serial_number) as max_end_serial_number
  FROM click_farming_detail t
  WHERE 1=1
  group by
  t.shop_id,
  t.base_date,
  t.start_serial_number
) maxsn
group by
maxsn.shop_id,
maxsn.base_date,
maxsn.max_end_serial_number
order by
min(maxsn.start_serial_number),
maxsn.max_end_serial_number
    """
  val CLICK_FARMING_MINUTE =
    """
select
cfd.shop_id,
cfd.base_date,
cfr.min_start_serial_number,
cfr.max_end_serial_number,
DATE_FORMAT(cfd.start_time, '%Y-%m-%d %h-%m') start_time,
DATE_FORMAT(cfd.end_time, '%Y-%m-%d %h-%m') end_time
from click_farming_detail cfd, click_farming_range cfr
where cfd.shop_id = cfr.shop_id
and cfd.base_date = cfr.base_date
and cfr.min_start_serial_number = cfd.start_serial_number
and cfr.max_end_serial_number = cfd.end_serial_number
group by
cfd.shop_id,
cfd.base_date,
cfr.min_start_serial_number,
cfr.max_end_serial_number,
DATE_FORMAT(cfd.start_time, '%Y-%m-%d %h-%m'),
DATE_FORMAT(cfd.end_time, '%Y-%m-%d %h-%m')
    """
  val CLICK_FARMING_READABLE =
    """
select
cfm.shop_id,
cfm.base_date,
cfm.min_start_serial_number,
cfmax.max_end_serial_number
from click_farming_minute cfm,
(
select
cfm.shop_id,
cfm.base_date,
min(cfm.min_start_serial_number) min_start_serial_number,
cfm.start_time
from click_farming_minute cfm
group by
cfm.shop_id,
cfm.base_date,
cfm.start_time
) cfmin,
(
select
cfm.shop_id,
cfm.base_date,
max(cfm.max_end_serial_number) max_end_serial_number,
cfm.end_time
from click_farming_minute cfm
group by
cfm.shop_id,
cfm.base_date,
cfm.end_time
) cfmax
where cfm.shop_id = cfmin.shop_id
and cfm.base_date = cfmin.base_date
and cfm.min_start_serial_number = cfmin.min_start_serial_number
and cfm.base_date = cfmax.base_date
and cfm.shop_id = cfmax.shop_id
and cfm.end_time = cfmax.end_time
    """
  val CLICK_FARMING_FINAL =
    """
select
cfcnt.shop_id,
cfcnt.base_date,
cfcnt.min_start_serial_number,
cfcnt.max_end_serial_number,
cfcnt.click_count,
cfe4st.start_time,
cfe4et.end_time
from (
  select
  cfr.shop_id,
  cfr.base_date,
  cfr.min_start_serial_number,
  cfr.max_end_serial_number,
  count(*) click_count
  from click_farming_readable cfr, %s cfi
  where cfr.shop_id = cfi.shop_id
  and cfr.base_date = date_format(cfi.create_time, 'yyyy-MM-dd')
  and cfr.min_start_serial_number <= cfi.serial_number
  and cfr.max_end_serial_number >= cfi.serial_number
  group by
  cfr.shop_id,
  cfr.base_date,
  cfr.min_start_serial_number,
  cfr.max_end_serial_number
) cfcnt, click_farming_ext cfe4st, click_farming_ext cfe4et
where cfcnt.shop_id = cfe4st.shop_id
and cfcnt.base_date = cfe4st.base_date
and cfcnt.min_start_serial_number = cfe4st.start_serial_number
and cfcnt.shop_id = cfe4et.shop_id
and cfcnt.base_date = cfe4et.base_date
and cfcnt.max_end_serial_number = cfe4et.end_serial_number
    """
  val CLICK_FARMING_END =
    """
select
'1' type,
maxet.shop_id,
maxet.base_date create_date,
maxet.min_start_serial_number,
maxet.max_end_serial_number,
maxet.click_count,
min(maxet.start_time) min_start_time,
maxet.max_end_time
from (
  SELECT
  cff.shop_id,
  cff.base_date,
  cff.min_start_serial_number,
  cff.max_end_serial_number,
  cff.click_count,
  cff.start_time,
  max(cff.end_time) max_end_time
  FROM click_farming_final cff
  WHERE 1=1
  group by
  cff.shop_id,
  cff.base_date,
  cff.min_start_serial_number,
  cff.max_end_serial_number,
  cff.click_count,
  cff.start_time
) maxet
group by
'1',
maxet.shop_id,
maxet.base_date,
maxet.min_start_serial_number,
maxet.max_end_serial_number,
maxet.click_count,
maxet.max_end_time
    """
}
