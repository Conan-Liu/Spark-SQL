package com.gnow.sql

object SQLBrand {
  val SQL =
    """
SELECT
  t.shop_id         brand_id,
  t.shop_name       brand_name,
  t2.shop_qty       shop_qty,
  t3.good_type_id   good_type_id,
  t3.good_type_name good_type_name
FROM
  %s t
LEFT JOIN
(
  SELECT
    t1.manage_shop_id, COUNT (t1.shop_id) shop_qty
  FROM
  %s t1
  WHERE t1.manage_shop_id != t1.shop_id
  AND t1.tiyan_dian = 0
  AND t1.state IN (2, 3)
  GROUP BY t1.manage_shop_id
) t2
ON
t2.manage_shop_id = t.shop_id
LEFT JOIN
%s t3
ON
t.shop_type = t3.good_type_id
left semi join
(
  SELECT DISTINCT t4.manage_shop_id
  FROM %s t4
  WHERE t4.manage_shop_id != t4.shop_id
) tmp
on
t.shop_id = tmp.manage_shop_id
where
t.tiyan_dian = 0
AND t.manage_shop_id != 43
ORDER BY t.shop_id
    """
}
