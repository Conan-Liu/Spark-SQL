package com.gnow.sql

import com.gnow.util.Variables

object SQLSecondPayDetail {
  val SQL =
    """
select
'${dt}' create_date,
t.pay_name,
t.pay_shopid,
t.pay_class,
t.pay_price,
t.pay_order,
t.pay_updatetime
from
com_pay t
where
t.pay_sourceid in (126,159)
and
t.pay_status = 1
and
t.pay_updatetime >= concat('${dt}',' 00:00:00')
and
t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
