package com.gnow.sql

import com.gnow.util.Variables

object SQLUserActive {
  val SQL_APP_DAILY =
    """
select
phase_ phase,
'${dt}' create_date,
0 device_type,
0 time_interval,
count(distinct device_id) amount
from basic_app_trace
where
(create_date between '${dt}' and date_add('${dt}',1))
and
to_date(from_unixtime(cast(create_time as bigint),'yyyy-MM-dd')) = '${dt}'
group by
phase
    """
  val SQL_APP_WEEKLY =
    """
select
phase,
'${dt}' create_date,
0 device_type,
1 time_interval,
count(distinct device_id) amount
from basic_app_trace
where
create_time >= unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
group by
phase
    """
  val SQL_APP_MONTHLY =
    """
select
phase,
'${dt}' create_date,
0 device_type,
2 time_interval,
count(distinct device_id) amount
from basic_app_trace
where
create_time >= unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
group by
phase
    """
  val SQL_WECHAT_DAILY =
    """
select
phase,
'${dt}' create_date,
1 device_type,
0 time_interval,
count(distinct open_id) as amount
from basic_wechat_trace
where
create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
and
phase != -2
group by
phase
    """
  val SQL_WECHAT_WEEKLY =
    """
select
phase,
'${dt}' create_date,
1 device_type,
1 time_interval,
count(distinct open_id) as amount
from basic_wechat_trace
where
create_time >= unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
and
phase != -2
group by
phase
    """
  val SQL_WECHAT_MONTHLY =
    """
select
phase,
'${dt}' create_date,
1 device_type,
2 time_interval,
count(distinct open_id) as amount
from basic_wechat_trace
where
create_time >= unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
and
phase != -2
group by
phase
    """

  val SQL_WECHAT_UNFOLLOW_DAILY =
    """
select
-2 phase,
'${dt}' create_date,
1 device_type,
0 time_interval,
count(distinct open_id) as amount
from basic_wechat_trace b
left semi join
(
  select
  open_id,
  max(create_time) as max_create_time
  from basic_wechat_trace
  group by
  open_id
) unfollow
on b.phase = -2
and
b.open_id = unfollow.open_id
and
b.create_time = unfollow.max_create_time
and
b.create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and
b.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """
  val SQL_WECHAT_UNFOLLOW_WEEKLY =
    """
select
-2 phase,
'${dt}' create_date,
1 device_type,
1 time_interval,
count(distinct open_id) as amount
from basic_wechat_trace b
left semi join
(
  select
  open_id,
  max(create_time) as max_create_time
  from basic_wechat_trace
  group by
  open_id
) unfollow
on b.phase = -2
and
b.open_id = unfollow.open_id
and
b.create_time = unfollow.max_create_time
and
create_time >= unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """
  val SQL_WECHAT_UNFOLLOW_MONTHLY =
    """
select
-2 phase,
'${dt}' create_date,
1 device_type,
2 time_interval,
count(distinct open_id) as amount
from basic_wechat_trace b
left semi join
(
  select
  open_id,
  max(create_time) as max_create_time
  from basic_wechat_trace
  group by
  open_id
) unfollow
on b.phase = -2
and
b.open_id = unfollow.open_id
and
b.create_time = unfollow.max_create_time
and
create_time >= unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """

  def getSQL4AppDaily(targetDate: String): String = {
    Variables.replace(SQL_APP_DAILY, "dt", targetDate)
  }

  def getSQL4AppWeekly(targetDate: String): String = {
    Variables.replace(SQL_APP_WEEKLY, "dt", targetDate)
  }

  def getSQL4AppMonthly(targetDate: String): String = {
    Variables.replace(SQL_APP_MONTHLY, "dt", targetDate)
  }

  def getSQL4WechatDaily(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_DAILY, "dt", targetDate)
  }

  def getSQL4WechatWeekly(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_WEEKLY, "dt", targetDate)
  }

  def getSQL4WechatMonthly(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_MONTHLY, "dt", targetDate)
  }

  def getSQL4WechatUnfollowDaily(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_UNFOLLOW_DAILY, "dt", targetDate)
  }

  def getSQL4WechatUnfollowWeekly(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_UNFOLLOW_WEEKLY, "dt", targetDate)
  }

  def getSQL4WechatUnfollowMonthly(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_UNFOLLOW_MONTHLY, "dt", targetDate)
  }

}
