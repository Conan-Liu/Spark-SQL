package com.gnow.sql

object SQLShopCircle {
  val SQL =
    """
SELECT
t1.shop_id,
t1.bcid circle_ids
FROM
%s t1
WHERE 1=1
    """
  val SQL2 =
    """
SELECT DISTINCT
t1.shop_id,
t1.circle_id
FROM
%s t1
WHERE 1=1
    """
}
