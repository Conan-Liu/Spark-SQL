package com.gnow.sql

object SQLDWBookingDaily {
  val SQL =
    """
      |select
      |date_format(from_unixtime(unix_timestamp()-24*3600), 'yyyy-MM-dd') day_id,
      |t3.city_id,
      |t4.district_id,
      |t5.circle_id,
      |t2.shop_id,
      |t6.source_id,
      |t11.queue_type_id,
      |t7.to_phone_id,
      |t8.to_sms_id,
      |t9.is_sure_id,
      |t10.book_status_id,
      |nvl(t1.open_key, '0') open_id,
      |count(t1.order_id) book_qty,
      |sum(t1.people_count)book_people_qty,
      |nvl(t1.auto_accept, '0') auto_accept_id
      |FROM
      |%s t1 join %s t2 on (
      | t1.shop_id = t2.shop_id
      | and t1.people_count > 0
      | and t1.order_source != '17'
      | and t1.order_source != '18'
      | and t1.phone != '10000000000'
      | and t1.phone != '11111111111'
      |) join %s t3 on (
      | t2.city_id = t3.city_id
      |) join %s t4 on (
      | t2.district_id = t4.district_id
      |) join %s t5 on (
      | t2.circle_id = t5.circle_id
      |) join %s t6 on (
      | t1.order_source = t6.source_id
      |) join %s t7 on (
      | t1.to_phone = t7.to_phone_id
      |) join %s t8 on (
      | t1.to_message = t8.to_sms_id
      |) join %s t9 on (
      | t1.is_sure = t9.is_sure_id
      |) join %s t10 on (
      | t1.status_ = t10.book_status_id
      |) join %s t11 on (
      | t1.afternoon_or_night = t11.queue_type_id
      |)
      |where 1 = 1
      |group by
      |date_format(from_unixtime(unix_timestamp()-24*3600), 'yyyy-MM-dd'),
      |t3.city_id,
      |t4.district_id,
      |t5.circle_id,
      |t2.shop_id,
      |t6.source_id,
      |t11.queue_type_id,
      |t7.to_phone_id,
      |t8.to_sms_id,
      |t9.is_sure_id,
      |t10.book_status_id,
      |t1.open_key,
      |t1.auto_accept
    """.stripMargin
}