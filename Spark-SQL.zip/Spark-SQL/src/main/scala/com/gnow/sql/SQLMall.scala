package com.gnow.sql

object SQLMall {
  val SQL_MALL =
    """
SELECT DISTINCT
t1.shoppingmall_shop_id  mall_id,
t1.shop_name             mall_name,
t1.city_area_id          district_id
FROM %s t1
WHERE 1=1
AND concat("", t1.tiyan_dian) = '0'
    """
}
