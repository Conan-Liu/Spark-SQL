package com.gnow.sql

import com.gnow.util.Variables

object SQLQueueingQrScan {
  val SQL =
    """
select count(operation) as scancount, %s as create_date   from
 %s
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
