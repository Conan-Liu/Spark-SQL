package com.gnow.sql

import com.gnow.schema.rdb
import com.gnow.util.Variables

object SQLShop {
  val SQL =
    """
select
t.shop_id,
t.shop_name,
t.type_,
t.shop_type,
t.city,
t.manage_shop_id,
t.shoppingmall_shop_id,
t.longitude,
t.latitude,
t.create_date
from %s t
where 1=1
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate).format(rdb.basic.SHOP_TABLE)
  }
}
