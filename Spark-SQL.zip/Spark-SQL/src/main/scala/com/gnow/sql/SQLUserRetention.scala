package com.gnow.sql

import com.gnow.util.Variables

object SQLUserRetention {
  val SQL_APP_DAILY =
    """
select
'${dt}' create_date,
date_sub('${dt}',1) corres_date,
0 device_type,
0 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    (device_type = 2 or device_type = 1)
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',1),' 0:0:0'))
    and
    create_time < unix_timestamp(concat('${dt}',' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    (device_type = 2 or device_type = 1)
    and
    create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_APP_DAILY_IOS =
    """
select
'${dt}' create_date,
date_sub('${dt}',1) corres_date,
11 device_type,
0 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    device_type = 1
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',1),' 0:0:0'))
    and
    create_time < unix_timestamp(concat('${dt}',' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    device_type = 1
    and
    create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_APP_DAILY_AND =
    """
select
'${dt}' create_date,
date_sub('${dt}',1) corres_date,
12 device_type,
0 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    device_type = 2
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',1),' 0:0:0'))
    and
    create_time < unix_timestamp(concat('${dt}',' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    device_type = 2
    and
    create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_APP_WEEK =
    """
select
'${dt}' create_date,
date_sub('${dt}',7) corres_date,
0 device_type,
1 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',13),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_APP_WEEK_IOS =
    """
select
'${dt}' create_date,
date_sub('${dt}',1) corres_date,
11 device_type,
1 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    device_type = 1
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',13),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    device_type = 1
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_APP_WEEK_AND =
    """
select
'${dt}' create_date,
date_sub('${dt}',1) corres_date,
12 device_type,
1 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    device_type = 2
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',13),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    device_type = 2
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_APP_MONTH =
    """
select
'${dt}' create_date,
date_sub('${dt}',dayofmonth(date_sub('${dt}',1))+1) corres_date,
0 device_type,
2 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    create_time >= unix_timestamp
    (
    case month('${dt}')
                            when 1 then concat(year('${dt}')-1,'-12','-01 0:0:0')
                            else concat(year('${dt}'),'-',month('${dt}')-1,'-01 0:0:0')
                            end
    )
    and
    create_time < unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_APP_MONTH_IOS =
    """
select
'${dt}' create_date,
date_sub('${dt}',dayofmonth(date_sub('${dt}',1))+1) corres_date,
11 device_type,
2 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    device_type = 1
    and
    cast(create_time as int) >= unix_timestamp
    (
    case month('${dt}')
                            when 1 then concat(year('${dt}')-1,'-12','-01 0:0:0')
                            else concat(year('${dt}'),'-',month('${dt}')-1,'-01 0:0:0')
                            end
    )
    and
    cast(create_time as int) < unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    device_type = 1
    and
    cast(create_time as int) >= unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0'))
    and
    cast(create_time as int) < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_APP_MONTH_AND =
    """
select
'${dt}' create_date,
date_sub('${dt}',dayofmonth(date_sub('${dt}',1))+1) corres_date,
12 device_type,
2 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(device_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct device_id as did
    from
    basic_app_trace
    where
    phase = 0
    and
    device_type = 2
    and
    cast(create_time as int) >= unix_timestamp
    (
    case month('${dt}')
                            when 1 then concat(year('${dt}')-1,'-12','-01 0:0:0')
                            else concat(year('${dt}'),'-',month('${dt}')-1,'-01 0:0:0')
                            end
    )
    and
    cast(create_time as int) < unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0')))
    tmp
  left join
    (select
    distinct device_id
    from
    basic_app_trace
    where
    phase != 0
    and
    device_type = 2
    and
    cast(create_time as int) >= unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0'))
    and
    cast(create_time as int) < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
    relogin
  on
  tmp.did = relogin.device_id)
b
    """
  val SQL_WECHAT_DAY =
    """
select
'${dt}' create_date,
date_sub('${dt}',1) corres_date,
1 device_type,
0 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(open_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct open_id as did
    from
    basic_wechat_trace
    where
    phase = 0
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',1),' 0:0:0'))
    and
    create_time < unix_timestamp(concat('${dt}',' 0:0:0')))
  tmp
  left join
    (select
    distinct open_id
    from
    basic_wechat_trace
    where
    phase != 0
    and
    phase != -2
    and
    create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
  relogin
  on
  tmp.did = relogin.open_id)
b
    """
  val SQL_WECHAT_WEEK =
    """
select
'${dt}' create_date,
date_sub('${dt}',7) corres_date,
1 device_type,
1 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(open_id) as cnt,
  count(tmp.did) as ccnt
  from
    (select
    distinct open_id as did
    from
    basic_wechat_trace
    where
    phase = 0
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',13),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0')))
  tmp
  left join
    (select
    distinct open_id
    from
    basic_wechat_trace
    where
    phase != 0
    and
    phase != -2
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0'))
    and
    create_time < unix_timestamp(concat('${dt}',' 0:0:0')))
  relogin
  on
  tmp.did = relogin.open_id)
  b
    """
  val SQL_WECHAT_MONTH =
    """
select
'${dt}' create_date,
date_sub('${dt}',dayofmonth(date_sub('${dt}',1))+1) corres_date,
1 device_type,
2 c_type,
b.ccnt activate_amount,
b.cnt relogin_amount,
b.cnt/b.ccnt retention_rate
from
  (select
  count(distinct open_id) as cnt,
  count(distinct tmp.did) as ccnt
  from
    (select
    open_id as did
    from
    basic_wechat_trace
    where
    phase = 0
    and
    create_time >= unix_timestamp
    (
    case month('${dt}')
    when 1 then concat(year('${dt}')-1,'-12','-01 0:0:0')
    else concat(year('${dt}'),'-',month('${dt}')-1,'-01 0:0:0')
    end
    )
    and
    create_time < unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0')))
  tmp
  left join
    (select
    open_id
    from
    basic_wechat_trace
    where
    phase != 0
    and
    phase != -2
    and
    create_time >= unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0'))
    and
    create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0')))
  relogin
  on
  tmp.did = relogin.open_id)
b
    """

  def getSQL4AppDaily(targetDate: String): String = {
    Variables.replace(SQL_APP_DAILY, "dt", targetDate)
  }

  def getSQL4AppDailyIOS(targetDate: String): String = {
    Variables.replace(SQL_APP_DAILY_IOS, "dt", targetDate)
  }

  def getSQL4AppDailyAndroid(targetDate: String): String = {
    Variables.replace(SQL_APP_DAILY_AND, "dt", targetDate)
  }

  def getSQL4AppWeekly(targetDate: String): String = {
    Variables.replace(SQL_APP_WEEK, "dt", targetDate)
  }

  def getSQL4AppWeeklyIOS(targetDate: String): String = {
    Variables.replace(SQL_APP_WEEK_IOS, "dt", targetDate)
  }

  def getSQL4AppWeeklyAndroid(targetDate: String): String = {
    Variables.replace(SQL_APP_WEEK_AND, "dt", targetDate)
  }

  def getSQL4AppMonthly(targetDate: String): String = {
    Variables.replace(SQL_APP_MONTH, "dt", targetDate)
  }

  def getSQL4AppMonthlyIOS(targetDate: String): String = {
    Variables.replace(SQL_APP_MONTH_IOS, "dt", targetDate)
  }

  def getSQL4AppMonthlyAndroid(targetDate: String): String = {
    Variables.replace(SQL_APP_MONTH_AND, "dt", targetDate)
  }

  def getSQL4WechatDaily(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_DAY, "dt", targetDate)
  }

  def getSQL4WechatWeekly(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_WEEK, "dt", targetDate)
  }

  def getSQL4WechatMonthly(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_MONTH, "dt", targetDate)
  }
}
