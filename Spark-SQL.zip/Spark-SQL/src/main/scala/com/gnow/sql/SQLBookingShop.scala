package com.gnow.sql

object SQLBookingShop {
  val SQL =
    """
select t1.shop_id,
       t1.shop_name,
       t2.good_type_id,
       t2.good_type_name,
       t3.city_id,
       t3.city_name,
       t4.district_id,
       t4.district_name,
       t5.circle_id,
       t5.circle_name,
       t1.client_manager,
       t1.address,
       t1.manage_shop_id brand_id,
       t1.create_date
 FROM
       %s t1,
       %s t2,
       %s t3,
       %s t4,
       %s t5
 where t1.shop_type = t2.good_type_id
       and t1.city = t3.city_id
       and nvl(t1.city_area_id, '0') = t4.district_id
       and nvl(t1.bcid, '0') = t5.circle_id
       and t1.tiyan_dian = 0
       and t1.manage_shop_id != 43
       and t1.type_ = 2
       and t1.state in (1, 2, 3)
       and t1.shop_name not like '%%测试%%'
order by t1.shop_id
    """
}



