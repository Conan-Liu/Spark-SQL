package com.gnow.sql

import com.gnow.util.Variables

object SQLFlashQuit {
  val SQL =
    """
SELECT DISTINCT
t.shop_id,
FROM_UNIXTIME(t.create_time/1000, 'yyyy-MM-dd') as create_date
FROM %s t
WHERE t.shop_id IS NOT NULL
AND t.warning_type_id in (231, 283, 232, 428, 433, 432, 431, 430, 429)
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
