package com.gnow.sql

object SQLUserPayRecordTest {
  val SQL =
    """
SELECT
*
FROM %s t
    """
}
