package com.gnow.sql

import com.gnow.util.Variables

object SQLSecondPayBack {
  val SQL =
    """
select
'${dt}' create_date,
0 interval,
amount_wechat,
income_wechat back_wechat,
amount_alipay,
income_alipay back_alipay,
amount_alipay+amount_wechat amount,
income_wechat*0.03+income_alipay*0.01 as all_back
from
(
  select * from
  ( select
    '${dt}' as date1,
    nvl(count(payback_refund_fee),0) as amount_wechat,
    nvl(sum(payback_refund_fee),0) as income_wechat
    from
    com_pay_back t
    where
    t.payback_class = 1
    and
    t.payback_sourceid in (126,159)
    and
    t.payback_creattime >= unix_timestamp(concat('${dt}',' 00:00:00'))
    and
    t.payback_creattime < unix_timestamp(concat(date_add('${dt}',1),' 00:00:00'))
  ) a
  join
  (
    select
    '${dt}' as date2,
    nvl(count(payback_refund_fee),0) as amount_alipay,
    nvl(sum(payback_refund_fee),0) as income_alipay
    from
    com_pay_back t
    where
    t.payback_class = 2
    and
    t.payback_sourceid in (126,159)
    and
    t.payback_creattime >= unix_timestamp(concat('${dt}',' 00:00:00'))
    and
    t.payback_creattime < unix_timestamp(concat(date_add('${dt}',1),' 00:00:00'))
  ) b
  on a.date1 = b.date2
) tmp
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
