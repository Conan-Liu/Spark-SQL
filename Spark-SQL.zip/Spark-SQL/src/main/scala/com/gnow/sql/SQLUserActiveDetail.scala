package com.gnow.sql

import com.gnow.util.Variables

object SQLUserActiveDetail {
  val SQL_APP_DAILY =
    """
select
0 type,
device_id as device_id,
device_type as device_type,
phase as phase,
mobile as id,
from_unixtime(create_time, 'yyyy-MM-dd HH:mm:ss') as create_time
from basic_app_trace
where
create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
and
phase != 0
and length(device_id) < 100
    """

  val SQL_WECHAT_DAILY =
    """
select
1 type,
device_id as device_id,
device_type as device_type,
phase as phase,
open_id as id,
from_unixtime(create_time, 'yyyy-MM-dd HH:mm:ss') as create_time
from basic_wechat_trace
where
create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
and
phase != -2
and
phase != 0
and length(device_id) < 100
    """


  def getSQL4AppDetailDaily(targetDate: String): String = {
    Variables.replace(SQL_APP_DAILY, "dt", targetDate)
  }

  def getSQL4WechatDetailDaily(targetDate: String): String = {
    Variables.replace(SQL_WECHAT_DAILY, "dt", targetDate)
  }


}
