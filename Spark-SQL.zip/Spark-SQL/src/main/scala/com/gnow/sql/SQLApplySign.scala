package com.gnow.sql

import com.gnow.util.Variables

object SQLApplySign {
  val SQL =
    """
select
'${dt}' create_date,
t.shop_id,
count(t.id) as signing_amount,
sum(t.money) as signing_income
from
booking_apply_sign t
where
t.inserttime >= unix_timestamp(concat('${dt}',' 0:0:0'))*1000
and t.inserttime < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))*1000
group by
t.shop_id
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
