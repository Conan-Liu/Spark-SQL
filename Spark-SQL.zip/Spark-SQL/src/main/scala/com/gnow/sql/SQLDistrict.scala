package com.gnow.sql

object SQLDistrict {
  val SQL =
    """
SELECT
t1.city_area_id    district_id,
t1.name_           district_name,
t1.region_id       region_id,
t1.city_id         city_id
FROM
%s t1
WHERE 1=1
    """
}
