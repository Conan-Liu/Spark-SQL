package com.gnow.sql

object SQLShopQueueReserveRule {
  val SQL =
    """
SELECT
*
FROM %s t
    """
}
