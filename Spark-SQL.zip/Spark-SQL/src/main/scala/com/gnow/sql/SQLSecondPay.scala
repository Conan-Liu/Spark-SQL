package com.gnow.sql

import com.gnow.util.Variables

object SQLSecondPay {
  val SQL =
    """
select
'${dt}' create_date,
0 interval,
amount_wechat,
income_wechat,
amount_alipay,
income_alipay,
amount_alipay+amount_wechat amount,
income_wechat*0.01+income_alipay*0.01 as income 
from
(
  select * from
  ( select
    '${dt}' as date1,
    nvl(count(pay_price),0) as amount_wechat,
    nvl(sum(pay_price),0) as income_wechat
    from
    com_pay t
    where
    t.pay_class = 1
    and
    t.pay_sourceid in (126,159)
    and
    t.pay_status = 1
    and
    t.pay_updatetime >= concat('${dt}',' 00:00:00')
    and
    t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
  ) a
  join
  (
    select
    '${dt}' as date2,
    nvl(count(pay_price),0) as amount_alipay,
    nvl(sum(pay_price),0) as income_alipay
    from
    com_pay t
    where
    t.pay_class = 2
    and
    t.pay_sourceid in (126,159)
    and
    t.pay_status = 1
    and
    t.pay_updatetime >= concat('${dt}',' 00:00:00')
    and
    t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
  ) b
  on a.date1 = b.date2
) tmp
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
