package com.gnow.sql

object SQLDWCustomerRegular {
  val QUEUEING_AND_SERVED_COMPACT =
    """
      SELECT
        NVL (t.user_id, 0) user_id,
        NVL (t.mobile, 0) mobile_id,
        NVL (t.open_id, 0) open_id,
        NVL (t3.cur_city_id, 0) city_id,
        (CASE
        WHEN NVL (t2.gender, 0) > 0
        THEN
        NVL (t2.gender, 0)
        ELSE
        NVL (t3.sex, 0)
        END) sex_id,
        t.shop_id shop_id,
        t1.shop_name shop_name,
        t.serial_id,
        t.create_date,
        (unix_timestamp(t.last_time) - unix_timestamp(t.create_date)) queue_sum_time
      FROM %s t
      LEFT JOIN %s t1
      ON t1.shop_id = t.shop_id
      LEFT JOIN %s t2
      ON t2.user_id = t.user_id
      LEFT JOIN %s t3
      ON t3.open_id = t.open_id
      WHERE
        (LENGTH (trim (t.mobile)) = 11
        OR t.open_id IS NOT NULL
        OR (t.user_id != 0 AND t.user_id IS NOT NULL))
        AND t.state = 5
        AND t1.type_ = 2
    """


  val QUEUEING_AND_SERVED =
    """
      SELECT
        1 as source_id,
        a.user_id,
        a.mobile_id,
        a.open_id,
        MAX (a.city_id) city_id,
        MAX (a.sex_id) sex_id,
        a.shop_id,
        a.shop_name,
        COUNT (a.serial_id) count_qty,
        MIN (a.create_date) min_create_date,
        MAX (a.create_date) max_create_date,
        SUM (a.queue_sum_time) queue_sum_time
      from %s a
      GROUP BY
        a.user_id,
        a.mobile_id,
        a.open_id,
        a.shop_id,
        a.shop_name
    """

  val QUEUEING_AND_NOT_SERVED =
    """
      SELECT
        NVL (t.user_id, 0) user_id,
        NVL (t.mobile, 0) mobile_id,
        NVL (t.open_id, 0) open_id,
        NVL (t3.cur_city_id, 0) city_id,
        (CASE
        WHEN NVL (t2.gender, 0) > 0
        THEN
        NVL (t2.gender, 0)
        ELSE
        NVL (t3.sex, 0)
        END) sex_id,
        t.shop_id shop_id,
        t1.shop_name shop_name,
        t.serial_id,
        t.create_date
      FROM %s t
      LEFT JOIN %s t1
      ON t1.shop_id = t.shop_id
      LEFT JOIN %s t2
      ON t2.user_id = t.user_id
      LEFT JOIN %s t3
      ON t3.open_id = t.open_id
      WHERE
        (LENGTH (trim (t.mobile)) = 11
        OR t.open_id IS NOT NULL
        OR (t.user_id != 0 AND t.user_id IS NOT NULL))
        AND t.state != 5
        AND t1.type_ = 2
    """

  val SQL_QUEUEING_AND_NOT_SERVED =
    """
      SELECT
        1 as source_id,
        a.user_id,
        a.mobile_id,
        a.open_id,
        MAX (a.city_id) city_id,
        MAX (a.sex_id) sex_id,
        a.shop_id,
        a.shop_name,
        0 as count_qty,
        MIN (a.create_date) min_create_date,
        MAX (a.create_date) max_create_date,
        0 as queue_sum_time
      from %s a
      GROUP BY
        a.user_id,
        a.mobile_id,
        a.open_id,
        a.shop_id,
        a.shop_name
    """

  val BOOKING_COMPACT =
    """
      SELECT
        d.id,
        a.user_id,
        NVL(c.mobile, 0) user_name,
        NVL(b.cur_city_id, 0) city_id,
        (CASE
        WHEN NVL(a.gender, 0) > 0
        THEN
        NVL(a.gender, 0)
        ELSE
        NVL(b.sex, 0)
        END) sex_id
      FROM %s a
      LEFT JOIN %s c
      on a.user_id = c.user_id
      LEFT JOIN %s b
      ON a.user_id = b.user_id
      JOIN %s d
      ON c.mobile = trim(d.phone)
    """

  val BOOKING_AND_SERVED_COMPACT =
    """
      SELECT
        NVL(t2.user_id, 0) user_id,
        NVL(trim(t.phone), 0) mobile_id,
        '0' open_id,
        NVL(t2.city_id, 0) city_id,
        t.sex sex_id,
        t.shop_id shop_id,
        t1.shop_name shop_name,
        t.id,
        concat (t.order_date, ' ',  t.order_time ,':00') create_date
      FROM %s t
      LEFT JOIN %s t1
      ON t.shop_id = t1.shop_id
      LEFT JOIN %s t2
      ON t2.id = t.id
      WHERE
      LENGTH (trim(t.phone)) = 11
      AND trim(t.phone) != '10000000000'
      AND trim(t.phone) != '11111111111'
      AND t.status_ = 3
      AND t1.type_ = 2
    """

  val BOOKING_AND_SERVED =
    """
      SELECT
        2 as source_id,
        a.user_id,
        a.mobile_id,
        a.open_id,
        MAX (a.city_id) city_id,
        MAX (a.sex_id) sex_id,
        a.shop_id,
        a.shop_name,
        COUNT (a.id) count_qty,
        MIN (create_date) min_create_date,
        MAX (create_date) max_create_date
      from %s a
      GROUP BY
        a.user_id,
        a.mobile_id,
        a.open_id,
        a.shop_id,
        a.shop_name
    """

  val BOOKING_AND_NOT_SERVED_COMPACT =
    """
      SELECT
        NVL(t2.user_id, 0) user_id,
        NVL(trim(t.phone), 0) mobile_id,
        '0' open_id,
        NVL(t2.city_id, 0) city_id,
        t.sex sex_id,
        t.shop_id shop_id,
        t1.shop_name shop_name,
        t.id,
        concat (t.order_date, ' ',  t.order_time ,':00') create_date
      FROM %s t
      LEFT JOIN %s t1
      ON t.shop_id = t1.shop_id
      LEFT JOIN %s t2
      ON t2.id = t.id
      WHERE
      LENGTH (trim(t.phone)) = 11
      AND trim(t.phone) != '10000000000'
      AND trim(t.phone) != '11111111111'
      AND t.status_ != 3
      AND t1.type_ = 2
    """

  val BOOKING_AND_NOT_SERVED =
    """
      SELECT
        2 as source_id,
        a.user_id,
        a.mobile_id,
        a.open_id,
        MAX (a.city_id) city_id,
        MAX (a.sex_id) sex_id,
        a.shop_id,
        a.shop_name,
        0 count_qty,
        MIN (create_date) min_create_date,
        MAX (create_date) max_create_date
      from %s a
      GROUP BY
        a.user_id,
        a.mobile_id,
        a.open_id,
        a.shop_id,
        a.shop_name
    """

  val ORDERING_COMPACT =
    """
      SELECT
        NVL (t.cust_id, 0) user_id,
        NVL (t4.mobile, 0) mobile_id,
        NVL (t3.open_id, 0) open_id,
        NVL (t3.cur_city_id, 0) city_id,
        (CASE
        WHEN NVL (t2.gender, 0) > 0
        THEN
        NVL (t2.gender, 0)
        ELSE
        NVL (t3.sex, 0)
        END) sex_id,
        t.rest_id shop_id,
        t1.shop_name shop_name,
        t.id,
        t.create_time create_date
      FROM %s t
      LEFT JOIN %s t1
      ON t1.shop_id = t.rest_id
      LEFT JOIN %s t2
      ON t2.user_id = t.cust_id
      LEFT JOIN %s t3
      ON t3.user_id = t2.user_id
      LEFT JOIN %s t4
      ON t2.user_id = t4.user_id
      WHERE
        t.order_status != -1
        AND t.cust_id != 0
        AND t.order_status != -2
        AND t.pay_status = 3
        AND t.biz_type != 5
        AND t1.type_ = 2
    """

  val ORDERING =
    """
      SELECT
        3 as source_id,
        a.user_id,
        a.mobile_id,
        a.open_id,
        MAX (a.city_id) city_id,
        MAX (a.sex_id) sex_id,
        a.shop_id,
        a.shop_name,
        COUNT (a.id) count_qty,
        MIN (a.create_date) min_create_date,
        MAX (a.create_date) max_create_date
      from %s a
      GROUP BY
        a.user_id,
        a.mobile_id,
        a.open_id,
        a.shop_id,
        a.shop_name
    """
}
