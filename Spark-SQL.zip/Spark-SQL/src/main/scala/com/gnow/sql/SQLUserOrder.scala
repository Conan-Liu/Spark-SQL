package com.gnow.sql

import com.gnow.util.Variables

object SQLUserOrder {
  val SQL =
    """
SELECT
*
FROM %s t
    """
}
