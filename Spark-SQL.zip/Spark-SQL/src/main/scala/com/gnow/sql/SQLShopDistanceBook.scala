package com.gnow.sql

import com.gnow.schema.repository
import com.gnow.util.Variables

object SQLShopDistanceBook {
  val SQL =
    """
select
distinct
b.user_id,
b.mobile,
'',
b.user_type,
b.shop_id,
b.shop_name,
b.order_id,
b.create_time,
'${dt}',
acos(sin(cast (a.latitude as double)/57.2958)*sin(cast(b.latitude as double)/57.2958) + cos(cast (a.latitude as double)/57.2958)*cos(cast (b.latitude as double)/57.2958)*cos((cast (a.longitude as double) - cast (b.longitude as double))/57.2958))* 6371.004,
1
from
%s b
join
%s a
on
(b.shop_id = a.shop_id
 and
b.user_type != 1
 and
b.user_type != 4
 and
b.longitude is not null
 and
b.latitude is not null
 and
b.create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and
b.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
)
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate).format(
      repository.kafka.BOOKING_MAIN_BOOK,
      "shop_compact")
  }
}
