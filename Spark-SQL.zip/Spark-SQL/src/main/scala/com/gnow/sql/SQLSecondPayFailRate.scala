package com.gnow.sql

object SQLSecondPayFailRate {
  val SQL =
    """
      |select
      |'%s' create_date,
      |ft.shop_id,
      |ft.fail_count,
      |tt.total_count
      |from (
      |    select
      |    t1.shop_id,
      |    count(t1.shop_id) fail_count
      |    from %s t1
      |    where t1.response_code <> 0
      |    group by
      |    t1.shop_id
      |) ft join (
      |    select
      |    t2.shop_id,
      |    count(t2.shop_id) total_count
      |    from %s t2
      |    group by
      |    t2.shop_id
      |) tt on (
      |    ft.shop_id = tt.shop_id
      |)
      |where ft.shop_id = tt.shop_id
    """.stripMargin
}
