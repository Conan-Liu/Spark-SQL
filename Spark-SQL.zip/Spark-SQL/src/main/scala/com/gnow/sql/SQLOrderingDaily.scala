package com.gnow.sql

object SQLOrderingDaily {
  val SQL =
    """
select
from_unixtime(t1.order_date, 'yyyyMMdd') order_date,
t1.shop_id           shop_id,
t2.shop_name         shop_name,
t4.brand_id          brand_id,
t4.brand_name        brand_name,
t3.city_name         city_name,
count(t1.order_id)   order_count,
count(case when t1.status_ = 1 then 1 else null end) confirm_order_count,
count(case when t1.status_ = 2 then 1 else null end) undeal_order_count,
count(case when t1.status_ = 3 then 1 else null end) finish_order_count,
count(case when t1.status_ = 4 then 1 else null end) unfinish_order_count,
count(case when t1.status_ = 5 then 1 else null end) cancel_order_count,
count(case when t1.status_ = 6 then 1 else null end) del_order_count,
count(case when t1.status_ = 7 then 1 else null end) keep_order_count,
sum(t1.people_count) people_count_sum,
sum(case when t1.status_ = 1 then t1.people_count else null end) confirm_people_count,
sum(case when t1.status_ = 2 then t1.people_count else null end) undeal_people_count,
sum(case when t1.status_ = 3 then t1.people_count else null end) finish_people_count,
sum(case when t1.status_ = 4 then t1.people_count else null end) unfinish_people_count,
sum(case when t1.status_ = 5 then t1.people_count else null end) cancel_people_count,
sum(case when t1.status_ = 6 then t1.people_count else null end) del_people_count,
sum(case when t1.status_ = 7 then t1.people_count else null end) keep_people_count,
round(count (case when t1.status_ = 3 then 1 else null end) / count (t1.order_id), 4) * 100 shop_rate
from
booking_table t1,
shop_table t2,
city t3,
transform_brand t4
where
t1.shop_id = t2.shop_id
and t2.manage_shop_id = t4.brand_id
and t2.city = t3.city_id
and t1.status_ != 0
and t1.people_count > 0
and t1.order_channel not in ('线下导入', '线下')
and t1.order_source not in ('17', '18')
and regexp_replace(t1.phone, ' ', '') not in ('10000000000', '11111111111')
and t2.tiyan_dian != 1
group by
t1.shop_id,
t4.brand_name,
t2.shop_name,
t3.city_name,
from_unixtime(t1.order_date, 'yyyyMMdd'),
t4.brand_id
    """
}
