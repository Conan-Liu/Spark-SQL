package com.gnow.sql

import com.gnow.util.Variables

object SQLQueueingNumberingPhone {
  val SQL =
    """
select
t.shop_id,
t.phone_queue,
t.create_time,
'${dt}' create_date,
t.operator
from
queueing_numbering_phone t
where
t.create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and t.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
