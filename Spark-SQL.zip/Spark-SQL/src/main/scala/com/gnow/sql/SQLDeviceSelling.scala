package com.gnow.sql

import com.gnow.util.Variables
import org.apache.spark.sql.DataFrame
import com.gnow.{ILogger, ISQLContext, UDAFConcat}


object SQLDeviceSelling extends ILogger with ISQLContext{
    
  val SQL =
    """
select
'${dt}',
t.order_type,
t.shop_id,
count(t.id) as sell_amount,
sum(t.scheme_amount) as all_scheme_amount,
sum(t.other_amount) as all_other_amount,
sum(t.change_amount) as all_chang_amount,
sum(t.scheme_amount)+sum(t.other_amount)+sum(t.change_amount) as sell_income
from
device_order t 
where
t.pay_status = 2
and t.order_type in (1, 2)
and t.category = 0
and t.pay_time >=  unix_timestamp(concat('${dt}',' 0:0:0'))
and t.pay_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
group by
t.order_type ,
t.shop_id
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}


