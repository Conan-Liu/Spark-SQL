package com.gnow.sql

object SQLShopGoodType {
  val SQL =
    """
select
t.type_id good_type_id,
t.type_name good_type_name,
nvl(t2.gt_shop_qty, 0) gt_shop_qty
from %s t left join (
  select t1.shop_type, count(t1.shop_id) gt_shop_qty
  from %s t1
  group by t1.shop_type
) t2 on t.type_id = t2.shop_type
order by t.type_id
    """
}
