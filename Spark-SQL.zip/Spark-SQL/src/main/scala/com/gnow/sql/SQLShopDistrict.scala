package com.gnow.sql

object SQLShopDistrict {
  val SQL =
    """
SELECT
t1.shop_id,
t1.city_area_id district_ids
FROM
%s t1
WHERE 1=1
    """
  val SQL2 =
    """
SELECT DISTINCT
t1.shop_id,
t1.district_id
FROM
%s t1
WHERE 1=1
    """
}
