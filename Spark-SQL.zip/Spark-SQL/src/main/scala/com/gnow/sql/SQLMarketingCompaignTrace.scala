package com.gnow.sql

import com.gnow.util.Variables

object SQLMarketingCompaignTrace {
  val SQL =
    """
select
  datatype,
  business,
  module,
  action_,
  date_,
  version,
  domain,
  category,
  attributes.user_agent,
  attributes.device_type,
  attributes.city_id,
  attributes.latitude,
  attributes.longitude,
  attributes.user_id,
  attributes.mobile,
  attributes.current_url,
  attributes.referer_url,
  attributes.name,
  attributes.app_version,
  create_time
from marketing_compaign_trace t
where 1=1
and t.create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and t.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
