package com.gnow.sql

import com.gnow.util.Variables

object SQLShopServiceDetail {
  val SQL4DAILY =
    """
select
t.shop_id,
t.shop_name,
t.service,
t.status,
0 time_interval,
t.create_time,
'${dt}' create_date
from  (
  select
  it.shop_id,
  it.service,
  max(create_time) as  max_create_time
  from basic_shop_service it
  group by
  it.shop_id,
  it.service
) mt join basic_shop_service t
where mt.shop_id = t.shop_id
and mt.service = t.service
and mt.max_create_time = t.create_time
and t.create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and t.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """

  val SQL4WEEKLY =
    """
select
t.shop_id,
t.shop_name,
t.service,
t.status,
1 time_interval,
t.create_time,
'${dt}' create_date
from  (
  select
  it.shop_id,
  it.service,
  max(create_time) as max_create_time
  from basic_shop_service it
  group by
  it.shop_id,
  it.service
) mt join basic_shop_service t
where mt.shop_id = t.shop_id
and mt.service = t.service
and mt.max_create_time = t.create_time
and t.create_time >= unix_timestamp(concat(date_sub('${dt}',6),' 0:0:0'))
and t.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """

  val SQL4MONTHLY =
    """
select
t.shop_id,
t.shop_name,
t.service,
t.status,
2 time_interval,
t.create_time,
'${dt}' create_date
from  (
  select
  it.shop_id,
  it.service,
  max(create_time) as max_create_time
  from basic_shop_service it
  group by
  it.shop_id,
  it.service
) mt join basic_shop_service t
where mt.shop_id = t.shop_id
and mt.service = t.service
and mt.max_create_time = t.create_time
and t.create_time >= unix_timestamp(concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 0:0:0'))
and t.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """

  def getSQL4Daily(targetDate: String): String = {
    Variables.replace(SQL4DAILY, "dt", targetDate)
  }

  def getSQL4Week(targetDate: String): String = {
    Variables.replace(SQL4WEEKLY, "dt", targetDate)
  }

  def getSQL4Month(targetDate: String): String = {
    Variables.replace(SQL4MONTHLY, "dt", targetDate)
  }
}
