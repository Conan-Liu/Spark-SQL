package com.gnow.sql

import com.gnow.util.Variables

object SQLSecondPayEstimate {
  val SQL_WEEK =
    """
    select distinct
    '${dt}'                                             as create_date,
    '1'                                                 as interval_type,
    c.manage_shop_id                                    as shop_id,
    count(a.pay_shopid)                                 as shop_amount,
    sum(a.wc_total_count)                               as wc_total_count,
    sum(nvl(b.wc_follow_count,0))                       as wc_follow_count,
    sum(nvl(b.wc_follow_count,0))/sum(a.wc_total_count) as follow_rate
    from
    (select
    t.pay_shopid,
    count(t.pay_openid) as wc_total_count
    from
    %s t
    where t.pay_sourceid in (119,126,159)
    and t.pay_status = 1
    and t.pay_updatetime >= concat(date_sub('${dt}',6),' 00:00:00')
    and t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
    group by
    t.pay_shopid
    ) a
    left join
    (select
    t.pay_shopid,
    count(distinct t.pay_openid) as wc_follow_count
    from %s t
    left semi join %s wx
    on wx.open_id=t.pay_openid
    where t.pay_sourceid in (119,126,159)
    and t.pay_status = 1
    and t.pay_updatetime >= concat(date_sub('${dt}',6),' 00:00:00')
    and t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
    group by
    t.pay_shopid
    ) b
    on a.pay_shopid = b.pay_shopid
    left join %s c
    on a.pay_shopid = c.shop_id
    where c.shop_name NOT LIKE '%%测试%%'
    and c.shop_name NOT LIKE '%%体验店%%'
    group by
    c.manage_shop_id
    """.stripMargin

  val SQL_MONTH =
    """
      select distinct
      '${dt}'                                             as create_date,
      '2'                                                 as interval_type,
      c.manage_shop_id                                    as shop_id,
      count(a.pay_shopid)                                 as shop_amount,
      sum(a.wc_total_count)                               as wc_total_count,
      sum(nvl(b.wc_follow_count,0))                       as wc_follow_count,
      sum(nvl(b.wc_follow_count,0))/sum(a.wc_total_count) as follow_rate
      from
      (select
      t.pay_shopid,
      count(t.pay_openid) as wc_total_count
      from
      %s t
      where t.pay_sourceid in (119,126,159)
      and t.pay_status = 1
      and t.pay_updatetime >= concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 00:00:00')
      and t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
      group by
      t.pay_shopid
      ) a
      left join
      (select
      t.pay_shopid,
      count(distinct t.pay_openid) as wc_follow_count
      from %s t
      left semi join %s wx
      on wx.open_id=t.pay_openid
      where t.pay_sourceid in (119,126,159)
      and t.pay_status = 1
      and t.pay_updatetime >= concat(date_sub('${dt}',dayofmonth(date_sub('${dt}',1))),' 00:00:00')
      and t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
      group by
      t.pay_shopid
      ) b
      on a.pay_shopid = b.pay_shopid
      left join %s c
      on a.pay_shopid = c.shop_id
      where c.shop_name NOT LIKE '%%测试%%'
      and c.shop_name NOT LIKE '%%体验店%%'
      group by
      c.manage_shop_id
    """.stripMargin

  val SQL_TOTAL_WEEK =
    """
    select distinct
    '${dt}'                                             as create_date,
    '3'                                                 as interval_type,
    c.manage_shop_id                                    as shop_id,
    count(a.pay_shopid)                                 as shop_amount,
    sum(a.wc_total_count)                               as wc_total_count,
    sum(nvl(b.wc_follow_count,0))                       as wc_follow_count,
    sum(nvl(b.wc_follow_count,0))/sum(a.wc_total_count) as follow_rate
    from
    (select
    t.pay_shopid,
    count(t.pay_openid) as wc_total_count
    from
    %s t
    where t.pay_sourceid in (119,126,159)
    and t.pay_status = 1
    and t.pay_updatetime >= concat('2016-05-21',' 00:00:00')
    and t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
    group by
    t.pay_shopid
    ) a
    left join
    (select
    t.pay_shopid,
    count(distinct t.pay_openid) as wc_follow_count
    from %s t
    left semi join %s wx
    on wx.open_id=t.pay_openid
    where t.pay_sourceid in (119,126,159)
    and t.pay_status = 1
    and t.pay_updatetime >= concat('2016-05-21',' 00:00:00')
    and t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
    group by
    t.pay_shopid
    ) b
    on a.pay_shopid = b.pay_shopid
    left join %s c
    on a.pay_shopid = c.shop_id
    where c.shop_name NOT LIKE '%%测试%%'
    and c.shop_name NOT LIKE '%%体验店%%'
    group by
    c.manage_shop_id
    """.stripMargin

  val SQL_TOTAL_MONTH =
    """
    select distinct
    '${dt}'                                             as create_date,
    '4'                                                 as interval_type,
    c.manage_shop_id                                    as shop_id,
    count(a.pay_shopid)                                 as shop_amount,
    sum(a.wc_total_count)                               as wc_total_count,
    sum(nvl(b.wc_follow_count,0))                       as wc_follow_count,
    sum(nvl(b.wc_follow_count,0))/sum(a.wc_total_count) as follow_rate
    from
    (select
    t.pay_shopid,
    count(t.pay_openid) as wc_total_count
    from
    %s t
    where t.pay_sourceid in (119,126,159)
    and t.pay_status = 1
    and t.pay_updatetime >= concat('2016-05-21',' 00:00:00')
    and t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
    group by
    t.pay_shopid
    ) a
    left join
    (select
    t.pay_shopid,
    count(distinct t.pay_openid) as wc_follow_count
    from %s t
    left semi join %s wx
    on wx.open_id=t.pay_openid
    where t.pay_sourceid in (119,126,159)
    and t.pay_status = 1
    and t.pay_updatetime >= concat('2016-05-21',' 00:00:00')
    and t.pay_updatetime < concat(date_add('${dt}',1),' 00:00:00')
    group by
    t.pay_shopid
    ) b
    on a.pay_shopid = b.pay_shopid
    left join %s c
    on a.pay_shopid = c.shop_id
    where c.shop_name NOT LIKE '%%测试%%'
    and c.shop_name NOT LIKE '%%体验店%%'
    group by
    c.manage_shop_id
    """.stripMargin

  val RES =
    """
      select
      a.create_date,
      a.interval_type,
      b.shop_name,
      a.shop_amount,
      a.wc_total_count,
      a.wc_follow_count,
      a.follow_rate
      from
      %s a
      join %s b
      on a.shop_id = b.shop_id

    """.stripMargin

  def getSQLWeek(targetDate: String): String = {
    Variables.replace(SQL_WEEK, "dt", targetDate)
  }

  def getSQLMonth(targetDate: String): String = {
    Variables.replace(SQL_MONTH, "dt", targetDate)
  }

  def getSQLTotalWeek(targetDate: String): String = {
    Variables.replace(SQL_TOTAL_WEEK, "dt", targetDate)
  }

  def getSQLTotalMonth(targetDate: String): String = {
    Variables.replace(SQL_TOTAL_MONTH, "dt", targetDate)
  }

  def getRes(targetDate: String): String = {
    Variables.replace(RES, "dt", targetDate)
  }

}
