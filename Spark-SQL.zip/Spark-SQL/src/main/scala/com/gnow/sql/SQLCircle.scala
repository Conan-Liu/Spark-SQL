package com.gnow.sql

object SQLCircle {
  val SQL =
    """
SELECT DISTINCT
t1.bcid             circle_id,
t1.name_            circle_name,
t1.city_area        district_id,
t1.city_id          city_id
FROM %s t1
WHERE 1=1
    """
}
