package com.gnow.sql

import com.gnow.util.Variables

object SQLUserAccess {
  val SQL_APP_MANY_MONTHS =
    """
select
'${dt}' as create_date,
tmp.device_id,
tmp.device_type,
tmp.phase,
NVL(tmp.mobile, '') mobile,
tmp.create_time,
relogin.last_time
from
  (select
  distinct
  device_id as device_id,
  device_type as device_type,
  phase_ as phase,
  mobile,
  create_time
  from
  basic_app_trace
  where
  (phase_ = 0 or phase_ = 1)
  and
  create_time <= unix_timestamp(concat('${dt}', ' 00:00:00'))
  )
  tmp
join
  (select
  distinct
  device_id as device_id,
  max(create_time) as last_time
  from
  basic_app_trace
  group by
  device_id
  )
  relogin
on
tmp.device_id = relogin.device_id
and relogin.last_time <= unix_timestamp(concat('${dt}', ' 00:00:00'))
    """

  def getSQL4APPManyMonthly(targetDate: String): String = {
    Variables.replace(SQL_APP_MANY_MONTHS, "dt", targetDate)
  }
}
