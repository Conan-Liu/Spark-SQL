package com.gnow.sql

import com.gnow.util.Variables

object SQLClickFarming {
  val SQL =
    """
select
t.serial_id as serial_number,
t.shop_id as shop_id,
t.create_date as create_time,
t.last_time as update_time
from queueing_table t
where 1=1
and to_date(t.create_date) = '${dt}'
and queue_id != '0'
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
