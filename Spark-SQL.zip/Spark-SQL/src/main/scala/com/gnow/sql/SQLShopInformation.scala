package com.gnow.sql

object SQLShopInformation {

  val SHOP =
    """
SELECT
  t1.shop_id shop_id,
  t1.shop_name shop_name,
  t2.good_type_name,
  t6.watershed_time_new watershed_time,
  t7.queue_id table_id,
  t7.name_ table_name,
  t8.queue_type_id,
  t8.queue_type_name,
  t3.city_id,
  t3.city_name,
  t4.district_name,
  t5.circle_name,
  t1.address,
  t1.create_date
FROM
  %s t1,
  %s t2,
  %s t3,
  %s t4,
  %s t5,
  %s t6,
  %s t7,
  %s t8
WHERE
  t1.shop_type = t2.good_type_id
  AND NVL (t1.city, 0) = t3.city_id
  AND t1.shop_id = t6.shop_id
  AND t1.shop_id = t7.shop_id
  AND NVL (t1.city_area_id, '0') = t4.district_id
  AND NVL (t1.bcid, '0') = t5.circle_id
  AND t1.tiyan_dian = 0
  AND t1.manage_shop_id != 43
  AND t1.type_ = 2
  AND t1.state IN (2, 3)
  AND t1.shop_name NOT LIKE '%%测试%%'
ORDER BY
t1.shop_id,
t8.queue_type_id,
t7.queue_id
    """
}
