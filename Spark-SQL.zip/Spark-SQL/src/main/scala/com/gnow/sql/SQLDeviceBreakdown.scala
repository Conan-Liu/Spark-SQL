package com.gnow.sql

import com.gnow.util.Variables

object SQLDeviceBreakdown {
  val SQL =
    """
select
'${dt}',
0,
t.dtype_id,
sum(t.device_num) as breakdown_amount
from
repair_out_order t
where
t.create_time >=  concat('${dt}',' 00:00:00')
and t.create_time < concat(date_add('${dt}',1),' 00:00:00')
group by
t.dtype_id
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
