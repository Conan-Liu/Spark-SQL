package com.gnow.sql

import com.gnow.util.Variables

object SQLUserAmount {
  val SQL_APP =
    """
select
'${dt}' create_date,
0 device_type,
0 c_type,
count(distinct device_id) amount
from basic_app_trace
where
create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
and
phase = 0

    """
  val SQL_WECHAT =
    """
select
'${dt}' create_date,
1 device_type,
0 c_type,
count(distinct open_id) as amount
from basic_wechat_trace
where
create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and
create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
and
phase = 0

    """

  def getSQL4APP(targetDate: String): String = {
    Variables.replace(SQL_APP, "dt", targetDate)
  }

  def getSQL4WECHAT(targetDate: String): String = {
    Variables.replace(SQL_WECHAT, "dt", targetDate)
  }
}
