package com.gnow.sql

import com.gnow.util.Variables

object SQLQueueingNumberingOffvalid {
  val SQL =
    """
select
t.shop_id,
t.off_valid,
t.create_time,
'${dt}' create_date,
t.operator
from
queueing_numbering_offvalid t
where
t.create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
and t.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
    """

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
