package com.gnow.sql

import com.gnow.util.Variables

object SQLBookingDeposit {
  val SQL =
    """
      |select
      |'${dt}' create_date,
      |t.type_ type,
      |t.shop_id,
      |count(t.id) as booking_amount,
      |sum(t.deposit) as booking_income
      |from
      |booking_deposit t
      |where
      |t.insert_time >= unix_timestamp(concat('${dt}',' 0:0:0'))*1000
      |and t.insert_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))*1000
      |and status_ in ('3', '4', '6')
      |group by
      |t.type_,
      |t.shop_id,
      |'${dt}'
    """.stripMargin

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
