package com.gnow.sql

object SQLSmsDaily {
  val SQL =
    """
SELECT
from_unixtime(unix_timestamp(), 'yyyy-MM-dd') create_date,
ct.city_id,
dstct.district_id,
crcl.circle_id,
brd.brand_id,
bs.shop_id,
sgt.good_type_id,
bss.sms_status_id,
bst.sms_type_id,
COUNT(slt.id) sms_quality,
SUM(slt.fee) sms_fee_quality
FROM
%s slt,
%s st,
%s ct,
%s dstct,
%s crcl,
%s brd,
%s sgt,
%s bs,
%s bss,
%s bst
WHERE
st.tiyan_dian = 0
AND slt.shop_id > 0
AND slt.shop_id = st.shop_id
AND NVL(st.city, '0') = ct.city_id
AND NVL(st.city_area_id, '0') = dstct.district_id
AND NVL(st.bcid, '0') = crcl.circle_id
AND NVL(st.manage_shop_id, 0) = brd.brand_id
AND NVL(st.shop_type, 0) = sgt.good_type_id
AND st.shop_id = bs.shop_id
AND slt.state = bss.sms_status_id
AND slt.type_ = bst.type_id
GROUP BY
from_unixtime(unix_timestamp(), 'yyyy-MM-dd'),
ct.city_id,
dstct.district_id,
crcl.circle_id,
brd.brand_id,
bs.shop_id,
sgt.good_type_id,
bss.sms_status_id,
bst.sms_type_id
    """
}
