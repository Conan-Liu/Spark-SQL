package com.gnow.sql

import com.gnow.util.Variables

object SQLShopAndService {
  val SQL =
    """
      |select
      |  t1.service,
      |  t1.status,
      |  '${dt}' create_date,
      |  0 time_interval,
      |  t1.amount
      |from
      |  (select
      |    t.service,
      |    t.status,
      |    count(t.shop_id) as amount
      |  from
      |    (select
      |        it.shop_id,
      |        it.service,
      |        max(create_time) as max_create_time
      |      from
      |        basic_shop_service it
      |      group by
      |        it.shop_id,
      |        it.service
      |      ) mt
      |  join
      |    basic_shop_service t
      |  on
      |    mt.shop_id = t.shop_id
      |    and
      |    mt.service = t.service
      |    and
      |    mt.max_create_time = t.create_time
      |    and
      |    t.create_time >= unix_timestamp(concat('${dt}',' 0:0:0'))
      |    and
      |    t.create_time < unix_timestamp(concat(date_add('${dt}',1),' 0:0:0'))
      |  group by
      |    t.service,
      |    t.status) t1
    """.stripMargin

  def getSQL(targetDate: String): String = {
    Variables.replace(SQL, "dt", targetDate)
  }
}
