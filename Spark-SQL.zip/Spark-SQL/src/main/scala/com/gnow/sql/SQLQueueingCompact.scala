package com.gnow.sql

object SQLQueueingCompact {
  val SQL =
    """
select
t1.serial_id                   serial_id,
t1.mobile                      mobile,
unix_timestamp(t1.create_date) create_date,
unix_timestamp(t1.last_time)   last_time,
t1.shop_id                     shop_id,
t1.state                       state,
t1.type_                       channel_id,
t1.queue_id                    queue_id,
NVL(t1.qrscan, 0)              is_qr_scan,
NVL(t1.smsview, 0)             is_sms_view,
NVL(t1.weixin_view, 0)         is_wechat_view,
NVL(t1.appview, 0)             is_app_view,
t1.dev_type                    device_type_id,
CASE WHEN t1.people > 50 THEN 50 ELSE t1.people END                                                   people,
CASE WHEN t1.mobile IS NULL THEN 0 ELSE 1 END                                                         call_quality,
CASE
  WHEN unix_timestamp(t1.last_time) <= unix_timestamp(t1.create_date) THEN 0
  ELSE unix_timestamp(t1.last_time) - unix_timestamp(t1.create_date)
END delta_time,
unix_timestamp(t1.last_time) - unix_timestamp(t1.create_date) real_delta_time,
CASE
  WHEN t1.qtype = 0
  AND from_unixtime(t1.create_date, 'yyyy-MM-dd HH:mm:ss')
  < date_format(concat(date_sub(to_date(current_timestamp()), 1), ' ', date_format(t2.watershed_time_new, 'HH:mm:ss')), 'yyyy-MM-dd HH:mm:ss')
  THEN 1
  WHEN t1.qtype = 0
  AND from_unixtime(t1.create_date, 'yyyy-MM-dd HH:mm:ss')
  >= date_format(concat(date_sub(to_date(current_timestamp()), 1), ' ', date_format(t2.watershed_time_new, 'HH:mm:ss')), 'yyyy-MM-dd HH:mm:ss')
  THEN 2
  ELSE t1.qtype
END queue_type_id
from %s t1 join %s t2 on (
  t1.shop_id = t2.shop_id
)
where 1 = 1
    """
}
