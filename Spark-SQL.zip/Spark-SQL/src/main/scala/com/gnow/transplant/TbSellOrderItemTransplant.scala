package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class TbSellOrderItemTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_197_SPARK;
  val BUSINESS: String = "basic"
  val FROM_TABLE: String = "tbSellOrderItem"
  val TO_TABLE: String = rdb.basic.TB_SELL_ORDER_ITEM
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "fsOrderTime >= '%s 00:00:00' AND fsOrderTime < '%s 00:00:00'"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}

