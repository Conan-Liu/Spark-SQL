package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class ShopQueueReserveRuleTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_100_QUEUES;
  val BUSINESS: String = "queueing"
  val FROM_TABLE: String = "shop_queue_reserve_rule"
  val TO_TABLE: String = rdb.queueing.SHOP_QUEUE_RESERVE_RULE
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null


  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
