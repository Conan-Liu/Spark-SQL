package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class TbMenuClsTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_197_SPARK;
  val BUSINESS: String = "basic"
  val FROM_TABLE: String = "tbmenucls"
  val TO_TABLE: String = rdb.basic.TB_MENU_CLS
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null;

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
