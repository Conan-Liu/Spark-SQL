package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class DeviceSellingTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_38_OA_STORAGE;
  val BUSINESS: String = "oa"
  val FROM_TABLE: String = "device_order"
  val TO_TABLE: String = rdb.oa.DEVICE_ORDER
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "create_time >= UNIX_TIMESTAMP('%s') AND create_time < UNIX_TIMESTAMP('%s')"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
