package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class BookingTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_100_RESTAURANT;
  val BUSINESS: String = "booking"
  val FROM_TABLE: String = "orderbooks"
  val TO_TABLE: String = rdb.booking.BOOKING_TABLE
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "inserttime >= unix_timestamp('%s')*1000  AND inserttime < unix_timestamp('%s')*1000"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
