package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class ComPayBackTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_4_PAYN;
  val BUSINESS: String = "paying"
  val FROM_TABLE: String = "com_pay_back"
  val TO_TABLE: String = rdb.paying.COM_PAY_BACK
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "payback_creattime >= UNIX_TIMESTAMP('%s') AND payback_creattime < UNIX_TIMESTAMP('%s')"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
