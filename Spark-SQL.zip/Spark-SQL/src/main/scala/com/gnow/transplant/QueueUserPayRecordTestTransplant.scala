package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class QueueUserPayRecordTestTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_100_QUEUES;
  val BUSINESS: String = "queueing"
  val FROM_TABLE: String = "queue_user_pay_record"
  val TO_TABLE: String = rdb.queueing.QUEUE_USER_PAY_RECORD
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
