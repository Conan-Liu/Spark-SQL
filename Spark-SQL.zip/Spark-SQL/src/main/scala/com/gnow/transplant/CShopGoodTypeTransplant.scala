package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class CShopGoodTypeTransplant extends Processor with Transplant {
  val DATABASE = DB.ORACLE_37_BWSWD;
  val BUSINESS: String = "basic"
  val FROM_TABLE: String = "c_shop_goodtype"
  val TO_TABLE: String = rdb.basic.C_SHOP_GOODTYPE
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null;

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
