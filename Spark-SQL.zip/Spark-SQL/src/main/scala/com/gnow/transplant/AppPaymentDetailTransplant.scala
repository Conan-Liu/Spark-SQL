package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class AppPaymentDetailTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_211_ALFRED_MOBILE;
  val BUSINESS: String = "ordering"
  val FROM_TABLE: String = "app_payment_detail"
  val TO_TABLE: String = rdb.ordering.APP_PAYMENT_DETAIL
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "update_time >= '%s' AND update_time < '%s'"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
