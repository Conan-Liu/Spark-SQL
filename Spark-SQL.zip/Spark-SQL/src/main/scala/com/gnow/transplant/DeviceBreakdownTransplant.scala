package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class DeviceBreakdownTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_38_OA_STORAGE;
  val BUSINESS: String = "oa"
  val FROM_TABLE: String = "repair_out_order"
  val TO_TABLE: String = rdb.oa.REPAIR_OUT_ORDER
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "create_time >= '%s 00:00' AND create_time < '%s 00:00'"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
