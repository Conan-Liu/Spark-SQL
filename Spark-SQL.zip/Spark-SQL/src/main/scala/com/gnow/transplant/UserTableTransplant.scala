package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class UserTableTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_32_RESTAURANT;
  val BUSINESS: String = "basic"
  val FROM_TABLE: String = "UserTable"
  val TO_TABLE: String = rdb.basic.USER_TABLE
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "CreateDate >= '%s' AND CreateDate < '%s'"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
