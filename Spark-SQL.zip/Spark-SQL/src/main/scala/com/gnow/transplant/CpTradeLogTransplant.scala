package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class CpTradeLogTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_220_COUPONS;
  val BUSINESS: String = "ordering"
  val FROM_TABLE: String = "cp_trade_log"
  val TO_TABLE: String = rdb.ordering.CP_TRADE_LOG
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "add_time >= UNIX_TIMESTAMP('%s') AND add_time < UNIX_TIMESTAMP('%s')"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
