package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class ComPayTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_4_PAYN;
  val BUSINESS: String = "paying"
  val FROM_TABLE: String = "com_pay"
  val TO_TABLE: String = rdb.paying.COM_PAY
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "pay_updatetime >= '%s 00:00' AND pay_updatetime < '%s 00:00'"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
