package com.gnow.transplant

import com.gnow.schema.rdb
import com.gnow.{DB, Processor, Transplant}

class WarnWarningTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_36_NOWWARNING;
  val BUSINESS: String = "paying"
  val FROM_TABLE: String = "warnwarnings"
  val TO_TABLE: String = rdb.paying.WARN_WARNINGS
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = "createTime >= UNIX_TIMESTAMP('%s')*1000 AND createTime < UNIX_TIMESTAMP('%s')*1000"

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
