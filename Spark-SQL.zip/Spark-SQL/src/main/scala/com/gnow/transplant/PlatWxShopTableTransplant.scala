package com.gnow.transplant

import com.gnow.{DB, Processor, Transplant}

class PlatWxShopTableTransplant extends Processor with Transplant {
  val DATABASE = DB.MYSQL_13_PLAT
  val BUSINESS: String = "basic"
  val FROM_TABLE: String = "plat_wx_shop_table"
  val TO_TABLE: String = "plat_wx_shop_table"
  val COLUMNS: String = "*"
  val WHERE_CLAUSE: String = null

  def reset(targetDate: String): Unit = {
  }

  def execute(targetDate: String, input: String, output: String) = {
    transplant(targetDate, DATABASE, BUSINESS, FROM_TABLE, TO_TABLE, COLUMNS, WHERE_CLAUSE)
  }
}
