package com.gnow

import java.io.{PrintWriter, StringWriter}

import org.apache.commons.mail.{DefaultAuthenticator, SimpleEmail}
import org.slf4j.LoggerFactory

object UserTagMail {
  val logger = LoggerFactory.getLogger("9now")
  val MAX_ATTEMPTS = 3
  val server = "smtp.exmail.qq.com"
  val account = "big.data@puscene.com"
  val password = "AW#4esz"
  val port = "465"


  def send(subject: String, message: String ): Unit = {
    for (i <- 1 to MAX_ATTEMPTS) {
      val isSent = try2send(i, subject, message)
      if (isSent) {
        return
      }
      Thread.sleep(1000)
    }
  }

  def try2send(count: Integer, subject: String, message: String ): Boolean = {
    try {
      _send(subject, message)
      return true
    } catch {
      case e: Throwable => {
        val sw = new StringWriter()
        val pw = new PrintWriter(sw)
        if (count >= MAX_ATTEMPTS) {
          e.printStackTrace(pw)
          logger.error(sw.toString())
          return false
        } else {
          return false
        }
      }
    }
  }
  
  
  

  def _send(subject: String, message: String): Unit = {
  
    val email = new SimpleEmail();

    val authenticator = new DefaultAuthenticator(account, password)
    email.setHostName(server);
    email.setSslSmtpPort(port);
    email.setAuthenticator(authenticator);
    email.setSSLOnConnect(true);
    email.setFrom(account);
    email.setSubject(subject)
    email.setMsg(message);
    email.addTo("ma.jinglong@puscene.com");
    email.addTo("sui.wenrong@puscene.com");
    email.addTo("zhou.jixiang@puscene.com");
    email.addTo("c_wx_push@puscene.com");
    email.addTo("liu.feiqiang@puscene.com")
//    email.addTo("li.tao@puscene.com");
    email.send();
 
  }
}
