package com.gnow

import java.util.concurrent.{ExecutorService, Executors}

import com.gnow.config.SaveMode
import com.gnow.eraser.DBEraser
import com.gnow.persistence.RDBWriter
import com.gnow.schema.{rdb, repository}
import org.apache.spark.SparkContext
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.slf4j.LoggerFactory

object Test {
  val logger = LoggerFactory.getLogger("9now")
  var df: DataFrame = null;
  var count: Long = 0;

  def main(): Unit = {
    //Mail.send("subject", "body")
    //fnQueueingWaitingTime();
    //tmp();
    //fnConnection();
    retention()
  }

  class ThreadDemo(threadName: String) extends Runnable {
    override def run() {
      val sql =
        """
          |delete
          |from apply_sign
          |where create_date='%s'
        """.stripMargin
      logger.info(s"thread :$threadName start...")
      DBEraser.remove(DB.ORACLE_37_BWSWD, sql.format("2016-09-01"))
      logger.info(s"thread:$threadName end.")
    }
  }

  def fnConnection(): Unit = {
    val threadPool: ExecutorService = Executors.newFixedThreadPool(5)
    try {
      for (i <- 1 to 100) {
        threadPool.execute(new ThreadDemo("thread" + i))
      }
    } finally {
      threadPool.shutdown()
    }

  }

  def fnQueueingWaitingTime(): Unit = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    rdb.queueing.df(rdb.queueing.QUEUEING_TABLE)
    repository.kafka.df(repository.kafka.QUEUEING_WAITING_TIME)
    val sql =
      """
        |select distinct
        |t1.shop_id,
        |t2.estimated_time,
        |abs(t2.estimated_time - ceil(unix_timestamp(t1.last_time) - unix_timestamp(t1.create_date))) abs_delta_time
        |from %s t1 join %s t2 on (
        |    t1.shop_id = t2.shop_id
        |)
        |where t2.estimated_time > -1 and t2.estimated_time <= 7200
      """.stripMargin
    val queueingWaitingTimeExtDF = sqlContext.sql(sql.format(
      rdb.queueing.QUEUEING_TABLE,
      repository.kafka.QUEUEING_WAITING_TIME))
    val QUEUEING_WAITING_TIME_EXT = "queueing_waiting_time_ext"
    queueingWaitingTimeExtDF.registerTempTable(QUEUEING_WAITING_TIME_EXT)
    val countSQL =
      """
        |select count(t1.shop_id) cnt_shop_id
        |from %s t1
      """.stripMargin
    val df = sqlContext.sql(countSQL.format(QUEUEING_WAITING_TIME_EXT))
    count = df.count()
    logger.info(s"qqqqqqqqqqqqqq:${count}")
    //RDBWriter.save(df, DB.ORACLE_37_BWSWD, "kafka_queueing_waiting_time", SaveMode.OVERWRITE)
  }

  def tmp(): Unit = {
    val sqlContext = SQLContext.getOrCreate(SparkContext.getOrCreate())
    repository.kafka.df(repository.kafka.BASIC_SHOP_SERVICE)
    val sql =
      """
        |select
        |version,
        |type_,
        |timestamp_,
        |status_,
        |shop_name,
        |date_,
        |datatype,
        |createtime,
        |create_time,
        |business,
        |action_,
        |host_,
        |level_,
        |module,
        |pid,
        |service,
        |shop_id
        |from %s t1
        |where t1.shop_id = '113812'
      """.stripMargin
    val df = sqlContext.sql(sql.format(repository.kafka.BASIC_SHOP_SERVICE))
    RDBWriter.save(df, DB.MYSQL_231_SPARK, "kafka_shop_and_service", SaveMode.OVERWRITE)
  }

  def retention():Unit = {
    val sql =
      """
        |select distinct
        |device_id as did,
        |phase_
        |from
        |basic_app_trace
        |where
        |device_type = 2
        |and
        |create_time >= unix_timestamp(concat(date_sub('%s',1),' 0:0:0'))
        |and
        |create_time < unix_timestamp(concat('%s',' 0:0:0'))
      """.stripMargin

    val targetDate = "2016-08-31"
    val df = repository.kafka.df4TodayAndPrevious(repository.kafka.BASIC_APP_TRACE, targetDate)
    val res = Utility.sql(df, sql.format(targetDate, targetDate))
    RDBWriter.overwrite(res, DB.MYSQL_231_SPARK, "retention")
  }
}

