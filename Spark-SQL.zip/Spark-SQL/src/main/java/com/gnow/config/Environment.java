package com.gnow.config;

public enum Environment {
    SNAPSHOT, PRODUCT
}
