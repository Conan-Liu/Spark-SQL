package com.gnow.config;

public enum FileFormat {
    JSON, PARQUET
}
