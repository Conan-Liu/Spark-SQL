package com.gnow.config;

public class Ordinal {
    public static String convert(int number) {
        String tail = null;
        if (number <= 0) {
            return "number must > 0";
        } else if (1 == number) {
            return "first";
        } else if (2 == number) {
            return "second";
        } else if (number >= 20) {
            int last = number % 10;
            if (1 == last) {
                tail = "st";
            } else if (2 == last) {
                tail = "nd";
            } else if (3 == last) {
                tail = "rd";
            } else {
                tail = "th";
            }
        } else {
            tail = "th";
        }
        return number + tail;
    }

}
