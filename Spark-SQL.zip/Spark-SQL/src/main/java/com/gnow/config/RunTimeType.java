package com.gnow.config;

public enum RunTimeType {
    YESTERDAY, ANYDAY
}
