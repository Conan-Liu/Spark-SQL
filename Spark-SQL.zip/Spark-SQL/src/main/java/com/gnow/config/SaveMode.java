package com.gnow.config;

public enum SaveMode {
    OVERWRITE, APPEND
}
