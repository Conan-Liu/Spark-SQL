package com.gnow.config;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class ApplicationContext {
    public Config config;

    public ApplicationContext(Config config) {
        this.config = config;
        config.checkValid(ConfigFactory.defaultReference());
    }

    public ApplicationContext() {
        this(ConfigFactory.load());
    }
}