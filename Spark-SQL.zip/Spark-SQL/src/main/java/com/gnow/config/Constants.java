package com.gnow.config;

public class Constants {
    public static String SPARK_SQL_ENVIRONMENT = "spark.sql.environment";
    public static String RDB = "rdb";
    public static String REPOSITORY = "repository";
    public static String CRAWLER = "crawler";

    public static String REPOSITORY_HOME = String.format("/%s", REPOSITORY);
    public static String REPOSITORY_KAFKA_HOME = String.format("%s/kafka", REPOSITORY_HOME);
    public static String REPOSITORY_TRANSFORM_HOME = String.format("%s/transform", REPOSITORY_HOME);
    public static String RDB_HOME = String.format("/%s", RDB);
    public static String CRAWLER_HOME = String.format("/%s", CRAWLER);

    public static String BUSINESS = "business";
    public static String MATCHED = "matched";
    public static String YYYY_MM_DD = "yyyy-MM-dd";
}
