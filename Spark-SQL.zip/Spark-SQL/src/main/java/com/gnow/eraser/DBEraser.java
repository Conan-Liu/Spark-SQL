package com.gnow.eraser;

import com.gnow.DB;
import com.gnow.Mail;
import com.gnow.config.Ordinal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBEraser {
    private static Logger logger = LoggerFactory.getLogger("9now");
    private static Integer MAX_TRIES = 5;
    private static Integer SLEEP_TIME = 1000 * 3;
    private static String TEMPLATE = "try to connect database %s for the %s time.";


    private static Connection getConnection(DB db) {
        Connection connection = null;
        try {
            connection = attempt(db);
        } catch (InterruptedException e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            logger.error(sw.toString());
            String subject = String.format(e.getMessage());
            Mail.send(subject, sw.toString());
            e.printStackTrace();
        }
        return connection;
    }

    private static Connection attempt(DB db) throws InterruptedException {
        Connection connection = null;
        for (int i = 1; i <= MAX_TRIES; i++) {
            try {
                logger.info(String.format(TEMPLATE, db.toString(), Ordinal.convert(i)));
                connection = connnect(db);
                break;
            } catch (SQLException e) {
                if (i != MAX_TRIES) {
                    Thread.sleep(SLEEP_TIME);
                    continue;
                } else {
                    StringWriter sw = new StringWriter();
                    PrintWriter pw = new PrintWriter(sw);
                    e.printStackTrace(pw);
                    logger.error(sw.toString());
                    String subject = String.format(e.getMessage());
                    Mail.send(subject, sw.toString());
                    e.printStackTrace();
                }
            }
        }
        return connection;
    }

    private static Connection connnect(DB db) throws SQLException {
        String driver = db.driver;
        String url = db.url;
        String username = db.user;
        String password = db.password;
        Connection connection = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            logger.error(sw.toString());
            String subject = String.format(e.getMessage());
            Mail.send(subject, sw.toString());
            e.printStackTrace();
        }
        return connection;
    }

    public static void remove(DB db, String sql) {
        DB runtimeDB = DB.getRuntimeDB(db);
        Connection conn = getConnection(runtimeDB);
        try {
            conn.setAutoCommit(true);
            Statement statement = conn.createStatement();
            if (runtimeDB.toString().startsWith("MYSQL")) {
                statement.addBatch("SET SQL_SAFE_UPDATES = 0;");
            }
            statement.addBatch(sql);
            if (runtimeDB.toString().startsWith("MYSQL")) {
                statement.addBatch("SET SQL_SAFE_UPDATES = 1;");
            }
            statement.executeBatch();
            statement.close();
            conn.close();
        } catch (SQLException e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            logger.error(sw.toString());
            String subject = String.format(e.getMessage());
            Mail.send(subject, sw.toString());
            e.printStackTrace();
        }
    }

    public static void insert(DB db, String sql) {
        DB runtimeDB = DB.getRuntimeDB(db);
        Connection conn = getConnection(runtimeDB);
        try {
            conn.setAutoCommit(true);
            Statement statement = conn.createStatement();
            if (runtimeDB.toString().startsWith("MYSQL")) {
                statement.addBatch("SET SQL_SAFE_UPDATES = 0;");
            }
            statement.addBatch(sql);
            if (runtimeDB.toString().startsWith("MYSQL")) {
                statement.addBatch("SET SQL_SAFE_UPDATES = 1;");
            }
            statement.executeBatch();
            statement.close();
            conn.close();
        } catch (SQLException e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            logger.error(sw.toString());
            logger.error(sql);
            String subject = String.format(e.getMessage());
//            Mail.send(subject, sw.toString());
            e.printStackTrace();
        }
    }
}
