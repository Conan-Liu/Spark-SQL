package com.gnow.transform.whsh;

/**
 * Created by whsh on 16/6/30.
 */

import com.gnow.transform.bean.TransformBean;

import java.util.*;


public class KeySort {
    public static ArrayList<TransformBean> list = new ArrayList<TransformBean>();

    public static List<TransformBean> sort() {


        // Collections.sort(list); //没有默认比较器，不能排序  
        System.out.println("数组序列中的元素:");
        myprint(list);
        System.out.println("比较的过程:");
        Collections.sort(list, new KeySort.MyComparator()); // 排序
        System.out.println("排序:");
        myprint(list);

        return list;
    }


    public static void myprint(ArrayList<TransformBean> list) {
        Iterator it = list.iterator();
        while (it.hasNext()) {
            System.out.println("\t" + it.next());
        }
    }

    static class MyComparator implements Comparator {

        public int compare(Object object1, Object object2) {
            TransformBean p1 = (TransformBean) object1;
            TransformBean p2 = (TransformBean) object2;
            if (p1.getValues().size() == 0 && p2.getValues().size() == 0) {
                System.out.println(p1 + "=" + p2 + " by size");
                return 0;
            } else if (p1.getValues().size() == 0 && p2.getValues().size() > 0) {
                System.out.println(p1 + "<" + p2 + " by size");
                return -1;
            } else if (p1.getValues().size() > 0 && p2.getValues().size() == 0) {
                System.out.println(p1 + ">" + p2 + " by size");
                return 1;
            } else {
                if (p1.getValues().contains(p2.getKey())) {
                    System.out.println(p1 + ">" + p2 + " by value");
                    return 1;
                } else if (p2.getValues().contains(p1.getKey())) {
                    System.out.println(p1 + "<" + p2 + " by value");
                    return -1;
                } else {
                    Iterator it = p1.getValues().iterator();
                    int res = 0;
                    while (it.hasNext()) {
                        int i;
                        String tmp = it.next().toString();
                        for (i = 0; i < list.size(); i++) {
                            System.out.println("list.get(" + i + ").getKey() = " + list.get(i).getKey() + ", its.toString() = " + tmp);
                            if (list.get(i).getKey() == tmp) {
                                res = compare(list.get(i), p2);
                                System.out.println("compare " + list.get(i) + " and " + p2 + " in loop 1");
                                if (res != 0)
                                    break;
                            }
                        }
                        if (i < list.size())
                            break;
                    }
                    if (res != 0) {
                        if (res > 0)
                            System.out.println(p1 + " compare to " + p2 + " in loop 1 end with >");
                        else
                            System.out.println(p1 + " compare to " + p2 + " in loop 1 end with <");
                        return res;
                    } else {
                        Iterator its = p2.getValues().iterator();
                        int res1 = 0;
                        while (its.hasNext()) {
                            int j;
                            String tmp = its.next().toString();
                            for (j = 0; j < list.size(); j++) {
                                System.out.println("list.get(" + j + ").getKey() = " + list.get(j).getKey() + ", its.toString() = " + tmp);
                                if (list.get(j).getKey() == tmp) {
                                    res1 = compare(p1, list.get(j));
                                    System.out.println("compare " + p1 + " and " + list.get(j) + " in loop 2");
                                    if (res1 != 0)
                                        break;
                                }
                            }
                            if (j < list.size())
                                break;
                        }
                        if (res1 > 0)
                            System.out.println(p1 + " compare to " + p2 + " in loop 2 end with >");
                        else if (res1 < 0)
                            System.out.println(p1 + " compare to " + p2 + " in loop 2 end with <");
                        else
                            System.out.println(p1 + " compare to " + p2 + " in loop 2      end with =");
                        return res1;

                    }
                }
            }
        }
    }

}
