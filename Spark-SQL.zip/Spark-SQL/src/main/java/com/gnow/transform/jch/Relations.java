package com.gnow.transform.jch;


import com.gnow.transform.bean.Relation;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Relations {
    public static Set<Relation> HOLDER = new HashSet<Relation>();

    static {
        HOLDER.add(new Relation("t1", "t11"));
        HOLDER.add(new Relation("t0", "t01"));
        HOLDER.add(new Relation("t1", "t12"));
        HOLDER.add(new Relation("t11", "t111"));
        HOLDER.add(new Relation("t12", "t121"));
        HOLDER.add(new Relation("t12", "t122"));
        HOLDER.add(new Relation("t13", "t99"));
    }

    public static Set<String> getApprentices(String master) {
        Set<String> rtn = new HashSet<>();
        Iterator<Relation> it = HOLDER.iterator();
        while (it.hasNext()) {
            Relation relation = it.next();
            if (master.equals(relation.getMaster())) {
                String apprentice = relation.getApprentice();
                rtn.add(apprentice);
            }
        }
        return rtn;
    }

    public static Set<String> getBornMasters() {
        Set<String> rtn = new HashSet<>();
        Iterator<Relation> it = HOLDER.iterator();
        while (it.hasNext()) {
            Relation relation = it.next();
            String master = relation.getMaster();
            Boolean isApprentice = isApprentice(master);
            if (!isApprentice) {
                rtn.add(master);
            }
        }
        return rtn;
    }

    private static Boolean isApprentice(String id) {
        Boolean rtn = false;
        Iterator<Relation> it = HOLDER.iterator();
        while (it.hasNext()) {
            Relation relation = it.next();
            if (relation.getApprentice().equals(id)) {
                rtn = true;
                break;
            }
        }
        return rtn;
    }
}
