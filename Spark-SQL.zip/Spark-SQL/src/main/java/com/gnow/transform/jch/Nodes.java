package com.gnow.transform.jch;

import com.gnow.transform.bean.Node;
import com.gnow.transform.bean.Relation;
import com.gnow.transform.bean.SortableTransformBean;

import java.util.*;

public class Nodes {
    private static String R00T = "R00T";
    private static String NULLTransform = "NULLTransform";
    public static Node ROOT = new Node(R00T);


    public static void init(Set<String> bornMasters) {
        Iterator<String> it = bornMasters.iterator();
        while (it.hasNext()) {
            String bornMaster = it.next();
            Node node = new Node(bornMaster);
            node.setMaster(ROOT);
            ROOT.getApprentices().add(node);
        }
    }

    public static void walk(Node node) {
        Set<Node> apprentices = node.getApprentices();
        Iterator<Node> it = apprentices.iterator();
        while (it.hasNext()) {
            Node apprentice = it.next();
            if (apprentice.getApprentices().isEmpty()) {
                Set<String> subApprentices = Relations.getApprentices(apprentice.getId());
                build(apprentice, subApprentices);
                walk(apprentice);
            }
        }
    }

    public static void build(Node master, Set<String> apprentices) {
        Iterator<String> it = apprentices.iterator();
        while (it.hasNext()) {
            String apprentice = it.next();
            Node node = new Node(apprentice);
            node.setMaster(master);
            master.getApprentices().add(node);
        }
    }

    public static Node build(Set<Relation> relations) {
        Relations.HOLDER.clear();
        Relations.HOLDER.addAll(relations);
        Set<String> bornMasters = Relations.getBornMasters();
        Nodes.init(bornMasters);
        Nodes.walk(ROOT);
        return ROOT;
    }

    public static void walk4stack(List<SortableTransformBean> holder, Node node, int depth) {
        Set<Node> apprentices = node.getApprentices();
        holder.add(new SortableTransformBean(node.getId(), depth));
        Iterator<Node> it = apprentices.iterator();
        depth++;
        while (it.hasNext()) {
            Node apprentice = it.next();
            walk4stack(holder, apprentice, depth);
        }
    }

    public static List<String> output() {
        List<String> rtn = new ArrayList<String>();
        List<SortableTransformBean> holder = new ArrayList<SortableTransformBean>();
        walk4stack(holder, ROOT, 0);
        Collections.sort(holder);
        for (int i = 0; i < holder.size(); i++) {
            SortableTransformBean sortableTransformBean = holder.get(i);
            String transform = sortableTransformBean.getTransform();
            if (!rtn.contains(transform)
                    && !R00T.equals(transform)
                    && !NULLTransform.equals(transform)) {
                rtn.add(transform);
            }
        }
        return rtn;
    }

    public static void main(String[] args) {
        Set<String> bornMasters = Relations.getBornMasters();
        Nodes.init(bornMasters);
        Nodes.walk(ROOT);
        System.out.println("end.");
    }
}
