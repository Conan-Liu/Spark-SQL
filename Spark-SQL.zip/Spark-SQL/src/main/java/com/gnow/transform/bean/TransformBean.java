package com.gnow.transform.bean;

import java.util.HashSet;
import java.util.Set;

public class TransformBean {
    private String key;
    private Set<String> values = new HashSet<String>();

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Set<String> getValues() {
        return values;
    }

    public String toString() {
        String showStr = getKey();
        return showStr;
    }

}


