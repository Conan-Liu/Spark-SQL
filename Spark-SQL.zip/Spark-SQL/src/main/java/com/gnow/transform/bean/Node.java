package com.gnow.transform.bean;

import java.util.HashSet;
import java.util.Set;

public class Node {
    private String id;
    private Node master;
    private Set<Node> apprentices = new HashSet<Node>();

    public Node(String id){
        this.id = id;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Node getMaster() {
        return master;
    }

    public void setMaster(Node master) {
        this.master = master;
    }

    public Set<Node> getApprentices() {
        return apprentices;
    }

    public void setApprentices(Set<Node> apprentices) {
        this.apprentices = apprentices;
    }
}
