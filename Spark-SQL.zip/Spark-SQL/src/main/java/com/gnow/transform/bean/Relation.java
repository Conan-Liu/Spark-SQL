package com.gnow.transform.bean;

public class Relation {
    private String master;
    private String apprentice;

    public Relation(String master, String apprentice){
        this.master = master;
        this.apprentice = apprentice;
    }
    public String getMaster() {
        return master;
    }

    public void setMaster(String master) {
        this.master = master;
    }

    public String getApprentice() {
        return apprentice;
    }

    public void setApprentice(String apprentice) {
        this.apprentice = apprentice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Relation relation = (Relation) o;

        if (!master.equals(relation.master)) return false;
        return apprentice.equals(relation.apprentice);

    }

    @Override
    public int hashCode() {
        int result = master.hashCode();
        result = 31 * result + apprentice.hashCode();
        return result;
    }
}
