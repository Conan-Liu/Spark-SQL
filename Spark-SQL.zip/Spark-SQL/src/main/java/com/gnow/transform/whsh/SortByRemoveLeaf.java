package com.gnow.transform.whsh;

/**
 * Created by whsh on 16/6/30.
 */

import com.gnow.transform.bean.TransformBean;

import java.util.ArrayList;
import java.util.Iterator;

class Prepare {
    public String key;
    public ArrayList<String> depends = new ArrayList<>();
};

public class SortByRemoveLeaf {

    public static ArrayList<Prepare> add(TransformBean t, ArrayList<Prepare> res) {
        //System.out.println("res.size() in  = " + res.size());
        Prepare tmp = new Prepare();
        tmp.key = t.getKey();
        tmp.depends.addAll(t.getValues());
        if (res.size() == 0) {
            res.add(tmp);
        } else {
            int i;
            for (i = 0; i < res.size(); i++) {
                if (res.get(i).key.equals(tmp.key))
                    break;
            }
            if (i == res.size()) {
                res.add(tmp);
            }
        }
        //System.out.println("res.size() out  = " + res.size());
        return res;
    }

    public static ArrayList<Prepare> add(Prepare tmp, ArrayList<Prepare> res) {
        //System.out.println("res.size() in  = " + res.size());
        if (res.size() == 0) {
            res.add(tmp);
        } else {
            int i;
            for (i = 0; i < res.size(); i++) {
                if (res.get(i).key.equals(tmp.key))
                    break;
            }
            if (i == res.size()) {
                res.add(tmp);
            }
        }
        //System.out.println("res.size() out  = " + res.size());
        return res;
    }

    public static ArrayList<Prepare> prepare(ArrayList<TransformBean> list) {
        ArrayList<Prepare> res = new ArrayList<>();
        Prepare leaf = new Prepare();

        for (int i = 0; i < list.size(); i++) {
            res = add(list.get(i), res);
            //System.out.println("list.get("+i+").getKey() = " + list.get(i).getKey() + " is put into ArrayList<Prepare> res");
            if (list.get(i).getValues().size() == 0) {
                //System.out.println(list.get(i).getKey() + " is a leaf, now put it in ArrayList<Prepare> res");
            } else {
                Iterator it = list.get(i).getValues().iterator();
                while (it.hasNext()) {
                    String tmpkey = it.next().toString();
                    //System.out.println("i = " + i + ", tmpkey = "+tmpkey);
                    int j;
                    for (j = 0; j < list.size(); j++) {
                        //System.out.println("In for loop list.get("+j+").getKey() = " + list.get(j).getKey());
                        if (list.get(j).getKey().equals(tmpkey)) {
                            res = add(list.get(j), res);
                            break;
                        }
                    }
                    if (j == list.size()) {
                        leaf.key = tmpkey;
                        //System.out.println(tmpkey + " is a leaf, now put it in ArrayList<Prepare> res");
                        leaf.depends.clear();
                        res = add(leaf, res);
                    }
                }
            }

        }

        return res;
    }

    public static ArrayList<String> output(ArrayList<Prepare> res) {
        ArrayList<String> out = new ArrayList<String>();
        if (res.size() == 0) {
            System.out.println("res is empty");
            out.clear();
            return out;
        }
        int i = 0;
        while (res.size() > 0) {
            //System.out.println("i = "+ i);
            if (res.get(i).depends.size() == 0) {
                System.out.println(res.get(i).key + "now is a leaf, output and remove from his father!");
                out.add(res.get(i).key);
                for (int j = 0; j < res.size(); j++) {
                    if (res.get(j).depends.contains(res.get(i).key)) {
                        res.get(j).depends.remove(res.get(j).depends.indexOf(res.get(i).key));
                    }
                }
                res.remove(i);
                i = 0;
            } else {
                i = (i + 1) % res.size();
            }
        }
        return out;
    }

    public static ArrayList<String> sortnew(ArrayList<TransformBean> list) {

        System.out.println("list.size() = " + list.size());
        ArrayList<Prepare> res = prepare(list);
        System.out.println("res.size() = " + res.size());
        ArrayList<String> out = output(res);
        System.out.println("output.size() = " + out.size());

        return out;
    }

}
