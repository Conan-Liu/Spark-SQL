package com.gnow.transform.bean;

public class SortableTransformBean implements Comparable {
    private String transform;
    private Integer depth;

    public SortableTransformBean(String transform, Integer depth) {
        this.transform = transform;
        this.depth = depth;
    }

    public String getTransform() {
        return transform;
    }

    public void setTransform(String transform) {
        this.transform = transform;
    }

    public Integer getDepth() {
        return depth;
    }

    public void setDepth(Integer depth) {
        this.depth = depth;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SortableTransformBean that = (SortableTransformBean) o;

        if (!transform.equals(that.transform)) return false;
        return depth.equals(that.depth);

    }

    @Override
    public int hashCode() {
        int result = transform.hashCode();
        result = 31 * result + depth.hashCode();
        return result;
    }

    @Override
    public int compareTo(Object o) {
        SortableTransformBean that = (SortableTransformBean) o;
        Integer depth = that.depth;
        String transform = that.transform;
        Integer rtn = -1 * this.depth.compareTo(depth);
        if (rtn == 0) {
            rtn = this.transform.compareTo(transform);
        }
        return rtn;
    }
}
